# Annexe — Archivage à froid (optionnel) : plateforme S3 interne d'objet et d'archivage

- **Rôle :** complément **optionnel** pour l'archivage à froid de **copies d'exports**. Le stockage objet du chemin chaud de Mimir, Loki et Tempo est **MinIO distribué** ([ADR-002](../adr/ADR-002_Stockage_objet.md), [Annexe MinIO](Annexe_Stockage_objet_S3_MinIO.md)).
- **Variables :** `ARCHIVE_S3_FQDN`, `ARCHIVE_S3_ENDPOINT`, `ARCHIVE_S3_CA_FILE`, `ARCHIVE_S3_BUCKET` dans [`variables/environnements.env`](../../variables/environnements.env) (**modifier ici seulement** ; FQDN d'exemple fictifs).
- **Lié à :** [checklist](Checklist_decision_stockage_objet.md) §3, annexes D des runbooks.
- **État :** procédures rédigées **côté consommateur**. L'administration de la plateforme reste à l'équipe stockage. Le **produit sous-jacent n'est pas nommé** dans l'offre : **ne pas affirmer** qu'il s'agit d'un HCP. Les mises en garde HCP / VSP One Object (§4–§5) s'appliquent **si** ce produit est confirmé. **Non testé** dans ce dépôt.
- **Sources Hitachi :** [protocoles d'accès aux espaces de noms HCP](https://docs.hitachivantara.com/r/en-us/mk-95hcph001/latest/administering-hcp/introduction-to-hitachi-content-platform/about-the-hitachi-content-platform/data-access-methods/namespace-access-protocols), [URL d'accès HCP (API S3)](https://docs.hitachivantara.com/r/en-us/mk-95hcph001-20/using-the-hitachi-api-for-amazon-s3/access-and-authentication/urls-for-access-to-hcp), [URL avec authentification HCP](https://docs.hitachivantara.com/r/en-us/mk-95hcph001-20/using-the-hitachi-api-for-amazon-s3/alternative-authentication-method/urls-with-hcp-authentication), [matrice de prise en charge de l'API S3 HCP](https://docs.hitachivantara.com/r/en-us/mk-95hcph002/latest/hcp-management-api-reference/introduction-to-the-hcp-management-api/support-for-the-amazon-s3-api), [suppression de plusieurs objets](https://docs.hitachivantara.com/r/en-us/mk-95hcph002/latest/using-the-hitachi-api-for-amazon-s3/working-with-objects/deleting-multiple-objects), [API S3 VSP One Object](https://docs.hitachivantara.com/r/en-us/mk-24vsp1ob000/latest/overview-of-vsp-one-object/support-for-the-amazon-s3-api), [Data Migrator to Cloud (HNAS)](https://docs.hitachivantara.com/r/en-us/mk-92hnas005-36/using-data-migrator-to-cloud/data-migrator-to-cloud-overview)

## 1. Offre de service

Offre transcrite de la documentation interne de l'équipe stockage : **« création de compartiment (bucket) sur la plateforme de stockage d'objet et d'archivage »**. Contenu, sans ajout :

- destinée à une clientèle utilisant les fonctionnalités avancées du stockage d'objet **ne requérant pas** de traitement intensif avec **modification fréquente** de la donnée ;
- options : gestion automatisée de **rétention** avant destruction, mise en suspens juridique (**legal hold**), **WORM** ;
- inclus : compartiment avec **accès S3 (HTTPS)** ; compartiment avec autres types d'accès (**justification requise**) ;
- exclus : **données personnelles**, **traitement intensif**, **modification fréquente** de la donnée ;
- requis : demande d'accès **Inf-360** préalable ;
- accord de service : lundi–vendredi **8 h 30–16 h 30** ; délai **5 jours ouvrables** en mode standard, **2 jours ou moins** en urgent (urgent = risque sur la disponibilité ou la stabilité des services, ou faire évoluer des solutions d'affaires).

**Pourquoi l'archivage à froid seulement.** Le chemin chaud LGTM (écritures continues, compactage, suppressions, rétention gérée par l'application, journaux contenant des données personnelles) relève des exclusions de l'offre, et les options WORM / legal hold / rétention automatisée empêcheraient le compactage. Il est donc porté par MinIO (ADR-002). En revanche, déposer des **copies d'exports** une fois, puis les conserver sans les modifier, correspond à la destination de l'offre ; les options WORM, legal hold et rétention y sont utilisables.

## 2. Périmètre des exports

- **Admis (à confirmer avec l'équipe stockage) :** copies d'exports **sans données personnelles**, déposées puis conservées sans modification (par exemple exports de configuration, de tableaux de bord, ou d'agrégats de métriques). Le choix exact des exports est **à définir** par l'exploitation.
- **Exclus par l'offre :** les données personnelles. Les journaux (Loki, Elasticsearch) contiennent potentiellement des noms d'utilisateur et des adresses IP : ne pas les exporter vers cette plateforme, sauf filtrage en amont (processeurs OpenTelemetry, avant écriture) **ou** accord écrit de l'équipe stockage. Les sauvegardes PostgreSQL Grafana contiennent des comptes utilisateurs : même règle. **À convenir.**
- **Hors périmètre :** le chemin chaud (blocs Mimir, Loki, Tempo), qui reste sur MinIO, et la sauvegarde opérationnelle `mc mirror` du cluster MinIO (cible distincte, Annexe MinIO §3.6).

## 3. Procédure de demande (mode standard, avec justification)

L'équipe LGTM **consomme** le service. **Ne pas inventer** de champs de formulaire au-delà de ce que l'offre indique. **Non testé.**

1. **Demande d'accès Inf-360** (préalable obligatoire de l'offre), selon le circuit de l'organisation. Attendre l'accord.
2. **Demande de création de compartiment** sur la « plateforme de stockage d'objet et d'archivage », en **mode standard** (l'archivage à froid ne répond pas aux critères d'urgence de l'offre).
3. **Justification** écrite : archivage à froid de copies d'exports de la plateforme d'observabilité ; accès **S3 HTTPS** (inclus dans l'offre ; aucun autre type d'accès requis) ; volumes et fréquence estimés ; absence de données personnelles (ou traitement convenu) ; options de rétention / legal hold / WORM souhaitées selon la politique de conservation de l'organisation (**à définir**).
4. Planifier **5 jours ouvrables** après la demande de compartiment (horaires lun–ven 8 h 30–16 h 30). Ce délai ne conditionne pas la mise en service LGTM.

### Paramètres à exiger

| Paramètre | Attendu |
|---|---|
| Produit et version de la plateforme | À confirmer. Ne pas présumer un HCP. |
| **Endpoint HTTPS** (FQDN, port) et **CA émettrice** (PEM, SAN = FQDN utilisé) | `ARCHIVE_S3_FQDN`, `ARCHIVE_S3_ENDPOINT`, `ARCHIVE_S3_CA_FILE` ; vérification TLS active. |
| Compartiment dédié | `ARCHIVE_S3_BUCKET` (exemple `lgtm-archive-exports`), un par environnement si la politique l'exige. |
| Options de conservation | Rétention automatisée (durée), legal hold, WORM : **à définir** selon la politique de l'organisation. |
| Opérations | Écriture, listage, **multipart** pour les gros exports, **URL présignées** si besoin de restauration ponctuelle, adressage path-style ou *virtual-hosted*. À confirmer. |
| Quotas et limites | Capacité, débit, req/s, nombre d'objets. |
| Compte de service | Moindre privilège sur ce seau, clés remises hors bande (fichier `0600`), rotation. |
| Données personnelles | Exclues par l'offre ; filtrage amont ou accord écrit. |

## 4. Si le produit s'avère être un HCP — formes d'URL documentées

Applicable **seulement si** l'équipe stockage confirme un **Hitachi Content Platform (HCP)** avec *Hitachi API for Amazon S3* (HS3). Hitachi documente : « With the S3-compatible API, namespaces are called buckets. » Le **point de service** est un **tenant**.

**Authentification HCP** (identifiant d'interface `hs3`, en minuscules) :

- Tenant : `https://<tenant>.<domaine-hcp>/hs3`
- Seau *virtual-hosted* : `https://<seau>.<tenant>.<domaine-hcp>/hs3` ; *path-style* : `https://<tenant>.<domaine-hcp>/hs3/<seau>`

**Authentification AWS** (Signature Version 4 ou 2, toutes deux prises en charge d'après la matrice HCP) :

> Note officielle Hitachi : **« Do not use the hs3 interface identifier when using AWS authentication. »**

`aws` et `mc` signent en AWS (v4) : **ne pas** placer `/hs3` dans `ARCHIVE_S3_ENDPOINT`. Endpoint de la forme `https://<tenant>.<domaine-hcp>` ; nom de seau = nom de l'espace de noms. Le *virtual-hosted* exige un DNS (souvent joker `*.<tenant>.<domaine-hcp>`) et un SAN adaptés ; à défaut, *path-style*.

**VSP One Object :** API Amazon S3 selon la matrice Hitachi. FQDN, style d'adressage et région éventuelle à **demander à l'équipe stockage** pour la version déployée.

## 5. Points de vigilance (matrices officielles Hitachi) — ne rien inventer

Aucune certification croisée n'a été trouvée : **qualifier en préproduction** avec les outils d'export retenus.

| Opération S3 | HCP (matrice officielle) | VSP One Object (matrice officielle) | Conséquence pour l'archivage |
|---|---|---|---|
| Listage (v1 et ListObjectsV2) | **Supported** | **Fully supported** | Inventaire des archives. |
| **DeleteObjects** | **Supported**, avec **limites** : pas de suppression par cette méthode d'objets **sous rétention**, **sous hold**, de *delete markers*, ni de **plusieurs versions** ([doc](https://docs.hitachivantara.com/r/en-us/mk-95hcph002/latest/using-the-hitachi-api-for-amazon-s3/working-with-objects/deleting-multiple-objects)) | **Fully supported** | Attendu pour des archives sous rétention / WORM : les objets ne sont pas supprimables avant échéance. C'est précisément ce qui exclut cette plateforme du chemin chaud (compactage). |
| **Multipart** | Documenté ; **List Multipart Uploads : Supported** | **Fully supported** (`CreateMultipartUpload`, `UploadPart`, `CompleteMultipartUpload`, `AbortMultipartUpload`, `ListParts`, `ListMultipartUploads`) | Gros exports. Qualifier les tailles réelles. |
| Versioning | **Supported** | `ListObjectVersions` : **Fully supported** | À convenir avec l'équipe stockage. |
| Cycle de vie S3 (`PUT/GET Bucket lifecycle`) | **Not supported** | À confirmer sur la matrice de la version | La rétention se règle par les options de l'offre (rétention automatisée), pas par une règle de cycle de vie S3. |
| Politique de seau (`PUT Bucket policy`) | **Not supported** | À confirmer | S'appuyer sur les comptes et ACL du produit. |

Autres écarts VSP One Object documentés : certaines opérations ne sont **pas** prises en charge (`GetObjectAcl`, `PutObjectAcl`, `RestoreObject`, etc.) ; `GetObject` sans en-têtes conditionnels ni `partNumber` ; `PutObject` : ETag non entouré de guillemets. **À confirmer** avec l'outil d'export.

## 6. Dépôt et tests (sans secret en ligne de commande)

**Non testé.** Identifiants dans un fichier `0600` (`AWS_SHARED_CREDENTIALS_FILE`, ou configuration `mc` en `0600`). Jamais de secret en argument, jamais `echo` du secret. CA via `--ca-bundle` / équivalent, pas `--no-verify`.

```
# Exemples — NON TESTÉ — valeurs issues de variables/environnements.env
export AWS_SHARED_CREDENTIALS_FILE=/etc/lgtm/archive-s3.credentials   # 0600
export AWS_CONFIG_FILE=/etc/lgtm/archive-s3.config

aws --endpoint-url "${ARCHIVE_S3_ENDPOINT}" --ca-bundle "${ARCHIVE_S3_CA_FILE}" \
    s3 ls "s3://${ARCHIVE_S3_BUCKET}/"

# Dépôt d'un export (fichier déjà produit et vérifié, sans données personnelles)
aws --endpoint-url "${ARCHIVE_S3_ENDPOINT}" --ca-bundle "${ARCHIVE_S3_CA_FILE}" \
    s3 cp /var/lib/lgtm/exports/export-AAAAMMJJ.tar.gz \
    "s3://${ARCHIVE_S3_BUCKET}/exports/export-AAAAMMJJ.tar.gz"

# Variante mc (alias défini au préalable par fichier 0600). Copie d'un préfixe
# d'exports du seau MinIO lgtm-admin vers l'archive, sans --remove ni --overwrite
# (options à vérifier sur « mc mirror --help » de la version installée).
# mc mirror lgtm/${S3_BUCKET_ADMIN}/exports archive/${ARCHIVE_S3_BUCKET}/exports
```

Planifier le dépôt par `systemd timer` (VM) ou `CronJob` (Kubernetes), avec journalisation des échecs sans secret. Contrôler le certificat (`openssl s_client -connect ${ARCHIVE_S3_FQDN}:443 -servername ${ARCHIVE_S3_FQDN}`) et tester une **restauration** d'un export vers un répertoire de préproduction.

## 7. Supervision

L'équipe stockage conserve la supervision de la plateforme (moyens en place, **ne pas inventer** d'export Prometheus). Côté LGTM : succès / échec et durée de chaque dépôt, expiration du certificat de l'endpoint, codes 403 / 5xx. **Non testé.**

## 8. Rappel — ce qui n'est pas une cible du chemin chaud

- **Plateforme S3 interne d'objet et d'archivage** : rejetée pour le chemin chaud (exclusions de l'offre ; WORM / legal hold / rétention incompatibles avec le compactage). ADR-002.
- **HNAS seul** : protocoles NFS, SMB/CIFS, FTP, iSCSI ; pas d'API S3 serveur. **Data Migrator to Cloud** est un **client** S3 qui envoie des données depuis HNAS vers une cible objet.
- **NFS / système de fichiers partagé** : rejeté par la documentation Grafana Labs pour Mimir (disque local), Loki *scalable* et Tempo distribuée.

Diagrammes : [07 — MinIO, cible](../diagrammes/07_stockage_objet_minio.vsdx), [08 — archivage à froid optionnel](../diagrammes/08_stockage_objet_hitachi.vsdx).
