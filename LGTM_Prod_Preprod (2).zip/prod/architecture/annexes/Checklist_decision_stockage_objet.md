# Décision stockage objet — chemin chaud MinIO, archivage à froid optionnel

- **Lié à :** [ADR-002](../adr/ADR-002_Stockage_objet.md), [Annexe MinIO](Annexe_Stockage_objet_S3_MinIO.md), [annexe archivage à froid](Annexe_Stockage_objet_Hitachi_HCP_S3.md)
- **Variables :** [`variables/environnements.env`](../../variables/environnements.env) — **modifier ici seulement**

## 1. Décision prise

| Élément | Décision |
|---|---|
| Stockage objet du chemin chaud (Mimir, Loki, Tempo) | **MinIO distribué** — `STOCKAGE_OBJET_SCENARIO=minio` ([ADR-002](../adr/ADR-002_Stockage_objet.md), statut Accepté) |
| Prérequis bloquant | Examen de la licence **AGPLv3** (ou offre commerciale MinIO) **conclu avant toute installation** |
| Plateforme S3 interne d'objet et d'archivage | **Rejetée pour le chemin chaud** : l'offre exclut le traitement intensif, la modification fréquente de la donnée et les données personnelles ; ses options WORM, legal hold et rétention automatisée sont incompatibles avec le compactage. **Conservée** en complément optionnel pour l'**archivage à froid** des exports. |
| HNAS seul, NFS / système de fichiers partagé | **Rejetés** (pas d'API S3 serveur ; documentation Grafana Labs) |

```mermaid
flowchart TD
  H["Chemin chaud Mimir / Loki / Tempo"] --> M["MinIO distribué — cible<br/>≥ 4 nœuds, erasure coding, TLS, IAM<br/>STOCKAGE_OBJET_SCENARIO=minio"]
  L["Examen licence AGPLv3<br/>prérequis bloquant"] --> M
  M -->|"copies d'exports (optionnel)"| A["Plateforme S3 interne d'objet et d'archivage<br/>archivage à froid<br/>Inf-360 + compartiment, 5 j ouvrables"]
  P["Plateforme S3 interne<br/>comme backend du chemin chaud"] --> R["Rejeté — exclusions de l'offre"]
  N["HNAS seul / NFS"] --> R2["Rejeté"]
```

## 2. Contrôles avant installation de MinIO

| # | Contrôle | État (à remplir) |
|---|---|---|
| M1 | Examen AGPLv3 conclu par écrit (ou offre commerciale retenue) | |
| M2 | Quatre VM (ou pods) MinIO par environnement, réparties sur les trois domaines de défaillance, disques dédiés | |
| M3 | Certificat de l'autorité interne pour la VIP `S3_FQDN` et les nœuds (SAN), CA dans `S3_CA_FILE` | |
| M4 | VIP HAProxy + keepalived, flux 443/9000 ouverts depuis Mimir, Loki, Tempo (et pools Kubernetes) | |
| M5 | Seaux `S3_BUCKET_*` créés ; seaux ou préfixes distincts pour les blocs, le *ruler* et l'Alertmanager Mimir | |
| M6 | Comptes d'application par composant, politique limitée à son seau, identifiants en fichiers `0600` | |
| M7 | Sauvegarde `mc mirror` planifiée vers une cible distincte, restauration testée en préproduction | |
| M8 | Supervision MinIO et alertes en place (nœud, disque, quorum / parité, certificat, sauvegarde) | |
| M9 | Équipe d'exploitation désignée et formée (mises à jour, remplacement de disque, reprise) | |

## 3. Questions à l'équipe stockage — archivage à froid (optionnel)

À poser par écrit **seulement si** l'archivage à froid des exports est souhaité. Ne conditionne pas la mise en service.

| # | Question | Réponse (à remplir) |
|---|---|---|
| Q1 | Quel est le **produit et la version** de la plateforme S3 interne d'objet et d'archivage ? (Non nommé dans l'offre ; ne pas présumer un HCP.) | |
| Q2 | Demande d'accès **Inf-360** : circuit et délai ? Puis demande de compartiment en **mode standard** (5 jours ouvrables, horaires lun–ven 8 h 30–16 h 30). | |
| Q3 | Usage visé : dépôt de **copies d'exports** (sans traitement intensif ni modification fréquente). L'équipe stockage le confirme-t-elle conforme à l'offre ? Volumes et fréquence estimés à joindre. | |
| Q4 | Options souhaitées sur le compartiment d'archives : **rétention automatisée** avant destruction (durée), **legal hold**, **WORM** — selon la politique de conservation de l'organisation (**à définir**). | |
| Q5 | **Endpoint HTTPS** (FQDN, port) et **CA émettrice** (fichier PEM, SAN = FQDN utilisé) → `ARCHIVE_S3_FQDN`, `ARCHIVE_S3_CA_FILE`. | |
| Q6 | Opérations disponibles : écriture, listage, **multipart** (gros exports), **URL présignées** si une restauration ponctuelle en a besoin, adressage **path-style** ou *virtual-hosted*. | |
| Q7 | **Quotas et limites** (capacité, débit, req/s, nombre d'objets). | |
| Q8 | **Données personnelles** : l'offre les exclut. Les exports de journaux (noms d'utilisateur, adresses IP) sont donc à **exclure**, ou à **filtrer en amont** (processeurs OpenTelemetry), ou à déclarer si l'équipe stockage l'accepte par écrit. **À convenir.** | |
| Q9 | Compte de service dédié, moindre privilège sur le seau `ARCHIVE_S3_BUCKET`, clés remises hors bande (fichier `0600`), rotation. | |
| Q10 | Réseau : flux depuis l'hôte d'export (ou le CronJob) vers l'endpoint, pare-feu. | |

Procédure de demande et paramètres : [annexe archivage à froid](Annexe_Stockage_objet_Hitachi_HCP_S3.md). Procédures **non testées** dans ce dépôt.
