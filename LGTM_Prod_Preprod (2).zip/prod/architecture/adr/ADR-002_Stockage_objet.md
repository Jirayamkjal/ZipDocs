# ADR-002 — Stockage objet pour Mimir, Loki et Tempo

- **Statut :** Accepté
- **Date :** 2026-11-13
- **Décideurs :** architecture / exploitation / stockage
- **Procédures :** [Annexe MinIO](../annexes/Annexe_Stockage_objet_S3_MinIO.md) et annexes C des runbooks (cible) ; [annexe archivage à froid](../annexes/Annexe_Stockage_objet_Hitachi_HCP_S3.md) et annexes D des runbooks (optionnel) ; [checklist](../annexes/Checklist_decision_stockage_objet.md)

## Contexte

En mode monolithique avec disque local, Mimir, Loki et Tempo ne tolèrent pas la perte d'un nœud sans perte de données historiques. Les modes de production documentés par Grafana Labs (microservices ou simple-scalable / distributed) s'appuient sur un **stockage objet compatible S3** pour les blocs et index de long terme.

Le chemin chaud LGTM n'est pas un dépôt d'archives immuables :

- **écritures continues** de blocs (métriques, journaux, traces) tant que la plateforme ingère ;
- **compactage** : relecture, réécriture et **suppression** d'objets (`DeleteObjects` et équivalents) pour fusionner les blocs ;
- **rétention gérée par l'application** (Mimir, Loki, Tempo), qui supprime elle-même les blocs échus ;
- journaux susceptibles de contenir des **données personnelles** (noms d'utilisateur, adresses IP).

L'équipe stockage propose une offre de service, transcrite de sa documentation interne : **« création de compartiment (bucket) sur la plateforme de stockage d'objet et d'archivage »**. Contenu, sans ajout :

- destinée à une clientèle utilisant les fonctionnalités avancées du stockage d'objet **ne requérant pas** de traitement intensif avec **modification fréquente** de la donnée ;
- options : gestion automatisée de **rétention** avant destruction, mise en suspens juridique (**legal hold**), **WORM** ;
- inclus : compartiment avec **accès S3 (HTTPS)** ; compartiment avec autres types d'accès (**justification requise**) ;
- exclus : **données personnelles**, **traitement intensif**, **modification fréquente** de la donnée ;
- requis : demande d'accès **Inf-360** préalable ;
- accord de service : lundi–vendredi **8 h 30–16 h 30** ; délai **5 jours ouvrables** en mode standard, **2 jours ou moins** en urgent (risque sur la disponibilité ou la stabilité des services, ou faire évoluer des solutions d'affaires).

Le produit sous-jacent de cette plateforme n'est **pas nommé** dans l'offre (à confirmer ; ne pas affirmer qu'il s'agit d'un HCP ou d'un autre produit).

Un **HNAS** n'expose pas d'API S3 serveur (NFS, SMB, FTP, iSCSI).

## Décision

Le stockage objet du chemin chaud de Mimir, Loki et Tempo est un **MinIO distribué**, exploité par l'équipe plateforme, un cluster par environnement (préproduction, production) :

- au moins **quatre nœuds**, répartis sur les trois domaines de défaillance ;
- **erasure coding** (jeux de disques fixés à l'initialisation) ;
- **TLS** sur l'API et la console (certificat de l'autorité interne, SAN = VIP et nœuds), VIP `S3_FQDN` derrière HAProxy + keepalived ;
- **IAM** : un compte d'application par composant (`mimir-svc`, `loki-svc`, `tempo-svc`), politique limitée à **son** seau ; identifiants racine réservés à l'administration, au coffre ;
- **seaux distincts** `lgtm-mimir`, `lgtm-loki`, `lgtm-tempo`, `lgtm-admin` ; pour Mimir, seaux ou préfixes distincts pour les blocs, le *ruler* et l'Alertmanager ([exigence officielle](https://grafana.com/docs/mimir/latest/configure/configure-object-storage-backend/)) ;
- **sauvegarde** : `mc mirror` planifié vers une cible distincte, restauration testée ;
- **supervision** : métriques Prometheus documentées par MinIO pour la version installée, alertes nœud hors ligne, disque saturé, quorum / parité, certificat, échec de sauvegarde.

**Prérequis bloquant :** l'édition communautaire de MinIO est publiée sous **AGPLv3**. L'examen de cette licence par l'organisation (ou le choix d'une offre commerciale MinIO) doit être **conclu avant toute installation**, en préproduction comme en production.

Variables (**modifier ici seulement**, [`variables/environnements.env`](../../variables/environnements.env)) : `STOCKAGE_OBJET_SCENARIO=minio`, `S3_FQDN`, `S3_ENDPOINT`, `S3_CA_FILE`, `S3_FORCE_PATH_STYLE`, `S3_BUCKET_*`, `MINIOxx_FQDN`.

**Complément — archivage à froid (optionnel) :** la plateforme S3 interne d'objet et d'archivage peut recevoir des **copies d'exports** (usage conforme à l'offre : dépôt, pas de traitement intensif ni de modification fréquente). Les options WORM, legal hold et rétention automatisée y sont alors utilisables. Prérequis : demande d'accès **Inf-360**, puis demande de compartiment en **mode standard**, avec justification ; prévoir **5 jours ouvrables**. L'exclusion des **données personnelles** s'applique aussi à ces exports : n'y déposer que des exports qui n'en contiennent pas, ou après accord écrit de l'équipe stockage (**à confirmer**). Variables `ARCHIVE_S3_*`. Ce complément ne conditionne pas la mise en service.

Identifiants dans des fichiers `0600`, jamais sur la ligne de commande. Chiffrement en transit (TLS, `insecure: false`). Chiffrement au repos : selon les options de la version MinIO retenue, **à confirmer**. Procédures **non testées** dans ce dépôt.

## Options rejetées

| Option | Motif du rejet |
|---|---|
| **Plateforme S3 interne d'objet et d'archivage** comme backend du chemin chaud | L'offre de service **exclut** le traitement intensif, la modification fréquente de la donnée et les données personnelles, ce qui correspond au profil LGTM (écritures continues, compactage, suppressions, journaux contenant des noms d'utilisateur et des adresses IP). Ses options **WORM**, **legal hold** et **rétention automatisée** sont incompatibles avec le compactage et la rétention gérée par Mimir, Loki et Tempo. Conservée uniquement pour l'**archivage à froid** des exports. |
| **HNAS seul** (NFS, SMB, FTP, iSCSI) ou Data Migrator to Cloud comme « endpoint S3 » | HNAS n'expose pas d'API S3 serveur ; Data Migrator to Cloud est un **client** S3. |
| **NFS** ou système de fichiers partagé comme backend des blocs | Grafana Labs : NFS et systèmes de fichiers réseau non pris en charge pour le disque local Mimir ([hardware requirements](https://grafana.com/docs/mimir/latest/set-up/hardware-requirements/)) ; Loki *scalable* exige un stockage objet ou MinIO en production ([configure storage](https://grafana.com/docs/loki/latest/setup/install/helm/configure-storage/)) ; Tempo distribuée s'appuie sur un stockage objet ([architecture](https://grafana.com/docs/tempo/latest/reference-tempo-architecture/object-storage/)). |
| Disque local uniquement (mode laboratoire) | Pas de réplication des blocs historiques. Démonstration seulement. |

## Conséquences

- **Positives :** backend objet maîtrisé par l'équipe plateforme, sans dépendance au délai ni aux exclusions de l'offre de stockage ; nœuds Mimir / Loki / Tempo interchangeables ; rétention appliquée par chaque composant.
- **Négatives :** quatre VM (ou pods) MinIO par environnement : **26 VM en préproduction, 45 en production** (dimensionnement de référence) ; exploitation MinIO à la charge de l'équipe (mises à jour, disques, erasure coding, sauvegarde, supervision, compétences) ; prérequis licence AGPLv3 bloquant.
- **Ouvert (à confirmer) :** conclusion de l'examen AGPLv3 ou choix d'une offre commerciale ; capacité disque réelle après observation en préproduction ; chiffrement au repos ; pour l'archivage à froid : produit de la plateforme, périmètre des exports et traitement des données personnelles.
