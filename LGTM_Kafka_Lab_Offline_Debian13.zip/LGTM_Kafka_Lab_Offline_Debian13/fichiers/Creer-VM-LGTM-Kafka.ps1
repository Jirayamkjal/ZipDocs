# Creer-VM-LGTM-Kafka.ps1 - hôte Hyper-V, PowerShell en administrateur.
# Enregistrer en UTF-8 avec BOM pour Windows PowerShell 5.1 (les messages affichés sont en ASCII).
# Crée les 6 VM du lab (génération 2, mémoire dynamique, VHDX dynamique). Ne modifie PAS DC ni ELK.
$ErrorActionPreference = 'Stop'
$Switch  = '<vSwitch du lab>'                       # Get-VMSwitch
$Dossier = 'C:\Hyper-V'                             # dossier des VHDX
$Iso     = 'C:\lgtm-iso\debian-13.7.0-amd64-netinst.iso'

# Nom, vCPU, RAM démarrage / min / max, disque, délai de démarrage automatique (s)
$Vms = @(
  @{ Nom='kafka01';   Cpu=2; Dem=3GB; Min=2GB;   Max=4GB; Disque=40GB; Delai=0   }
  @{ Nom='mimir01';   Cpu=2; Dem=3GB; Min=2GB;   Max=4GB; Disque=40GB; Delai=60  }
  @{ Nom='loki01';    Cpu=2; Dem=2GB; Min=1.5GB; Max=3GB; Disque=40GB; Delai=60  }
  @{ Nom='tempo01';   Cpu=1; Dem=2GB; Min=1.5GB; Max=3GB; Disque=30GB; Delai=60  }
  @{ Nom='otel-gw';   Cpu=2; Dem=2GB; Min=1.5GB; Max=3GB; Disque=20GB; Delai=120 }
  @{ Nom='grafana01'; Cpu=1; Dem=2GB; Min=1GB;   Max=3GB; Disque=20GB; Delai=120 }
)

# 0. Checkpoint des VM existantes (aucune modification de leurs ressources)
Get-VM | Where-Object Name -in 'DC','ELK' | ForEach-Object {
  Checkpoint-VM -Name $_.Name -SnapshotName "avant-lgtm-kafka-$(Get-Date -Format yyyyMMdd)"
}

# 1. AppDynamics : reste éteinte et ne démarre pas avec l'hôte (adapter le nom)
$Appd = Get-VM -Name 'AppDynamics' -ErrorAction SilentlyContinue
if ($Appd) {
  if ($Appd.State -ne 'Off') { Stop-VM -Name $Appd.Name }
  Set-VM -Name $Appd.Name -AutomaticStartAction Nothing
}

# 2. Nouvelles VM
foreach ($v in $Vms) {
  if (Get-VM -Name $v.Nom -ErrorAction SilentlyContinue) { Write-Host "$($v.Nom) existe deja : ignoree"; continue }
  New-VM -Name $v.Nom -Generation 2 -MemoryStartupBytes $v.Dem -SwitchName $Switch `
         -NewVHDPath "$Dossier\$($v.Nom)\$($v.Nom).vhdx" -NewVHDSizeBytes $v.Disque | Out-Null
  Set-VMProcessor -VMName $v.Nom -Count $v.Cpu
  Set-VMMemory    -VMName $v.Nom -DynamicMemoryEnabled $true -StartupBytes $v.Dem -MinimumBytes $v.Min -MaximumBytes $v.Max
  Set-VMFirmware  -VMName $v.Nom -SecureBootTemplate MicrosoftUEFICertificateAuthority
  Add-VMDvdDrive  -VMName $v.Nom -Path $Iso
  Set-VMFirmware  -VMName $v.Nom -FirstBootDevice (Get-VMDvdDrive -VMName $v.Nom)
  Set-VM          -Name $v.Nom -AutomaticCheckpointsEnabled $false -AutomaticStartAction Start -AutomaticStartDelay $v.Delai
  Write-Host "$($v.Nom) creee"
}

# 3. Contrôle (DC et ELK doivent afficher leurs valeurs habituelles : 1 vCPU 2/1/2 Go et 2 vCPU 3/2/4 Go)
Get-VM | Select-Object Name, State, ProcessorCount,
  @{n='Demarrage_Go';e={$_.MemoryStartup/1GB}}, @{n='Min_Go';e={$_.MemoryMinimum/1GB}}, @{n='Max_Go';e={$_.MemoryMaximum/1GB}} |
  Format-Table -AutoSize
$Total = ($Vms | ForEach-Object { $_.Max } | Measure-Object -Sum).Sum / 1GB
Write-Host "Maximum cumule des nouvelles VM : $Total Go (attendu : 20)"

# 4. Installation : démarrer une VM à la fois et ouvrir sa console (section 4.4)
# Start-VM -Name kafka01 ; vmconnect.exe localhost kafka01
