# 04 – Décisions d'architecture (ADR)

> Format : contexte, décision, conséquences, alternatives écartées. Statut au 28 oct. 2026 (révision « une VM par service + Kafka »). Toute nouvelle décision s'ajoute à la fin avec un nouveau numéro ; une décision remplacée passe au statut « Remplacée par ADR-xxx ».

| ADR | Titre | Statut |
|---|---|---|
| [ADR-001](#adr-001) | Services systemd natifs, sans Docker | Acceptée |
| [ADR-002](#adr-002) | Installation hors ligne : Windows télécharge, Linux vérifie et installe | Acceptée |
| [ADR-003](#adr-003) | Mimir monolithique, architecture classique (Kafka **devant** Mimir, pas d'*ingest storage*) | Acceptée (révisée le 28 oct. 2026) |
| [ADR-004](#adr-004) | Prometheus en mode agent plutôt que Grafana Alloy, placé sur otel-gw, sans Kafka | Acceptée (révisée) |
| [ADR-005](#adr-005) | Alertmanager intégré à Mimir | Acceptée |
| [ADR-006](#adr-006) | Migration Strangler Fig : double consommation ELK / Loki par groupes Kafka | Acceptée (révisée) |
| [ADR-007](#adr-007) | Rétention et plafonds de disque (dont Kafka) | Acceptée (révisée) |
| [ADR-008](#adr-008) | Versions épinglées (Kafka 4.4.0, Grafana 13.2.4 plutôt que 13.3.0) | Acceptée (révisée) |
| [ADR-009](#adr-009) | Kafka comme tampon d'ingestion (KRaft, un nœud, trois sujets, « au moins une fois ») | Acceptée |
| [ADR-010](#adr-010) | Une VM par service (remplace la VM unique obs-lgtm) | Acceptée |
| [ADR-011](#adr-011) | Consommateurs sur les VM de stockage ; consommateur ELK sur otel-gw | Acceptée |
| [ADR-012](#adr-012) | Java : archive Eclipse Temurin JRE 25 plutôt que le paquet Debian | Acceptée |
| [ADR-013](#adr-013) | Ressources de DC et ELK inchangées | Acceptée |

---

<a id="adr-001"></a>
## ADR-001 – Services systemd natifs, sans Docker

**Contexte.** Le lab tourne sur un hôte Hyper-V à RAM limitée. Les VM Linux n'ont pas Internet : un registre d'images ne serait pas joignable, et il faudrait importer des images à la main (`docker load`). Le plan d'intégration impose déjà une installation native.

**Décision.** Chaque composant est installé à partir du paquet `.deb` officiel (Grafana, Mimir, mimirtool, Loki, Tempo, otelcol-contrib) ou de l'archive binaire officielle (Prometheus, node_exporter, Apache Kafka, Eclipse Temurin), et tourne en **service systemd** avec son propre utilisateur système. Les limites de ressources sont posées par des drop-ins (`MemoryHigh`, `MemoryMax`, `GOMEMLIMIT` ; *heap* Java pour Kafka).

**Conséquences.**
- (+) Pas de démon de conteneurs, pas d'images à transporter ; empreinte mémoire plus faible.
- (+) Outils standard : `systemctl`, `journalctl`, `systemd-cgtop`, `dpkg`.
- (+) Les paquets fournissent l'unité systemd, l'utilisateur et la configuration d'exemple.
- (−) Les scripts `postinst` de Mimir, Loki, Tempo et otelcol-contrib **activent et démarrent** le service avec la configuration d'exemple : il faut les arrêter juste après `dpkg -i` (runbook §5).
- Kafka et Java n'ont pas de `.deb` officiel : archives officielles dans `/opt` (liens `current`), unité `kafka.service` écrite par le runbook, compte système `kafka`.
- (−) Mise à jour = nouveau lot hors ligne, puis `dpkg -i` (voir [08_Exploitation_supervision.md](08_Exploitation_supervision.md)).

**Alternatives écartées.** Docker / Podman avec images importées (plus de RAM, plus de fichiers à transporter, contraire au plan) ; Kubernetes / Helm (hors de proportion pour un lab).

---

<a id="adr-002"></a>
## ADR-002 – Installation hors ligne : Windows télécharge, Linux vérifie et installe

**Contexte.** Seul un poste Windows a accès à Internet. Les outils de vérification fiables (`sha256sum`, `sqv`) sont présents sur Debian 13 ; sur Windows, seuls `Get-FileHash`, `curl.exe` et `tar.exe` sont garantis.

**Décision.**
1. Le poste Windows **ne fait que télécharger** : script `Telecharger-LGTM-Kafka.ps1` (versions épinglées, `curl.exe --fail`, URL de secours pour Kafka), manifeste `Get-FileHash`, archive `tar`, transfert `scp` vers **otel-gw**.
2. Toute la confiance est établie **sur Linux** (`verifier-lgtm.sh`) à trois niveaux : (a) empreintes publiées par chaque projet, (b) **index APT Grafana signé** (`InRelease`, clé `B53A E77B ADB6 30A6 8304 6005 963F A277 1045 8545`, vérifiée avec `sqv`), qui contient les SHA-256 des `.deb` Grafana, Mimir, mimirtool, Loki et Tempo, (c) empreintes attendues inscrites dans le runbook (`lgtm-sha256-attendus`), (d) **signatures OpenPGP de Kafka** (`.asc`, fichier `KEYS` du projet, signataire `1817 905E 3B27 08B1 1A24 B88E 9AFA 6F66 CC8C 3534`) et de **Temurin** (`.sig`, clé Adoptium `3B04 D753 C905 0D9A 5D34 3F39 843C 48A5 65F8 F04B`).
3. L'ISO Debian est vérifiée avec `SHA256SUMS.sign` (clé `DF9B 9C49 EAA9 2984 3258 9D76 DA87 E80D 6294 BE9B`).
4. otel-gw, VM de réception, vérifie tout le lot ; `distribuer-lot.sh` envoie ensuite à chaque VM **seulement ses fichiers**, et chaque VM les **recontrôle** avec `lgtm-sha256-attendus`.
5. Rien n'est installé si une seule vérification échoue.

**Conséquences.**
- (+) Une archive altérée pendant le transfert, ou une empreinte publiée modifiée, est détectée (testé avec des fichiers altérés).
- (+) `sqv` est toujours présent sur Debian 13 (dépendance d'`apt` 3.0) ; `curl` n'est pas sur l'ISO netinst, d'où l'usage de `wget`.
- (−) `InRelease` est régénéré chaque jour : il faut le télécharger **en même temps** que `Packages.gz`.
- (−) Les signatures Sigstore (`.sigstore.json`) d'OpenTelemetry ne sont pas vérifiées (`cosign` absent hors ligne).

**Alternatives écartées.** Miroir APT local (`apt-mirror`, `aptly`) : trop lourd pour un lab ; vérification sous Windows : outils GPG non disponibles par défaut, et cela contredirait la séparation des rôles.

---

<a id="adr-003"></a>
## ADR-003 – Mimir monolithique, architecture classique (Kafka devant Mimir, pas d'*ingest storage*)

**Contexte.** Le plan stockait les métriques dans Prometheus ; la demande est une vraie pile LGTM avec **Mimir**. Depuis Mimir 3.0, l'architecture recommandée est l'*ingest storage*, où Mimir utilise **lui-même** Kafka entre ses distributeurs et ses ingesters ; l'architecture classique reste prise en charge ([notes de version 3.0](https://grafana.com/docs/mimir/v3.0.x/release-notes/v3.0/)). Le lab a maintenant un Kafka (ADR-009), mais **devant** les stockages.

**Décision.** Un seul processus `mimir` sur mimir01 avec `target: all,alertmanager`, architecture **classique**, stockage `filesystem` sous `/var/lib/mimir`, anneau `inmemory`, gRPC et memberlist sur `127.0.0.1`, HTTP sur `0.0.0.0:9009` filtré par nftables, `MemoryMax=1536M`. Le consommateur `lgtm-mimir` lit `otlp_metrics` et écrit en OTLP sur `127.0.0.1:9009/otlp`.

**Conséquences.**
- (+) Un seul service à exploiter ; un seul usage de Kafka dans le lab, facile à expliquer.
- (+) API Prometheus complète (`/prometheus`), réception OTLP native (`/otlp`), *ruler* et Alertmanager inclus.
- (−) Pas de haute disponibilité ; le stockage `filesystem` est signalé par Mimir comme réservé au développement et aux tests.
- (−) Mimir classique pourrait devenir obsolète dans une version majeure future : à revoir à chaque mise à jour. L'*ingest storage* pourra faire l'objet d'un exercice séparé (sujets dédiés, configuration Mimir différente).

**Alternatives écartées.** *Ingest storage* sur le Kafka du lab (deux usages de Kafka mélangés, configuration Mimir plus complexe, plus de RAM) ; Prometheus serveur seul ; Mimir en microservices ; Thanos / VictoriaMetrics.

---

<a id="adr-004"></a>
## ADR-004 – Prometheus en mode agent plutôt que Grafana Alloy

**Contexte.** Il faut un composant qui *scrape* les exporteurs (node_exporter, windows_exporter, métriques internes) et pousse vers Mimir. Deux candidats : Prometheus 3.15.1 `--agent` et Grafana Alloy 1.21.2.

**Décision.** **Prometheus en mode agent.** `otelcol-contrib` reste le seul collecteur OTLP (façade d'ingestion et agents).

| Critère | Prometheus agent | Alloy |
|---|---|---|
| Rôle restant à couvrir | scrape + `remote_write` uniquement | scrape, journaux, traces, OTLP… (déjà couverts par otelcol-contrib) |
| Doublon avec otelcol-contrib | non | **oui** (deux collecteurs à configurer et à limiter) |
| Continuité avec le plan | même outil, même `prometheus.yml`, `promtool check config --agent` | nouveau langage de configuration (Alloy syntax) |
| Taille de l'artefact | archive ≈ 112 Mo | `.deb` ≈ 168 Mo |
| Mémoire au repos mesurée en test | 115–130 Mo | non mesurée |

**Conséquences.** (+) Configuration connue et vérifiable avec `promtool`. (−) Deux outils de collecte (Prometheus pour le *pull*, otelcol pour le *push*) au lieu d'un seul. Alloy reste une option si l'on veut remplacer **à la fois** Prometheus agent et otelcol-contrib par un seul agent Grafana ; ce serait un nouvel ADR.

**Placement : otel-gw, et sans Kafka.** otel-gw est la VM de **collecte** : elle reçoit (OTLP) et va chercher (*scrape*). Prometheus agent y tourne et écrit **directement** dans Mimir (`remote_write`) :
- Prometheus ne sait pas produire dans Kafka ; il faudrait un intermédiaire (otelcol avec récepteur `prometheus`), plus de configuration pour peu de gain ;
- son **WAL** (`/var/lib/prometheus`) sert déjà de tampon si Mimir est indisponible ;
- grafana01 reste dédiée à la consultation, et mimir01 ne se supervise pas lui-même.

Même logique pour la supervision de Kafka (récepteur `kafka_metrics` sur otel-gw, vers Mimir sans passer par Kafka) : elle doit rester visible quand Kafka est saturé.

**Alternatives écartées.** Récepteur `prometheus` d'otelcol-contrib (possible, mais charge la passerelle et s'éloigne du plan) ; Alloy ; Prometheus sur grafana01 (mélange consultation et collecte) ou sur mimir01 (le stockage supervisé par lui-même).

---

<a id="adr-005"></a>
## ADR-005 – Alertmanager intégré à Mimir

**Décision.** Pas de service `alertmanager` autonome : Mimir fournit un Alertmanager compatible (`target: all,alertmanager`, `/alertmanager`). Le *ruler* de Mimir et celui de Loki y envoient leurs alertes. Configuration de repli `/etc/mimir/alertmanager-fallback.yml` avec un récepteur nul `lab-null` ; la configuration réelle se charge avec `mimirtool alertmanager load` après `mimirtool alertmanager verify`.

**Conséquences.** (+) Un service et 64 Mo de RAM de moins que le plan. (+) Datasource Grafana `mimir-am` (implémentation `mimir`). (−) La cible `all` seule ne démarre **pas** l'Alertmanager (constaté en test : `404`).

---

<a id="adr-006"></a>
## ADR-006 – Migration Strangler Fig : double consommation ELK / Loki par groupes Kafka

**Contexte.** ELK est en service et sert aux démonstrations ; on ne peut pas le couper d'un coup. La version précédente faisait une double **écriture** depuis le collecteur (deux exportateurs dans le même pipeline : une destination lente ou en panne ralentissait l'autre).

**Décision.** Suivre les phases 0 à 6 du plan. Les **façades** (otel-gw pour l'entrée, Grafana pour la consultation) sont installées d'abord. Pour les journaux, la passerelle écrit **une fois** dans `otlp_logs` ; deux **groupes de consommateurs** indépendants lisent le même sujet :
- `lgtm-loki` (loki01) → Loki ;
- `elk-es` (otel-gw) → Elasticsearch, jusqu'à la phase 6.

En phase 6, on retire le pipeline `logs/elk` puis on supprime le groupe `elk-es` ; les sources ne changent pas. Détail : [07_Plan_migration_Strangler_Fig.md](07_Plan_migration_Strangler_Fig.md).

**Conséquences.**
- (+) Les deux destinations sont **découplées** : chacune a ses offsets et son retard ; une panne d'ES ne touche pas Loki (testé dans l'autre sens : Loki arrêté, `elk-es` non affecté).
- (+) Comparaison exacte : les deux groupes reçoivent les mêmes messages (même `LOG-END-OFFSET`).
- (+) Retour arrière par phase sans perte ; un nouveau groupe peut **relire 24 h** de journaux.
- (−) Une VM de plus (kafka01) et un composant de plus à exploiter (retard, disque).
- (−) Le consommateur ELK ajoute une charge à otel-gw (limite de la passerelle : 768 Mo).

---

<a id="adr-007"></a>
## ADR-007 – Rétention et plafonds de disque (dont Kafka)

**Décision.**

| Données | Rétention | Paramètre | Disque de la VM |
|---|---|---|---|
| Métriques (Mimir) | 15 jours | `limits.compactor_blocks_retention_period: 15d` | mimir01 : 40 Go |
| Journaux (Loki) | 168 h | `limits_config.retention_period: 168h`, `compactor.retention_enabled: true` | loki01 : 40 Go |
| Traces (Tempo) | 72 h | `overrides.defaults.compaction.block_retention: 72h` | tempo01 : 30 Go |
| Messages Kafka | **24 h ou** 2 Gio (`otlp_logs`) / 1 Gio (`otlp_metrics`, `otlp_spans`) **par partition**, 3 partitions | `retention.ms=86400000`, `retention.bytes`, `segment.bytes=268435456` | kafka01 : 40 Go (≈ 12 Gio de messages au maximum + 9 segments actifs ≤ 2,25 Gio) |
| Journaux applicatifs Kafka | 7 jours | `/etc/tmpfiles.d/kafka.conf` ; GC 5 × 10 Mo | kafka01 |
| WAL Prometheus agent | jusqu'à l'envoi vers Mimir | – | otel-gw : 20 Go |
| Journal systemd | 300 Mo par VM | `SystemMaxUse=300M` | toutes |

Mimir limite aussi la cardinalité (`max_global_series_per_user: 150000`, `ingestion_rate: 20000`). Kafka refuse la création automatique de sujets (`auto.create.topics.enable=false`) : aucun sujet ne peut apparaître sans plafond.

**Conséquences.** (+) Aucun disque ne peut se remplir par les données seules ; alerte `KafkaDisqueFaible` (< 20 % libre). (+) Disques séparés : rétentions plus longues qu'avec la VM unique. (−) Un consommateur arrêté **plus de 24 h** perd les messages expirés : alerte `KafkaConsommateurAbsent` après 5 min.

**Note de test.** Dans Tempo 3.1, `block_retention` placé dans le bloc du *backend worker* n'était pas pris en compte ; seul le paramètre d'`overrides` l'a été. Dans Kafka, `retention.bytes` s'applique **par partition** ; la suppression se fait par segment entier, jamais sur le segment actif.

---

<a id="adr-008"></a>
## ADR-008 – Versions épinglées et Grafana 13.2.4 plutôt que 13.3.0

**Décision.** Versions fixées dans le script de téléchargement et dans `lgtm-sha256-attendus` :

| Composant | Version |
|---|---|
| Apache Kafka | 4.4.0 (Scala 2.13), sortie le 22 oct. 2026 |
| Eclipse Temurin JRE | 25.0.5+8 (LTS) |
| Grafana OSS | 13.2.4 (build 38252365904) |
| Grafana Mimir / mimirtool | 3.2.3 |
| Grafana Loki | 3.7.9 |
| Grafana Tempo | 3.1.1 |
| Prometheus | 3.15.1 |
| node_exporter | 1.12.1 |
| OpenTelemetry Collector contrib | 0.164.0 |
| windows_exporter | 0.32.0 |
| Debian | 13.7.0 (netinst), `adduser` 3.152 |

Grafana 13.3.0 est sorti le 27 oct. 2026 mais **n'était pas encore dans l'index APT signé** le 28 oct. 2026 : sa vérification par la chaîne GPG aurait été impossible. 13.2.4 est retenu.

Kafka 4.4.0 est la version la plus récente sur `downloads.apache.org` le 28 oct. 2026 ; la documentation 4.4 recommande Java 25 (Java 17, 21 et 25 pris en charge).

**Conséquences.** Toute montée de version passe par une nouvelle vérification complète (voir [08_Exploitation_supervision.md](08_Exploitation_supervision.md) et [GUARDRAILS.md](GUARDRAILS.md)).

---

<a id="adr-009"></a>
## ADR-009 – Kafka comme tampon d'ingestion (KRaft, un nœud, trois sujets, « au moins une fois »)

**Contexte.** Avec une seule VM, la passerelle écrivait directement dans les stockages : un stockage arrêté faisait perdre des données (après la file en mémoire du collecteur) et la double écriture ELK / Loki couplait les deux destinations. La demande : « une VM par service comme ça on peut bien utiliser Kafka ».

**Décision.**
- **Apache Kafka 4.4.0 en mode KRaft combiné** (`process.roles=broker,controller`), **un seul nœud** (node.id 1, contrôleur sur `127.0.0.1:9093`), facteur de réplication **1**, sur kafka01.
- **Trois sujets créés à la main**, un par signal : `otlp_logs`, `otlp_metrics`, `otlp_spans` (noms par défaut d'OpenTelemetry), **3 partitions**, format `otlp_proto`, compression `zstd`, `auto.create.topics.enable=false`.
- Passerelle productrice (`required_acks: -1`), consommateurs « **au moins une fois** » (offset validé après l'écriture, pas de `batch` ni de file d'envoi, `error_backoff` sans limite).
- Supervision : `kafka_metrics` (otel-gw) → Mimir ; alertes de retard, d'absence de consommateur et de disque.

**Conséquences.**
- (+) Tampon de 24 h devant chaque stockage ; relecture possible (remise à zéro d'un groupe) ; nouvelles destinations sans toucher aux sources.
- (+) Tout ce que fait Kafka est observable (offsets, retard, partitions) : objectif pédagogique du lab.
- (−) Une JVM à exploiter (Java, *heap*, cache de pages) et un point unique de défaillance (un seul broker).
- (−) Latence ajoutée (lots de la passerelle + lecture des consommateurs) : quelques secondes, sans importance pour l'observabilité du lab.
- (−) `PLAINTEXT` sans authentification : acceptable sur le vSwitch isolé du lab, filtré par nftables ([06](06_Securite.md)).

**Alternatives écartées.** Kafka à trois nœuds (×3 RAM, hors budget) ; ZooKeeper (supprimé dans Kafka 4) ; création automatique des sujets (sujets mal dimensionnés) ; une file en mémoire du collecteur seulement (perdue au redémarrage) ; Redpanda ou autres (hors demande).

---

<a id="adr-010"></a>
## ADR-010 – Une VM par service (remplace la VM unique obs-lgtm)

**Contexte.** La version précédente regroupait collecteur, Prometheus, Mimir, Loki, Tempo et Grafana sur obs-lgtm (4 Go). Avec Kafka, l'intérêt est que chaque stockage vive, tombe et redémarre **seul**. L'hôte a 32 Go.

**Décision.** Six nouvelles VM Debian 13 : **kafka01**, **otel-gw**, **mimir01**, **loki01**, **tempo01**, **grafana01** (dimensionnement : [05](05_Dimensionnement_infra.md)). Les API d'écriture restent locales à chaque VM ; seules les API de lecture (Grafana) et de collecte passent sur le réseau.

**Conséquences.**
- (+) Isolation : une saturation mémoire ou disque n'affecte qu'un service ; arrêt d'un stockage = démonstration du tampon Kafka.
- (+) Dimensionnement et rétention par service ; checkpoints par service.
- (−) Six systèmes à maintenir (mises à jour Debian, SSH, horloge) ; 14 Go de RAM au démarrage au lieu de 4.
- (−) Les ports HTTP de Mimir, Loki et Tempo écoutent sur le réseau : filtrage nftables nécessaire.

**Alternatives écartées.** VM unique avec Kafka ajouté (pas d'isolation, mémoire trop serrée) ; deux VM (« ingestion » et « stockage ») : moins de VM mais les trois stockages restent liés.

---

<a id="adr-011"></a>
## ADR-011 – Consommateurs sur les VM de stockage ; consommateur ELK sur otel-gw

**Contexte.** Il faut décider où tournent les consommateurs Kafka (otelcol-contrib avec récepteur `kafka`).

**Décision.**
- `lgtm-mimir`, `lgtm-loki`, `lgtm-tempo` tournent **sur la VM du stockage** et écrivent sur `127.0.0.1`.
- `elk-es` tourne **sur otel-gw** (pipeline `logs/elk` de la passerelle).

**Raisons.**
1. Un groupe, un stockage, une VM : le retard et les redémarrages de chaque consommateur sont faciles à relier à leur stockage.
2. Une panne d'un stockage ne touche que son groupe.
3. Les API d'écriture (`/otlp`, OTLP de Tempo) restent sur la boucle locale.
4. Pour ELK, les ressources de la VM sont figées (ADR-013) : le consommateur n'y est pas ajouté ; otel-gw a la place (≈ 210 Mo mesurés pour la passerelle complète en test).

**Conséquences.** (+) Clair et isolé. (−) Un otelcol-contrib de plus par VM de stockage (≤ 384 Mo chacun). (−) otel-gw porte deux rôles (producteur et consommateur ELK) jusqu'à la phase 6.

**Alternatives écartées.** Tous les consommateurs sur otel-gw (un seul processus, mais une erreur d'un stockage pèse sur la passerelle et les API d'écriture passent sur le réseau) ; consommateurs dans une VM dédiée (une VM de plus sans bénéfice pédagogique) ; consommateur ELK sur la VM ELK (contraire à ADR-013).

---

<a id="adr-012"></a>
## ADR-012 – Java : archive Eclipse Temurin JRE 25 plutôt que le paquet Debian

**Contexte.** Kafka 4.4 a besoin de Java (17, 21 ou 25 ; 25 recommandé). Les VM n'ont pas Internet.

**Décision.** Archive **Eclipse Temurin JRE 25.0.5+8** (`OpenJDK25U-jre_x64_linux_hotspot_25.0.5_8.tar.gz`, 62 Mo) décompressée dans `/opt/java`, lien `/opt/java/current`. Vérification : `.sha256.txt` publié et signature `.sig` (clé Adoptium, empreinte publiée sur adoptium.net).

**Conséquences.** (+) Un seul fichier, autonome, signé ; Java recommandé par la documentation Kafka 4.4. (+) Mise à jour réversible par changement de lien. (−) Pas de mises à jour de sécurité par `apt` : nouvelle version = nouveau lot hors ligne.

**Alternatives écartées.** `openjdk-21-jre-headless` de Debian (21.0.13 dans trixie) : dépend de `ca-certificates-java`, `java-common`, `libnss3`, `libpcsclite1`, `libjpeg62-turbo`, `liblcms2-2` et d'autres paquets absents de l'ISO netinst, soit une dizaine de `.deb` à télécharger et vérifier. `openjdk-25-jre-headless` de Debian : mêmes dépendances. Temurin 21 : possible, mais Java 25 est recommandé.

---

<a id="adr-013"></a>
## ADR-013 – Ressources de DC et ELK inchangées

**Contexte.** DC et ELK fonctionnent bien avec les valeurs de la section 2 du plan. La version précédente proposait ELK à 4 Go (3–5 Go).

**Décision.** **Aucune modification** : DC 1 vCPU, 2 Go (1–2 Go) ; ELK 2 vCPU, 3 Go (2–4 Go). Aucune commande Hyper-V ne change leurs ressources (seuls des checkpoints sont pris). Seules les six nouvelles VM se partagent le reste des 32 Go. Le consommateur ELK tourne sur otel-gw (ADR-011).

**Conséquences.** (+) Aucun risque sur l'existant. (−) Les agents ajoutés sur ELK (`node_exporter`, `otelcol-contrib` ≤ 320 Mo) et ElastAlert 2 partagent 2–4 Go avec Elasticsearch et Kibana : **point de vigilance** (RAM disponible, *swap*, redémarrages), pas un changement. Si la mémoire manque, on le signale et on décide plus tard.
