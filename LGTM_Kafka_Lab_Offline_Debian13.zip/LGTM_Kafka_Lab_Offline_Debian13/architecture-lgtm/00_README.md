# 00 – Index du dossier d'architecture LGTM + Kafka

Dossier d'architecture de la pile **LGTM** (Loki, Grafana, Tempo, Mimir) du lab Hyper-V, avec **Apache Kafka** comme tampon d'ingestion, installée **hors ligne** sur Debian 13, **une VM par service**, en services **systemd** (sans Docker). Présentation générale, prérequis et ordre de lecture : [README.md](README.md).

| # | Document | Contenu |
|---|---|---|
| – | [README.md](README.md) | Objet, carte des documents, prérequis, démarrage rapide, conventions, versions épinglées |
| – | [GUARDRAILS.md](GUARDRAILS.md) | Garde-fous obligatoires : hors ligne, sans Docker, vérifications, checkpoints, secrets, limites (dont disque et rétention Kafka), règles Kafka, validation, retour arrière, interdits, liste de contrôle |
| 01 | [01_Vue_ensemble_architecture.md](01_Vue_ensemble_architecture.md) | Contexte, composants, vues logique et physique (Mermaid), rôle et contenu de chaque VM |
| 02 | [02_Flux_de_donnees.md](02_Flux_de_donnees.md) | Pipelines par signal, sujets et groupes Kafka, livraison « au moins une fois », double consommation ELK / Loki, séquences |
| 03 | [03_Matrice_reseau_ports.md](03_Matrice_reseau_ports.md) | Tous les flux (source, destination, port, protocole, objet), ports d'écoute par VM, filtrage nftables |
| 04 | [04_Decisions_architecture_ADR.md](04_Decisions_architecture_ADR.md) | ADR-001 à ADR-013 : systemd natif, hors ligne, Mimir classique, Prometheus agent, Alertmanager intégré, Strangler Fig par groupes de consommateurs, rétention, versions, **Kafka tampon**, **une VM par service**, **placement des consommateurs**, **Java Temurin**, **DC et ELK inchangés** |
| 05 | [05_Dimensionnement_infra.md](05_Dimensionnement_infra.md) | vCPU, RAM et disque par VM (hôte de 32 Go), variante 4 processeurs, limites mémoire par service, disque Kafka |
| 06 | [06_Securite.md](06_Securite.md) | Utilisateurs, permissions, réseau (Kafka `PLAINTEXT` dans le lab), TLS, clés API (90 jours, moindre privilège), chaîne d'approvisionnement |
| 07 | [07_Plan_migration_Strangler_Fig.md](07_Plan_migration_Strangler_Fig.md) | Phases 0 à 6, critères de passage, groupes `elk-es` / `lgtm-loki`, retour arrière |
| 08 | [08_Exploitation_supervision.md](08_Exploitation_supervision.md) | Contrôles de santé, retard des consommateurs, disque Kafka, auto-supervision, sauvegardes, mises à jour hors ligne |

Documents du dossier parent :

- [`../Runbook_LGTM_Kafka_Offline_Debian13.md`](../Runbook_LGTM_Kafka_Offline_Debian13.md) (et `.docx`) : **procédure de référence**.
- [`../Plan_integration_observabilite_lab.md`](../Plan_integration_observabilite_lab.md) : plan d'intégration Strangler Fig d'origine (non modifié).
- `../architecture-lgtm.v1-obs-lgtm.bak/` : version précédente de ce dossier (une seule VM obs-lgtm, sans Kafka).

État : rédigé le 28 oct. 2026. Les composants (dont Kafka 4.4.0 avec Temurin 25) ont été testés en lançant les binaires directement, toutes les « VM » sur une seule machine de test Debian 13 ; l'installation sur six VM Hyper-V sous systemd reste à jouer (annexe A du runbook).
