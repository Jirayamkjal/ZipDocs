#!/usr/bin/env bash
# =============================================================================
# Rendu des modèles de configuration LGTM par substitution de variables.
# =============================================================================
#
# Utilise envsubst (gettext) s'il est présent, sinon un repli Python
# équivalent (scripts/_envsubst.py). Les modèles dans variables/templates/ portent
# l'extension .tmpl et des placeholders du type ${GRAFANA_FQDN}.
#
# Usage :
#   LGTM_ENV=prod    ./scripts/rendre-config.sh
#   LGTM_ENV=preprod ./scripts/rendre-config.sh
#   LGTM_ENV=prod    ./scripts/rendre-config.sh chemin/modele.tmpl [fichier-sortie]
#   LGTM_ENV=prod    ./scripts/rendre-config.sh --liste
#
# Par défaut, tous les modèles sont rendus dans :
#   variables/rendu/${LGTM_ENV}/
#
# Ce script ne dépose rien dans /etc : l'opérateur recopie après relecture.
# Aucun secret n'est attendu dans le fichier de variables (mots de passe,
# jetons : fichiers 0600 à part, jamais en argument).
# =============================================================================
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROD_ROOT="$(cd "${SCRIPT_DIR}/.." && pwd)"
ENV_FILE="${LGTM_ENV_FILE:-${PROD_ROOT}/variables/environnements.env}"
TMPL_DIR="${PROD_ROOT}/variables/templates"
LGTM_ENV="${LGTM_ENV:-prod}"
OUT_DIR="${PROD_ROOT}/variables/rendu/${LGTM_ENV}"

usage() {
  sed -n '2,24p' "$0"
}

# Préférer envsubst (gettext). Repli : scripts/_envsubst.py (même sémantique).
_ENVSUBST=()
if command -v envsubst >/dev/null 2>&1; then
  _ENVSUBST=(envsubst)
else
  _ENVSUBST=(python3 "${SCRIPT_DIR}/_envsubst.py")
  printf 'Note : envsubst (gettext) est absent ; repli sur scripts/_envsubst.py.\n' >&2
fi

if [[ ! -f "${ENV_FILE}" ]]; then
  printf 'Fichier de variables introuvable : %s\n' "${ENV_FILE}" >&2
  exit 2
fi

# Charger les variables (jeu court selon LGTM_ENV)
set -a
# shellcheck disable=SC1090
. "${ENV_FILE}"
set +a

if [[ "${1:-}" == "-h" || "${1:-}" == "--help" ]]; then
  usage
  exit 0
fi

if [[ "${1:-}" == "--liste" ]]; then
  printf 'LGTM_ENV=%s  DOMAIN=%s\n' "${LGTM_ENV}" "${DOMAIN}"
  printf 'Fichier : %s\n' "${ENV_FILE}"
  printf '\nVariables courtes (extrait) :\n'
  for v in DOMAIN GRAFANA_FQDN GRAFANA_VIP GRAFANA_URL \
           OTEL_GW_FQDN OTEL_GW_VIP KAFKA_BOOTSTRAP KAFKA_DNS \
           MIMIR_FQDN MIMIR_VIP LOKI_FQDN LOKI_VIP TEMPO_FQDN TEMPO_VIP \
           S3_FQDN S3_VIP S3_ENDPOINT S3_BUCKET_MIMIR S3_BUCKET_LOKI S3_BUCKET_TEMPO S3_BUCKET_ADMIN MINIO_API_PORT MINIO_CONSOLE_PORT PG_FQDN PG_VIP \
           ES_FQDN ES_URL APPD_FQDN APPD_URL APPD_OTEL_INGEST \
           SCOM_FQDN SCOM_URL DC01_FQDN DC02_FQDN LDAP_HOSTS \
           REGISTRY_FQDN BASTION01_FQDN LB01_FQDN \
           PORT_GRAFANA PORT_OTEL_GRPC PORT_OTEL_HTTP PORT_KAFKA \
           PORT_MIMIR PORT_LOKI PORT_TEMPO PORT_ES PORT_APPD_HTTPS PORT_SCOM_WEB PORT_LDAPS PORT_KERBEROS \
           KRB_REALM KRB_SERVICE_ACCOUNT KRB_PRINCIPAL KRB_KEYTAB AUTH_PROXY_HEADER AUTH_PROXY_WHITELIST \
           ADFS_FQDN ADFS_URL ADFS_WELLKNOWN ADFS_AUTH_URL ADFS_TOKEN_URL ADFS_USERINFO_URL OAUTH_REDIRECT_URL \
           ES_VERSION ROR_VERSION KIBANA_VERSION ROR_ES_PLUGIN_ZIP ROR_KBN_PLUGIN_ZIP \
           STOCKAGE_OBJET_SCENARIO S3_CA_FILE S3_FORCE_PATH_STYLE S3_REGION
  do
    printf '  %-22s = %s\n' "$v" "${!v-}"
  done
  exit 0
fi

# Liste des variables à substituer (évite de laisser fuiter tout l'environnement)
VARS=$(printf '${%s}' DOMAIN IP_PREFIX AD_DOMAIN \
  GRAFANA_FQDN GRAFANA_VIP GRAFANA_URL GRAFANA01_FQDN GRAFANA01_IP GRAFANA02_FQDN GRAFANA02_IP \
  OTEL_GW_FQDN OTEL_GW_VIP OTLP_FQDN OTLP_VIP \
  OTELGW01_FQDN OTELGW01_IP OTELGW02_FQDN OTELGW02_IP OTELGW03_FQDN OTELGW03_IP \
  KAFKA_DNS KAFKA_BOOTSTRAP KAFKA01_FQDN KAFKA01_IP KAFKA02_FQDN KAFKA02_IP KAFKA03_FQDN KAFKA03_IP \
  MIMIR_FQDN MIMIR_VIP LOKI_FQDN LOKI_VIP TEMPO_FQDN TEMPO_VIP \
  S3_FQDN S3_VIP S3_ENDPOINT S3_BUCKET_MIMIR S3_BUCKET_LOKI S3_BUCKET_TEMPO S3_BUCKET_ADMIN MINIO_API_PORT MINIO_CONSOLE_PORT PG_FQDN PG_VIP PG01_FQDN PG01_IP PG02_FQDN PG02_IP \
  ES_FQDN ES_VIP ES_URL APPD_FQDN APPD_VIP APPD_URL APPD_OTEL_INGEST \
  SCOM_FQDN SCOM_VIP SCOM_URL DC01_FQDN DC01_IP DC02_FQDN DC02_IP LDAP_HOSTS \
  REGISTRY_FQDN BASTION01_FQDN BASTION01_IP BASTION02_FQDN BASTION02_IP \
  LB01_FQDN LB01_IP LB02_FQDN LB02_IP \
  PORT_GRAFANA PORT_OTEL_GRPC PORT_OTEL_HTTP PORT_KAFKA PORT_KAFKA_CONTROLLER \
  PORT_MIMIR PORT_LOKI PORT_TEMPO PORT_S3 PORT_POSTGRES PORT_ES \
  PORT_APPD_HTTPS PORT_APPD_HTTP PORT_SCOM_WEB PORT_LDAPS PORT_KERBEROS \
  KRB_REALM KRB_SERVICE_ACCOUNT KRB_PRINCIPAL KRB_KEYTAB AUTH_PROXY_HEADER AUTH_PROXY_WHITELIST \
  ADFS_FQDN ADFS_URL ADFS_WELLKNOWN ADFS_AUTH_URL ADFS_TOKEN_URL ADFS_USERINFO_URL OAUTH_REDIRECT_URL \
  ES_VERSION ROR_VERSION KIBANA_VERSION ROR_ES_PLUGIN_ZIP ROR_KBN_PLUGIN_ZIP \
  STOCKAGE_OBJET_SCENARIO S3_CA_FILE S3_FORCE_PATH_STYLE S3_REGION \
  ADMIN_NET INGEST_NET KAFKA_NET STORE_NET UI_NET OBJ_NET VIP_NET \
  LGTM_ENV)

rendre_un() {
  local tmpl="$1"
  local dest="$2"
  mkdir -p "$(dirname "${dest}")"
  # envsubst ne conserve que les variables listées — les ${autres} restent
  # VARS est une chaîne du type ${A}${B}${C} (syntaxe envsubst).
  # Pour le repli Python, on passe la liste des noms.
  if [[ "${_ENVSUBST[0]}" == "envsubst" ]]; then
    envsubst "${VARS}" < "${tmpl}" > "${dest}"
  else
    _names=()
    _tmp="${VARS}"
    while [[ "${_tmp}" =~ \$\{([A-Za-z_][A-Za-z0-9_]*)\} ]]; do
      _names+=("${BASH_REMATCH[1]}")
      _tmp="${_tmp#*"${BASH_REMATCH[0]}"}"
    done
    python3 "${SCRIPT_DIR}/_envsubst.py" "${_names[@]}" < "${tmpl}" > "${dest}"
  fi
  printf 'rendu : %s → %s\n' "${tmpl}" "${dest}"
}

if [[ $# -ge 1 ]]; then
  tmpl="$1"
  if [[ ! -f "${tmpl}" ]]; then
    # essayer relatif au répertoire de modèles
    if [[ -f "${TMPL_DIR}/${tmpl}" ]]; then
      tmpl="${TMPL_DIR}/${tmpl}"
    else
      printf 'Modèle introuvable : %s\n' "$1" >&2
      exit 2
    fi
  fi
  dest="${2:-${OUT_DIR}/$(basename "${tmpl}" .tmpl)}"
  rendre_un "${tmpl}" "${dest}"
  exit 0
fi

# Tous les modèles
shopt -s nullglob
tmpls=("${TMPL_DIR}"/*.tmpl)
if [[ ${#tmpls[@]} -eq 0 ]]; then
  printf 'Aucun modèle dans %s\n' "${TMPL_DIR}" >&2
  exit 2
fi
mkdir -p "${OUT_DIR}"
for tmpl in "${tmpls[@]}"; do
  rendre_un "${tmpl}" "${OUT_DIR}/$(basename "${tmpl}" .tmpl)"
done
printf 'Terminé (%s) dans %s\n' "${LGTM_ENV}" "${OUT_DIR}"
