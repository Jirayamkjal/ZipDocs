# Variables d'environnements — DNS, plan d'adressage et VIP

**Modifier ici seulement :** [`environnements.env`](environnements.env) et son équivalent YAML [`environnements.yaml`](environnements.yaml). Les deux fichiers décrivent les mêmes exemples fictifs (domaines `obs.exemple.local` en production et `obs-pp.exemple.local` en préproduction). Ils doivent rester alignés. Les commandes des runbooks et le rendu des modèles s'appuient sur le fichier `.env`.

## Chargement

```bash
export LGTM_ENV=prod          # ou : preprod
set -a
. /chemin/vers/variables/environnements.env
set +a
# Ensuite : echo "$GRAFANA_FQDN"  "$KAFKA_BOOTSTRAP"  "$APPD_URL"
```

## Rendu des modèles (envsubst)

```bash
# Tous les modèles de templates/ → variables/rendu/prod/ (ou preprod/)
LGTM_ENV=prod    ../scripts/rendre-config.sh
LGTM_ENV=preprod ../scripts/rendre-config.sh

# Un modèle isolé, ou liste des variables chargées
LGTM_ENV=prod ../scripts/rendre-config.sh --liste
LGTM_ENV=prod ../scripts/rendre-config.sh grafana.ini.tmpl /tmp/grafana.ini
```

Le script exige `envsubst` (paquet `gettext`). Le répertoire `variables/rendu/` est un produit généré : il peut être recréé à tout moment et n'est pas une source.

Aucun secret (mot de passe, jeton, clé S3) n'appartient à ces fichiers.

## SSO (Kerberos et AD FS)

Les variables `KRB_*`, `AUTH_PROXY_*`, `ADFS_*` et `OAUTH_REDIRECT_URL` sont dans le même fichier
(bloc « SSO Grafana OSS »). Aucun secret (keytab, client_secret) n'y figure. Voir
[ADR-011](../architecture/adr/ADR-011_SSO_Grafana_OSS.md) et les modèles
`grafana-auth-proxy.ini.tmpl`, `httpd-mod-auth-gssapi.conf.tmpl`,
`grafana-generic-oauth.ini.tmpl`, `krb5.conf.tmpl`.

## Versions Elasticsearch et ReadonlyREST

`ES_VERSION=8.19.0`, `ROR_VERSION=1.72.0`, `KIBANA_VERSION=8.19.0` (cette dernière à aligner sur la Kibana réellement déployée), ainsi que les noms de paquets `ROR_ES_PLUGIN_ZIP` (`readonlyrest-1.72.0_es8.19.0.zip`) et `ROR_KBN_PLUGIN_ZIP`. Le build ROR doit correspondre exactement à la version Elasticsearch. Voir [ADR-004](../architecture/adr/ADR-004_ROR_vs_XPack.md).

## Stockage objet

`STOCKAGE_OBJET_SCENARIO` : `hitachi` (scénario A, HCP / VSP One Object) ou `minio` (scénario B). Valeur initiale `a_confirmer` jusqu'à la [checklist](../architecture/annexes/Checklist_decision_stockage_objet.md). Un HNAS seul n'est pas une cible S3.

`S3_ENDPOINT` / `S3_FQDN` : point de service (tenant HCP, endpoint VSP One Object, ou VIP MinIO). En scénario A Hitachi, remplacer les FQDN d'exemple `s3.obs.exemple.local` par le FQDN fourni par l'équipe stockage (authentification AWS : sans `/hs3`).

`S3_CA_FILE` : chemin du PEM de la CA du service objet. `S3_FORCE_PATH_STYLE` : `true` (path-style) ou `false` (virtual-hosted). `S3_REGION` : exigé par les clients Grafana, à confirmer.

## Seaux objet et MinIO

Les noms de seaux (`S3_BUCKET_MIMIR`, `S3_BUCKET_LOKI`, `S3_BUCKET_TEMPO`, `S3_BUCKET_ADMIN`) et les ports MinIO d'exemple (`MINIO_API_PORT`, `MINIO_CONSOLE_PORT`) se définissent dans le même fichier `.env`. Les FQDN `s3.` et `minio-01` … `minio-04` sont déjà dérivés du domaine. Procédure si aucun S3 n'existe : [Annexe stockage objet](../architecture/annexes/Annexe_Stockage_objet_S3_MinIO.md).

Les variables SSO (Kerberos, AD FS) restent disponibles pour l'**annexe** SSO des runbooks ; elles ne sont pas requises pour l'authentification LDAP principale.
