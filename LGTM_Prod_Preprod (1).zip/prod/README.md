# Plateforme LGTM — préproduction et production

Paquet autonome pour déployer Grafana LGTM (Loki, Grafana, Tempo, Mimir) avec
Kafka, OpenTelemetry Collector, ReadonlyREST **Enterprise 1.72.0** (Elasticsearch **8.19.0**), authentification **LDAP** (mécanisme principal, Grafana OSS), vue unique, et intégration
logique de SCOM **2019** et d'AppDynamics **on-premises**.

## Démarrer par

| Fichier | Contenu |
|---|---|
| [architecture/00_README.md](architecture/00_README.md) | Architecture, ADR, étude d'impact, diagrammes Visio |
| [Runbook_LGTM_Prod_VM_RHEL8.md](Runbook_LGTM_Prod_VM_RHEL8.md) | Déploiement sur machines virtuelles RHEL 8 (systemd, hors ligne, SELinux) |
| [Runbook_LGTM_Prod_Kubernetes.md](Runbook_LGTM_Prod_Kubernetes.md) | Déploiement Kubernetes (Helm, opérateurs, registre privé) |
| [scripts/README.md](scripts/README.md) | Composant `grafana_acl_sync` (ACL / LDAP) |
| [dashboards/one_screen_home.json](dashboards/one_screen_home.json) | Tableau de bord d'accueil « vue unique » |
| [k8s/](k8s/) | Extraits de values Helm et exemple de namespace |
| [variables/](variables/) | **Modifier ici seulement** : DNS, plan d'adressage, VIP (`.env` + YAML) |
| [scripts/rendre-config.sh](scripts/rendre-config.sh) | Rendu des modèles par substitution (`envsubst` ou repli Python) |
| [architecture/annexes/Checklist_decision_stockage_objet.md](architecture/annexes/Checklist_decision_stockage_objet.md) | Décision stockage : scénario A Hitachi ou B MinIO (HNAS seul insuffisant) |
| [architecture/annexes/Annexe_Stockage_objet_Hitachi_HCP_S3.md](architecture/annexes/Annexe_Stockage_objet_Hitachi_HCP_S3.md) | Scénario A — HCP (HS3) ou VSP One Object, côté consommateur |
| [architecture/annexes/Annexe_Stockage_objet_S3_MinIO.md](architecture/annexes/Annexe_Stockage_objet_S3_MinIO.md) | Scénario B — MinIO distribué si aucun S3 serveur |
| Annexes B des runbooks VM et Kubernetes | SSO Kerberos / OIDC — complément optionnel, LDAP reste le socle |

Les noms d'hôtes, VIP et adresses sont des **exemples fictifs** (`obs.exemple.local` /
`obs-pp.exemple.local`) à modifier **uniquement** dans `variables/environnements.env`
(équivalent YAML fourni). Le dimensionnement des VM et des pools Kubernetes est
un ensemble d'**estimations recommandées** (données sensibles, trois domaines de
défaillance). Les points non testés figurent en annexe de chaque runbook.
