# Runbook — Plateforme LGTM préproduction et production sur Kubernetes

**Cible :** déployer la même plateforme d'observabilité **LGTM** (Loki, Grafana, Tempo, Mimir) avec **Apache Kafka**, **OpenTelemetry Collector**, haute disponibilité, intégration **ReadonlyREST**, **LDAP**, vue unique, SCOM **2019** et AppDynamics **on-premises**, sur un **cluster Kubernetes**, en **hors ligne** (images et charts issus d'un **registre privé**, par exemple Artifactory).

Ce document est **autonome**. Il ne suppose pas d'avoir suivi un autre runbook. L'architecture logique, les ADR et l'étude d'impact sont dans `architecture/`. Le composant ACL est dans `scripts/` (CronJob inclus). Le tableau de bord d'accueil est dans `dashboards/one_screen_home.json`. Des extraits de `values.yaml` figurent aussi dans `k8s/`.

---

> **Versions épinglées :** Elasticsearch **8.19.0**, ReadonlyREST Enterprise **1.72.0** (`ES_VERSION`, `ROR_VERSION` dans [`variables/environnements.env`](variables/environnements.env) — paquet `readonlyrest-1.72.0_es8.19.0.zip`). Le build ROR doit correspondre exactement à la version ES. Voir [ADR-004](architecture/adr/ADR-004_ROR_vs_XPack.md) et le §13.
>
> **Hypothèses à valider :**
> - Cluster Kubernetes déjà existant (version 1.24+ recommandée pour les charts récents — **à confirmer** avec les notes du chart retenu), avec StorageClass, Ingress controller, et accès à un registre privé.
> - Stockage objet : à trancher via la [checklist de décision](architecture/annexes/Checklist_decision_stockage_objet.md) (S3 existant **prioritaire** si les critères sont remplis, sinon Annexe C MinIO, éventuellement dans le cluster ; licence AGPLv3 à valider).
> - Noms des groupes AD, FQDN d'Ingress, ressources (les budgets sont des **estimations**).
> - Licence Grafana Enterprise **non** supposée.
> - Elasticsearch **8.19.0** + ROR Enterprise **1.72.0** déjà en place (souvent **hors** du cluster) ; ElastAlert2 inchangé.
> - Version Kibana à aligner sur `KIBANA_VERSION` (exemple 8.19.0) pour le greffon ROR Kibana.

> **Sécurité :** jamais de secret en clair dans un manifeste Git. Utiliser des `Secret` créés hors bande (`kubectl create secret ... --from-file=`), fichiers `0600` / `0400`. Pas de mot de passe sur la ligne de commande dans l'historique local. Vérifications sans affichage de secret.

---

### Versions de référence des composants (28 octobre 2026)

Mêmes versions applicatives que le déploiement VM, à revérifier :

| Composant | Version de référence |
|---|---|
| Apache Kafka | 4.4.0 (KRaft) |
| Grafana OSS | 13.2.4 |
| Mimir | 3.2.3 |
| Loki | 3.7.9 |
| Tempo | 3.1.1 |
| otelcol-contrib | 0.164.0 |
| Prometheus (si agent / sidecar) | 3.15.1 |
| Elasticsearch (existant, souvent hors cluster) | **8.19.0** (`ES_VERSION`) |
| ReadonlyREST Enterprise | **1.72.0** (`ROR_VERSION`) — paquet `readonlyrest-1.72.0_es8.19.0.zip` |

### Charts Helm — noms officiels, versions à relire à l'installation

Fin 2025, Grafana Labs a déplacé plusieurs charts communautaires vers le dépôt **`grafana-community`**. Les charts laissés dans `grafana/helm-charts` pour Loki / Tempo / Grafana sont signalés **dépréciés** et ne reçoivent plus de correctifs. Ne pas utiliser le chart parapluie `lgtm-distributed`, également déprécié.

| Composant | Dépôt et chart à utiliser | Remarques |
|---|---|---|
| Mimir | `grafana/mimir-distributed` (`https://grafana.github.io/helm-charts`) | Source dans le dépôt Grafana Mimir. Une dépréciation au profit de `grafana-community` a été **annoncée** (suivre les notes du chart au moment de l'install). |
| Loki | `grafana-community/loki` (`https://grafana-community.github.io/helm-charts`) | `deploymentMode: Distributed` ou `SimpleScalable`. Le chart `grafana/loki-distributed` est déprécié. |
| Tempo | `grafana-community/tempo-distributed` | Le chart `grafana/tempo-distributed` historique est déprécié / déplacé. |
| Grafana | `grafana-community/grafana` | Correspondant applicatif 13.2.4 observé sur une revue de charts fin octobre 2026 (chart ≈ 14.0.x) — **à vérifier sur Artifact Hub**. |
| Kafka | **Strimzi** (`https://strimzi.io`) | Opérateur + CR `Kafka`. Vérifier que la version Strimzi retenue **prend en charge Kafka 4.4**. |
| OpenTelemetry | `open-telemetry/opentelemetry-operator` (et éventuellement `opentelemetry-kube-stack`) | `https://open-telemetry.github.io/opentelemetry-helm-charts` |
| cert-manager | `cert-manager` (`https://charts.jetstack.io`) | `Issuer` / `ClusterIssuer` CA interne |
| PostgreSQL | chart bitnami ou opérateur déjà en vigueur dans l'organisation | Base partagée Grafana |

**Les numéros de version de charts doivent être lus sur Artifact Hub le jour de l'installation** et figés dans un `Chart.lock` versionné. Les images correspondantes sont **recopiées** dans le registre privé.

OCI : les charts `grafana-community` sont aussi publiés en `oci://ghcr.io/grafana-community/helm-charts/<nom>` — à miroiter de la même façon.

---

## 0. Démarrage rapide

Les FQDN, VIP et le registre privé sont définis dans [`variables/environnements.env`](variables/environnements.env) — **modifier ici seulement**. Équivalent YAML fourni. Chargement :

```bash
export LGTM_ENV=prod    # ou preprod
set -a
. /chemin/vers/variables/environnements.env
set +a
```

Rendu des modèles : `LGTM_ENV=prod ./scripts/rendre-config.sh`. Le dimensionnement des **pools de nœuds** (estimations recommandées, données sensibles) figure au §1.1.

1. Miroir hors ligne : charts + images vers Artifactory (§2).
2. Namespace `lgtm`, quotas, NetworkPolicies, StorageClass (§3).
3. cert-manager et Issuer CA interne (§4).
4. Stockage objet (§5).
5. Strimzi + cluster Kafka 3 courtiers, sujets, RF=3 (§6).
6. `mimir-distributed`, `loki`, `tempo-distributed` (§7–9).
7. OpenTelemetry Operator + Collector gateway HA + pipeline `elk-es` (§10).
8. Grafana HA + PostgreSQL + Ingress + LDAP (§11–12).
9. ROR (§13), CronJob `grafana_acl_sync` (§14), vue unique (§16).
10. Vérifications, exercices (PDB, perte de pod), go-live (§17–18).

---

## 1. Architecture Kubernetes

![Architecture Kubernetes](architecture/diagrammes/02_architecture_k8s.png)

Le graphe logique est identique au déploiement VM : agents → passerelle OTLP → Kafka (`otlp_logs` / `otlp_metrics` / `otlp_spans`) → consommateurs `lgtm-loki`, `lgtm-mimir`, `lgtm-tempo`, `elk-es` → stockages et, pour les journaux, Elasticsearch + ROR. Grafana est la façade, LDAP l'identité, `grafana_acl_sync` les ACL, la vue unique l'écran d'accueil.

```mermaid
flowchart TB
  subgraph IN["Ingress TLS — cert-manager"]
    IG["${GRAFANA_FQDN}\ngrafana.obs.exemple.local"]
    IO["${OTEL_GW_FQDN}\notel-gw.obs.exemple.local"]
  end
  subgraph NS["Namespace lgtm"]
    COL["OpenTelemetry Collector gateway × N<br/>PDB + anti-affinité"]
    SK["Strimzi Kafka KRaft 3 brokers<br/>RF=3 min.ISR=2"]
    MM["mimir-distributed"]
    LK["loki Distributed / SimpleScalable"]
    TP["tempo-distributed"]
    GF["grafana × 2+  PDB  PostgreSQL"]
    ACL["CronJob grafana-acl-sync"]
  end
  ART["Registre ${REGISTRY_FQDN}"]
  S3["S3 ${S3_FQDN}"]
  ES["ES ${ES_FQDN} + ROR"]
  AD["AD LDAPS"]
  IO --> COL --> SK
  SK --> MM --> S3
  SK --> LK --> S3
  SK --> TP --> S3
  SK --> ES
  IG --> GF
  GF --> MM
  GF --> LK
  GF --> TP
  GF --> ES
  AD --> GF
  ACL --> GF
  ART -.-> NS
```

**Résilience Kubernetes (obligatoire sur les charges critiques) :**

- `PodDisruptionBudget` : `minAvailable: 1` (ou `maxUnavailable: 1` si le nombre de réplicas le permet) pour que `drain` ne casse pas le quorum.
- `affinity.podAntiAffinity` (`required` en prod pour Kafka, ingesters, Grafana) : pas deux pods critiques sur le même nœud.
- `topologySpreadConstraints` sur une clé de zone (`topology.kubernetes.io/zone`) lorsqu'il y a plusieurs zones.
- `resources.requests` = budget réel, `limits` calés ; pas de BestEffort.
- Sondes `readiness` / `liveness` officiels des charts (`/ready`).
- Volumes persistants pour Kafka, PostgreSQL, WAL ; **pas** de RWO unique pour un composant censé être multi-réplicas.

### 1.1 Pools de nœuds — estimations recommandées

Équivalent Kubernetes des tableaux VM du [document d'architecture, §8](architecture/01_Document_architecture.md) et du runbook VM. **Estimations recommandées** pour une organisation à **données sensibles** : préprod et prod sur des clusters **séparés**, au moins trois zones (`topology.kubernetes.io/zone`), séparation des rôles par pools, nœuds d'administration / ingress dédiés, pas de point unique de défaillance, StorageClass chiffrée, réseaux / NetworkPolicies par zone. Justification dans le document d'architecture. À recalibrer après observation.

**Préproduction :**

| Pool | Nœuds | vCPU / RAM / disque par nœud | Usage | Zones |
|---|---|---|---|---|
| ingest | 2 | 4 / 8 Go / 100 Go | passerelle OTel, agent Prometheus | A, B |
| kafka | 3 | 4 / 16 Go / 350 Go local | StatefulSet Kafka (Strimzi) | A, B, C |
| lgtm | 6 | 4 / 16 Go / 150 Go | Mimir, Loki, Tempo (anti-affinité) | A, B, C (2 chacun) |
| ui | 2 | 2 / 8 Go / 120 Go | Grafana, PostgreSQL | A, C |
| objet | 0 ou 4 | 4 / 8 Go / 1 To | MinIO, si pas de S3 existant | A, B, C, A |
| system | 2 (ou existant) | 4 / 8 Go | Ingress, cert-manager, opérateurs | A, B |

**Production :**

| Pool | Nœuds | vCPU / RAM / disque par nœud | Usage | Zones |
|---|---|---|---|---|
| ingest | 3 | 6 / 16 Go / 150 Go | passerelle OTel, agent Prometheus | A, B, C |
| kafka | 3 | 8 / 32 Go / 850 Go local | StatefulSet Kafka | A, B, C |
| lgtm-write | 3 | 16 / 64 Go / 250 Go | ingesters / write Mimir, Loki, Tempo | A, B, C |
| lgtm-read | 3 | 8 / 32 Go / 100 Go | couches de requête | A, B, C |
| lgtm-backend | 3 | 8 / 32 Go / 150 Go | store-gateway, compacteurs, Alertmanager | A, B, C |
| ui | 2 | 4 / 16 Go / 200 Go | Grafana, PostgreSQL | A, C |
| objet | 0 ou 4 | 8 / 16 Go / 2 To | MinIO, si pas de S3 existant | A, B, C, A |
| system | 3 | 4 / 16 Go | Ingress, opérateurs | A, B, C |

Les FQDN d'Ingress sont `${GRAFANA_FQDN}` et `${OTEL_GW_FQDN}` (exemples : `grafana.obs.exemple.local`, `otel-gw.obs.exemple.local` ; préprod : `obs-pp.exemple.local`).

---

## 2. Miroir hors ligne (registre privé)

Aucune VM du cluster n'a d'accès Internet. Sur un poste connecté :

1. Télécharger les charts (`helm pull grafana/mimir-distributed --version <figée>`) et leurs dépendances.
2. Lister les images (`helm template ... | grep image:`) et les recopier (`skopeo copy` ou `docker pull` + `docker push` vers `${REGISTRY_FQDN}/...`).
3. Recopier aussi les images d'opérateurs (Strimzi, cert-manager, OpenTelemetry), les sidecars (rollout-operator de Mimir, etc.) et les init containers. **Un oubli se voit au premier `ImagePullBackOff`.**
4. Vérifier les empreintes / signatures lorsque le projet en publie (cosign, si utilisé en interne).
5. Dans tous les `values.yaml`, remplacer `image.registry` / `image.repository` par le chemin Artifactory. `imagePullSecrets` si le registre est authentifié (Secret `docker-registry` créé hors bande).
6. `helm` s'installe depuis une archive officielle, pas via un script `https://get.helm.sh` exécuté en prod. Les charts sont ajoutés en local : `helm repo add` vers un miroir HTTP interne, ou installation depuis le fichier `.tgz`.

```
# Exemple — registre et versions à adapter
helm install mimir ./charts/mimir-distributed-<ver>.tgz \
  --namespace lgtm --create-namespace \
  -f k8s/mimir-values.yaml \
  --set image.repository=${REGISTRY_FQDN}/grafana/mimir
```

---

## 3. Préparation du cluster

```
kubectl create namespace lgtm
kubectl apply -f k8s/namespace-policies.yaml   # NetworkPolicy, ResourceQuota — à rédiger selon le réseau réel
```

- NetworkPolicy : n'autoriser vers Kafka que les Collector et les consommateurs ; vers Grafana seulement l'Ingress et le CronJob ACL ; vers l'extérieur (ES, AD, S3) uniquement les pods concernés.
- StorageClass : disques basés sur SSD pour Kafka (IOPS), classe adaptée à PostgreSQL. **Confirmer** les noms des classes avec l'exploitation du cluster.
- Priorités / `PriorityClass` pour Kafka et les ingesters, afin qu'ils ne soient pas évincés au profit d'un batch.

SELinux : si les nœuds sont RHEL 8 avec SELinux enforcing, les collines (`scc` OpenShift, ou politiques) doivent permettre les ports et volumes des charts. À valider sur le cluster réel (**non testé** ici).

---

## 4. Certificats — cert-manager et SAN

La règle du SAN est **identique** à tout autre déploiement : **le FQDN que le client utilise doit figurer dans le SAN**. Un certificat qui ne contient que le nom court d'un pod ou d'un Service, alors que le client appelle `${ES_FQDN}` ou `kibana.exemple.local`, produit :

```
x509: certificate is valid for <nom-court>, not <fqdn-client>
```

### 4.1 cert-manager et CA interne

Installer cert-manager depuis le miroir. Importer le CA d'entreprise (et sa clé, **Secret 0400**, hors Git) :

```
# Extrait — Issuer CA interne (cert-manager.io/v1)
apiVersion: cert-manager.io/v1
kind: ClusterIssuer
metadata:
  name: pki-interne
spec:
  ca:
    secretName: entreprise-ca   # Secret dans le namespace cert-manager
```

Les `Certificate` demandent explicitement les DNS names du **VIP / Ingress / Service DNS** utilisés par les clients :

```
apiVersion: cert-manager.io/v1
kind: Certificate
metadata:
  name: grafana-tls
  namespace: lgtm
spec:
  secretName: grafana-tls
  issuerRef:
    name: pki-interne
    kind: ClusterIssuer
  duration: 2160h          # 90 jours — à aligner sur la politique PKI
  renewBefore: 720h        # 30 jours : laisse une marge pour l'alerte
  commonName: ${GRAFANA_FQDN}
  dnsNames:
    - ${GRAFANA_FQDN}
    - grafana.lgtm.svc
    - grafana.lgtm.svc.cluster.local
```

Répéter pour `${OTEL_GW_FQDN}`, Mimir, Loki, Tempo, Kafka (Strimzi peut s'intégrer à cert-manager — suivre la doc Strimzi de la version retenue), et pour le certificat **présentée par ES** si ES est dans le cluster. Si ES est hors cluster, le certificat reste géré comme un service VM : même exigence de SAN, même contrôle `openssl`.

### 4.2 Distribution de la confiance

- `Secret` du CA monté en volume dans les pods (Collector `tls.ca_file`, Grafana `tlsCACert`).
- Paquet CA dans le `ConfigMap` / truststore des images si l'organisation le fait au build.
- Jamais `insecureSkipVerify: true` en préprod ou prod.

### 4.3 Vérification et erreurs

```
# Depuis un pod debug ou un bastion, SNI = FQDN client
openssl s_client -connect ${GRAFANA_FQDN}:443 -servername ${GRAFANA_FQDN} </dev/null 2>/dev/null \
  | openssl x509 -noout -subject -issuer -dates -ext subjectAltName
```

Le FQDN doit apparaître. Tableau des erreurs (identique en substance) :

| Symptôme | Cause | Action |
|---|---|---|
| `x509: certificate is valid for X, not Y` | SAN incomplet | Ajouter le FQDN au `Certificate`, laisser cert-manager renouveler, redémarrer les pods qui cachent le Secret |
| `unknown authority` | CA non monté | Volume + `ca_file` / `update-ca-trust` dans l'image |
| `certificate has expired` | Renouvellement cassé | `kubectl describe certificate`, événements cert-manager, `renewBefore` |
| `ImagePullBackOff` après renouvellement | Sans rapport direct | Ne pas confondre avec un problème TLS |

```mermaid
sequenceDiagram
  participant CM as cert-manager
  participant ISS as ClusterIssuer CA interne
  participant SEC as Secret TLS
  participant POD as Pod Grafana / Collector
  participant CL as Client
  CM->>ISS: signer CSR (dnsNames = FQDN d'Ingress)
  ISS-->>CM: certificat + chaîne
  CM->>SEC: écrire tls.crt / tls.key
  POD->>SEC: monté, rechargé (Ingress / sidecar)
  CL->>POD: SNI=FQDN
  POD-->>CL: certificat dont le SAN contient le FQDN
```

Rotation : cert-manager renouvelle automatiquement avant `renewBefore`. **Tester** qu'Ingress et les pods rechargent sans interruption (selon le contrôleur : rechargement à chaud ou rolling). Alerter si `Certificate` n'est pas `Ready`.

mTLS Kafka : Strimzi le prend en charge (`tls` + `authentication: type: tls`). Optionnel en première étape, recommandé ensuite. **Non testé** ici.

---

## 5. Stockage objet

**Étape de décision obligatoire**, avant de déployer Mimir / Loki / Tempo et avant de provisionner un Tenant MinIO. Remplir la [checklist](architecture/annexes/Checklist_decision_stockage_objet.md) avec l'équipe stockage / infrastructure ([ADR-002](architecture/adr/ADR-002_Stockage_objet.md)). Renseigner `STOCKAGE_OBJET_SCENARIO` (`hitachi` ou `minio`), `S3_ENDPOINT`, `S3_CA_FILE` et `S3_FORCE_PATH_STYLE` dans `variables/environnements.env` (**modifier ici seulement**).

**Questions** (Q0–Q10 de la checklist) : avez-vous un **HCP** (HS3) ou un **VSP One Object** ? Un **HNAS seul ne suffit pas**. FQDN du tenant / endpoint, path-style ou virtual-hosted, TLS et CA, IAM, capacité, rétention (`DeleteObjects` HCP), réseau et NetworkPolicy.

**Critères essentiels** pour le scénario A : API **S3 serveur** réellement utilisable par Mimir, Loki et Tempo ; ce n'est pas un HNAS ni un NFS ; TLS avec vérification ; IAM moindre privilège ; capacité ; réseau testé.

```mermaid
flowchart TD
  A["Checklist équipe stockage"] --> B{"HCP HS3 ou VSP One Object ?"}
  B -->|oui, critères OK| C["Scénario A — Hitachi<br/>STOCKAGE_OBJET_SCENARIO=hitachi<br/>Annexe D"]
  B -->|"HNAS seul"| D["Pas une cible S3"]
  D --> E{"Obtenir HCP / VSP One Object ?"}
  E -->|oui| C
  E -->|non| F
  B -->|aucun S3 serveur| F["Scénario B — MinIO<br/>STOCKAGE_OBJET_SCENARIO=minio<br/>Annexe C, AGPLv3 à valider"]
  G["NFS comme backend des blocs"] --> H["Rejeté — doc Grafana Labs"]
```

- **Scénario A** (`STOCKAGE_OBJET_SCENARIO=hitachi`) : pointer `S3_ENDPOINT` vers le tenant HCP ou VSP One Object (authentification AWS : **sans** `/hs3`), seaux = espaces de noms, identifiants dans un `Secret`, CA montée (`${S3_CA_FILE}`), `insecure: false`, `S3_FORCE_PATH_STYLE` selon le DNS. Ne **pas** déployer MinIO. Procédure : [Annexe Hitachi](architecture/annexes/Annexe_Stockage_objet_Hitachi_HCP_S3.md) et **[Annexe D](#annexe-d--scénario-a--stockage-objet-hitachi-hcp--vsp-one-object)**. **Non testé.**
- **Scénario B** (`STOCKAGE_OBJET_SCENARIO=minio`) : MinIO distribué, **[Annexe C](#annexe-c--scénario-b--minio-distribué-aucun-stockage-objet-s3)** et [Annexe MinIO](architecture/annexes/Annexe_Stockage_objet_S3_MinIO.md) (opérateur ou chart officiel, quatre pods, TLS cert-manager, erasure coding, IAM, `mc mirror`, supervision). **Avant** l'installation : licence **AGPLv3**. **Non testé.**
- **NFS** (export HNAS compris) comme backend des blocs : **rejeté** (documentation Grafana Labs).

Décision écrite, datée.

---

## 6. Kafka avec Strimzi (KRaft, RF=3)

Vérifier la matrice de compatibilité Strimzi / Kafka **4.4.0** avant de figer le chart.

Extrait de CR (à adapter, **non testé** contre Kafka 4.4 dans ce dépôt) :

```
apiVersion: kafka.strimzi.io/v1beta2
kind: Kafka
metadata:
  name: lgtm
  namespace: lgtm
spec:
  kafka:
    version: 4.4.0          # si supporté par l'opérateur retenu
    replicas: 3
    listeners:
      - name: tls
        port: 9093
        type: internal
        tls: true
      - name: external      # si otel hors cluster
        port: 9094
        type: ingress       # ou loadbalancer — à décider
        tls: true
    config:
      default.replication.factor: 3
      min.insync.replicas: 2
      offsets.topic.replication.factor: 3
      transaction.state.log.replication.factor: 3
      transaction.state.log.min.isr: 2
      auto.create.topics.enable: false
      log.retention.hours: 72          # hypothèse 3 jours
    storage:
      type: persistent-claim
      size: 200Gi                      # estimation
      class: <storageclass-rapide>
    template:
      pod:
        affinity:
          podAntiAffinity:
            requiredDuringSchedulingIgnoredDuringExecution:
              - labelSelector:
                  matchLabels:
                    strimzi.io/name: lgtm-kafka
                topologyKey: kubernetes.io/hostname
    resources:
      requests: { cpu: "2", memory: 8Gi }
      limits:   { cpu: "4", memory: 16Gi }
  entityOperator:
    topicOperator: {}
    userOperator: {}
# En KRaft, le formalisme contrôleurs (process.roles, KRaft combined ou dédié)
# dépend de la version Strimzi : suivre LE guide de cette version, ne pas copier
# un exemple ZooKeeper (Kafka 4 n'a plus ZooKeeper).
```

`PodDisruptionBudget` est généralement créé par Strimzi : le vérifier (`kubectl get pdb -n lgtm`).

Sujets, via `KafkaTopic` (Topic Operator) :

```
apiVersion: kafka.strimzi.io/v1beta2
kind: KafkaTopic
metadata:
  name: otlp-logs
  namespace: lgtm
  labels:
    strimzi.io/cluster: lgtm
spec:
  topicName: otlp_logs
  partitions: 6
  replicas: 3
  config:
    min.insync.replicas: "2"
    retention.ms: "259200000"
    compression.type: zstd
```

Répéter pour `otlp_metrics` et `otlp_spans`. Vérification :

```
kubectl -n lgtm get kafka lgtm -o wide
# Outil kafka-topics depuis un pod d'outils Strimzi, bootstrap = Service interne
```

Les groupes `lgtm-*` et `elk-es` n'apparaissent qu'après le démarrage des consommateurs.

---

## 7. Mimir — chart `grafana/mimir-distributed`

Documentation : [mimir-distributed Helm](https://grafana.com/docs/mimir/latest/set-up/helm-chart/).

Extrait `k8s/mimir-values.yaml` (indicatif) :

```
# Miroir
image:
  repository: ${REGISTRY_FQDN}/grafana/mimir
# Désactiver MinIO embarqué si S3 externe
minio:
  enabled: false
mimir:
  structuredConfig:
    common:
      storage:
        backend: s3
        s3:
          endpoint: ${S3_FQDN}
          bucket_name: lgtm-mimir
          insecure: false
    ingester:
      ring:
        replication_factor: 3
# Réplicas : estimations préprod
ingester:
  replicas: 3
  zoneAwareReplication:
    enabled: true
  affinity:
    podAntiAffinity:
      requiredDuringSchedulingIgnoredDuringExecution:
        - labelSelector: { matchLabels: { app.kubernetes.io/component: ingester } }
          topologyKey: kubernetes.io/hostname
distributor:
  replicas: 2
querier:
  replicas: 2
query_frontend:
  replicas: 2
store_gateway:
  replicas: 3
  zoneAwareReplication:
    enabled: true
compactor:
  replicas: 2
alertmanager:
  replicas: 3
  statefulSet:
    enabled: true
# PDB : souvent fournis par le chart — vérifier et durcir
```

Les identifiants S3 viennent d'un `Secret` (clés `access_key_id` / `secret_access_key` selon le schéma du chart — **lire les values du chart figé**). Alertmanager en cluster (réplicas ≥ 3). Valider : `kubectl -n lgtm port-forward svc/mimir-nginx 8080:80` puis `/ready` (en préprod) ; en prod, Ingress TLS interne.

Consommateur Kafka : soit un Collector dédié (OpenTelemetry Operator, pipeline `otlp_metrics` → `lgtm-mimir` → OTLP Mimir), soit, si le chart expose une ingestion Kafka native dans la version retenue, la configuration officielle. Le modèle Collector est celui déjà validé conceptuellement (groupe `lgtm-mimir`).

---

## 8. Loki — chart `grafana-community/loki`

```
# k8s/loki-values.yaml — indicatif
deploymentMode: Distributed          # ou SimpleScalable
loki:
  image:
    registry: ${REGISTRY_FQDN}
  storage:
    type: s3
    bucketNames:
      chunks: lgtm-loki
      ruler: lgtm-loki
      admin: lgtm-loki
    s3:
      endpoint: ${S3_FQDN}
      insecure: false
  schemaConfig:
    # COPIER le schema_config documenté pour Loki 3.7.9 — ne pas l'inventer
    configs: []
  ingester:
    lifecycler:
      ring:
        replication_factor: 3
ingester:
  replicas: 3
  maxUnavailable: 1
querier:
  replicas: 2
distributor:
  replicas: 2
backend:
  replicas: 3
gateway:
  replicas: 2
minio:
  enabled: false
```

`kubectl` : PDB, anti-affinité, `/ready` du gateway. Consommateur : groupe `lgtm-loki`, sujet `otlp_logs`.

---

## 9. Tempo — chart `grafana-community/tempo-distributed`

```
# k8s/tempo-values.yaml — indicatif
tempo:
  # image miroir
storage:
  trace:
    backend: s3
    s3:
      bucket: lgtm-tempo
      endpoint: ${S3_FQDN}
      insecure: false
distributor:
  replicas: 2
ingester:
  replicas: 3
  topologySpreadConstraints: []     # à renseigner avec la zone
querier:
  replicas: 2
queryFrontend:
  replicas: 2
compactor:
  replicas: 2
metricsGenerator:
  enabled: true
  config:
    storage:
      remote_write:
        - url: http://mimir-nginx.lgtm.svc:80/api/v1/push
minio:
  enabled: false
```

Consommateur : groupe `lgtm-tempo`, sujet `otlp_spans`. Le metrics-generator alimente la carte des services Grafana. Le compteur d'acceptation de traces n'apparaît qu'après le premier span.

---

## 10. OpenTelemetry Operator et passerelle HA

Chart `open-telemetry/opentelemetry-operator`. L'opérateur exige cert-manager (webhooks). CR `OpenTelemetryCollector` en mode **deployment** (gateway), réplicas ≥ 2 (3 en prod) :

```
apiVersion: opentelemetry.io/v1beta1
kind: OpenTelemetryCollector
metadata:
  name: gateway
  namespace: lgtm
spec:
  mode: deployment
  replicas: 3
  image: ${REGISTRY_FQDN}/otel/otelcol-contrib:0.164.0
  upgradeStrategy: automatic
  podDisruptionBudget:
    minAvailable: 2
  affinity:
    podAntiAffinity:
      requiredDuringSchedulingIgnoredDuringExecution:
        - labelSelector:
            matchLabels:
              app.kubernetes.io/name: gateway-collector
          topologyKey: kubernetes.io/hostname
  env:
    - name: ES_USER
      value: otel-writer
    - name: ES_PASSWORD
      valueFrom:
        secretKeyRef:
          name: otel-es-writer
          key: password
  volumeMounts:
    - name: ca
      mountPath: /certs
      readOnly: true
  volumes:
    - name: ca
      secret:
        secretName: entreprise-ca-bundle
  config:
    # Même logique que le déploiement VM : récepteur OTLP,
    # exportateur kafka (acks=-1, zstd, sujets otlp_*),
    # récepteur kafka/elk groupe elk-es, topics [otlp_logs],
    # exportateur elasticsearch user/password (PAS d'api_key ROR),
    # kafka_metrics vers Mimir.
    # Le YAML exact est celui de la section passerelle du paquet
    # (adapters brokers = lgtm-kafka-bootstrap.lgtm.svc:9093, TLS).
```

> ROR ne fournit pas `POST /_security/api_key`. L'exportateur utilise `user` / `password` (Secret). L'endpoint ES est le **FQDN du SAN**.
>
> Indentation du bloc `logs: topics: [otlp_logs]` : un oubli envoie le récepteur sur un sujet par défaut (`otel_logs` possible) et produit `UNKNOWN_TOPIC_OR_PARTITION`.
>
> Noms d'exportateurs 0.164.0 : `otlp_http` / `otlp_grpc` (les anciens noms sont obsolètes).

Ingress ou Service LoadBalancer `${OTEL_GW_FQDN}` : ports 4317 (gRPC) et 4318 (HTTPS). Certificat cert-manager, SAN = ce FQDN.

Un second Collector (ou le même, pipelines distincts) peut consommer `otlp_metrics` / `otlp_spans` / `otlp_logs` vers Mimir / Tempo / Loki s'ils ne sont pas consommés autrement. DaemonSet optionnel pour les journaux et métriques des nœuds Kubernetes.

Prometheus : soit un agent (Deployment) en `remote_write` vers Mimir, soit le chart `kube-prometheus-stack` en mode agent, images miroir. Hors Kafka.

---

## 11. Grafana HA, Ingress, PostgreSQL

Chart `grafana-community/grafana` :

```
# k8s/grafana-values.yaml — indicatif
replicas: 2
image:
  registry: ${REGISTRY_FQDN}
  tag: 13.2.4
podDisruptionBudget:
  minAvailable: 1
affinity:
  podAntiAffinity:
    requiredDuringSchedulingIgnoredDuringExecution:
      - labelSelector: { matchLabels: { app.kubernetes.io/name: grafana } }
        topologyKey: kubernetes.io/hostname
persistence:
  enabled: false          # l'état est dans PostgreSQL, pas dans un PVC local
grafana.ini:
  analytics:
    reporting_enabled: false
    check_for_updates: false
  plugins:
    preinstall_disabled: true
  database:
    type: postgres
    host: postgresql.lgtm.svc:5432
    name: grafana
    user: grafana
    ssl_mode: require
  server:
    root_url: https://${GRAFANA_FQDN}
    domain: ${GRAFANA_FQDN}
  auth.ldap:
    enabled: true
    config_file: /etc/grafana/ldap.toml
    allow_sign_up: true
# Mot de passe DB et admin d'urgence : Secret (GF_DATABASE_PASSWORD, GF_SECURITY_ADMIN_PASSWORD)
envFromSecrets:
  - grafana-env
ingress:
  enabled: true
  ingressClassName: <classe>
  hosts: [${GRAFANA_FQDN}]
  tls:
    - secretName: grafana-tls
      hosts: [${GRAFANA_FQDN}]
# ldap.toml monté depuis un Secret 0400
# datasources : provisioning, même contenu logique que le déploiement VM
# (Mimir, Loki, Tempo, ES basicAuth grafana-reader, $__file ou Secret)
datasources:
  datasources.yaml:
    apiVersion: 1
    datasources: []    # remplir : voir le YAML du paquet VM, URLs internes ou Ingress
```

PostgreSQL : 2 instances (opérateur ou chart déjà approuvé), TLS, sauvegardes, test de restauration. Grafana **sans PVC d'état** : les deux pods sont interchangeables.

LDAP : même `ldap.toml` que dans l'architecture (LDAPS, `ssl_skip_verify = false`, `group_mappings`). Fichier dans un Secret.

« Save & test » sur chaque source. L'URL Elasticsearch = FQDN du SAN.

---

## 12. Authentification LDAP et équipes (mécanisme **principal**)

**LDAP / LDAPS est le mécanisme d'authentification principal** de Grafana OSS, aussi en Kubernetes ([ADR-006](architecture/adr/ADR-006_Authentification_LDAP.md)). Grafana OSS mappe les groupes AD vers Admin / Editor / Viewer au login ([doc LDAP](https://grafana.com/docs/grafana/latest/setup-grafana/configure-access/configure-authentication/ldap/)). **Team Sync est Grafana Enterprise** ([doc](https://grafana.com/docs/grafana/latest/setup-grafana/configure-access/configure-team-sync/)) : le CronJob `grafana_acl_sync` (§14) pose les équipes, dossiers et permissions. Les **mêmes groupes AD** alimentent ReadonlyREST Enterprise (§13). ConfigMap / volume pour `ldap.toml` (`0640`), mot de passe de liaison dans un `Secret` monté en fichier, jamais en clair dans les values. CA d'AD montée pour LDAPS 636 (`ssl_skip_verify = false`). Compte d'urgence local au coffre.

```mermaid
sequenceDiagram
  participant U as Utilisateur
  participant IN as Ingress ${GRAFANA_FQDN}
  participant GF as Pod Grafana
  participant AD as AD LDAPS
  participant PG as PostgreSQL
  U->>IN: HTTPS /login
  IN->>GF: TLS SAN=${GRAFANA_FQDN}
  GF->>AD: liaison + sAMAccountName
  AD-->>GF: memberOf
  GF->>GF: premier group_mappings → rôle Org
  GF->>PG: utilisateur créé ou mis à jour
  GF-->>U: session (partagée via PG)
```

Compte d'urgence local au coffre.

---


Le **SSO** (OIDC vers AD FS, Kerberos / Auth Proxy, ou oauth2-proxy) est un **complément optionnel**, documenté en **[Annexe B](#annexe-b--sso-grafana-oss-en-kubernetes-complément-optionnel)**. Il ne remplace pas LDAP.

---


## 13. ReadonlyREST Enterprise

**ROR est en édition Enterprise 1.72.0**, sur **Elasticsearch 8.19.0** (`ROR_VERSION`, `ES_VERSION` dans [`variables/environnements.env`](variables/environnements.env) — paquet `readonlyrest-1.72.0_es8.19.0.zip`). Sources : [ADR-004](architecture/adr/ADR-004_ROR_vs_XPack.md), [For Elasticsearch](https://docs.readonlyrest.com/elasticsearch) (installation, patch), [For Kibana](https://docs.readonlyrest.com/kibana), [Audit](https://docs.readonlyrest.com/elasticsearch/audit), [changelog 1.72.0](https://docs.readonlyrest.com/changelog) (11 octobre 2026).

Le cluster ES est souvent **hors** du cluster Kubernetes : dans ce cas, suivre le §13.0 du [runbook VM](Runbook_LGTM_Prod_VM_RHEL8.md) (commandes officielles d'installation hors ligne, patch et mise à jour). **Non testé** dans ce dépôt.

**Installation officielle** (rappel, nœud arrêté pour une mise à jour, chemin absolu, trois barres après `file:`) :

```
bin/elasticsearch-plugin install file:///chemin/absolu/readonlyrest-1.72.0_es8.19.0.zip
```

À l'invite des permissions, répondre **`y`**. **Patch obligatoire** (ES ≥ 6.7.0). Pour ES **8.3+** (donc 8.19.0), le patch **exige root**. Depuis la racine ES :

```
jdk/bin/java -jar plugins/readonlyrest/ror-tools.jar patch --I_UNDERSTAND_AND_ACCEPT_ES_PATCHING=yes
jdk/bin/java -jar plugins/readonlyrest/ror-tools.jar verify
```

Java **17** au minimum pour ES 8.x (tableau officiel). Mise à jour : `unpatch` puis `elasticsearch-plugin remove readonlyrest`, puis installer le nouveau zip et `patch`. Upgrade ES : unpatch et désinstallation **avant** l'upgrade, puis build ROR aligné et re-patch (risque de corruption sinon, avertissement officiel).

**Si Elasticsearch est déployé dans le cluster** (ECK ou équivalent) : suivre la documentation officielle ROR pour ECK ([installation](https://docs.readonlyrest.com/elasticsearch)) — image personnalisée hors ligne qui installe le zip `readonlyrest-1.72.0_es8.19.0.zip` et exécute le `patch` **en root** (`I_UNDERSTAND_AND_ACCEPT_ES_PATCHING=yes`). Ne pas inventer de manifeste ici ; caler sur la page officielle de la version. Service interne, NetworkPolicy, certificat SAN = nom DNS que les Collector utilisent (`es.observabilite.svc` **et** tout alias externe).

**Greffon Kibana :** schéma documenté `readonlyrest_kbn_universal-1.72.0_es8.19.0.zip` — **vérifier le nom exact livré par le portail**, aligner `KIBANA_VERSION`. Patch Kibana 8.15+ Linux : `node/glibc-217/bin/node plugins/readonlyrestkbn/ror-tools.js patch` ([For Kibana](https://docs.readonlyrest.com/kibana)). Si Kibana est derrière un Ingress / mandataire : `readonlyrest_kbn.trusted_proxies` dans `kibana.yml` (changelog 1.72.0 : `none`, `all`, ou liste d'IP / CIDR).

- **Ne pas** appeler `POST /_security/api_key`. **Ne pas** utiliser `ssl_hostname_verification` (absent de 1.72.0 ; introduit dans le changelog 1.73.1).
- Comptes `otel-writer` et `grafana-reader`, `auth_key_pbkdf2` (HmacSHA512, 10 000 itérations, sel = valeur). Hachage par `getpass` (aucun écho). Extra : `scripts/ror-acl-groups.example.yml`.
- Blocs **en tête**. Connecteur `ldaps` et `ldap_auth` (port 636, `ssl_trust_all_certs: false`, mot de passe `${env:ROR_LDAP_BIND_PASSWORD}` dans un Secret) : **mêmes groupes AD** que Grafana (§12).
- **Rechargement à chaud** depuis l'application Kibana ROR (index `.readonlyrest`), sans redémarrer Elasticsearch. `readonlyrest.force_load_from_file: true` uniquement en **secours** si l'index est corrompu ([documentation](https://docs.readonlyrest.com/kibana)).
- **Audit :** `audit.enabled: true`, sortie `index` (modèle `readonlyrest_audit-*`), bloc `forbid` de protection, tableau de bord depuis l'onglet Audit Kibana ROR. En 1.72.0, un *ingest pipeline* optionnel et un mode `failover` pour un cluster d'audit distant sont documentés — caler la syntaxe sur la [doc Audit](https://docs.readonlyrest.com/elasticsearch/audit).
- **Multi-tenancy Kibana** (Enterprise, activée par défaut) : `kibana.index` par tenancy, `groups_any_of` alignés sur l'AD, éventuellement `readonlyrest_kbn.kibanaIndexTemplate`. `readonlyrest_kbn.cookiePass` (≥ 32 caractères depuis ROR 1.51) dans un Secret ; si plusieurs réplicas Kibana : `store_sessions_in_index: true`.
- **JWT** et `proxy_auth` : disponibles, complémentaires (Kibana derrière un mandataire, ou lien JWT). Ils ne remplacent pas LDAP. otelcol et Grafana conservent HTTP Basic.
- Actions exactes **non testées** contre otelcol 0.164.0 : ajuster d'après un 403 (journal ES), puis rechargement à chaud.

Vérification : `curl --cacert ... -u otel-writer https://${ES_FQDN}:9200/_cluster/health` (mot de passe demandé, non affiché). 403 attendu sur une action hors périmètre. Contrôler aussi un login LDAP et un événement d'audit.

---

## 14. CronJob `grafana_acl_sync`

Manifeste : `scripts/grafana-acl-sync-cronjob.yaml`.

1. Construire hors ligne une image minimale (`python:3.12` interne + script + roues `requirements.txt`), la pousser dans Artifactory.
2. `Secret` `grafana-acl-sync` : `acl-config.yaml`, `token` (compte de service Grafana), `ldap-bind-password`. `defaultMode: 0400`.
3. ConfigMap des tableaux de bord (JSON `one_screen_home.json`).
4. Adapter les chemins `token_file` / `bind_password_file` de la config aux chemins montés (`/etc/grafana-acl-sync/token`).
5. Appliquer le CronJob (`schedule: "*/15 * * * *"`, `concurrencyPolicy: Forbid`, `runAsNonRoot`, `readOnlyRootFilesystem`, `drop: ALL`).
6. Premier lancement manuel : `kubectl -n lgtm create job --from=cronjob/grafana-acl-sync acl-sync-once` puis `kubectl logs`. Codes de sortie : 0, 1, 2, 3, 4, 5 (voir `scripts/README.md`).

Validé dans ce dépôt : `py_compile`, `--help`, `--mock --dry-run`. **Non exécuté** contre un AD ni un Grafana réels, **non testé** comme CronJob sur un cluster.

Onboarding d'une équipe :

```mermaid
flowchart TD
  A["Groupe AD créé, personnes inscrites"] --> B["Mapping ajouté dans acl-config.yaml du Secret"]
  B --> C["Job --dry-run puis Job réel"]
  C --> D["Extrait ROR intégré, rechargement à chaud Enterprise"]
  D --> E["Première connexion LDAP des utilisateurs"]
  E --> F["Tour suivant : membres d'équipe, dossiers visibles"]
```

---

## 15. SCOM 2019 et AppDynamics on-premises

Même intégration logique que le déploiement VM ([ADR-008](architecture/adr/ADR-008_Integration_SCOM_AppDynamics.md), figure [06](architecture/diagrammes/06_integration_scom_appd.png)). Les FQDN viennent de `variables/environnements.env`.

- **SCOM 2019** — cycle de vie officiel : support étendu jusqu'au **10 avril 2029** (heure du Pacifique), support standard terminé le 10 avril 2024 ([lifecycle](https://learn.microsoft.com/en-us/lifecycle/products/system-center-2019-operations-manager)). Au 12 novembre 2026, produit en support étendu. Planifier la migration vers une version en support standard.
- **SCOM voie A :** récepteur `windowseventlog` (otelcol-contrib officiel) sur agents Windows ou collecteur WEF, OTLP vers `${OTEL_GW_FQDN}`. Si des charges Windows sont *dans* le cluster, ce n'est généralement pas le cas de SCOM : le flux reste hors cluster vers l'Ingress OTLP. **Non testé**.
- **SCOM voie B :** exportateur Prometheus communautaire [OpsLogix](https://github.com/opslogix/SCOM-Prometheus-Exporter), prérequis « Microsoft SCOM 2019 or later », **non officiel Microsoft**, licence AGPL-3.0, à qualifier ; scrape par l'agent, `remote_write` Mimir. **Non testé**.
- **SCOM voie C :** API REST (depuis 1801 ; UR1 : jeton CSRF `SCOM-CSRF-TOKEN`), SDK / OMCF documentés par Microsoft ([vue sc-om-2019](https://learn.microsoft.com/en-us/system-center/scom/plan-thirdparty-integration?view=sc-om-2019)). Greffon Grafana tierce OpsLogix (ni Grafana Labs, ni Microsoft) vers `${SCOM_URL}` : à qualifier. Consultation SQL des bases SCOM non retenue comme voie principale. **Non testé**.
- **AppDynamics de bout en bout :** les agents déjà en place parlent au contrôleur on-premises (HTTPS **8181**, CA interne, LDAP optionnel sur le contrôleur). Les applications OTel envoient traces / métriques / journaux à la passerelle, Kafka, Tempo / Mimir / Loki, visibles dans la vue unique (§16), corrélation `service.name` / `trace_id`. Export optionnel de la passerelle vers `${APPD_OTEL_INGEST}` uniquement si la version du contrôleur le documente. Greffon Grafana = Enterprise ; sans cette licence, lien vers `${APPD_URL}`. **Non testé.**
- **AppDynamics, contrôleur on-premises :** HTTPS **8181** (`${APPD_URL}`), HTTP 8090 à bloquer. Certificat de l'autorité interne, SAN = `${APPD_FQDN}`, CA dans le truststore Grafana. LDAP du contrôleur contre AD (LDAPS 636, `sAMAccountName`), compte local de secours. Greffon [`dlopes7-appdynamics-datasource`](https://grafana.com/docs/plugins/dlopes7-appdynamics-datasource/latest/) = **Enterprise** ; URL = `${APPD_URL}` ; à vérifier sur le contrôleur on-prem (**non testé**). Sans licence, lien + corrélation `service.name`. [AppDynamics for OpenTelemetry (On-Premises)](https://help.splunk.com/en/appdynamics-on-premises/application-performance-monitoring/26.7.0/splunk-appdynamics-for-opentelemetry/configure-the-opentelemetry-collector/configure-exporters) envoie des traces **vers** le contrôleur (`${APPD_OTEL_INGEST}`, forme documentée `https://<dns>:8181/otis/ingest`, à vérifier, non testé), pas vers Tempo.

---

## 16. Vue unique

Même tableau de bord `dashboards/one_screen_home.json` (uid `lgtm-one-screen`), provisionné par le sidecar du chart Grafana (ConfigMap) et/ou par `grafana_acl_sync`. Corrélations Mimir ↔ Tempo ↔ Loki identiques. Adapter les `job` labels. JSON validé, **non exercé** en production.

Explore : après un test, métrique de test dans Mimir, `{service_name="test-kafka"}` dans Loki, service `test-kafka` dans Tempo, `logs-*` dans ES.

---

## 17. Vérifications

```
kubectl -n lgtm get pods,pdb,ing,svc
kubectl -n lgtm get certificate
# Tous les Certificate Ready=True ; pas d'ImagePullBackOff
# /ready via Ingress ou port-forward (préprod)
# Groupes Kafka :
#   kafka-consumer-groups.sh --bootstrap-server lgtm-kafka-bootstrap.lgtm.svc:9093 --describe --group lgtm-loki
# (idem lgtm-mimir, lgtm-tempo, elk-es) — LAG → 0 après émission
```

Émission de test OTLP vers `https://${OTEL_GW_FQDN}:4318` (CA interne). Contrôle `openssl s_client` sur chaque Ingress. LDAP : une connexion réelle par rôle. ACL : logs du Job.

Ne pas interroger le port 9009 sur un pod Tempo (ni 3100 sur Mimir) : chaque service a **son** port, comme en VM. Le mélange des ports produit un silence trompeur si `-q` est utilisé.

---

## 18. Exploitation

### 18.1 Sauvegardes

PostgreSQL Grafana, `Secret` / scellés (SealedSecrets, ExternalSecrets — selon l'outil interne), charts et `values` dans Git **sans** secrets, seaux S3, CR Strimzi. Test de restauration d'un namespace de banc.

### 18.2 Mises à jour

`helm upgrade` depuis le miroir, notes officielles, préprod d'abord. Un courrier Kafka / un StatefulSet à la fois, ISR ou ring complet entre chaque. ROR : aligner le build sur la version ES. Verrouiller les versions (`image.tag`, `Chart.lock`).

### 18.3 Scénarios de panne

#### Perte d'un pod courrier Kafka

```mermaid
sequenceDiagram
  participant C as Collector
  participant K1 as kafka-0
  participant K2 as kafka-1
  participant K3 as kafka-2
  Note over K3: nœud drain ou crash
  Note over K1,K2: PDB empêche de drainer K2 en même temps
  C->>K1: produce acks=all, ISR=2, OK
  Note over K3: le contrôleur réélit les leaders
```

`kubectl -n lgtm get pdb`. Ne pas `drain` deux nœuds Kafka ensemble.

#### Perte d'un ingester

RF=3, zone-aware. LAG temporaire du groupe concerné, rattrapage. Vérifier l'objet S3 et les PVC.

#### Perte d'un pod Grafana

```mermaid
sequenceDiagram
  participant U as Utilisateur
  participant IN as Ingress
  participant G1 as grafana-0
  participant G2 as grafana-1
  participant PG as PostgreSQL
  Note over G1: evicted
  U->>IN: HTTPS
  IN->>G2: endpoints restants
  G2->>PG: état partagé
  G2-->>U: même URL
```

PDB `minAvailable: 1`. Contrôle : `https://${GRAFANA_FQDN}/api/health`.

#### Perte d'un pod Collector

Service / Ingress sur les réplicas restants. PDB `minAvailable: 2` (si 3 réplicas).

#### Certificat Ingress expiré

```mermaid
flowchart TD
  A["x509 expired / Handshake"] --> B["kubectl describe certificate -n lgtm"]
  B --> C{"cert-manager Ready ?"}
  C -->|non| D["Journal de l'Issuer, Secret CA, renewBefore"]
  C -->|oui, Secret à jour| E["Rechargement Ingress / rolling des pods"]
  E --> F["openssl s_client : nouvelles dates, SAN inchangé"]
```

#### Drain d'un nœud

Le PDB doit **bloquer** un drain qui casserait un quorum. Vérifier le message `Cannot evict pod as it would violate the pod's disruption budget` : c'est le comportement attendu. Drainer un autre nœud, ou augmenter temporairement les réplicas selon la procédure d'exploitation.

### 18.4 Supervision de la supervision

Mêmes alertes que pour tout déploiement (LAG, `up`, échecs d'export, certificats, WAL) plus : `KubePodCrashLooping`, `KubeDeploymentReplicasMismatch`, `CertificateNotReady`, `ImagePullBackOff` durable, PVC presque plein. Routage Alertmanager Mimir vers l'ITSM.

### 18.5 Go-live préprod → prod

1. Hypothèses tranchées (objet, AD, FQDN, StorageClass, licence).
2. Toutes les images et charts prod sont ceux validés en préprod (digest figé).
3. SAN de **tous** les Ingress et de ES contrôlés avant le trafic.
4. NetworkPolicies et règles d'infrastructure ouvertes.
5. Exercices : drain d'un nœud Kafka (PDB), kill d'un Grafana, kill d'un Collector, renouvellement d'un Certificate.
6. Restauration PostgreSQL testée.
7. CronJob ACL exécuté contre l'AD de préprod.
8. Double écriture : LAG `elk-es` à 0, pas de 403, échantillon comparé.
9. Vue unique OK, sources « Save & test ».
10. Alertes routées, astreinte formée, retour arrière (retrait du pipeline `logs/elk`) documenté et applicable.

---

## 19. Sources

- Charts : [grafana helm-charts](https://grafana.github.io/helm-charts), [grafana-community](https://grafana-community.github.io/helm-charts), [Artifact Hub mimir-distributed](https://artifacthub.io/packages/helm/grafana/mimir-distributed), [Mimir Helm](https://grafana.com/docs/mimir/latest/set-up/helm-chart/)
- [Strimzi](https://strimzi.io/documentation/)
- [OpenTelemetry Helm](https://open-telemetry.github.io/opentelemetry-helm-charts/)
- [cert-manager](https://cert-manager.io/docs/)
- Kafka 4.4 [KRaft](https://kafka.apache.org/44/operations/kraft/)
- SSO OSS : [ADR-011](architecture/adr/ADR-011_SSO_Grafana_OSS.md), [Auth proxy](https://grafana.com/docs/grafana/latest/setup-grafana/configure-access/configure-authentication/auth-proxy/), [Generic OAuth](https://grafana.com/docs/grafana/latest/setup-grafana/configure-access/configure-authentication/generic-oauth/), [AD FS OIDC](https://learn.microsoft.com/en-us/windows-server/identity/ad-fs/development/ad-fs-openid-connect-oauth-concepts), [oauth2-proxy](https://oauth2-proxy.github.io/oauth2-proxy/) (communautaire)
- Grafana [HA](https://grafana.com/docs/grafana/latest/setup-grafana/set-up-for-high-availability/), [LDAP](https://grafana.com/docs/grafana/latest/setup-grafana/configure-access/configure-authentication/ldap/), [Team Sync Enterprise](https://grafana.com/docs/grafana/latest/setup-grafana/configure-access/configure-team-sync/)
- [ReadonlyREST](https://docs.readonlyrest.com/elasticsearch)
- Greffon AppDynamics [Enterprise](https://grafana.com/docs/plugins/dlopes7-appdynamics-datasource/latest/)
- [AppDynamics for OpenTelemetry (On-Premises)](https://help.splunk.com/en/appdynamics-on-premises/application-performance-monitoring/26.7.0/splunk-appdynamics-for-opentelemetry/configure-the-opentelemetry-collector/configure-exporters)
- [AppDynamics on-premises — Port Settings](https://docs.appdynamics.com/appd/onprem/24.x/latest/en/planning-your-deployment/port-settings)
- [SCOM 2019 — cycle de vie](https://learn.microsoft.com/en-us/lifecycle/products/system-center-2019-operations-manager), [intégration tierce](https://learn.microsoft.com/en-us/system-center/scom/plan-thirdparty-integration?view=sc-om-2019)
- [SCOM-Prometheus-Exporter](https://github.com/opslogix/SCOM-Prometheus-Exporter) (communautaire, SCOM 2019+)

---

## Annexe A — Points non testés

| # | Point | État |
|---|---|---|
| 1 | Installation réelle sur un cluster (Helm, opérateurs) | Rédigé, **non exécuté** |
| 2 | Compatibilité Strimzi avec Kafka 4.4 KRaft | **À vérifier** sur la matrice officielle Strimzi |
| 3 | Versions exactes des charts au 11 nov. 2026 | **À lire** sur Artifact Hub ; chiffres fin octobre indicatifs |
| 4 | Zone-aware Mimir / Tempo + S3 réel | Extraits indicatifs, **non testés** |
| 5 | otelcol elasticsearch + ROR depuis un pod | **Non testé** bout en bout |
| 6 | CronJob ACL sur un cluster, AD réel | Script validé en mock uniquement |
| 7 | cert-manager + CA d'entreprise, rechargement Ingress | Procédure écrite, **non exécutée** |
| 8 | NetworkPolicies, StorageClass réelles | À caler avec l'exploitation |
| 9 | PDB lors d'un drain réel | **À exercer** en préprod |
| 10 | Stockage objet (scénarios A / B) | Procédures rédigées, **non testées** ; checklist : HCP / VSP One Object (A) ou MinIO (B, AGPLv3) ; HNAS seul insuffisant |
| 11 | Greffon AppD Enterprise contre contrôleur on-prem, voies SCOM 2019 B/C, certificats et LDAP AppD | Licences et qualification ouvertes ; **non testé** |
| 12 | schema_config Loki 3.7.9 | **À copier** depuis la doc officielle, non inventé ici |
| 13 | SSO OIDC AD FS, oauth2-proxy, Kerberos/auth.proxy en cluster (Annexe B) | Complément optionnel, LDAP reste principal ; **non testé** |

## Annexe B — SSO Grafana OSS en Kubernetes (complément optionnel)

> **Cette annexe est facultative.** LDAP (§12) reste le mécanisme **principal**. Ne suivre cette annexe qu'après un LDAP fonctionnel. [ADR-011](architecture/adr/ADR-011_SSO_Grafana_OSS.md). **Non testé.**

### B.1 Voies OIDC, Kerberos et oauth2-proxy

Même décision qu'[ADR-011](architecture/adr/ADR-011_SSO_Grafana_OSS.md) et que l'annexe B du runbook VM. **Non testé.** Variables : `variables/environnements.env`.

**Voie OIDC recommandée en Kubernetes** (client officiel Grafana) : section `grafana.ini` / `auth.generic_oauth` dans les values Helm, vers AD FS si le rôle est installé. Secret du client dans un Secret Kubernetes (`GF_AUTH_GENERIC_OAUTH_CLIENT_SECRET`), pas en clair dans les values. URL de rappel : `${OAUTH_REDIRECT_URL}` (Ingress `${GRAFANA_FQDN}`). `role_attribute_path`, et en OSS ≥ 11.2 `org_attribute_path` / `org_mapping`. CA d'AD FS montée dans le pod Grafana (`tls_client_ca`).

```yaml
# Extrait indicatif k8s/grafana-values — NON TESTÉ
# FQDN d'exemple après source de environnements.env
grafana.ini:
  server:
    domain: ${GRAFANA_FQDN}
    root_url: ${GRAFANA_URL}
  auth.generic_oauth:
    enabled: true
    name: AD FS
    scopes: openid profile email
    auth_url: ${ADFS_AUTH_URL}
    token_url: ${ADFS_TOKEN_URL}
    api_url: ${ADFS_USERINFO_URL}
    use_pkce: true
    allow_sign_up: true
    # role_attribute_path : à caler sur les revendications réelles
```

**Voie Kerberos / Auth Proxy :** un sidecar ou un pod Apache / `mod_auth_gssapi` devant le Service Grafana, ou un Ingress capable de Negotiate (non standard sur tous les contrôleurs). Grafana : `[auth.proxy]` + `whitelist` = IP **du pod ou de l'Ingress vu en TCP** (pas `X-Forwarded-For`). Keytab dans un Secret monté en volume `0640`. SPN `HTTP/${GRAFANA_FQDN}`. **Non testé** ; plus délicat en Kubernetes (IP source, réplicas, keytab).

**oauth2-proxy** ([documentation du projet](https://oauth2-proxy.github.io/oauth2-proxy/)) est un outil **communautaire**, pas un composant Grafana Labs. Il peut s'intercaler en Ingress (annotations nginx `auth-url` / `auth-signin`) et poser un en-tête consommé par `[auth.proxy]`. Image à mirroir dans `${REGISTRY_FQDN}`. À n'utiliser que si l'on ne veut pas que Grafana soit lui-même le client OIDC. **Non testé.**

**Ingress :** TLS cert-manager, SAN = `${GRAFANA_FQDN}`. NetworkPolicy : les utilisateurs n'atteignent pas le port 3000 des pods, seulement l'Ingress 443.

Compensations identiques : `grafana_acl_sync` (CronJob §14), organisations pour isoler les sources, journaux Grafana / Ingress vers Loki (pas l'auditing Enterprise).

```mermaid
sequenceDiagram
  autonumber
  participant P as Navigateur
  participant IN as Ingress ${GRAFANA_FQDN}
  participant GF as Pod Grafana
  participant ADFS as AD FS
  P->>IN: HTTPS /login
  IN->>GF: TLS interne
  GF->>ADFS: OIDC authorize
  ADFS-->>P: authentification
  ADFS-->>GF: code / jeton
  GF->>GF: role_attribute_path / org_mapping (OSS)
  GF-->>P: session
```

```mermaid
sequenceDiagram
  autonumber
  participant P as Poste du domaine
  participant IN as Ingress / Apache GSSAPI
  participant DC as DC Kerberos
  participant GF as Pod Grafana (auth.proxy)
  P->>IN: HTTPS Negotiate
  IN->>DC: SPN HTTP/${GRAFANA_FQDN}
  IN->>GF: ${AUTH_PROXY_HEADER} depuis une IP de la whitelist
  GF-->>P: session
```

---

## Annexe C — Scénario B : MinIO distribué (aucun stockage objet S3)

> **Scénario B**, après la [checklist](architecture/annexes/Checklist_decision_stockage_objet.md), lorsque `STOCKAGE_OBJET_SCENARIO=minio`. Déployer MinIO dans le cluster (ou un MinIO sur VM consommé depuis le cluster), **après** validation de la licence **AGPLv3**. Un **HNAS seul ne suffit pas**. Si le scénario A est retenu : [Annexe D](#annexe-d--scénario-a--stockage-objet-hitachi-hcp--vsp-one-object) — ne pas déployer MinIO. Documents : [Annexe MinIO](architecture/annexes/Annexe_Stockage_objet_S3_MinIO.md), [ADR-002](architecture/adr/ADR-002_Stockage_objet.md). **Non testé.**

Rappel Kubernetes :

1. Opérateur MinIO (Tenant) ou chart Helm **officiel**, images mirroir dans `${REGISTRY_FQDN}`. Lire la documentation de la **version** au moment de l'installation (ne pas inventer de numéro de chart ici).
2. **Quatre** pods au minimum, anti-affinité sur zones distinctes, PVC de type disque local (pas un NFS unique comme seul support — même réserve que Grafana Labs pour Mimir / Loki / Tempo). Répertoires / volumes **vides** à l'initialisation (erasure coding figé ensuite).
3. TLS via cert-manager, SAN = `${S3_FQDN}` et noms de Service nécessaires. Racine MinIO dans un `Secret`, pas dans les values commises.
4. Job `mc` : seaux `${S3_BUCKET_*}` , politiques IAM par composant, utilisateurs d'application. CronJob `mc mirror` vers `${S3_BUCKET_ADMIN}` ou un second site.
5. Service interne / Ingress vers `${S3_FQDN}` ; console limitée au réseau d'administration (NetworkPolicy). Métriques Prometheus selon la doc MinIO de la version, *ServiceMonitor* si disponible.
6. Licence communautaire **AGPLv3** à faire examiner.

## Annexe D — Scénario A : stockage objet Hitachi (HCP / VSP One Object)

> **Scénario A**, `STOCKAGE_OBJET_SCENARIO=hitachi`. Procédure complète : [Annexe Hitachi](architecture/annexes/Annexe_Stockage_objet_Hitachi_HCP_S3.md), [ADR-002](architecture/adr/ADR-002_Stockage_objet.md), diagramme [08](architecture/diagrammes/08_stockage_objet_hitachi.vsdx). **Non testé.**

Rappel Kubernetes :

1. Demander à l'équipe stockage un tenant / des espaces de noms dédiés par environnement et par usage, HS3 activé, quotas, HTTPS, CA, comptes de service, clés (dans un `Secret`, jamais dans les values Git), style d'adressage, versioning, rétention, réseau. Un **HNAS seul n'est pas une cible**.
2. `S3_ENDPOINT` = FQDN du tenant HCP ou de VSP One Object, **sans** `/hs3` pour une authentification AWS, **sans** préfixe de seau. Seau = espace de noms. `S3_FORCE_PATH_STYLE` selon le DNS (joker pour le virtual-hosted). `S3_CA_FILE` monté (ConfigMap / volume) et déclaré dans le paramètre TLS documenté par la version du chart ; `insecure: false`.
3. Values Helm : `minio.enabled: false`. Extraçits dans `k8s/mimir-values.yaml`, `k8s/loki-values.yaml`, `k8s/tempo-values.yaml` (endpoint, seau, `forcepathstyle` / `bucket_lookup_type`). Tempo : `forcepathstyle` officiel. Loki Thanos : `bucket_lookup_type: path` si path-style.
4. Tests depuis un Job ou un pod de diagnostic : `aws` ou `mc` avec CA et identifiants montés en fichier `0400`, jamais un secret en ligne de commande. Qualifier list / put / get / delete et un compactage (limites HCP `DeleteObjects` si rétention Hitachi).
5. NFS comme StorageClass unique pour les **blocs objet** : **rejeté**. Les PVC locaux des ingesters restent du disque bloc (pas NFS) — documentation Mimir (*NFS and network filesystems are not supported* pour le disque local).
