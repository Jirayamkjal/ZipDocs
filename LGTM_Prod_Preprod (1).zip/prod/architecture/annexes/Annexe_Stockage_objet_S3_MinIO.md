# Annexe — Scénario B : aucun stockage objet S3 — MinIO distribué

- **Scénario :** B — `STOCKAGE_OBJET_SCENARIO=minio` dans [`../../variables/environnements.env`](../../variables/environnements.env)
- **Lié à :** [ADR-002](../adr/ADR-002_Stockage_objet.md), **[checklist de décision](Checklist_decision_stockage_objet.md)** (à remplir **en premier**)
- **Scénario A** (HCP / VSP One Object) : [Annexe Hitachi](Annexe_Stockage_objet_Hitachi_HCP_S3.md)
- **Variables :** **modifier ici seulement** (`S3_FQDN`, `S3_VIP`, `S3_ENDPOINT`, `S3_CA_FILE`, `S3_FORCE_PATH_STYLE`, `S3_BUCKET_*`, `MINIOxx_FQDN`)
- **État :** procédures rédigées, **non testées** dans ce dépôt. Caler les options sur la documentation de la **version** MinIO retenue au moment de l'installation.
- **Licence :** l'édition communautaire de MinIO est publiée sous **AGPLv3**. L'organisation doit examiner cette licence (et toute offre commerciale MinIO) **avant** le déploiement MinIO.

Cette annexe décrit le **scénario B** : fournir le backend objet exigé par Mimir, Loki et Tempo **lorsque aucun service S3 serveur n'est disponible** (pas de HCP / VSP One Object / autre S3 qualifié ; un HNAS seul ne suffit pas).

## 0. Étape de décision (obligatoire)

**Avant** de déployer Mimir, Loki ou Tempo, et **avant** de commander des machines ou un pool MinIO, remplir la [checklist de décision](Checklist_decision_stockage_objet.md) avec l'équipe stockage / infrastructure (y compris : avez-vous un **HCP** ou un **VSP One Object** ? un **HNAS seul ne suffit pas**).

- Si un HCP (HS3) ou un VSP One Object (ou un autre S3 qualifié) remplit les critères essentiels : **scénario A**, [annexe Hitachi](Annexe_Stockage_objet_Hitachi_HCP_S3.md). Ne **pas** suivre cette annexe MinIO.
- Sinon (aucun S3 serveur, y compris « HNAS seul ») : **cette annexe (scénario B)**. Valider la licence **AGPLv3** **avant** l'installation. Décision écrite, datée. `STOCKAGE_OBJET_SCENARIO=minio`.

## 1. Rappel — si un service S3 existe déjà (scénario A, hors de cette annexe)

Dans ce cas, ne pas déployer MinIO. Pointer `S3_ENDPOINT` / `S3_FQDN` / `S3_CA_FILE` / `S3_FORCE_PATH_STYLE`, créer les seaux et les identifiants, et suivre l'annexe Hitachi lorsque le produit est HCP ou VSP One Object. Pour mémoire, le câblage consommateur consiste à :

1. Pointer `S3_ENDPOINT` / `S3_FQDN` / `S3_VIP` vers ce service (fichier de variables).
2. Créer **quatre seaux** distincts (ou trois + un de sauvegarde), chiffres d'exemple : `${S3_BUCKET_MIMIR}`, `${S3_BUCKET_LOKI}`, `${S3_BUCKET_TEMPO}`, `${S3_BUCKET_ADMIN}`.
3. Créer un **utilisateur ou rôle IAM** par composant (moindre privilège : uniquement `s3:Get*`, `s3:Put*`, `s3:Delete*`, `s3:List*` sur **son** seau). Identifiants dans un fichier `0600` (jamais sur la ligne de commande).
4. Faire confiance au CA du service (magasin des nœuds Mimir / Loki / Tempo / Grafana).
5. Renseigner les extraits de configuration déjà prévus dans les runbooks (endpoint, région, seau, `insecure: false`).
6. Confirmer auprès de l'exploitant du S3 : réplication, cycle de vie, chiffrement au repos, sauvegarde, réseau (443) depuis les zones LGTM.

Le reste de cette annexe concerne le cas **où aucun S3 n'existe**.

## 2. MinIO distribué — principes (documentation MinIO)

Sources : [MinIO Server](https://minio.community/community/minio-object-store/reference/minio-server/minio-server.html), [Erasure Coding](https://minio.community/community/minio-object-store/operations/concepts/erasure-coding.html), [Network Encryption (TLS)](https://minio.community/community/minio-object-store/operations/network-encryption.html), [déploiement distribué](https://github.com/minio/minio/blob/master/docs/distributed/README.md).

- **Au moins quatre nœuds** (déjà prévus dans les tableaux de dimensionnement : `minio-01` … `minio-04`, trois domaines de défaillance, un quatrième nœud dans la zone A). Nœuds **homogènes** (OS, nombre de disques, réseau). Disques **locaux** recommandés ; MinIO déconseille le NAS pour la production.
- **Erasure coding** : MinIO forme des *erasure sets* à l'initialisation (taille de 2 à 16 disques, selon la documentation du mode distribué). **Ces jeux ne sont plus modifiables ensuite.** Répertoires **vides** au premier démarrage. La commande est **identique** sur chaque nœud. La notation d'expansion MinIO utilise **trois points** : `{1...4}` (et non `{1..4}`, qui serait développé par le shell).
- **Horloges** : les nœuds doivent être à moins de 15 minutes les uns des autres (NTP, déjà exigé pour Kerberos / AD).
- **Identifiants racine** : mêmes `MINIO_ROOT_USER` et `MINIO_ROOT_PASSWORD` sur tous les nœuds, lus depuis un `EnvironmentFile` `0600`, jamais en clair dans un dépôt ni sur la ligne de commande. Longueurs minimales : à respecter d'après la documentation de la version (historiquement ≥ 3 et ≥ 8 caractères).
- **TLS** : MinIO active TLS dès qu'il trouve `public.crt` et `private.key` dans le répertoire de certificats (`--certs-dir`, par exemple `/opt/minio/certs`). **Chaque nœud** doit avoir une configuration de certificats cohérente. Le certificat (SAN) doit couvrir le **VIP / FQDN de service** (`${S3_FQDN}`, ex. `s3.obs.exemple.local`) **et** les FQDN de nœuds (`minio-01` …). Chaîne de la CA interne dans le truststore des clients (Mimir, Loki, Tempo, `mc`).
- **VIP** : HAProxy + keepalived sur `${S3_VIP}` (déjà dans le plan d'adressage), backend les quatre nœuds, port API (9000 par défaut, à confirmer). La console (9001 par défaut) n'est exposée que sur le réseau d'administration.

## 3. Mise en place sur machines virtuelles RHEL 8

**Non testé.** Source du binaire ou du RPM : téléchargement hors ligne depuis un poste autorisé, vérification d'empreinte SHA-256, même discipline que le reste du runbook VM. Ne pas inventer un numéro de version ici : lire celui du lot au moment de l'installation.

### 3.1 Système

Sur chaque `minio-0N` (exemple prod : `minio-01.obs.exemple.local`) :

- Disque de données dédié, chiffré au repos (LUKS, comme les autres volumes de données du runbook), monté par exemple en `/data` (XFS ou ext4, *noatime* selon pratique locale). Répertoire MinIO **vide** : `/data/minio`.
- Utilisateur système `minio`, sans coquille de connexion, répertoires `0700` / `0750`.
- SELinux : contexte adapté au binaire et au répertoire de données (même méthode que le runbook : `semanage fcontext`, `restorecon` — **pas** `setenforce 0` durable). Ports 9000/9001 : `semanage port` si nécessaire. **À valider** sur l'image réelle.
- Pare-feu : 9000 entre nœuds MinIO et depuis Mimir / Loki / Tempo / HAProxy ; 9001 seulement depuis le réseau d'administration.

### 3.2 Certificats

Déposer sur chaque nœud, dans `/opt/minio/certs/` (propriétaire `minio`, `0640` pour la clé) :

- `private.key` — clé du certificat (SAN complet, voir ci-dessus) ;
- `public.crt` — certificat + chaîne si requis par la version ;
- éventuellement `CAs/ca.crt` pour que MinIO fasse confiance aux clients mTLS (optionnel, **non prescrit** ici).

### 3.3 Fichier d'environnement et service systemd

```
# /etc/minio/minio.env — 0600, root:minio — NE PAS commettre ce fichier
# Saisir MINIO_ROOT_USER et MINIO_ROOT_PASSWORD à l'éditeur (read -rsp pour les
# générer puis coller). Jamais d'echo du secret.
MINIO_ROOT_USER=
MINIO_ROOT_PASSWORD=
MINIO_VOLUMES="https://minio-0{1...4}.obs.exemple.local/data/minio"
# MINIO_VOLUMES : trois points. Adapter le domaine (variables : MINIOxx_FQDN).
MINIO_OPTS="--certs-dir /opt/minio/certs --console-address :9001"
# MINIO_SERVER_URL : URL publique (VIP) utilisée par la console pour l'API, si documentée par la version.
MINIO_SERVER_URL=https://s3.obs.exemple.local
```

Unité systemd (chemins à caler sur le paquet installé) : `User=minio`, `EnvironmentFile=/etc/minio/minio.env`, `ExecStart=/usr/local/bin/minio server $MINIO_OPTS $MINIO_VOLUMES`, `LimitNOFILE` élevé (MinIO le documente), `Restart=on-failure`. Démarrer les **quatre** nœuds dans une fenêtre courte. Journal : `journalctl -u minio`.

Contrôle : `curl --cacert /etc/pki/ca-trust/source/anchors/obs-ca.crt https://s3.obs.exemple.local/minio/health/live` — le chemin exact de *health* se lit dans la documentation de la version (MinIO documente des endpoints de santé : les vérifier, **ne pas** les supposer si la page de la version diffère).

### 3.4 Client `mc`, seaux, politiques IAM, comptes d'application

Installer `mc` (même discipline d'empreinte). Configurer un alias **sans** coller le secret sur la ligne de commande : `mc alias set` lit aussi un fichier ou une invite selon la version — à suivre dans `mc alias set --help`. Fichier de configuration `~/.mc/` en `0600`.

```
# NON TESTÉ — exemples, noms issus de variables/environnements.env
# Seaux (une fois le cluster sain) :
#   mc mb lgtm/${S3_BUCKET_MIMIR}
#   mc mb lgtm/${S3_BUCKET_LOKI}
#   mc mb lgtm/${S3_BUCKET_TEMPO}
#   mc mb lgtm/${S3_BUCKET_ADMIN}
#   mc ls lgtm
```

Politique IAM d'exemple (moindre privilège, un fichier par composant) — schéma de politique **style AWS** documenté par MinIO :

```json
{
  "Version": "2012-10-17",
  "Statement": [
    {
      "Effect": "Allow",
      "Action": ["s3:GetBucketLocation", "s3:ListBucket"],
      "Resource": ["arn:aws:s3:::lgtm-mimir"]
    },
    {
      "Effect": "Allow",
      "Action": ["s3:GetObject", "s3:PutObject", "s3:DeleteObject"],
      "Resource": ["arn:aws:s3:::lgtm-mimir/*"]
    }
  ]
}
```

```
# NON TESTÉ
# mc admin policy create lgtm mimir-write /etc/minio/policies/mimir-write.json
# Créer un utilisateur d'application (mot de passe saisi à l'invite ou via un
# fichier 0600, jamais en argument visible) :
#   mc admin user add lgtm mimir-svc
#   mc admin policy attach lgtm mimir-write --user mimir-svc
# Répéter pour loki-svc et tempo-svc, chacun limité à SON seau.
```

Les **comptes de service** MinIO (identifiants dérivés d'un utilisateur, souvent via `mc admin user svcacct`) existent dans la documentation MinIO de certaines versions : les utiliser s'ils sont documentés pour la version installée, sinon les utilisateurs IAM ci-dessus suffisent. Access key / secret key : fichier `0600` sur chaque nœud Mimir / Loki / Tempo (`S3_ACCESS_KEY_FILE`, déjà le principe des runbooks).

**Ne pas** laisser le compte racine MinIO aux applications.

### 3.5 Câblage Mimir, Loki, Tempo

Les extraits des runbooks (endpoint `${S3_ENDPOINT}`, `insecure: false`, seau, préfixe, région fictive `us-east-1` souvent exigée par les clients S3 même en interne) restent valables. Redémarrer ou relancer les composants après création des seaux et des identifiants. Contrôler l'écriture d'un objet de test **dans un préfixe dédié**, puis le supprimer.

### 3.6 Sauvegarde

- Seau `${S3_BUCKET_ADMIN}` ou un **deuxième** cluster / site : `mc mirror` (commande officielle) depuis les seaux métier, sur une planification (`systemd timer`), vers cette cible. Tester une **restauration** (`mc mirror` en sens inverse vers un seau de préprod) — **non testé**.
- La **réplication de site** MinIO est une fonction documentée à part : la retenir seulement si l'on a deux sites et que la version la prend en charge ; ne pas l'improviser.
- Les identifiants racine et les certificats se sauvegardent avec le coffre (pas dans le seau).

### 3.7 Supervision

- Suivre la documentation officielle MinIO **« Collect MinIO Metrics Using Prometheus »** (ou équivalent de la version) pour le point d'exposition des métriques et le mode d'authentification (jeton). Les scraper avec le Prometheus en mode agent déjà prévu, les enregistrer dans Mimir. **Ne pas** inventer le chemin si la page de la version en indique un autre.
- Alertes minimales à caler en préprod : nœud hors ligne, disque saturé, erreur de quorum / de parité, certificat proche de l'expiration, échec de `mc mirror`.
- Journaux `journald` du service `minio` vers la passerelle OTLP, sujet `otlp_logs`, Loki.

### 3.8 HAProxy

Frontend TLS `${S3_FQDN}:${PORT}` (443 ou 9000, selon que l'on termine le TLS sur HAProxy ou que l'on fait du passage TCP vers MinIO déjà en TLS). En passage TCP (recommandé pour ne pas casser l'authentification S3 / les signatures si mal configuré) : mode TCP, backends `minio-01..04:9000`, contrôle de santé TCP ou HTTP de santé MinIO. **Non testé** : valider que les signatures S3 (chemin virtuel-hôte ou *path-style*) restent correctes derrière la VIP. Mimir / Loki / Tempo documentent souvent `bucket_lookup_type` / *path style* — à caler.

## 4. Mise en place sur Kubernetes

**Non testé.** Deux voies officielles courantes : l'**opérateur** MinIO (Tenant) ou un **chart Helm** documenté par MinIO. Lire la documentation de la voie retenue **au moment de l'installation** (versions d'opérateur et de Tenant, CRD).

Principes à conserver, quel que soit le chart :

- **Quatre** pods (ou davantage), anti-affinité sur des nœuds / zones distinctes, PVC locaux ou une classe de stockage équivalente à des disques locaux (éviter un NFS partagé comme unique disque de chaque pod — même réserve que Grafana Labs pour Mimir / Loki / Tempo).
- TLS : `cert-manager`, SAN = `${S3_FQDN}` et noms de Service / Pods nécessaires. Secret monté comme `public.crt` / `private.key` selon le chart.
- Identifiants racine : `Secret` Kubernetes, pas dans les values commises. Policies et seaux : *Job* de post-installation utilisant `mc` (même commandes qu'en §3.4), ou l'API / les CRD documentées par l'opérateur.
- Service / Ingress ou *LoadBalancer* interne vers la VIP `${S3_FQDN}`. Exposition de la console limitée au réseau d'administration (NetworkPolicy).
- Métriques : *ServiceMonitor* ou scrape équivalent, selon la doc de la version.
- Sauvegarde : même `mc mirror`, depuis un CronJob, vers un seau ou une cible hors cluster.

Le registre privé (`registre.exemple.local`) reçoit les images MinIO et `mc` (miroir hors ligne, empreintes).

## 5. Dimensionnement

Les tableaux de dimensionnement du document d'architecture et du runbook VM prévoient déjà, **si MinIO est retenu** :

- préproduction : 4 VM, 4 vCPU, 8 Go, OS 50 Go + données 1 To, RHEL 8, zones A, B, C, A ;
- production : 4 VM, 8 vCPU, 16 Go, OS 50 Go + données 2 To, RHEL 8, mêmes zones.

Ce sont des **estimations recommandées**, à revoir selon la rétention réelle (hypothèse ouverte). Si un S3 existant est choisi, ces 4 VM (ou le pool Kubernetes « objet ») ne sont pas déployées.

## 6. Diagramme de flux

```mermaid
flowchart LR
  subgraph clients [Clients LGTM]
    M[Mimir]
    L[Loki]
    T[Tempo]
    B[sauvegardes mc mirror]
  end
  subgraph vip [VIP TLS]
    S["s3.obs.exemple.local<br/>HAProxy / Service"]
  end
  subgraph minio [MinIO distribué — erasure coding]
    N1[minio-01 zone A]
    N2[minio-02 zone B]
    N3[minio-03 zone C]
    N4[minio-04 zone A]
  end
  M -->|seaux lgtm-mimir| S
  L -->|lgtm-loki| S
  T -->|lgtm-tempo| S
  B -->|lgtm-admin ou site 2| S
  S --> N1 & N2 & N3 & N4
```

Identité des clients : utilisateurs IAM (ou comptes de service MinIO), TLS mutuellement de confiance avec la CA interne. Le compte racine MinIO reste au coffre.

## 7. Points à confirmer

- Choix **S3 existant** ou **MinIO** (hypothèse H1).
- Licence AGPLv3 / offre commerciale MinIO.
- Version exacte, parité d'erasure retenue par MinIO à l'initialisation.
- Taille réelle des volumes selon la rétention.
- Chiffrement au repos *côté objet* (KMS) en plus du chiffrement des disques.
- *Path-style* contre *virtual-hosted-style* derrière la VIP.
