# Étape de décision — stockage objet (scénario A Hitachi ou scénario B MinIO)

- **Lié à :** [ADR-002](../adr/ADR-002_Stockage_objet.md), [Annexe A — Hitachi HCP / VSP One Object](Annexe_Stockage_objet_Hitachi_HCP_S3.md), [Annexe B — MinIO](Annexe_Stockage_objet_S3_MinIO.md)
- **Quand :** **avant** de déployer Mimir, Loki et Tempo, et **avant** de commander des machines MinIO. Cette étape tranche l'hypothèse H1 et renseigne `STOCKAGE_OBJET_SCENARIO` (`hitachi` ou `minio`) dans [`variables/environnements.env`](../../variables/environnements.env).
- **Décision écrite :** datée, avec les réponses de l'équipe stockage / infrastructure.

Deux chemins documentés :

- **Scénario A — stockage objet Hitachi existant** (HCP avec API S3 / HS3, ou VSP One Object) : prioritaire s'il existe et si les critères essentiels sont remplis.
- **Scénario B — aucun stockage objet S3 :** MinIO distribué (Annexe C des runbooks). Licence communautaire **AGPLv3** à faire valider **avant** tout déploiement MinIO.

**Un Hitachi HNAS seul ne suffit pas** : HNAS n'expose pas d'API S3 serveur (protocoles NFS, SMB, FTP, iSCSI). « HTTPS (S3) vers le nuage » est un **client** (Data Migrator to Cloud) vers HCP, VSP One Object ou un autre S3, pas un endpoint pour Mimir / Loki / Tempo. Le NFS / système de fichiers partagé n'est **pas** retenu en production (documentation Grafana Labs, voir l'annexe Hitachi §0.3).

```mermaid
flowchart TD
  A["Checklist avec l'équipe stockage"] --> B{"Avez-vous un HCP avec HS3<br/>ou un VSP One Object ?"}
  B -->|oui| C{"Critères essentiels :<br/>API S3, TLS, IAM, capacité, réseau ?"}
  C -->|oui| D["Scénario A<br/>STOCKAGE_OBJET_SCENARIO=hitachi<br/>Annexe Hitachi"]
  C -->|non, et pas de correctif| E
  B -->|"HNAS seul, ou Data Migrator seulement"| F["HNAS n'est pas une cible S3"]
  F --> G{"Peut-on obtenir HCP<br/>ou VSP One Object ?"}
  G -->|oui| C
  G -->|non| E
  B -->|aucun objet S3| E["Scénario B<br/>STOCKAGE_OBJET_SCENARIO=minio<br/>Annexe MinIO, AGPLv3 à valider"]
  H["NFS / filesystem partagé<br/>comme backend des blocs"] --> I["Rejeté — doc Grafana Labs"]
```

## 1. Questions à poser à l'équipe stockage / infrastructure

Les poser par écrit. Cocher et noter la réponse réelle.

| # | Question | Réponse (à remplir) |
|---|---|---|
| Q0 | Avez-vous un **Hitachi Content Platform (HCP)** avec l'API S3 (**HS3**) activée, et/ou un **VSP One Object** (ex HCP Cloud Scale) ? Quelle version ? | Oui HCP / oui VSP One Object / les deux / non — version, contact |
| Q0b | Avez-vous uniquement un **HNAS** (NFS, SMB, FTP, iSCSI) ? | Un HNAS seul **n'est pas** une API S3 serveur et **ne suffit pas**. Data Migrator to Cloud est un client, pas un endpoint LGTM. |
| Q1 | Existe-t-il déjà un autre service objet **compatible API S3** (hors Hitachi), joignable depuis les réseaux préprod et prod LGTM ? | Oui / Non — nom, contact. S'il est qualifié, il se traite comme un S3 existant (même critères, même câblage consommateur que le scénario A). |
| Q2 | **Point d'entrée :** FQDN, VIP, port, style d'accès (*path-style* ou *virtual-hosted*), région éventuelle exigée par les clients ? Pour HCP : FQDN du **tenant** (point de service) ; le seau est l'**espace de noms**. Authentification AWS : **sans** le segment `/hs3` (note officielle Hitachi). | |
| Q3 | **TLS :** le trafic est-il uniquement en HTTPS ? Quelle CA signe le certificat ? Peut-on déposer cette CA (`S3_CA_FILE`) dans les truststores LGTM (vérification réelle, pas `insecure`) ? Le SAN couvre-t-il les FQDN utilisés (y compris les noms *virtual-hosted* le cas échéant) ? | |
| Q4 | **Versioning** des objets (activation possible par seau / namespace) ? | Oui / Non / partiel |
| Q5 | **IAM :** peut-on créer un utilisateur ou un rôle **par composant** (Mimir, Loki, Tempo, éventuellement sauvegarde), avec moindre privilège limité à **un** seau, et une rotation des clés d'accès ? | |
| Q6 | **Capacité :** quota, marge, débit / IOPS, au regard de la rétention prévue ? Réplication ? | |
| Q7 | **Cycle de vie**, chiffrement **au repos**, journalisation d'accès, sauvegarde / restauration déjà qualifiés ? (Sur HCP, `PUT Bucket lifecycle` n'est **pas** pris en charge d'après la matrice officielle : convenir d'un équivalent — *service plan*, rétention Grafana.) | |
| Q8 | **Réseau et sécurité :** flux depuis les nœuds Mimir / Loki / Tempo (et les pools Kubernetes) vers le service, règles pare-feu, pas d'exposition Internet inutile ? | |
| Q9 | **Tenant / namespace dédiés** par environnement (préprod, prod) et par usage (mimir, loki, tempo) ? Quotas ? Sur HCP : HS3 **activé** sur ces espaces de noms ? | |
| Q10 | **Rétention / object lock** susceptibles de bloquer `DeleteObjects` (limite documentée HCP pour les objets sous rétention ou *hold*) ? | À expliciter avant le câblage des compacteurs |

## 2. Critères pour retenir le scénario A (Hitachi ou autre S3 existant)

Retenir ce chemin **seulement** si les réponses permettent de cocher **tous** les critères essentiels :

| Critère | Essentiel ? | OK ? |
|---|---|---|
| Service **déjà en production** (ou qualifié) exposant une **API S3 serveur** : HCP avec HS3, VSP One Object, ou autre S3 compatible réellement utilisable par Mimir, Loki et Tempo | oui | |
| Ce n'est **pas** un HNAS seul, ni un export **NFS** | oui | |
| **TLS** avec vérification du certificat (CA connue, `insecure: false`) | oui | |
| **IAM** : identifiants distincts par composant, moindre privilège par seau, secrets dans des fichiers `0600` | oui | |
| **Capacité** suffisante (volume et débit) pour la rétention visée, avec une marge | oui | |
| Réseau ouvert et testé depuis les zones LGTM (Q8) | oui | |
| Versioning disponible | souhaitable | |
| Cycle de vie ou équivalent, chiffrement au repos, sauvegarde déjà en place | souhaitable | |

**Décision :**

- Si Q0 ou Q1 = **oui** et tous les critères essentiels sont **OK** : **scénario A**. `STOCKAGE_OBJET_SCENARIO=hitachi` (ou, pour un S3 non Hitachi qualifié, le même câblage consommateur : pointer `S3_ENDPOINT`, ne pas déployer MinIO). Suivre [Annexe_Stockage_objet_Hitachi_HCP_S3.md](Annexe_Stockage_objet_Hitachi_HCP_S3.md) lorsque le produit est HCP ou VSP One Object. Renseigner `S3_ENDPOINT`, `S3_FQDN`, `S3_CA_FILE`, `S3_FORCE_PATH_STYLE`. Créer les seaux / espaces de noms `${S3_BUCKET_MIMIR}`, `${S3_BUCKET_LOKI}`, `${S3_BUCKET_TEMPO}`, éventuellement `${S3_BUCKET_ADMIN}`. Ne **pas** déployer les quatre VM (ou le pool) MinIO.
- Si Q0 et Q1 = **non** (y compris « HNAS seul »), ou si un critère essentiel échoue sans correctif : **scénario B**. `STOCKAGE_OBJET_SCENARIO=minio`. **Avant** toute installation : faire examiner la licence **AGPLv3** de l'édition communautaire MinIO (ou une offre commerciale). Puis [Annexe_Stockage_objet_S3_MinIO.md](Annexe_Stockage_objet_S3_MinIO.md).

Cette checklist ne remplace pas la qualification en préproduction (écriture / lecture / compactage réels depuis Mimir, Loki et Tempo). Procédures **non testées** dans ce dépôt.
