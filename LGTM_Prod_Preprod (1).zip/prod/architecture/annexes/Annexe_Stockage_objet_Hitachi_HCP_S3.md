# Annexe — Scénario A : stockage objet Hitachi existant (HCP ou VSP One Object)

- **Scénario :** A — `STOCKAGE_OBJET_SCENARIO=hitachi` dans [`variables/environnements.env`](../../variables/environnements.env) (**modifier ici seulement**)
- **Lié à :** [ADR-002](../adr/ADR-002_Stockage_objet.md), [checklist de décision](Checklist_decision_stockage_objet.md)
- **Scénario B** (aucun stockage objet S3) : [Annexe MinIO](Annexe_Stockage_objet_S3_MinIO.md) et annexes C des runbooks
- **État :** procédures rédigées **côté consommateur** (Mimir, Loki, Tempo). L'administration du cluster HCP ou VSP One Object reste à l'équipe stockage. **Non testé** dans ce dépôt.
- **Sources Hitachi :** [protocoles d'accès aux espaces de noms HCP](https://docs.hitachivantara.com/r/en-us/mk-95hcph001/latest/administering-hcp/introduction-to-hitachi-content-platform/about-the-hitachi-content-platform/data-access-methods/namespace-access-protocols), [URL d'accès HCP (API S3)](https://docs.hitachivantara.com/r/en-us/mk-95hcph001-20/using-the-hitachi-api-for-amazon-s3/access-and-authentication/urls-for-access-to-hcp), [URL avec authentification HCP](https://docs.hitachivantara.com/r/en-us/mk-95hcph001-20/using-the-hitachi-api-for-amazon-s3/alternative-authentication-method/urls-with-hcp-authentication), [matrice de prise en charge de l'API S3 HCP](https://docs.hitachivantara.com/r/en-us/mk-95hcph002/latest/hcp-management-api-reference/introduction-to-the-hcp-management-api/support-for-the-amazon-s3-api), [suppression de plusieurs objets](https://docs.hitachivantara.com/r/en-us/mk-95hcph002/latest/using-the-hitachi-api-for-amazon-s3/working-with-objects/deleting-multiple-objects), [API S3 VSP One Object](https://docs.hitachivantara.com/r/en-us/mk-24vsp1ob000/latest/overview-of-vsp-one-object/support-for-the-amazon-s3-api), [Data Migrator to Cloud (HNAS)](https://docs.hitachivantara.com/r/en-us/mk-92hnas005-36/using-data-migrator-to-cloud/data-migrator-to-cloud-overview)
- **Sources Grafana Labs :** [stockage objet Mimir](https://grafana.com/docs/mimir/latest/configure/configure-object-storage-backend/), [matériel Mimir — systèmes de fichiers non pris en charge](https://grafana.com/docs/mimir/latest/set-up/hardware-requirements/), [stockage Loki (Helm)](https://grafana.com/docs/loki/latest/setup/install/helm/configure-storage/), [migration clients S3 Loki (Thanos, `bucket_lookup_type`)](https://grafana.com/docs/loki/latest/setup/migrate/migrate-storage-clients/), [stockage objet Tempo](https://grafana.com/docs/tempo/latest/configuration/hosted-storage/s3/), [architecture objet Tempo](https://grafana.com/docs/tempo/latest/reference-tempo-architecture/object-storage/)

## 0. Ce qui est une cible, et ce qui ne l'est pas

### 0.1 Produits Hitachi qui exposent une API S3 serveur

Deux produits documentés par Hitachi comme compatibles avec l'API Amazon S3 :

1. **Hitachi Content Platform (HCP)** — *Hitachi API for Amazon S3* (souvent appelée **HS3**). Hitachi documente : « With the S3-compatible API, namespaces are called buckets. » Le **point de service** (*service point* / *endpoint*) est un **tenant**. Chaque requête S3 s'exécute dans le contexte d'un tenant.
2. **VSP One Object** (anciennement HCP Cloud Scale) — Hitachi documente une compatibilité avec l'API REST Amazon S3 (seaux, objets, ACL côté service d'accès, matrice d'opérations).

Ces deux produits sont le **scénario A**, lorsqu'ils sont déjà exploités (ou qualifiés) et joignables depuis les zones LGTM, avec HS3 / S3 activé, HTTPS, comptes de moindre privilège et capacité suffisante (voir la checklist).

### 0.2 HNAS seul n'est pas une cible S3

**Hitachi NAS (HNAS)** expose des protocoles de **fichiers et de blocs** (NFS, SMB/CIFS, FTP, iSCSI). Il n'expose **pas** d'API S3 *serveur* que Mimir, Loki ou Tempo pourraient utiliser comme backend objet.

La fonction Hitachi souvent présentée comme « HTTPS (S3) vers le nuage » est **Data Migrator to Cloud** : un **client** S3 qui *envoie* des données depuis HNAS vers une cible objet (HCP, VSP One Object, ou un autre fournisseur S3). Ce n'est pas un point d'entrée S3 pour la plateforme LGTM. Avoir uniquement un HNAS **ne suffit pas**. Si l'organisation n'a que HNAS, retenir le **scénario B** (MinIO) ou demander à l'équipe stockage un HCP / VSP One Object.

### 0.3 NFS / système de fichiers partagé : non retenu en production

Grafana Labs **ne recommande pas**, pour la production, de remplacer le stockage objet par un système de fichiers partagé (NFS ou équivalent, y compris un export HNAS) :

- **Mimir** — documentation officielle [hardware requirements](https://grafana.com/docs/mimir/latest/set-up/hardware-requirements/) : « NFS and network filesystems are not supported for any Grafana Mimir component that uses local disk storage. » NFS, EFS, FUSE et tout système sans garanties POSIX `mmap` cohérentes sont listés comme **non pris en charge** (risque de plantage ou de corruption silencieuse). Le stockage de long terme documenté est un **objet** S3 compatible (ou GCS, Azure, Swift).
- **Loki** — documentation officielle [Configure storage (Helm)](https://grafana.com/docs/loki/latest/setup/install/helm/configure-storage/) : l'installation *scalable* **exige** un stockage objet géré (S3, GCS, …) ou un MinIO auto-hébergé. L'installation *single binary* peut utiliser le système de fichiers, mais Grafana Labs **recommande** un stockage objet (fournisseur ou MinIO) pour les déploiements de production.
- **Tempo** — l'architecture officielle des déploiements distribués s'appuie sur un [stockage objet](https://grafana.com/docs/tempo/latest/reference-tempo-architecture/object-storage/) (S3, GCS, Azure, etc.). Le backend `local` / système de fichiers n'est pas le chemin documenté pour une Tempo distribuée en production.

**NFS direct (HNAS ou autre) est donc rejeté** comme backend des blocs Mimir / Loki / Tempo en préprod et prod (ADR-002).

## 1. Demande à l'équipe stockage (côté consommateur)

À formaliser par écrit (ticket). L'équipe LGTM **consomme** le service ; elle n'administre pas le cluster Hitachi. **Non testé.**

| # | Demande | Pourquoi |
|---|---|---|
| D1 | Confirmer le produit et la **version** : HCP (avec HS3) et/ou **VSP One Object**. Un HNAS seul ne convient pas (voir §0.2). | Trancher le scénario A. |
| D2 | Un **tenant** (HCP) ou un compte / domaine équivalent (VSP One Object) **dédié par environnement** (préprod, prod). | Isolation des données sensibles. |
| D3 | Des **espaces de noms / seaux** dédiés par usage : métriques (Mimir), journaux (Loki), traces (Tempo), éventuellement un seau de copie de sauvegarde. Sur HCP, l'espace de noms **est** le seau S3. Les noms d'exemple sont `${S3_BUCKET_MIMIR}`, `${S3_BUCKET_LOKI}`, `${S3_BUCKET_TEMPO}`, `${S3_BUCKET_ADMIN}`. | Moindre privilège, pas de mélange des préfixes. Mimir refuse en outre de partager le même seau *et* le même préfixe entre blocs, règle et Alertmanager ([doc Mimir](https://grafana.com/docs/mimir/latest/configure/configure-object-storage-backend/)). |
| D4 | **Protocole S3 / HS3 activé** sur ces espaces de noms (HCP : l'API S3 compatible doit être autorisée sur le namespace). | Sans cela, les clients Grafana n'ont pas d'API. |
| D5 | **HTTPS uniquement**, certificat du point de service, **chaîne de CA** à remettre (fichier PEM) pour le truststore des nœuds LGTM. SAN du certificat = FQDN réellement utilisé (tenant, et noms *virtual-hosted* le cas échéant, ou joker documenté par l'équipe PKI / stockage). | `insecure: false`. Pas de `ssl_skip_verify`. |
| D6 | **FQDN et port** du point de service, style d'adressage retenu (**path-style** ou **virtual-hosted**), et besoin DNS associé (voir §2). | Renseigner `S3_ENDPOINT`, `S3_FQDN`, `S3_FORCE_PATH_STYLE`. |
| D7 | **Quotas** (capacité, débit, nombre d'objets) alignés sur la rétention visée, avec une marge. | Critère essentiel de la checklist. |
| D8 | Un **compte de service** (utilisateur de tenant HCP, ou équivalent VSP One Object) **par composant**, moindre privilège limité à **son** seau (lecture, écriture, listage, suppression sur ce seau seulement). **Clés d'accès** (access key / secret key) remises hors bande, rotation. | Fichiers `0600`, jamais en ligne de commande. La documentation HCP décrit la génération d'un jeton d'autorisation / de clés dans la console d'administration du tenant — suivre la procédure de **la version** déployée, côté équipe stockage. |
| D9 | **Versioning**, **rétention** / *object lock*, **réplication** déjà en place ou souhaités. | Voir les points de vigilance §6 (rétention HCP et `DeleteObjects`). |
| D10 | **Réseau** : flux depuis les nœuds Mimir / Loki / Tempo (et les pools Kubernetes) vers le point de service, pare-feu, pas d'exposition Internet inutile. | |

Décision écrite, datée. Si D1 est négatif ou si un critère essentiel échoue : scénario B.

## 2. Point d'entrée, path-style et virtual-hosted

### 2.1 HCP — formes d'URL documentées

Hitachi documente que le **point de service** est le **tenant**. Deux styles d'URL existent pour un seau (espace de noms) et pour un objet.

**Authentification HCP** (identifiant d'interface `hs3`, en **minuscules**, sensible à la casse) :

- Tenant : `https://<tenant>.<domaine-hcp>/hs3`
- Seau, nom dans l'hôte (*virtual-hosted*) : `https://<seau>.<tenant>.<domaine-hcp>/hs3`
- Seau, nom dans le chemin (*path-style*) : `https://<tenant>.<domaine-hcp>/hs3/<seau>`
- Objet, *virtual-hosted* : `https://<seau>.<tenant>.<domaine-hcp>/hs3/<objet>`
- Objet, *path-style* : `https://<tenant>.<domaine-hcp>/hs3/<seau>/<objet>`

**Authentification AWS** (Signature Version 4 ou 2 — toutes deux **prises en charge** d'après la [matrice HCP](https://docs.hitachivantara.com/r/en-us/mk-95hcph002/latest/hcp-management-api-reference/introduction-to-the-hcp-management-api/support-for-the-amazon-s3-api)) :

> Note officielle Hitachi : **« Do not use the hs3 interface identifier when using AWS authentication. »**

Les clients Grafana (Mimir, Loki, Tempo), `aws` et `mc` utilisent en général une signature **AWS**. Dans ce cas, **ne pas** placer `/hs3` dans `S3_ENDPOINT`. Le point d'entrée à demander à l'équipe stockage est du type :

```
https://<tenant>.<domaine-hcp>
```

exemple fictif : `https://lgtm.hcp.exemple.local` — à remplacer par le FQDN réel.

Le **nom de seau** côté client est le **nom de l'espace de noms** HCP.

Documentation **Mimir** : « Don’t prefix the endpoint value with your bucket name. » L'endpoint est le tenant, **pas** `<seau>.<tenant>.<domaine-hcp>`.

**DNS :** le style *virtual-hosted* exige que `<seau>.<tenant>.<domaine-hcp>` (souvent un enregistrement joker `*.<tenant>.<domaine-hcp>`) soit résolu. Si ce DNS n'existe pas, retenir le *path-style* et `S3_FORCE_PATH_STYLE=true`. **À confirmer** avec l'équipe stockage et à qualifier en préprod (les deux styles sont documentés par Hitachi ; le choix opérationnel dépend du DNS et du certificat).

### 2.2 VSP One Object

L'API est celle d'Amazon S3 (matrice Hitachi). Le FQDN exact, le style d'adressage et la région éventuelle sont à **demander à l'équipe stockage** pour la version déployée — ne pas inventer un schéma d'URL ici.

### 2.3 Variables

Dans `variables/environnements.env` (**modifier ici seulement**) :

- `STOCKAGE_OBJET_SCENARIO=hitachi`
- `S3_FQDN` / `S3_ENDPOINT` : point de service (tenant HCP ou endpoint VSP One Object), schéma `https://`
- `S3_CA_FILE` : chemin du PEM de la CA, déposé sur chaque nœud consommateur (`0644` pour le certificat, pas de clé privée)
- `S3_FORCE_PATH_STYLE` : `true` (path-style) ou `false` (virtual-hosted), selon D6
- `S3_REGION` : valeur exigée par les clients Grafana ; **à confirmer** auprès de l'équipe stockage (aucune exigence de région n'est affirmée ici sans documentation Hitachi correspondante)
- `S3_BUCKET_*` : noms des espaces de noms / seaux

Les identifiants ne figurent **pas** dans ce fichier.

## 3. Configuration Mimir, Loki et Tempo

**Non testé** contre un HCP ou un VSP One Object réel dans ce dépôt. Caler les **noms exacts** des clés YAML sur la documentation de la **version** installée (Mimir 3.2.3, Loki 3.7.9, Tempo 3.1.1). Secrets lus depuis un `EnvironmentFile` `0600` (VM) ou un `Secret` Kubernetes, jamais en clair dans Git ni sur la ligne de commande. `insecure: false`.

### 3.1 Mimir

Source : [Configure object storage backend](https://grafana.com/docs/mimir/latest/configure/configure-object-storage-backend/). Backend `s3` (S3 et implémentations compatibles). Mimir **ne crée pas** le seau.

```
# Extrait — NON TESTÉ — secrets depuis l'environnement (fichier 0600)
# Ne pas préfixer l'endpoint par le nom du seau (documentation Mimir).
common:
  storage:
    backend: s3
    s3:
      endpoint: ${S3_FQDN}
      region: ${S3_REGION}
      access_key_id: ${S3_ACCESS_KEY}
      secret_access_key: ${S3_SECRET_KEY}
      insecure: false
      # Style d'adressage : caler le nom du paramètre sur la doc Mimir 3.2.3
      # (bucket_lookup_type ou équivalent documenté). Si S3_FORCE_PATH_STYLE=true
      # et que la version documente bucket_lookup_type :
      # bucket_lookup_type: path
      # CA : faire confiance à ${S3_CA_FILE} (magasin système et/ou paramètre
      # HTTP/TLS documenté par la version — ne pas inventer le nom de la clé).
blocks_storage:
  s3:
    bucket_name: ${S3_BUCKET_MIMIR}
  storage_prefix: blocks
# Seaux ou préfixes distincts pour ruler_storage et alertmanager_storage
# (exigence officielle Mimir si le même seau est réutilisé).
```

### 3.2 Loki

Pour les clients Thanos (documentés pour Loki récent), `S3ForcePathStyle` est remplacé par `bucket_lookup_type: path` lorsque l'adressage path-style est requis ([migration](https://grafana.com/docs/loki/latest/setup/migrate/migrate-storage-clients/)). La CA se configure dans le bloc HTTP documenté (ex. `http` / `tls_ca_path` selon la version — caler le nom, ne pas l'inventer).

```
# Extrait — NON TESTÉ — caler sur la doc Loki 3.7.9
# storage_config / object_store selon le schéma de la version
#   s3:
#     bucket_name: ${S3_BUCKET_LOKI}
#     endpoint: ${S3_FQDN}
#     region: ${S3_REGION}
#     access_key_id: ${S3_ACCESS_KEY}
#     secret_access_key: ${S3_SECRET_KEY}
#     insecure: false
#     bucket_lookup_type: path    # si S3_FORCE_PATH_STYLE=true (doc Thanos/Loki)
```

### 3.3 Tempo

Source : [Amazon S3 and S3-compatible storage](https://grafana.com/docs/tempo/latest/configuration/hosted-storage/s3/). Paramètre officiel documenté : `forcepathstyle`.

```
# Extrait — NON TESTÉ — caler sur la doc Tempo 3.1.1
storage:
  trace:
    backend: s3
    s3:
      endpoint: ${S3_FQDN}
      bucket: ${S3_BUCKET_TEMPO}
      region: ${S3_REGION}
      access_key: ${S3_ACCESS_KEY}     # depuis fichier 0600
      secret_key: ${S3_SECRET_KEY}
      insecure: false
      forcepathstyle: true             # si S3_FORCE_PATH_STYLE=true
      # CA : magasin système et/ou paramètre TLS documenté par la version
```

Déposer la CA (`${S3_CA_FILE}`) et l'enregistrer dans le magasin de confiance (RHEL : `update-ca-trust`, procédure déjà au §3.4 du runbook VM ; Kubernetes : ConfigMap / volume monté, plus le paramètre TLS du client si la version le documente).

## 4. Tests (sans secret en ligne de commande)

**Non testé.** Identifiants dans un fichier `0600` (`~/.aws/credentials` ou `AWS_SHARED_CREDENTIALS_FILE`, ou configuration `mc` dans `~/.mc/` en `0600`). Jamais `--secret-key` ni `-w` sur la ligne, jamais `echo` du secret.

```
# Exemples — NON TESTÉ — FQDN et seau issus des variables
# CA : --ca-bundle / --cacert, pas --no-verify
export AWS_SHARED_CREDENTIALS_FILE=/etc/lgtm/s3-mimir.credentials   # 0600
export AWS_CONFIG_FILE=/etc/lgtm/s3-mimir.config

# Listage (path-style si retenu : --addressing-style path, selon aws cli)
aws --endpoint-url "${S3_ENDPOINT}" --ca-bundle "${S3_CA_FILE}" \
    s3 ls "s3://${S3_BUCKET_MIMIR}/"

# Écriture / lecture / suppression sur un préfixe de TEST dédié, jamais un préfixe métier
aws --endpoint-url "${S3_ENDPOINT}" --ca-bundle "${S3_CA_FILE}" \
    s3 cp /etc/hosts "s3://${S3_BUCKET_MIMIR}/lgtm-test/$(hostname)-probe.txt"
aws --endpoint-url "${S3_ENDPOINT}" --ca-bundle "${S3_CA_FILE}" \
    s3 ls "s3://${S3_BUCKET_MIMIR}/lgtm-test/"
aws --endpoint-url "${S3_ENDPOINT}" --ca-bundle "${S3_CA_FILE}" \
    s3 rm "s3://${S3_BUCKET_MIMIR}/lgtm-test/$(hostname)-probe.txt"

# Variante mc (alias défini au préalable par fichier, pas de secret en argument)
# mc alias set … — suivre mc alias set --help de la version (fichier 0600)
mc --insecure=false ls "lgtm-mimir/${S3_BUCKET_MIMIR}"
```

Répéter pour Loki et Tempo (identifiants de **leur** compte). Contrôler aussi un `openssl s_client -connect ${S3_FQDN}:443 -servername ${S3_FQDN}` : le SAN doit contenir le FQDN utilisé. Puis une écriture réelle depuis Mimir, Loki et Tempo en préproduction (création d'un bloc, lecture, compactage / rétention).

## 5. Supervision

L'équipe stockage conserve la supervision du cluster HCP / VSP One Object (moyens déjà en place : console, SNMP, API d'administration — **ne pas inventer** d'export Prometheus Hitachi ici). Côté LGTM :

- erreurs et latences d'écriture / lecture objet dans les métriques Mimir, Loki et Tempo (compteurs documentés par chaque composant) ;
- codes 403 / 5xx vers `${S3_ENDPOINT}` ;
- expiration du certificat du point de service ;
- test périodique de list / put / get / delete sur le préfixe de test (§4) ;
- journalisation des échecs, sans jamais tracer un secret.

**Non testé.**

## 6. Points de vigilance (compatibilité API) — ne rien inventer

Les clients Grafana documentent un backend **S3 compatible**. Hitachi documente, pour chaque produit, le **niveau de prise en charge** des opérations S3. Aucune certification croisée Grafana Labs × Hitachi n'a été trouvée dans ces sources : **qualifier en préproduction**. Ce qui suit est uniquement ce que les matrices officielles Hitachi indiquent.

| Opération S3 | HCP (matrice officielle) | VSP One Object (matrice officielle) | Usage côté LGTM | Suite |
|---|---|---|---|---|
| Listage (List Objects v1 et **ListObjectsV2** / GET Bucket Version 2) | **Supported** (v1 et v2) | **Fully supported** (`ListObjects`, `ListObjectsV2`) | Inventaire des blocs / chunks | Compatible d'après Hitachi. Qualifier avec Mimir / Loki / Tempo en préprod. |
| **DeleteObjects** (suppression multiple, `POST ?delete`) | **Supported**, avec **limites** documentées : on ne peut pas supprimer par cette méthode des objets **sous rétention**, **sous hold**, des *delete markers*, ni **plusieurs versions** d'objets ([doc](https://docs.hitachivantara.com/r/en-us/mk-95hcph002/latest/using-the-hitachi-api-for-amazon-s3/working-with-objects/deleting-multiple-objects)) | **Fully supported** | Compactage et rétention Grafana (suppressions de blocs) | **À confirmer** : ne pas activer une rétention / un *object lock* HCP qui empêcherait le compacteur de supprimer, ou aligner explicitement avec la rétention Grafana. Qualifier en préprod. |
| **Multipart** (initiate, UploadPart, Complete, Abort, List) | HCP documente le travail avec les *multipart uploads* (dépôt d'une partie, listage des en-cours). La matrice cite notamment **List Multipart Uploads : Supported**. | **Fully supported** pour `CreateMultipartUpload`, `UploadPart`, `CompleteMultipartUpload`, `AbortMultipartUpload`, `ListParts`, `ListMultipartUploads` | Envoi de gros blocs | Compatible d'après Hitachi (VSP One Object : sans réserve sur ces appels). Qualifier les tailles réelles en préprod. |
| Versioning de seau | GET / PUT Bucket versioning : **Supported** | `ListObjectVersions` : **Fully supported** | Optionnel | **À confirmer** avec l'équipe stockage (souhaitable dans la checklist). |
| Cycle de vie S3 (`PUT/GET Bucket lifecycle`) | **Not supported** sur HCP (matrice) | **À confirmer** sur la matrice de la version VSP One Object (ne pas l'affirmer ici) | Rétention | La rétention opérationnelle LGTM se règle côté Mimir / Loki / Tempo. Les *service plans* HCP éventuels sont à convenir avec l'équipe stockage. |
| Politique de seau S3 (`PUT Bucket policy`) | **Not supported** sur HCP | **À confirmer** (VSP One Object) | IAM | S'appuyer sur les comptes et ACL **du produit Hitachi**, pas sur une bucket policy S3 AWS. |

Autres écarts VSP One Object documentés (pour ne pas les découvrir en production) : certaines opérations ne sont **pas** prises en charge (`GetObjectAcl`, `PutObjectAcl`, `RestoreObject`, etc.) ; `GetObject` sans en-têtes conditionnels ni `partNumber` ; `PutObject` : l'ETag n'est pas entouré de guillemets. Sans impact attendu sur le chemin nominal Mimir / Loki / Tempo, **à confirmer** en préprod.

Signature : HCP prend en charge AWS Signature **v4 et v2**. Les clients Grafana récents utilisent v4 (Loki Thanos : « always uses Signature Version 4 »). Rester en v4.

## 7. Schéma de décision

```mermaid
flowchart TD
  A["Checklist avec l'équipe stockage"] --> B{"HCP avec HS3 ou VSP One Object,<br/>joignable, HTTPS, IAM, capacité ?"}
  B -->|oui, critères essentiels OK| C["Scénario A — Hitachi<br/>Annexe HCP / VSP One Object<br/>STOCKAGE_OBJET_SCENARIO=hitachi"]
  B -->|"HNAS seul (NFS/SMB/FTP/iSCSI)<br/>ou Data Migrator seulement"| D["HNAS n'est pas une API S3 serveur"]
  D --> E{"Peut-on obtenir un HCP<br/>ou un VSP One Object ?"}
  E -->|oui| C
  E -->|non| F
  B -->|aucun stockage objet S3| F["Scénario B — MinIO distribué<br/>Annexe C, licence AGPLv3 à valider<br/>STOCKAGE_OBJET_SCENARIO=minio"]
  G["NFS ou système de fichiers partagé<br/>comme backend des blocs"] --> H["Rejeté — doc Grafana Labs<br/>Mimir / Loki / Tempo"]
```

Procédures **non testées**. Diagrammes : [07 MinIO (scénario B)](../diagrammes/07_stockage_objet_minio.vsdx), [08 Hitachi (scénario A)](../diagrammes/08_stockage_objet_hitachi.vsdx).
