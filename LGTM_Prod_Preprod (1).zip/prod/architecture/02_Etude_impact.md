# Étude d'impact — Introduction de la plateforme LGTM en préproduction et production

**Date :** 2026-11-11. Cette étude accompagne le [document d'architecture](01_Document_architecture.md). Elle identifie les impacts sur l'existant, les risques et le plan de transition. Elle ne remplace pas une analyse de risque formelle de l'organisation.

---

## 1. Synthèse

L'introduction de LGTM + Kafka + OpenTelemetry est conçue comme une **extension** de l'observabilité, pas comme une coupure. Elasticsearch 8, ReadonlyREST, ElastAlert2, SCOM et AppDynamics **restent en service**. La double écriture des journaux (groupe Kafka `elk-es`) permet de comparer et de revenir en arrière. Les impacts principaux portent sur le **réseau** (nouveaux flux), la **PKI** (nouveaux certificats, discipline du SAN), l'**identité** (comptes de liaison AD, groupes), les **ressources** (machines ou nœuds Kubernetes, stockage objet) et l'**exploitation** (nouvelles compétences, supervision de la supervision).

Le risque le plus élevé si la transition est mal menée : une **double vérité** (alertes ElastAlert2 et alertes Mimir divergentes) ou une **perte d'écriture vers ES** (certificat, 401 ROR) sans que Loki ne soit encore la référence. Ces risques sont mitigés par le maintien d'ElastAlert2 jusqu'aux critères de retrait, par le LAG Kafka visible dans la vue unique, et par des exercices de panne en préprod.

---

## 2. Impact sur Elasticsearch, ReadonlyREST et ElastAlert2

### 2.1 Ce qui ne change pas

- Le cluster ES 8, ses nœuds, ses index existants, ROR comme moteur d'accès, ElastAlert2 comme moteur d'alertes sur ES.
- X-Pack Security n'est pas réactivé pour l'authentification (voir [ADR-004](adr/ADR-004_ROR_vs_XPack.md)).

### 2.2 Ce qui s'ajoute

- Deux comptes de service ROR : `otel-writer` (écriture `logs-*`) et `grafana-reader` (lecture). Hachage `auth_key_pbkdf2`. Mots de passe dans des fichiers 0600 / `$__file{}`.
- Blocs `ldap_auth`, alignés sur les groupes AD de Grafana. Placement **avant** les blocs larges. Rechargement à chaud (ROR Enterprise) ; `force_load_from_file` en secours. Audit et multi-tenancy Kibana à activer (ADR-004).
- Un flux d'écriture nouveau : otel-gw → HTTPS 9200, volume égal aux journaux OTLP (à dimensionner : ingestion, shards, ILM existant).
- Data streams `logs-*` : vérifier la compatibilité avec les politiques ILM / index already used by Logstash. **Non testé** contre le mapping exact en place.

### 2.3 Risques spécifiques

| Risque | Impact | Mitigation |
|---|---|---|
| 403 sur une action ES non listée dans le bloc ROR | Arrêt de la double écriture, LAG `elk-es` | Démarrer avec un jeu d'actions prudent, ajuster d'après le journal ES (sans jamais afficher de secret) |
| Configuration ROR lue depuis l'index `.readonlyrest` | Fichier ignoré | `force_load_from_file: true` le temps de la mise à jour |
| Certificat ES sans le FQDN client dans le SAN | Échec TLS, aucune écriture | Procédure SAN du runbook, contrôle `openssl` avant bascule |
| Charge additionnelle sur ES | Latence, saturation | Observer en préprod, limiter le pipeline, possibilité de réduire le débit |
| Collision de champs avec l'ingestion Logstash existante | Mapping conflict | Préfixe / data stream dédié (`logs-otel-*`) si besoin, à décider en préprod |

ElastAlert2 n'a pas à changer tant qu'il lit les mêmes `logs-*`. Si le format OTel diffère du format Logstash, des règles devront être adaptées **avant** tout retrait de l'ancienne ingestion. Cette comparaison est un **critère de passage**.

```mermaid
flowchart LR
  A["Journaux OTLP"] --> K["Kafka otlp_logs"]
  K --> L["Loki — groupe lgtm-loki"]
  K --> E["ES — groupe elk-es"]
  E --> EA2["ElastAlert2 inchangé"]
  E --> KB["Kibana inchangé"]
  L --> GF["Grafana"]
  E --> GF
```

---

## 3. Impact sur SCOM 2019

SCOM **2019** (System Center 2019 Operations Manager) reste le superviseur Microsoft. La plateforme LGTM n'en prend pas le rôle.

**Cycle de vie officiel** ([Product Lifecycle](https://learn.microsoft.com/en-us/lifecycle/products/system-center-2019-operations-manager), politique Fixed) : support standard terminé le **10 avril 2024** (heure du Pacifique) ; support étendu jusqu'au **10 avril 2029** (06:59:59 PT). Au 12 novembre 2026, le produit est en **support étendu** (correctifs de sécurité, pas de nouvelles fonctionnalités au titre de cette phase). Certaines pages de documentation 2019 affichent une bannière invitant à passer à Operations Manager 2022 ; les dates contraignantes restent celles de la page Lifecycle. **Planifier la migration** vers une version en support standard avant avril 2029. Cette migration est hors déploiement LGTM, mais elle limite l'investissement dans des intégrations liées à la seule version 2019.

- **Voie journaux (A), recommandée en premier :** agents OpenTelemetry (`windowseventlog`) ou collecteur WEF → VIP `${OTEL_GW_FQDN}` → Loki. Impact : déploiement d'agents sur les serveurs Windows concernés, règles de pare-feu, volume de journaux à estimer (canaux choisis, pas l'intégralité de Security sans étude).
- **Voie métriques (B) :** exportateur Prometheus communautaire ([OpsLogix](https://github.com/opslogix/SCOM-Prometheus-Exporter)), prérequis du projet « Microsoft SCOM 2019 or later » — **non officiel Microsoft**, licence AGPL-3.0, à qualifier (charge sur le SDK / le serveur de gestion). Impact uniquement après qualification.
- **Voie C — API REST et SDK :** SCOM 2019 expose une API REST (depuis 1801) ; à partir de UR1, jeton CSRF (`SCOM-CSRF-TOKEN`). Le SDK et le Connector Framework (OMCF) sont documentés par Microsoft ([third-party integration, vue sc-om-2019](https://learn.microsoft.com/en-us/system-center/scom/plan-thirdparty-integration?view=sc-om-2019)). Un greffon Grafana tierce (OpsLogix SCOM Data Source) s'appuie sur cette API : ni Grafana Labs, ni Microsoft ; à qualifier. La consultation SQL des bases Operations Manager / Data Warehouse n'est **pas** retenue comme voie principale (données sensibles).
- **Pas d'impact** sur les moniteurs et notifications SCOM existants tant qu'aucune bascule n'est décidée.

FQDN d'exemple de la console : `${SCOM_FQDN}` (`scom.exemple.local` / `scom-pp.exemple.local`), port 443. Risque : croire que Grafana « remplace » SCOM dès le jour 1. Mitigation : panneaux d'accueil clairement intitulés « emplacement », communication aux équipes. Détail : [ADR-008](adr/ADR-008_Integration_SCOM_AppDynamics.md).

---

## 4. Impact sur AppDynamics (contrôleur on-premises)

Le contrôleur AppDynamics est **sur site**. Il reste la référence APM. Les flux, certificats et l'annuaire se configurent contre ce contrôleur, pas contre un tenant SaaS. FQDN d'exemple : `${APPD_FQDN}` (`appd.exemple.local`), URL `${APPD_URL}` (`https://appd.exemple.local:8181`).

- Aucune obligation d'éteindre le contrôleur.
- **Ports :** HTTPS **8181** (à utiliser) ; HTTP **8090** à désactiver et bloquer ; Enterprise Console 9191 ; Events Service 9080/9081 si présent. Sources : [Port Settings on-premises](https://docs.appdynamics.com/appd/onprem/24.x/latest/en/planning-your-deployment/port-settings).
- **Certificats :** remplacer le certificat auto-signé éventuel par un certificat de l'autorité interne, **SAN = FQDN réellement utilisé** par Grafana, les agents et les navigateurs. Le CA interne va dans le truststore de Grafana et des agents (les agents .NET l'exigent). **Non testé** ici.
- **LDAP :** le contrôleur on-premises peut s'authentifier contre AD (LDAPS 636) : *Controller Settings > Administration > Authentication Provider > LDAP*. Bind DN, Base DN, `sAMAccountName`, mapping des groupes vers les rôles AppDynamics ; compte d'administration local en secours. Recommandation : **même AD** que Grafana (deux configurations indépendantes). Flux nouveau possible : contrôleur → DC 636, s'il n'est pas déjà ouvert. **Non testé**.
- Le greffon Grafana officiel est **Enterprise** ([docs](https://grafana.com/docs/plugins/dlopes7-appdynamics-datasource/latest/)). L'URL pointe vers `${APPD_URL}`. Le fonctionnement contre un contrôleur on-premises est **à vérifier (non testé)**. Sans licence, pas d'intégration native des métriques AppD dans Grafana OSS (lien + corrélation `service.name`).
- *AppDynamics for OpenTelemetry* (documentation On-Premises) envoie des traces **vers** le contrôleur (`otlphttp`, en-tête `x-api-key`, endpoint documenté `${APPD_OTEL_INGEST}` = `https://<dns>:8181/otis/ingest`, **à vérifier sur la version installée, non testé**). Ce n'est pas un flux AppD → Tempo.
- Impact futur : instrumentation OTel des applications (SDK) vers la passerelle, en parallèle de l'agent AppD le temps de la comparaison (possible surcharge : deux agents). À piloter application par application.

Détail : [ADR-008](adr/ADR-008_Integration_SCOM_AppDynamics.md).

---

## 5. Impact réseau et pare-feu

Tous les flux du [tableau du document d'architecture, §6](01_Document_architecture.md) sont des **demandes nouvelles** (ou des extensions). En particulier :

- Ouverture 4317/4318 vers le VIP otel-gw depuis les sous-réseaux applicatifs et d'administration.
- Ouverture 9092 (et 9093 entre courtiers, si distinct) entre otel-gw, consommateurs et Kafka.
- Ouverture 9200 depuis otel-gw et Grafana vers ES (souvent déjà ouvert depuis Logstash / Kibana : **ajouter** les nouvelles sources, ne pas tout ouvrir).
- LDAPS 636 depuis Grafana, grafana_acl_sync et les nœuds ES (ROR).
- Accès objet S3 depuis Mimir, Loki, Tempo : **scénario A** vers le tenant HCP ou VSP One Object (port 443, CA interne) ; **scénario B** vers MinIO (443 ou 9000). Un HNAS (NFS) n'est pas un flux S3.
- VIP Grafana 443 depuis les réseaux utilisateurs.
- Grafana (greffon, si licence) et éventuellement otel-gw vers le contrôleur AppDynamics on-premises **8181** ; LDAP du contrôleur vers AD **636**.
- Éventuellement Grafana ou un exportateur qualifié vers la console SCOM 2019 **443**.

Sur RHEL 8 : règles **firewalld** par zone, limitées aux sources nécessaires. En Kubernetes : NetworkPolicies. Les VIP keepalived impliquent le multicast ou unicast VRRP autorisé entre les deux équilibreurs.

Impact opérationnel : délai de qualification réseau, souvent le chemin critique.

---

## 6. Impact sécurité

| Thème | Impact | Mesure |
|---|---|---|
| Surface d'attaque | Nouveaux services exposés (VIP OTLP, VIP Grafana, S3, Kafka) | TLS, filtrage par source, pas d'écoute 0.0.0.0 sans règle |
| Identité | Comptes de liaison AD (Grafana, ROR, acl_sync) | Lecture seule, UO dédiée, mot de passe rotatif, fichiers 0600 |
| Secrets | Jetons Grafana, mots de passe ROR, clés S3, keystores Kafka | Jamais en ligne de commande, jamais dans Git, `$__file{}` / env depuis fichier |
| Certificats | Nombreux certificats de service | SAN complet, alerte J-30, procédure de rotation |
| SELinux | Services sur ports non standard | `semanage port`, `restorecon`, jamais de permissive durable |
| Audit | Nouveaux journaux d'accès Grafana et ROR | Conservation alignée sur la politique existante |
| Licence | Greffon AppDynamics = Enterprise ; Team Sync = Enterprise | Décision d'achat explicite, sinon composant OSS |

---

## 6.1 Impact identité — LDAP principal (ADR-006), SSO optionnel (ADR-011)

**LDAP / LDAPS est le mécanisme d'authentification principal** de Grafana OSS : impact principalement organisationnel (compte de liaison, groupes AD, CA pour le port 636, script `grafana_acl_sync`). ReadonlyREST **Enterprise** s'aligne sur les **mêmes groupes** (connecteur `ldaps`, audit, multi-tenancy Kibana, rechargement à chaud).

Un SSO en édition OSS (annexe, ADR-011) n'est **pas** requis pour entrer en service. S'il est activé plus tard, il n'achète pas SAML, Team Sync, les permissions fines de sources ni l'auditing natif Grafana (fonctions Grafana Enterprise). Il ajoute :

- **Kerberos** : compte de service AD, SPN, keytab AES-256, Apache sur les nœuds Grafana, port 3000 restreint à la boucle locale, flux vers le DC **88**, exigence d'horloge et de DNS (direct et inverse).
- **OIDC** : uniquement si **AD FS** est déjà (ou sera) déployé — application AD FS, secret client, flux 443, URL de rappel `${OAUTH_REDIRECT_URL}`. Sans AD FS, cette voie n'est pas ouverte.
- **Compensations :** `grafana_acl_sync` (déjà prévu), organisations Grafana pour isoler les sources, journaux Grafana/Apache vers Loki (piste d'exploitation, pas un équivalent de l'[auditing Enterprise](https://grafana.com/docs/grafana/latest/setup-grafana/configure-security/audit-grafana/)).

Risque nouveau (uniquement si le SSO Auth Proxy est activé) : usurpation de l'en-tête si `whitelist` ou la liaison locale sont omises. Mitigation : procédure en **annexe B** des runbooks. **Non testé.**

---

## 7. Impact exploitation

- **Compétences :** Kafka (KRaft, groupes, LAG), Mimir / Loki / Tempo (modes distribués, objet), Grafana HA, otelcol, Helm/opérateurs si Kubernetes.
- **Astreinte :** ajouter les alertes « supervision de la supervision » (LAG, `up`, certificats, files d'export) à la chaîne existante (Alertmanager → ITSM / messagerie déjà utilisée).
- **Sauvegardes :** PostgreSQL Grafana, configuration (Git), seaux S3, métadonnées Kafka, `readonlyrest.yml`. Les blocs objet sont la vérité des historiques LGTM.
- **Mises à jour :** campagnes hors ligne (même chaîne Windows → SFTP), préprod d'abord, notes de version officielles. Kafka, ES et ROR : versions liées (ROR doit matcher ES).
- **Horaires :** exercices de panne et de restauration en préprod avant la prod.

---

## 8. Impact coûts et ressources

Ordres de grandeur uniquement (voir le dimensionnement du document d'architecture, clairement indiqué comme **estimations recommandées**) :

- **Préproduction :** 22 VM, ou **26** en scénario B (MinIO) ; pools Kubernetes équivalents (§8.3). En scénario A (Hitachi), les quatre VM MinIO ne sont pas déployées.
- **Production :** 41 VM, ou **45** en scénario B. Préprod et prod sont des environnements **séparés** (pas de mutualisation du plan de données).
- Stockage objet : terme dominant sur 6–12 mois de rétention, fonction du débit réel (inconnu ici) ; chiffrement au repos demandé. Scénario A : capacité et quotas à convenir avec l'équipe stockage Hitachi. Scénario B : disques des quatre nœuds MinIO.
- Licences : Grafana OSS = 0 ; ROR déjà en place ; MinIO (scénario B) selon l'édition retenue, licence communautaire **AGPLv3** à valider ; greffon AppDynamics et Team Sync = Grafana Enterprise **si** on les veut. Exportateur SCOM communautaire : licence AGPL-3.0 du projet, à relire. SCOM 2019 est en support étendu : la migration vers une version en support standard a un coût propre, hors LGTM.
- Charge humaine : un chantier d'installation et de qualification de plusieurs semaines (réseau, PKI, AD, essais), puis un effort d'exploitation récurrent. Ajouter la qualification des voies SCOM B/C et, le cas échéant, du greffon AppDynamics contre le contrôleur on-premises.

Ces chiffres **n'ont pas été tarifés** : ils demandent les prix internes (VM, stockage, éventuelles licences).

---

## 9. Risques et mitigations

| Id | Risque | Prob. | Impact | Mitigation |
|---|---|---|---|---|
| R01 | Certificat sans le FQDN client (SAN) | moyenne | écriture ES ou TLS OTLP cassés | Contrôle `openssl` obligatoire, alerte, procédure dédiée (ADR-007) |
| R02 | Quorum Kafka perdu (2 courtiers) | faible | arrêt d'ingestion | 3 AZ / 3 VM distinctes, supervision, pas de maintenance simultanée |
| R03 | Divergence alertes ElastAlert2 / Mimir | moyenne | faux sentiment de couverture | période de double course, critère de retrait écrit |
| R04 | 403 ROR mal calibré | moyenne | double écriture arrêtée | jeu d'actions ajusté en préprod, LAG `elk-es` |
| R05 | AD indisponible | faible | plus de nouvelle connexion Grafana | compte d'urgence local, sessions déjà ouvertes |
| R06 | Charge imprévue (cardinalité Mimir, volume Loki) | moyenne | coût, lenteur | limites, recording rules, observation préprod |
| R07 | Dérive des versions entre VM et Kubernetes | moyenne | divergences de comportement | tableau de versions commun, campagne unique |
| R08 | Qualité de l'exportateur SCOM communautaire (2019+) | inconnue | intégration métriques SCOM décalée | voie A (journaux) d'abord ; qualification explicite des voies B/C |
| R09 | Attente d'un greffon AppD dans OSS ; certificats / LDAP du contrôleur on-prem | haute (fait Enterprise) | pas de métriques AppD natives dans Grafana OSS ; TLS cassé si SAN ou CA manquant | ADR-008, licence ou corrélation manuelle ; CA interne et SAN = FQDN client |
| R10 | Installation hors ligne incomplète (dépendance RPM manquante) | moyenne | retard | manifeste SHA, `rpm -qp --requires`, lot de dépendances RHEL 8 |
| R11 | SELinux bloque un port ou un répertoire | moyenne | service down | `semanage` / `restorecon` dans chaque étape du runbook |
| R12 | Secret fuité (capture, historique, ticket) | faible | compromission | procédures `read -rsp`, révocation, échéance 90 j |
| R14 | Usurpation Auth Proxy ou keytab / SPN Kerberos incorrect (si SSO activé, annexe) | moyenne | connexion d'un tiers ou SSO inopérant | whitelist + bind 127.0.0.1 ; AES-256 ; contrôles setspn ; ADR-011 ; LDAP reste le socle |
| R13 | Fin du support étendu SCOM 2019 (10 avril 2029 PT) | certaine (date) | intégration à reprendre sur une version supérieure | planifier la migration ; limiter l'investissement spécifique 2019 |

---

## 10. Plan de transition

Le principe est le **remplacement progressif** (double course, critères, puis retrait), pas un basculement unique.

```mermaid
flowchart TD
  P0["P0 — Fondation<br/>PKI, AD, réseau, objet, Kafka, stockages, Grafana HA, LDAP, ACL, vue unique"]
  P1["P1 — Agents d'infrastructure<br/>node_exporter, otelcol journald / Windows<br/>métriques et journaux d'hôtes dans LGTM"]
  P2["P2 — Double écriture journaux<br/>pipeline logs/elk, groupe elk-es, ROR otel-writer<br/>comparaison avec l'ingestion ES existante"]
  P3["P3 — Applications OTLP<br/>SDK, traces dans Tempo, corrélation"]
  P4["P4 — SCOM 2019 / AppD on-prem<br/>voie A SCOM, qualification B/C,<br/>certificats et LDAP du contrôleur,<br/>décision greffon AppD ou liens"]
  P5["P5 — Observation<br/>double course des alertes, critères écrits"]
  P6["P6 — Retrait contrôlé<br/>pipeline elk-es retiré, comptes révoqués<br/>ELK en lecture seule puis, éventuellement, extinction"]
  P0 --> P1 --> P2 --> P3 --> P4 --> P5 --> P6
  P6 -->|retour arrière| P2
```

### Critères de passage (indicatifs, à formaliser)

| De | Vers | Critères |
|---|---|---|
| P0 → P1 | Fondation verte | Tous les `up` à 1, certificats validés, LDAP OK, ACL `--dry-run` puis réel, vue unique provisionnée |
| P1 → P2 | Agents stables | Journaux d'hôtes visibles dans Loki, LAG 0 |
| P2 → P3 | Double écriture fiable | LAG `elk-es` à 0, mêmes événements visibles dans ES et Loki sur un échantillon, pas de 403 |
| P3 → P4 | Une application pilote | Une trace bout en bout dans Grafana (Tempo ↔ Loki ↔ Mimir) |
| P5 → P6 | Observation | Aucune alerte ElastAlert2 manquée par le nouveau dispositif sur la période convenue ; décision écrite |

### Retour arrière

À tout moment avant P6 : arrêter les nouveaux agents ou les rediriger, laisser ES / ElastAlert2 / SCOM / AppDynamics comme avant. Après activation de `elk-es`, le retrait du pipeline suffit à cesser d'écrire dans ES ; l'ancienne ingestion (Logstash ou équivalent) n'est pas coupée avant P6. Après P6, le retour arrière recrée le pipeline et un nouveau groupe, dans la limite de la rétention Kafka.

---

## 11. Critères de go-live préprod → prod

Repris et détaillés dans les runbooks (liste de contrôle). Conditions minimales :

1. Fondation P0 verte en préprod, exercices de panne (1 courrier Kafka, 1 Grafana, 1 otel-gw, 1 ingester) réalisés et mesurés.
2. Rotation d'un certificat testée.
3. Restauration PostgreSQL Grafana testée.
4. ACL sync exécuté contre l'AD de préprod (pas seulement `--mock`).
5. Règles réseau prod demandées et ouvertes, SAN des certificats prod contrôlés **avant** le premier trafic.
6. Décision écrite sur le stockage objet (checklist : scénario A Hitachi ou B MinIO ; HNAS seul insuffisant), les groupes AD, les rétentions.
7. Astreinte formée, alertes de supervision de la supervision routées.
