#!/usr/bin/env python3
"""Génère les diagrammes Visio (.vsdx) et les aperçus PNG de la plateforme LGTM préprod/prod.

Les fichiers .vsdx suivent le format OPC Visio 2013 (ISO/IEC 29500), avec formes
éditables, connecteurs et pages nommées. La structure est validée par réouverture
(zip + XML + bibliothèque vsdx si disponible).
"""
from __future__ import annotations

import io
import os
import shutil
import zipfile
from dataclasses import dataclass, field
from pathlib import Path
from xml.etree import ElementTree as ET
from xml.sax.saxutils import escape

# ---------------------------------------------------------------------------
# Géométrie : coordonnées d'auteur en pouces, origine en haut à gauche.
# Page 16:9 (13,333 in × 7,5 in) pour projection, agrandie à 16 in × 9 in.
# ---------------------------------------------------------------------------
PAGE_W = 16.0
PAGE_H = 9.0
MM_PER_IN = 25.4
NS = "http://schemas.microsoft.com/office/visio/2012/main"
RNS = "http://schemas.openxmlformats.org/officeDocument/2006/relationships"

# Palette
NAVY = "#1F3864"
NAVY_LT = "#2E5090"
GRY = "#F4F6F9"
GRY_BD = "#8EA0C0"
WHT = "#FFFFFF"
BLK = "#1A1A1A"
KAFKA = "#231F20"
KAFKA_BG = "#F3F0EB"
MIMIR = "#6D28D9"
MIMIR_BG = "#EDE9FE"
LOKI = "#C2410C"
LOKI_BG = "#FFEDD5"
TEMPO = "#1D4ED8"
TEMPO_BG = "#DBEAFE"
GRAF = "#F46800"
GRAF_BG = "#FFF4E6"
ES = "#0077CC"
ES_BG = "#E6F3FB"
OTEL = "#4F46E5"
OTEL_BG = "#E0E7FF"
SEC = "#A16207"
SEC_BG = "#FEF3C7"
SCOM = "#0078D4"
SCOM_BG = "#E0F2FE"
APPD = "#AE1F23"
APPD_BG = "#FEE2E2"
OK = "#166534"
OK_BG = "#DCFCE7"
WARN = "#9A3412"
WARN_BG = "#FFEDD5"
RED = "#991B1B"
RED_BG = "#FEE2E2"
TEAL = "#0F766E"
TEAL_BG = "#CCFBF1"

HERE = Path(__file__).resolve().parent
TPL = HERE / "_template"
OUT = HERE


def _cell(parent, n, v, f=None):
    a = {"N": n, "V": str(v)}
    if f is not None:
        a["F"] = f
    ET.SubElement(parent, "Cell", a)


@dataclass
class Shape:
    sid: int
    name: str
    kind: str  # box, zone, text, connector
    x: float
    y: float
    w: float
    h: float
    text: str = ""
    fill: str = WHT
    stroke: str = NAVY
    font: float = 0.11
    bold: bool = False
    italic: bool = False
    fc: str = BLK
    align: int = 1  # 0 left, 1 center, 2 right
    valign_top: bool = False
    rounding: float = 0.06
    dashed: bool = False
    line_w: float = 0.012
    src: int | None = None
    dst: int | None = None
    arrow: bool = True
    both: bool = False


class Page:
    def __init__(self, name: str):
        self.name = name
        self.shapes: list[Shape] = []
        self._id = 0

    def _nid(self) -> int:
        self._id += 1
        return self._id

    def box(self, text, x, y, w, h, fill=WHT, stroke=NAVY, font=0.11, bold=False,
            fc=BLK, align=1, rounding=0.06, dashed=False, line_w=0.012, valign_top=False):
        s = Shape(self._nid(), f"Shape{self._id}", "box", x, y, w, h, text,
                  fill, stroke, font, bold, False, fc, align, valign_top, rounding,
                  dashed, line_w)
        self.shapes.append(s)
        return s.sid

    def zone(self, title, x, y, w, h, fill=GRY, stroke=GRY_BD, dashed=False):
        return self.box(title, x, y, w, h, fill=fill, stroke=stroke, font=0.12,
                        bold=True, fc=NAVY, align=0, rounding=0.08, dashed=dashed,
                        valign_top=True)

    def text(self, text, x, y, w, h, font=0.11, bold=False, fc=BLK, align=0, italic=False):
        s = Shape(self._nid(), f"Text{self._id}", "text", x, y, w, h, text,
                  fill="none", stroke="none", font=font, bold=bold, italic=italic,
                  fc=fc, align=align, rounding=0, line_w=0)
        self.shapes.append(s)
        return s.sid

    def edge(self, src, dst, label="", color=NAVY, dashed=False, both=False, width=0.014):
        a = next(s for s in self.shapes if s.sid == src)
        b = next(s for s in self.shapes if s.sid == dst)
        ax, ay = a.x + a.w / 2, a.y + a.h / 2
        bx, by = b.x + b.w / 2, b.y + b.h / 2
        x = min(ax, bx)
        y = min(ay, by)
        w = max(abs(bx - ax), 0.08)
        h = max(abs(by - ay), 0.04)
        s = Shape(self._nid(), f"Dynamic connector.{self._id}", "connector",
                  x, y, w, h, label, fill="none", stroke=color, font=0.09,
                  fc=color, dashed=dashed, line_w=width, src=src, dst=dst,
                  arrow=True, both=both)
        self.shapes.append(s)
        return s.sid


def _pin(s: Shape):
    """Visio : Pin au centre, origine bas-gauche."""
    pinx = s.x + s.w / 2
    piny = PAGE_H - (s.y + s.h / 2)
    return pinx, piny


def _shape_xml(s: Shape) -> ET.Element:
    pinx, piny = _pin(s)
    el = ET.Element("Shape", {
        "ID": str(s.sid),
        "NameU": s.name,
        "Name": s.name,
        "Type": "Shape",
        "LineStyle": "0",
        "FillStyle": "0",
        "TextStyle": "0",
    })
    if s.kind == "connector":
        el.set("Master", "4")
        a = next(sh for sh in _CURRENT.shapes if sh.sid == s.src)
        b = next(sh for sh in _CURRENT.shapes if sh.sid == s.dst)
        apx, apy = _pin(a)
        bpx, bpy = _pin(b)
        # begin/end at box edges (approximate: center to center, Visio walks glue)
        _cell(el, "PinX", (apx + bpx) / 2)
        _cell(el, "PinY", (apy + bpy) / 2)
        _cell(el, "Width", max(abs(bpx - apx), 0.05))
        _cell(el, "Height", max(abs(bpy - apy), 0.02))
        _cell(el, "LocPinX", max(abs(bpx - apx), 0.05) / 2)
        _cell(el, "LocPinY", max(abs(bpy - apy), 0.02) / 2)
        _cell(el, "BeginX", apx, f="_WALKGLUE(BegTrigger,EndTrigger,WalkPreference)")
        _cell(el, "BeginY", apy, f="_WALKGLUE(BegTrigger,EndTrigger,WalkPreference)")
        _cell(el, "EndX", bpx, f="_WALKGLUE(EndTrigger,BegTrigger,WalkPreference)")
        _cell(el, "EndY", bpy, f="_WALKGLUE(EndTrigger,BegTrigger,WalkPreference)")
        _cell(el, "BegTrigger", "2", f"_XFTRIGGER(Sheet.{s.src}!EventXFMod)")
        _cell(el, "EndTrigger", "2", f"_XFTRIGGER(Sheet.{s.dst}!EventXFMod)")
        _cell(el, "ConFixedCode", "6")
        _cell(el, "LayerMember", "0")
        _cell(el, "FillPattern", "0")
        _cell(el, "LineColor", s.stroke)
        _cell(el, "LineWeight", s.line_w)
        _cell(el, "TextBkgnd", "#ffffff")
        _cell(el, "BeginArrow", "4" if s.both else "0")
        _cell(el, "BeginArrowSize", "2")
        _cell(el, "EndArrow", "4" if s.arrow else "0")
        _cell(el, "EndArrowSize", "2")
        if s.dashed:
            _cell(el, "LinePattern", "2")
        if s.text:
            sec = ET.SubElement(el, "Section", {"N": "Character"})
            row = ET.SubElement(sec, "Row", {"IX": "0"})
            _cell(row, "Color", s.fc)
            _cell(row, "Size", s.font)
            _cell(row, "Font", "Calibri")
            _cell(row, "Style", "0")
            par = ET.SubElement(el, "Section", {"N": "Paragraph"})
            r2 = ET.SubElement(par, "Row", {"IX": "0"})
            _cell(r2, "HorzAlign", "1")
            tx = ET.SubElement(el, "Text")
            ET.SubElement(tx, "cp", {"IX": "0"})
            tx.tail = None
            tx.text = s.text  # will fix below
            # proper text node
            tx.clear()
            cp = ET.SubElement(tx, "cp", {"IX": "0"})
            cp.tail = s.text
        geo = ET.SubElement(el, "Section", {"N": "Geometry", "IX": "0"})
        r = ET.SubElement(geo, "Row", {"T": "MoveTo", "IX": "1"})
        _cell(r, "X", "0")
        _cell(r, "Y", "0")
        r = ET.SubElement(geo, "Row", {"T": "LineTo", "IX": "2"})
        _cell(r, "X", max(abs(bpx - apx), 0.05))
        _cell(r, "Y", "0")
        _cell(geo, "NoFill", "1")
        _cell(geo, "NoLine", "0")
        return el

    _cell(el, "PinX", pinx)
    _cell(el, "PinY", piny)
    _cell(el, "Width", s.w)
    _cell(el, "Height", s.h)
    _cell(el, "LocPinX", s.w / 2)
    _cell(el, "LocPinY", s.h / 2)
    _cell(el, "LayerMember", "0")
    if s.kind == "text":
        _cell(el, "FillPattern", "0")
        _cell(el, "LinePattern", "0")
        _cell(el, "LineColorTrans", "1")
        _cell(el, "FillForegndTrans", "1")
    else:
        _cell(el, "FillForegnd", s.fill)
        _cell(el, "LineColor", s.stroke)
        _cell(el, "Rounding", s.rounding)
        _cell(el, "LineWeight", s.line_w)
        if s.dashed:
            _cell(el, "LinePattern", "2")
    # text box position: top-aligned for zones
    if s.valign_top:
        _cell(el, "TxtPinX", s.w / 2)
        _cell(el, "TxtPinY", s.h - 0.14)
        _cell(el, "TxtWidth", s.w - 0.08)
        _cell(el, "TxtHeight", 0.28)
        _cell(el, "TxtLocPinX", (s.w - 0.08) / 2)
        _cell(el, "TxtLocPinY", 0.14)
    else:
        _cell(el, "TxtPinX", s.w / 2)
        _cell(el, "TxtPinY", s.h / 2)
        _cell(el, "TxtWidth", s.w - 0.08)
        _cell(el, "TxtHeight", s.h - 0.08)
        _cell(el, "TxtLocPinX", (s.w - 0.08) / 2)
        _cell(el, "TxtLocPinY", (s.h - 0.08) / 2)

    style = 17 if s.bold else 0
    if s.italic:
        style |= 2
    lines = s.text.split("\n") if s.text else [""]
    sec = ET.SubElement(el, "Section", {"N": "Character"})
    for i, _ln in enumerate(lines):
        row = ET.SubElement(sec, "Row", {"IX": str(i)})
        _cell(row, "Color", s.fc)
        _cell(row, "Size", s.font)
        _cell(row, "Font", "Calibri")
        _cell(row, "Style", str(style))
        _cell(row, "Case", "0")
        _cell(row, "Pos", "0")
        _cell(row, "FontScale", "1")
        _cell(row, "Letterspace", "0")
    par = ET.SubElement(el, "Section", {"N": "Paragraph"})
    for i, _ln in enumerate(lines):
        r2 = ET.SubElement(par, "Row", {"IX": str(i)})
        _cell(r2, "HorzAlign", str(s.align))
    tx = ET.SubElement(el, "Text")
    for i, ln in enumerate(lines):
        cp = ET.SubElement(tx, "cp", {"IX": str(i)})
        if i == 0:
            tx.text = None
            cp.tail = ln + ("\n" if i < len(lines) - 1 else "")
        else:
            cp.tail = ln + ("\n" if i < len(lines) - 1 else "")
    if s.kind != "text":
        geo = ET.SubElement(el, "Section", {"N": "Geometry", "IX": "0"})
        pts = [(0, s.h), (s.w, s.h), (s.w, 0), (0, 0), (0, s.h)]
        r = ET.SubElement(geo, "Row", {"T": "MoveTo", "IX": "1"})
        _cell(r, "X", pts[0][0])
        _cell(r, "Y", pts[0][1])
        for i, (x, y) in enumerate(pts[1:], start=2):
            r = ET.SubElement(geo, "Row", {"T": "LineTo", "IX": str(i)})
            _cell(r, "X", x)
            _cell(r, "Y", y)
        _cell(geo, "NoFill", "0")
        _cell(geo, "NoLine", "0")
    return el


_CURRENT: Page | None = None


def page_xml(page: Page) -> bytes:
    global _CURRENT
    _CURRENT = page
    root = ET.Element("PageContents", {"xmlns": NS})
    shapes = ET.SubElement(root, "Shapes")
    connects = []
    for s in page.shapes:
        shapes.append(_shape_xml(s))
        if s.kind == "connector" and s.src and s.dst:
            connects.append((s.sid, s.src, s.dst))
    if connects:
        croot = ET.SubElement(root, "Connects")
        for sid, src, dst in connects:
            ET.SubElement(croot, "Connect", {"FromSheet": str(sid), "FromCell": "BeginX", "ToSheet": str(src)})
            ET.SubElement(croot, "Connect", {"FromSheet": str(sid), "FromCell": "EndX", "ToSheet": str(dst)})
    # register namespace for serialization
    ET.register_namespace("", NS)
    raw = ET.tostring(root, encoding="utf-8", xml_declaration=True)
    return raw.replace(b"ns0:", b"").replace(b"xmlns:ns0=", b"xmlns=")


def pages_xml(pages: list[Page]) -> bytes:
    parts = [
        "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>",
        '<Pages xmlns="http://schemas.microsoft.com/office/visio/2012/main"'
        ' xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">',
    ]
    for i, p in enumerate(pages):
        parts.append(
            f'<Page ID="{i}" NameU="{escape(p.name)}" Name="{escape(p.name)}"><PageSheet>'
            f'<Cell N="PageWidth" V="{PAGE_W}"/>'
            f'<Cell N="PageHeight" V="{PAGE_H}"/>'
            f'<Cell N="PageScale" V="1"/>'
            f'<Cell N="DrawingScale" V="1"/>'
            '<Section N="Layer"><Row IX="0">'
            '<Cell N="Name" V="Background"/><Cell N="Color" V="255"/><Cell N="Status" V="0"/>'
            '<Cell N="Visible" V="1"/><Cell N="Print" V="1"/><Cell N="Active" V="0"/>'
            '<Cell N="Lock" V="0"/><Cell N="Snap" V="1"/><Cell N="Glue" V="1"/>'
            '<Cell N="NameUniv" V="Background"/><Cell N="ColorTrans" V="0"/>'
            f'</Row></Section></PageSheet><Rel r:id="rId{i+1}"/></Page>'
        )
    parts.append("</Pages>")
    return "".join(parts).encode("utf-8")

CONTENT_TYPES_HEAD = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">
<Default Extension="png" ContentType="image/png"/>
<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>
<Default Extension="xml" ContentType="application/xml"/>
<Override PartName="/docProps/app.xml" ContentType="application/vnd.openxmlformats-officedocument.extended-properties+xml"/>
<Override PartName="/docProps/core.xml" ContentType="application/vnd.openxmlformats-package.core-properties+xml"/>
<Override PartName="/docProps/custom.xml" ContentType="application/vnd.openxmlformats-officedocument.custom-properties+xml"/>
<Override PartName="/visio/document.xml" ContentType="application/vnd.ms-visio.drawing.main+xml"/>
<Override PartName="/visio/masters/masters.xml" ContentType="application/vnd.ms-visio.masters+xml"/>
<Override PartName="/visio/masters/master1.xml" ContentType="application/vnd.ms-visio.master+xml"/>
<Override PartName="/visio/pages/pages.xml" ContentType="application/vnd.ms-visio.pages+xml"/>
<Override PartName="/visio/windows.xml" ContentType="application/vnd.ms-visio.windows+xml"/>
"""


def content_types(n: int) -> str:
    extra = "".join(
        f'<Override PartName="/visio/pages/page{i}.xml" ContentType="application/vnd.ms-visio.page+xml"/>'
        for i in range(1, n + 1)
    )
    return CONTENT_TYPES_HEAD + extra + "</Types>"


RELS = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/package/2006/relationships/metadata/core-properties" Target="docProps/core.xml"/>
<Relationship Id="rId2" Type="http://schemas.microsoft.com/visio/2010/relationships/document" Target="visio/document.xml"/>
<Relationship Id="rId3" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/custom-properties" Target="docProps/custom.xml"/>
<Relationship Id="rId4" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/extended-properties" Target="docProps/app.xml"/>
</Relationships>"""

DOC_RELS = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
<Relationship Id="rId1" Type="http://schemas.microsoft.com/visio/2010/relationships/masters" Target="masters/masters.xml"/>
<Relationship Id="rId2" Type="http://schemas.microsoft.com/visio/2010/relationships/pages" Target="pages/pages.xml"/>
<Relationship Id="rId3" Type="http://schemas.microsoft.com/visio/2010/relationships/windows" Target="windows.xml"/>
</Relationships>"""

APP = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Properties xmlns="http://schemas.openxmlformats.org/officeDocument/2006/extended-properties" xmlns:vt="http://schemas.openxmlformats.org/officeDocument/2006/docPropsVTypes">
<Application>Microsoft Visio</Application><AppVersion>15.0000</AppVersion>
</Properties>"""

CORE = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<cp:coreProperties xmlns:cp="http://schemas.openxmlformats.org/package/2006/metadata/core-properties" xmlns:dc="http://purl.org/dc/elements/1.1/" xmlns:dcterms="http://purl.org/dc/terms/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">
<dc:title>Plateforme LGTM préproduction et production</dc:title>
<dc:creator>Architecture observabilité</dc:creator>
<dc:language>fr-CA</dc:language>
</cp:coreProperties>"""

CUSTOM = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Properties xmlns="http://schemas.openxmlformats.org/officeDocument/2006/custom-properties" xmlns:vt="http://schemas.openxmlformats.org/officeDocument/2006/docPropsVTypes"/>"""

WINDOWS = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Windows ClientWidth="1920" ClientHeight="1080" xmlns="http://schemas.microsoft.com/office/visio/2012/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships" xml:space="preserve"/>"""

PAGE_RELS = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
<Relationship Type="http://schemas.microsoft.com/visio/2010/relationships/master" Id="rId1" Target="../masters/master1.xml"/>
</Relationships>"""


def write_vsdx(path: Path, pages: list[Page], title: str = ""):
    path.parent.mkdir(parents=True, exist_ok=True)
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w", compression=zipfile.ZIP_DEFLATED) as z:
        z.writestr("[Content_Types].xml", content_types(len(pages)))
        z.writestr("_rels/.rels", RELS)
        core = CORE
        if title:
            core = core.replace("Plateforme LGTM préproduction et production", escape(title))
        z.writestr("docProps/app.xml", APP)
        z.writestr("docProps/core.xml", core)
        z.writestr("docProps/custom.xml", CUSTOM)
        z.writestr("visio/document.xml", (TPL / "document.xml").read_bytes())
        z.writestr("visio/windows.xml", WINDOWS)
        z.writestr("visio/_rels/document.xml.rels", DOC_RELS)
        z.writestr("visio/masters/masters.xml", (TPL / "masters.xml").read_bytes())
        z.writestr("visio/masters/master1.xml", (TPL / "master1.xml").read_bytes())
        z.writestr("visio/masters/_rels/masters.xml.rels", (TPL / "masters.xml.rels").read_text())
        z.writestr("visio/pages/pages.xml", pages_xml(pages))
        prels = "".join(
            f'<Relationship Id="rId{i}" Type="http://schemas.microsoft.com/visio/2010/relationships/page" Target="page{i}.xml"/>'
            for i in range(1, len(pages) + 1)
        )
        z.writestr(
            "visio/pages/_rels/pages.xml.rels",
            '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
            '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
            + prels
            + "</Relationships>",
        )
        for i, p in enumerate(pages, start=1):
            z.writestr(f"visio/pages/page{i}.xml", page_xml(p))
            z.writestr(f"visio/pages/_rels/page{i}.xml.rels", PAGE_RELS)
    path.write_bytes(buf.getvalue())
    return path


# ============================= PNG (matplotlib) =============================

def render_png(page: Page, path: Path, dpi: int = 160):
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    from matplotlib.patches import FancyBboxPatch, FancyArrowPatch, Rectangle
    from matplotlib.patches import BoxStyle
    fig_w, fig_h = PAGE_W, PAGE_H
    fig, ax = plt.subplots(figsize=(fig_w, fig_h), dpi=dpi)
    ax.set_xlim(0, PAGE_W)
    ax.set_ylim(PAGE_H, 0)
    ax.set_aspect("equal")
    ax.axis("off")
    fig.subplots_adjust(0, 0, 1, 1)
    fig.patch.set_facecolor("white")
    ax.set_facecolor("white")

    def hex2(c):
        if not c or c in ("none", "None", "transparent"):
            return (1, 1, 1, 0)
        c = str(c).lstrip("#").strip()
        if len(c) < 6:
            return (0.1, 0.15, 0.25, 1)
        try:
            return tuple(int(c[i:i+2], 16) / 255 for i in (0, 2, 4))
        except ValueError:
            return (0.1, 0.15, 0.25, 1)

    id2 = {s.sid: s for s in page.shapes}
    # zones and boxes first, connectors, then text
    for s in page.shapes:
        if s.kind in ("box",):
            fill = hex2(s.fill) if s.fill != "none" else (1, 1, 1, 0)
            lw = s.line_w * 72
            ls = (0, (4, 3)) if s.dashed else "-"
            pad = 0.04
            box = FancyBboxPatch(
                (s.x, s.y), s.w, s.h,
                boxstyle=f"round,pad=0.0,rounding_size={s.rounding}",
                facecolor=fill, edgecolor=hex2(s.stroke), linewidth=max(lw, 0.8),
                linestyle=ls, mutation_aspect=1,
            )
            ax.add_patch(box)
            if s.text:
                weight = "bold" if s.bold else "normal"
                style = "italic" if s.italic else "normal"
                ha = {0: "left", 1: "center", 2: "right"}[s.align]
                if s.valign_top:
                    ax.text(s.x + 0.08, s.y + 0.08, s.text.split("\n")[0],
                            fontsize=s.font * 72 * 0.85, fontweight="bold",
                            color=hex2(s.fc), ha="left", va="top", fontfamily="DejaVu Sans")
                else:
                    tx = s.x + (0.08 if ha == "left" else s.w / 2 if ha == "center" else s.w - 0.08)
                    ax.text(tx, s.y + s.h / 2, s.text,
                            fontsize=s.font * 72 * 0.85, fontweight=weight, fontstyle=style,
                            color=hex2(s.fc), ha=ha, va="center", fontfamily="DejaVu Sans",
                            wrap=True, linespacing=1.25)
        elif s.kind == "text":
            ha = {0: "left", 1: "center", 2: "right"}[s.align]
            tx = s.x if ha == "left" else s.x + s.w / 2 if ha == "center" else s.x + s.w
            ax.text(tx, s.y + s.h / 2, s.text,
                    fontsize=s.font * 72 * 0.9, fontweight="bold" if s.bold else "normal",
                    fontstyle="italic" if s.italic else "normal",
                    color=hex2(s.fc), ha=ha, va="center", fontfamily="DejaVu Sans")
        elif s.kind == "connector":
            a, b = id2[s.src], id2[s.dst]
            # simple edge from closest sides
            ax0, ay0 = a.x + a.w / 2, a.y + a.h / 2
            bx0, by0 = b.x + b.w / 2, b.y + b.h / 2
            # start at border
            def border(sh, tx, ty):
                cx, cy = sh.x + sh.w / 2, sh.y + sh.h / 2
                dx, dy = tx - cx, ty - cy
                if abs(dx) < 1e-9 and abs(dy) < 1e-9:
                    return cx, cy
                # intersect rectangle
                sx = (sh.w / 2) / abs(dx) if dx else 1e9
                sy = (sh.h / 2) / abs(dy) if dy else 1e9
                t = min(sx, sy)
                return cx + dx * t, cy + dy * t
            x1, y1 = border(a, bx0, by0)
            x2, y2 = border(b, ax0, ay0)
            style = "dashed" if s.dashed else "solid"
            arr = "both" if s.both else "end" if s.arrow else "none"
            kw = dict(arrowstyle="-|>" if arr == "end" else ("<|-|>" if arr == "both" else "-"),
                      color=hex2(s.stroke), lw=max(s.line_w * 72, 1.0),
                      mutation_scale=12, linestyle=style,
                      connectionstyle="arc3,rad=0")
            ax.annotate("", xy=(x2, y2), xytext=(x1, y1),
                        arrowprops=dict(arrowstyle=kw["arrowstyle"], color=kw["color"],
                                        lw=kw["lw"], linestyle=(0, (4, 3)) if s.dashed else "-",
                                        mutation_scale=12, shrinkA=0, shrinkB=0))
            if s.text:
                ax.text((x1 + x2) / 2, (y1 + y2) / 2 - 0.08, s.text,
                        fontsize=8, color=hex2(s.stroke), ha="center", va="bottom",
                        fontfamily="DejaVu Sans",
                        bbox=dict(boxstyle="round,pad=0.12", fc="white", ec="none", alpha=0.9))
    path.parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(path, dpi=dpi, facecolor="white", bbox_inches="tight", pad_inches=0.08)
    plt.close(fig)


# ============================= Diagrammes =============================

def header(p: Page, title: str, subtitle: str):
    p.box("", 0.0, 0.0, PAGE_W, 0.62, fill=NAVY, stroke=NAVY, rounding=0)
    p.text(title, 0.25, 0.05, 12, 0.32, font=0.22, bold=True, fc=WHT, align=0)
    p.text(subtitle, 0.25, 0.32, 15, 0.25, font=0.11, fc="#D6E0F0", align=0)
    p.text("Exemples : obs.exemple.local (prod) / obs-pp.exemple.local (préprod)  —  modifier dans variables/environnements.env", 8.6, 0.15, 7.2, 0.35,
           font=0.08, fc="#D6E0F0", align=2, italic=True)


def footer(p: Page, note: str):
    p.box("", 0, 8.72, PAGE_W, 0.28, fill="#EEF2F7", stroke="#EEF2F7", rounding=0)
    p.text(note, 0.25, 8.72, 15.5, 0.28, font=0.09, fc="#445", align=0, italic=True)


def d_archi_vm() -> Page:
    p = Page("1 - Architecture VM RHEL 8")
    header(p, "Architecture cible — déploiement sur machines virtuelles RHEL 8",
           "Pile LGTM (Loki, Grafana, Tempo, Mimir) + Kafka + OpenTelemetry — haute disponibilité")
    # Sources
    p.zone("Sources", 0.2, 0.8, 2.55, 4.55, fill="#F8FAFC", stroke=GRY_BD)
    a1 = p.box("Applications\nSDK OpenTelemetry\nOTLP 4317 / 4318", 0.35, 1.15, 2.25, 0.85, fill=OTEL_BG, stroke=OTEL, font=0.10, bold=True)
    a2 = p.box("Agents hôtes\nnode_exporter\notelcol (journald)\nwindows_exporter", 0.35, 2.1, 2.25, 0.95, fill=OTEL_BG, stroke=OTEL, font=0.10)
    a3 = p.box("SCOM 2019\nscom.exemple.local\n(événements / API)", 0.35, 3.15, 2.25, 0.9, fill=SCOM_BG, stroke=SCOM, font=0.10)
    a4 = p.box("AppDynamics on-prem\nappd.exemple.local:8181\ncorrélation one-screen", 0.35, 4.15, 2.25, 0.95, fill=APPD_BG, stroke=APPD, font=0.10)

    p.zone("Ingestion HA", 2.95, 0.8, 3.15, 4.55, fill="#F8FAFC", stroke=GRY_BD)
    lb1 = p.box("HAProxy + keepalived\nVIP otel-gw.obs.exemple.local\n10.80.8.11  :4317 / :4318 TLS", 3.1, 1.15, 2.85, 0.8, fill="#DBEAFE", stroke=NAVY, font=0.10, bold=True)
    g1 = p.box("otel-gw-01\n.obs.exemple.local\nproducteur Kafka", 3.1, 2.1, 1.35, 1.15, fill=OTEL_BG, stroke=OTEL, font=0.10)
    g2 = p.box("otel-gw-02\n… otel-gw-N\nmême config", 4.55, 2.1, 1.4, 1.15, fill=OTEL_BG, stroke=OTEL, font=0.10)
    prom = p.box("Prometheus agent\nremote_write → Mimir\n(collecte pull)", 3.1, 3.4, 2.85, 0.8, fill=MIMIR_BG, stroke=MIMIR, font=0.10)
    ces = p.box("Consommateur elk-es\ndouble écriture journaux → ES (ROR)", 3.1, 4.3, 2.85, 0.8, fill=ES_BG, stroke=ES, font=0.095, bold=True)

    p.zone("Kafka KRaft — 3 courtiers  RF=3  min.insync.replicas=2", 6.3, 0.8, 3.5, 4.55, fill=KAFKA_BG, stroke=KAFKA)
    k1 = p.box("kafka-01.obs.exemple.local\nbroker + contrôleur", 6.5, 1.2, 3.1, 0.65, fill=WHT, stroke=KAFKA, font=0.10, bold=True)
    k2 = p.box("kafka-02.obs.exemple.local\nbroker + contrôleur", 6.5, 1.95, 3.1, 0.65, fill=WHT, stroke=KAFKA, font=0.10, bold=True)
    k3 = p.box("kafka-03.obs.exemple.local\nbroker + contrôleur", 6.5, 2.7, 3.1, 0.65, fill=WHT, stroke=KAFKA, font=0.10, bold=True)
    t1 = p.box("otlp_logs", 6.5, 3.5, 1.0, 0.55, fill="#FEF3C7", stroke=SEC, font=0.10, bold=True)
    t2 = p.box("otlp_metrics", 7.6, 3.5, 1.05, 0.55, fill=MIMIR_BG, stroke=MIMIR, font=0.095, bold=True)
    t3 = p.box("otlp_spans", 8.75, 3.5, 0.95, 0.55, fill=TEMPO_BG, stroke=TEMPO, font=0.10, bold=True)
    p.box("Groupes : lgtm-loki · lgtm-mimir · lgtm-tempo · elk-es", 6.5, 4.2, 3.1, 0.85, fill=WHT, stroke=KAFKA, font=0.10)

    p.zone("Stockages HA + objet S3", 10.05, 0.8, 5.75, 4.55, fill="#F8FAFC", stroke=GRY_BD)
    m = p.box("Mimir (microservices / simple-scalable)\ningesters · store-gateway · queriers\nAlertmanager en cluster", 10.2, 1.15, 2.65, 1.2, fill=MIMIR_BG, stroke=MIMIR, font=0.10, bold=True)
    l = p.box("Loki (simple-scalable / distributed)\nwrite · read · backend", 13.0, 1.15, 2.6, 1.2, fill=LOKI_BG, stroke=LOKI, font=0.10, bold=True)
    t = p.box("Tempo (microservices)\ndistributor · ingester · querier\nmetrics-generator → Mimir", 10.2, 2.5, 2.65, 1.2, fill=TEMPO_BG, stroke=TEMPO, font=0.10, bold=True)
    s3 = p.box("Stockage objet\ns3.obs.exemple.local\n(MinIO distribué\nou S3 existant)", 13.0, 2.5, 2.6, 1.2, fill="#ECFDF5", stroke=TEAL, font=0.10, bold=True)
    es = p.box("Elasticsearch 8 + ROR\nes.exemple.local\nTLS + ACL  ·  logs-*\nElastAlert2", 10.2, 3.85, 2.65, 1.25, fill=ES_BG, stroke=ES, font=0.10, bold=True)
    objn = p.box("Consommateurs locaux\notelcol sur chaque\nstockage LGTM", 13.0, 3.85, 2.6, 1.25, fill=OTEL_BG, stroke=OTEL, font=0.10)

    # Consultation
    p.zone("Consultation « one screen » et identité", 0.2, 5.5, 15.6, 3.05, fill="#FFFBF5", stroke=GRAF)
    haproxy = p.box("HAProxy + keepalived\ngrafana.obs.exemple.local\nVIP 10.80.8.10  :443", 0.35, 5.9, 2.35, 0.9, fill="#DBEAFE", stroke=NAVY, font=0.10, bold=True)
    gf1 = p.box("grafana-01\n.obs.exemple.local", 2.85, 5.9, 1.7, 0.9, fill=GRAF_BG, stroke=GRAF, font=0.10, bold=True)
    gf2 = p.box("grafana-02\n.obs.exemple.local", 4.65, 5.9, 1.7, 0.9, fill=GRAF_BG, stroke=GRAF, font=0.10, bold=True)
    pg = p.box("PostgreSQL HA\n(base partagée Grafana)", 6.5, 5.9, 2.3, 0.9, fill="#F1F5F9", stroke=NAVY, font=0.10)
    ones = p.box("Tableau de bord d'accueil\nvue unique santé + signaux\n+ corrélation SCOM / AppD", 9.0, 5.9, 3.2, 0.9, fill=GRAF_BG, stroke=GRAF, font=0.10, bold=True)
    ldap = p.box("Active Directory\ndc01 / dc02.exemple.local\nLDAPS 636", 12.4, 5.9, 3.15, 0.9, fill=SEC_BG, stroke=SEC, font=0.10, bold=True)
    acl = p.box("Composant ACL\ngrafana_acl_sync\nAD → équipes → dossiers → permissions", 0.35, 6.95, 6.0, 0.85, fill=SEC_BG, stroke=SEC, font=0.10, bold=True)
    pki = p.box("PKI interne (AD CS)\nSAN = FQDN des clients  ·  chaîne de confiance  ·  rotation", 6.55, 6.95, 9.0, 0.85, fill=SEC_BG, stroke=SEC, font=0.10, bold=True)

    p.edge(a1, lb1, "OTLP", color=OTEL)
    p.edge(a2, lb1, "", color=OTEL)
    p.edge(a3, lb1, "", color=SCOM, dashed=True)
    p.edge(lb1, g1, "", color=OTEL)
    p.edge(g1, k1, "produce", color=KAFKA)
    p.edge(k1, m, "lgtm-mimir", color=MIMIR)
    p.edge(k2, l, "lgtm-loki", color=LOKI)
    p.edge(k3, t, "lgtm-tempo", color=TEMPO)
    p.edge(ces, es, "logs-*", color=ES, dashed=True)
    p.edge(m, s3, "", color=TEAL)
    p.edge(haproxy, gf1, "", color=GRAF)
    p.edge(gf1, ones, "", color=GRAF)
    p.edge(ldap, gf2, "LDAP", color=SEC)
    footer(p, "Noms : obs.exemple.local (prod), obs-pp.exemple.local (préprod), 10.80 / 10.81 — modifier uniquement variables/environnements.env. Préprod et prod séparés, 3 zones A/B/C. Objets MinIO ou S3 existant : hypothèse. Systemd, sans Docker.")
    return p


def d_archi_k8s() -> Page:
    p = Page("2 - Architecture Kubernetes")
    header(p, "Architecture cible — déploiement Kubernetes",
           "Mêmes blocs logiques, Helm + opérateurs, registre privé, cert-manager")
    p.zone("Cluster Kubernetes (préprod / prod)", 0.2, 0.8, 15.6, 7.75, fill="#F8FAFC", stroke=NAVY)

    p.zone("Ingress / TLS", 0.4, 1.15, 3.2, 2.15, fill="#DBEAFE", stroke=NAVY)
    p.box("Ingress HTTPS\ngrafana.obs.exemple.local\notel-gw.obs.exemple.local", 0.55, 1.5, 2.9, 0.85, fill=WHT, stroke=NAVY, font=0.10, bold=True)
    p.box("cert-manager\nIssuer CA interne", 0.55, 2.45, 2.9, 0.7, fill=SEC_BG, stroke=SEC, font=0.10, bold=True)

    p.zone("Collecte", 3.8, 1.15, 3.5, 2.15, fill=OTEL_BG, stroke=OTEL)
    p.box("OpenTelemetry Operator\nCollector gateway × N\nPDB + anti-affinité", 3.95, 1.5, 3.2, 0.85, fill=WHT, stroke=OTEL, font=0.10, bold=True)
    p.box("DaemonSet agents nœuds\n(optionnel, logs / métriques K8s)", 3.95, 2.45, 3.2, 0.7, fill=WHT, stroke=OTEL, font=0.10)

    p.zone("Messagerie", 7.5, 1.15, 3.9, 2.15, fill=KAFKA_BG, stroke=KAFKA)
    p.box("Strimzi — Kafka KRaft\n3 brokers  RF=3  min.ISR=2\nSujets otlp_logs / metrics / spans", 7.65, 1.5, 3.6, 1.6, fill=WHT, stroke=KAFKA, font=0.10, bold=True)

    p.zone("Registre et charts", 11.6, 1.15, 3.95, 2.15, fill="#ECFDF5", stroke=TEAL)
    p.box("Registre privé\nregistre.exemple.local\nimages + charts Helm\ninstallation hors ligne", 11.75, 1.5, 3.65, 1.6, fill=WHT, stroke=TEAL, font=0.10, bold=True)

    p.zone("Stockages LGTM (Helm)", 0.4, 3.5, 10.0, 2.55, fill="#F1F5F9", stroke=GRY_BD)
    p.box("grafana/mimir-distributed\nmicroservices + S3\nAlertmanager cluster", 0.55, 3.9, 3.1, 1.9, fill=MIMIR_BG, stroke=MIMIR, font=0.10, bold=True)
    p.box("grafana-community/loki\ndeploymentMode: Distributed\n(ou SimpleScalable)", 3.8, 3.9, 3.15, 1.9, fill=LOKI_BG, stroke=LOKI, font=0.10, bold=True)
    p.box("grafana-community/\ntempo-distributed\nmetrics-generator", 7.1, 3.9, 3.1, 1.9, fill=TEMPO_BG, stroke=TEMPO, font=0.10, bold=True)

    p.zone("Grafana et identité", 10.6, 3.5, 4.95, 2.55, fill=GRAF_BG, stroke=GRAF)
    p.box("grafana-community/grafana\n× 2+  ·  PDB  ·  PostgreSQL\nLDAP + vue unique", 10.75, 3.9, 4.65, 1.0, fill=WHT, stroke=GRAF, font=0.10, bold=True)
    p.box("CronJob grafana-acl-sync\nAD → équipes / dossiers", 10.75, 5.05, 4.65, 0.8, fill=SEC_BG, stroke=SEC, font=0.10, bold=True)

    p.zone("Résilience Kubernetes", 0.4, 6.25, 7.5, 2.05, fill=OK_BG, stroke=OK)
    p.box("PodDisruptionBudget\nsur tous les composants critiques", 0.55, 6.65, 3.5, 1.45, fill=WHT, stroke=OK, font=0.10)
    p.box("anti-affinité + topologySpread\nStorageClass + volumes persistants", 4.2, 6.65, 3.5, 1.45, fill=WHT, stroke=OK, font=0.10)

    p.zone("Systèmes existants (hors cluster ou connectés)", 8.1, 6.25, 7.45, 2.05, fill="#F8FAFC", stroke=GRY_BD)
    p.box("ES 8 + ROR\nes.exemple.local\ndouble écriture", 8.25, 6.65, 2.3, 1.45, fill=ES_BG, stroke=ES, font=0.10, bold=True)
    p.box("SCOM 2019\nscom.exemple.local\nvoie A / B / C", 10.7, 6.65, 2.2, 1.45, fill=SCOM_BG, stroke=SCOM, font=0.10)
    p.box("AppDynamics on-prem\nappd.exemple.local\nHTTPS 8181", 13.05, 6.65, 2.3, 1.45, fill=APPD_BG, stroke=APPD, font=0.10)
    footer(p, "FQDN : grafana.obs.exemple.local, otel-gw.obs.exemple.local (préprod : obs-pp) — variables/environnements.env. Charts à vérifier à l'installation. Pools de nœuds : estimations recommandées, 3 zones.")
    return p


def d_flux() -> Page:
    p = Page("3 - Flux de données")
    header(p, "Flux de données — OTLP → Kafka → Mimir / Loki / Tempo et double écriture ELK",
           "Chaque signal a son sujet et son groupe de consommateurs ; les journaux sont lus deux fois (Loki et Elasticsearch)")
    # columns
    p.zone("1. Émission", 0.25, 0.9, 2.5, 6.4, fill="#F8FAFC", stroke=GRY_BD)
    s1 = p.box("Application\nSDK OTel", 0.4, 1.4, 2.2, 0.85, fill=OTEL_BG, stroke=OTEL, font=0.11, bold=True)
    s2 = p.box("Agent Linux\njournald → OTLP", 0.4, 2.4, 2.2, 0.85, fill=OTEL_BG, stroke=OTEL, font=0.11)
    s3 = p.box("Agent Windows\nwindowseventlog", 0.4, 3.4, 2.2, 0.85, fill=OTEL_BG, stroke=OTEL, font=0.11)
    s4 = p.box("Prometheus agent\nscrape + remote_write\n(hors Kafka)", 0.4, 4.5, 2.2, 1.05, fill=MIMIR_BG, stroke=MIMIR, font=0.10)
    p.box("OTLP gRPC :4317\nOTLP HTTP :4318", 0.4, 5.75, 2.2, 0.85, fill=WHT, stroke=NAVY, font=0.10, bold=True)

    p.zone("2. Passerelle", 2.95, 0.9, 2.7, 6.4, fill=OTEL_BG, stroke=OTEL)
    gw = p.box("otel-gw\nrécepteur OTLP\nmemory_limiter + batch\nexportateur kafka\nacks=-1  zstd", 3.1, 1.5, 2.4, 1.7, fill=WHT, stroke=OTEL, font=0.10, bold=True)
    km = p.box("récepteur kafka_metrics\nlag des groupes\n→ Mimir", 3.1, 3.4, 2.4, 1.15, fill=MIMIR_BG, stroke=MIMIR, font=0.10)
    elk = p.box("récepteur kafka/elk\ngroupe elk-es\nexportateur elasticsearch\n(pipeline logs/elk)", 3.1, 4.75, 2.4, 1.5, fill=ES_BG, stroke=ES, font=0.10, bold=True)

    p.zone("3. Tampon Kafka", 5.85, 0.9, 3.15, 6.4, fill=KAFKA_BG, stroke=KAFKA)
    tl = p.box("sujet otlp_logs\n3+ partitions  RF=3", 6.05, 1.5, 2.75, 1.05, fill="#FEF3C7", stroke=SEC, font=0.11, bold=True)
    tm = p.box("sujet otlp_metrics\n3+ partitions  RF=3", 6.05, 2.75, 2.75, 1.05, fill=MIMIR_BG, stroke=MIMIR, font=0.11, bold=True)
    ts = p.box("sujet otlp_spans\n3+ partitions  RF=3", 6.05, 4.0, 2.75, 1.05, fill=TEMPO_BG, stroke=TEMPO, font=0.11, bold=True)
    p.box("Rétention à définir\n(ex. 3 jours — hypothèse)\nauto.create.topics=false", 6.05, 5.25, 2.75, 1.35, fill=WHT, stroke=KAFKA, font=0.10)

    p.zone("4. Consommation et stockage", 9.2, 0.9, 6.55, 6.4, fill="#F8FAFC", stroke=GRY_BD)
    cl = p.box("groupe lgtm-loki\n→ Loki :3100", 9.4, 1.5, 2.9, 1.05, fill=LOKI_BG, stroke=LOKI, font=0.11, bold=True)
    cm = p.box("groupe lgtm-mimir\n→ Mimir :9009/otlp", 9.4, 2.75, 2.9, 1.05, fill=MIMIR_BG, stroke=MIMIR, font=0.11, bold=True)
    ct = p.box("groupe lgtm-tempo\n→ Tempo :3200", 9.4, 4.0, 2.9, 1.05, fill=TEMPO_BG, stroke=TEMPO, font=0.11, bold=True)
    ce = p.box("groupe elk-es\n→ ES :9200 / logs-*\nauth ROR (compte service)", 9.4, 5.25, 2.9, 1.35, fill=ES_BG, stroke=ES, font=0.10, bold=True)
    loki = p.box("Loki +\nS3", 12.5, 1.5, 2.05, 1.05, fill=LOKI_BG, stroke=LOKI, font=0.11, bold=True)
    mimir = p.box("Mimir +\nS3 + AM", 12.5, 2.75, 2.05, 1.05, fill=MIMIR_BG, stroke=MIMIR, font=0.11, bold=True)
    tempo = p.box("Tempo +\nS3", 12.5, 4.0, 2.05, 1.05, fill=TEMPO_BG, stroke=TEMPO, font=0.11, bold=True)
    esb = p.box("ES 8 + ROR\nElastAlert2", 12.5, 5.25, 2.05, 1.35, fill=ES_BG, stroke=ES, font=0.10, bold=True)

    p.edge(s1, gw, "", color=OTEL)
    p.edge(s2, gw, "", color=OTEL)
    p.edge(gw, tl, "", color=SEC)
    p.edge(gw, tm, "", color=MIMIR)
    p.edge(gw, ts, "", color=TEMPO)
    p.edge(tl, cl, "", color=LOKI)
    p.edge(tm, cm, "", color=MIMIR)
    p.edge(ts, ct, "", color=TEMPO)
    p.edge(tl, elk, "même sujet", color=ES, dashed=True)
    p.edge(elk, ce, "", color=ES)
    p.edge(cl, loki, "", color=LOKI)
    p.edge(cm, mimir, "", color=MIMIR)
    p.edge(ct, tempo, "", color=TEMPO)
    p.edge(ce, esb, "", color=ES)
    p.edge(s4, mimir, "remote_write", color=MIMIR, dashed=True)
    footer(p, "Le groupe elk-es est indépendant de lgtm-loki : chaque groupe a son offset. En phase de retrait ELK, le pipeline logs/elk est retiré. LAG = 0 en régime établi.")
    return p


def d_securite() -> Page:
    p = Page("4 - Flux de sécurité et d'authentification")
    header(p, "Sécurité — LDAP principal, ROR Enterprise, certificats",
           "LDAP / LDAPS 636 = authentification principale (ADR-006). SSO Kerberos/OIDC = annexe optionnelle (ADR-011). ROR Enterprise : LDAP, audit, tenancy, rechargement à chaud.")

    p.zone("Identité — Active Directory (LDAPS :636)", 0.25, 0.9, 5.15, 3.7, fill=SEC_BG, stroke=SEC)
    ad = p.box("Contrôleurs de domaine\nLDAPS  ·  groupes métier\ncompte de liaison en lecture", 0.4, 1.3, 2.35, 1.15, fill=WHT, stroke=SEC, font=0.10, bold=True)
    gf = p.box("Grafana OSS — LDAP principal\ngroup_mappings\nAdmin / Editor / Viewer\nSSO = annexe optionnelle", 2.9, 1.3, 2.3, 1.15, fill=GRAF_BG, stroke=GRAF, font=0.10, bold=True)
    sync = p.box("grafana_acl_sync\n(OSS : Team Sync est une fonction Grafana Enterprise)\nAD → équipes → dossiers → tableaux de bord", 0.4, 2.6, 4.8, 1.15, fill=WHT, stroke=SEC, font=0.10, bold=True)
    p.box("Jeton de compte de service Grafana\nlude dans un fichier 0600  ·  jamais en ligne de commande", 0.4, 3.85, 4.8, 0.55, fill=WHT, stroke=NAVY, font=0.09)

    p.zone("ReadonlyREST Enterprise devant Elasticsearch 8", 5.6, 0.9, 5.3, 3.7, fill=ES_BG, stroke=ES)
    ror = p.box("readonlyrest.yml\nblocs access_control_rules\n(premier bloc qui correspond gagne)", 5.75, 1.3, 5.0, 0.85, fill=WHT, stroke=ES, font=0.10, bold=True)
    p.box("otel-writer\nauth_key_pbkdf2\nindices: logs-*\nactions d'écriture limitées", 5.75, 2.25, 2.4, 1.2, fill=WHT, stroke=ES, font=0.10)
    p.box("grafana-reader\nauth_key_pbkdf2\nindices: logs-*\nlecture seule", 8.3, 2.25, 2.45, 1.2, fill=WHT, stroke=ES, font=0.10)
    p.box("ldap_auth (ldaps)  ·  mêmes groupes AD\naudit index  ·  multi-tenancy Kibana\nrechargement à chaud (GUI)  ·  pas d'api_key", 5.75, 3.55, 5.0, 0.85, fill=WHT, stroke=SEC, font=0.10)

    p.zone("PKI interne — leçon du SAN", 11.1, 0.9, 4.65, 3.7, fill="#FEF2F2", stroke=RED)
    p.box("Autorité : AD CS (ou équivalent)\némission des certificats de service", 11.25, 1.3, 4.35, 0.8, fill=WHT, stroke=SEC, font=0.10, bold=True)
    p.box("INCORRECT\ncertificat ES avec SAN = hôte court\n(ex. es01 seulement)", 11.25, 2.2, 4.35, 0.95, fill=RED_BG, stroke=RED, font=0.10, bold=True, fc=RED)
    p.box("CORRECT\nSAN = FQDN réellement utilisé\n+ hôte court + localhost au besoin\nex. es.exemple.local, es01", 11.25, 3.25, 4.35, 1.15, fill=OK_BG, stroke=OK, font=0.10, bold=True, fc=OK)

    p.zone("Annexe optionnelle — SSO Kerberos (postes du domaine)", 0.25, 4.8, 7.7, 2.55, fill=GRAF_BG, stroke=GRAF)
    p.box("Poste Windows\nNegotiate / Kerberos", 0.4, 5.15, 1.85, 0.95, fill=WHT, stroke=NAVY, font=0.09)
    p.box("Apache + mod_auth_gssapi\ngrafana.obs.exemple.local\nHTTPS 443  SAN = FQDN VIP", 2.35, 5.15, 2.7, 0.95, fill=WHT, stroke=GRAF, font=0.09, bold=True)
    p.box("Grafana [auth.proxy]\n127.0.0.1:3000\nX-WEBAUTH-USER\nwhitelist = 127.0.0.1", 5.15, 5.15, 2.6, 0.95, fill=WHT, stroke=GRAF, font=0.09, bold=True)
    p.box("SPN HTTP/grafana.obs.exemple.local  ·  keytab AES-256  ·  krb5 EXEMPLE.LOCAL\nCompte svc-grafana-http  —  modifier dans variables/environnements.env", 0.4, 6.2, 7.35, 0.95, fill=WHT, stroke=SEC, font=0.09)

    p.zone("Annexe optionnelle — SSO OIDC / Generic OAuth (si AD FS)", 8.15, 4.8, 7.6, 2.55, fill=SEC_BG, stroke=SEC)
    p.box("Navigateur → Grafana\n/login/generic_oauth", 8.3, 5.15, 2.4, 0.95, fill=WHT, stroke=SEC, font=0.09)
    p.box("AD FS  adfs.exemple.local\n/adfs/oauth2/authorize\n/adfs/oauth2/token", 10.8, 5.15, 2.55, 0.95, fill=WHT, stroke=SEC, font=0.09, bold=True)
    p.box("role_attribute_path\norg_mapping (OSS ≥ 11.2)\nTeam Sync = Enterprise", 13.45, 5.15, 2.15, 0.95, fill=WHT, stroke=WARN, font=0.085)
    p.box("Compensation : grafana_acl_sync (équipes) · organisations (isolation sources)\nJournaux Grafana/Apache → Loki (pas l'auditing Enterprise). Non testé.", 8.3, 6.2, 7.3, 0.95, fill=WARN_BG, stroke=WARN, font=0.09)

    p.box("PKI : openssl s_client, SAN = FQDN client (grafana.obs.exemple.local, es.exemple.local). Rotation 30 j. Secrets : read -rsp / Read-Host -AsSecureString, fichiers 0600/0640, jamais en ligne de commande. ktpass -pass * (invite).",
         0.25, 7.45, 15.5, 1.1, fill=WHT, stroke=NAVY, font=0.10, align=0)
    footer(p, "LDAP principal : ADR-006. SSO annexe : ADR-011. ROR Enterprise : ADR-004 (audit, tenancy, rechargement à chaud ; pas de _security/api_key). SAML / Team Sync Grafana = Grafana Enterprise. Non testé.")
    return p


def d_ha() -> Page:
    p = Page("5 - Topologie HA et bascule")
    header(p, "Haute disponibilité et bascule — tolérance à la perte d'un nœud",
           "Objectif : un incident simple (1 courrier Kafka, 1 ingester, 1 Grafana, 1 passerelle) ne coupe pas l'ingestion ni la consultation")

    p.zone("Kafka — perte d'un courrier", 0.25, 0.9, 5.15, 3.55, fill=KAFKA_BG, stroke=KAFKA)
    p.box("kafka-01\nleader part. 0", 0.4, 1.3, 1.55, 0.9, fill=OK_BG, stroke=OK, font=0.10, bold=True)
    p.box("kafka-02\nleader part. 1", 2.05, 1.3, 1.55, 0.9, fill=OK_BG, stroke=OK, font=0.10, bold=True)
    p.box("kafka-03\nHORS SERVICE", 3.7, 1.3, 1.5, 0.9, fill=RED_BG, stroke=RED, font=0.10, bold=True, fc=RED)
    p.box("RF=3, ISR≥2  →  les partitions restent disponibles\nProducteurs acks=all  ·  pas de perte si ISR respecté\nContrôleurs : quorum 2/3, un échec toléré", 0.4, 2.35, 4.8, 1.2, fill=WHT, stroke=KAFKA, font=0.10)
    p.box("À 2 courriers perdus : quorum perdu, écriture arrêtée.", 0.4, 3.65, 4.8, 0.55, fill=WARN_BG, stroke=WARN, font=0.10)

    p.zone("Grafana — perte d'une instance", 5.6, 0.9, 5.15, 3.55, fill=GRAF_BG, stroke=GRAF)
    p.box("VIP grafana\n.obs.exemple.local\n10.80.8.10 :443", 5.75, 1.3, 2.0, 0.9, fill="#DBEAFE", stroke=NAVY, font=0.10, bold=True)
    p.box("grafana-01\nHORS SERVICE", 7.9, 1.3, 1.25, 0.9, fill=RED_BG, stroke=RED, font=0.095, bold=True, fc=RED)
    p.box("grafana-02\nactif", 9.25, 1.3, 1.3, 0.9, fill=OK_BG, stroke=OK, font=0.10, bold=True)
    p.box("Sessions et tableaux de bord dans PostgreSQL partagé\nL'utilisateur reconnecte sur le VIP, même URL\nPas d'état local indispensable", 5.75, 2.35, 4.8, 1.2, fill=WHT, stroke=GRAF, font=0.10)
    p.box("PostgreSQL lui-même en réplique (primaire + secondaire).", 5.75, 3.65, 4.8, 0.55, fill=WHT, stroke=NAVY, font=0.10)

    p.zone("Mimir / Loki / Tempo — perte d'un ingester", 10.95, 0.9, 4.8, 3.55, fill=MIMIR_BG, stroke=MIMIR)
    p.box("Ingester A\nzone 1  OK", 11.1, 1.3, 2.15, 0.85, fill=OK_BG, stroke=OK, font=0.10, bold=True)
    p.box("Ingester B\nzone 2  PANNE", 13.4, 1.3, 2.15, 0.85, fill=RED_BG, stroke=RED, font=0.10, bold=True, fc=RED)
    p.box("Réplication d'ingestion (ex. RF=3, zone-aware)\nLes blocs non flushed sont sur d'autres\ningesters. Requêtes via query-frontend.", 11.1, 2.3, 4.45, 1.15, fill=WHT, stroke=MIMIR, font=0.10)
    p.box("Le tampon Kafka absorbe le surcroît le temps de rattrapage.", 11.1, 3.55, 4.45, 0.65, fill=KAFKA_BG, stroke=KAFKA, font=0.10)

    p.zone("Passerelle OTel et Alertmanager", 0.25, 4.65, 7.7, 3.9, fill=OTEL_BG, stroke=OTEL)
    p.box("VIP otel-gw\n.obs.exemple.local", 0.4, 5.05, 1.7, 0.8, fill="#DBEAFE", stroke=NAVY, font=0.10, bold=True)
    p.box("otel-gw-01\nPANNE", 2.25, 5.05, 1.7, 0.8, fill=RED_BG, stroke=RED, font=0.10, bold=True, fc=RED)
    p.box("otel-gw-02\nreçoit le trafic", 4.1, 5.05, 1.85, 0.8, fill=OK_BG, stroke=OK, font=0.10, bold=True)
    p.box("otel-gw-03", 6.1, 5.05, 1.65, 0.8, fill=OK_BG, stroke=OK, font=0.10)
    p.box("Les agents ne voient que le VIP. Aucune reconfiguration.\nAlertmanager Mimir en cluster (gossip) : une instance perdue, les notifications continuent\n(éviter les doublons par le peering officiel).", 0.4, 6.05, 7.35, 1.2, fill=WHT, stroke=NAVY, font=0.10)
    p.box("Surveillance de la supervision : lag Kafka, up des cibles, certificats, files d'export.", 0.4, 7.4, 7.35, 0.85, fill=SEC_BG, stroke=SEC, font=0.10)

    p.zone("Certificat expiré (scénario d'échec)", 8.15, 4.65, 7.6, 3.9, fill=RED_BG, stroke=RED)
    p.box("Symptôme : x509 certificate has expired ou handshake failure.\nImpact : otel-gw n'écrit plus vers ES, Grafana ne teste plus la source ES,\nles clients OTLP TLS refusent la passerelle.", 8.3, 5.05, 7.3, 1.3, fill=WHT, stroke=RED, font=0.10)
    p.box("Remède : renouveler le certificat (même SAN complet), déployer la chaîne,\nrestaurer le contexte SELinux, redémarrer le service, vérifier openssl s_client.\nPrévention : alerte à 30 jours, procédure de rotation testée en préprod.", 8.3, 6.5, 7.3, 1.7, fill=WHT, stroke=NAVY, font=0.10)
    footer(p, "Les bascules décrites sont des conceptions cibles. Les délais réels de rattrapage (LAG, flush d'ingester) doivent être mesurés en préprod — non testés à l'échelle de production dans ce document.")
    return p


def d_scom_appd() -> Page:
    p = Page("6 - Intégration SCOM 2019 et AppDynamics on-prem")
    header(p, "Intégration SCOM 2019 et AppDynamics on-premises dans la vue unique",
           "Contrôleur AppDynamics sur site (8181) · SCOM 2019 (support étendu jusqu'au 10 avril 2029 PT) · Grafana corrèle, ne remplace pas")

    p.zone("SCOM 2019 — scom.exemple.local  (console HTTPS 443)", 0.25, 0.9, 7.7, 4.55, fill=SCOM_BG, stroke=SCOM)
    p.box("System Center 2019 Operations Manager\nSupport étendu jusqu'au 10 avril 2029 (heure du Pacifique) — lifecycle Microsoft\nPlanifier la migration vers une version en support standard", 0.4, 1.25, 7.4, 0.95, fill=WHT, stroke=SCOM, font=0.09, bold=True)
    p.box("Voie A — journaux (recommandée)\nRécepteur OpenTelemetry officiel\nwindowseventlog ou collecteur WEF\n→ VIP otel-gw.obs.exemple.local\n→ otlp_logs → Loki / ES", 0.4, 2.3, 2.4, 1.85, fill=WHT, stroke=SCOM, font=0.09)
    p.box("Voie B — métriques\nExportateur Prometheus\ncommunautaire OpsLogix\n(SCOM 2019+, AGPL-3.0)\nnon officiel Microsoft\nà qualifier → Mimir", 2.9, 2.3, 2.4, 1.85, fill=WHT, stroke=SCOM, font=0.09)
    p.box("Voie C — API REST / SDK\nREST depuis 1801 ; UR1 : CSRF\nSDK / OMCF (docs Microsoft)\nGreffon Grafana tierce : à qualifier\nSQL des bases : pas de voie principale", 5.4, 2.3, 2.4, 1.85, fill=WHT, stroke=SCOM, font=0.09)
    p.box("Voie A : composants OpenTelemetry documentés (non testé ici).\nVoies B et C : communautaires ou à qualifier (licence, CSRF, charge SDK).", 0.4, 4.25, 7.4, 1.0, fill=WARN_BG, stroke=WARN, font=0.09)

    p.zone("AppDynamics on-premises — appd.exemple.local:8181", 8.15, 0.9, 7.6, 4.55, fill=APPD_BG, stroke=APPD)
    p.box("Contrôleur SUR SITE  ·  HTTPS 8181 à utiliser  ·  HTTP 8090 à bloquer\nCertificat de l'autorité interne, SAN = appd.exemple.local\nLDAP du contrôleur : AD LDAPS 636, sAMAccountName, compte local de secours", 8.3, 1.25, 7.3, 1.05, fill=WHT, stroke=APPD, font=0.09, bold=True)
    p.box("Voie 1 — greffon Grafana\ndlopes7-appdynamics-datasource\nEnterprise (licence requise)\nURL https://appd.exemple.local:8181\nCA du contrôleur dans Grafana\nà vérifier on-prem (non testé)", 8.3, 2.4, 3.55, 1.75, fill=WHT, stroke=APPD, font=0.09)
    p.box("Voie 2 — OpenTelemetry\nTraces VERS le contrôleur\notlphttp + x-api-key\n:8181/otis/ingest\n(à vérifier sur la version)\nPas un flux AppD → Tempo", 11.95, 2.4, 3.5, 1.75, fill=WHT, stroke=APPD, font=0.09)
    p.box("Sans licence Enterprise : lien vers https://appd.exemple.local:8181\net corrélation par service.name. FQDN : variables/environnements.env uniquement.", 8.3, 4.25, 7.3, 1.0, fill=WARN_BG, stroke=WARN, font=0.09)

    p.zone("Vue unique Grafana — grafana.obs.exemple.local  (VIP 10.80.8.10)", 0.25, 5.6, 15.5, 2.95, fill=GRAF_BG, stroke=GRAF)
    p.box("Santé LGTM\nlag, ingest, up", 0.45, 6.0, 2.85, 1.35, fill=WHT, stroke=GRAF, font=0.11, bold=True)
    p.box("Métriques Mimir\nmimir.obs.exemple.local\n(+ SCOM si voie B)", 3.45, 6.0, 2.95, 1.35, fill=MIMIR_BG, stroke=MIMIR, font=0.10, bold=True)
    p.box("Journaux Loki / ES\nloki.obs.exemple.local\n(+ événements Windows)", 6.55, 6.0, 2.95, 1.35, fill=LOKI_BG, stroke=LOKI, font=0.10, bold=True)
    p.box("Traces Tempo\ntempo.obs.exemple.local\n(apps instrumentées OTel)", 9.65, 6.0, 2.95, 1.35, fill=TEMPO_BG, stroke=TEMPO, font=0.10, bold=True)
    p.box("Panneau AppD\nappd.exemple.local:8181\nou lien contrôleur", 12.75, 6.0, 2.8, 1.35, fill=APPD_BG, stroke=APPD, font=0.10, bold=True)
    p.box("Préprod : obs-pp.exemple.local, scom-pp, appd-pp — même logique. Modifier uniquement variables/environnements.env.", 0.45, 7.5, 15.1, 0.8, fill=WHT, stroke=NAVY, font=0.10)
    footer(p, "Greffon AppDynamics = Enterprise (docs Grafana Labs). Exportateur SCOM = projet communautaire OpsLogix, non officiel Microsoft, SCOM 2019+. Cycle de vie SCOM 2019 : support étendu jusqu'au 10 avril 2029 PT. Non testé sur l'environnement réel.")
    return p


def d_minio() -> Page:
    p = Page("7 - Scénario B — MinIO distribué")
    header(p, "Scénario B — Aucun stockage objet S3 : MinIO distribué",
           "ADR-002 et checklist. STOCKAGE_OBJET_SCENARIO=minio. Quatre nœuds, erasure coding, TLS. Licence communautaire AGPLv3 à valider. Non testé.")

    p.zone("Si un HCP (HS3) ou un VSP One Object existe : scénario A — voir la page 8. Un HNAS (NFS) n'est pas une cible S3.", 0.25, 0.9, 15.5, 0.85, fill=OK_BG, stroke=OK)
    p.box("Cette page décrit uniquement le scénario B (STOCKAGE_OBJET_SCENARIO=minio), après checklist et validation de la licence AGPLv3.",
         0.4, 1.05, 15.2, 0.55, fill=WHT, stroke=OK, font=0.10, bold=True)

    p.zone("MinIO distribué  ·  VIP s3.obs.exemple.local  ·  10.80.8.15", 0.25, 1.9, 15.5, 5.45, fill=SEC_BG, stroke=SEC)
    p.box("Mimir", 0.45, 2.55, 1.7, 0.7, fill=WHT, stroke=NAVY, font=0.11, bold=True)
    p.box("Loki", 2.3, 2.55, 1.7, 0.7, fill=WHT, stroke=NAVY, font=0.11, bold=True)
    p.box("Tempo", 4.15, 2.55, 1.7, 0.7, fill=WHT, stroke=NAVY, font=0.11, bold=True)
    p.box("mc mirror\n(sauvegarde)", 6.0, 2.55, 1.85, 0.7, fill=WHT, stroke=WARN, font=0.10, bold=True)
    vip = p.box("HAProxy + keepalived\ns3.obs.exemple.local\nTLS  ·  SAN = VIP + nœuds", 8.1, 2.5, 3.3, 0.8, fill=WHT, stroke=SEC, font=0.10, bold=True)
    p.box("IAM / politiques\nmimir-svc · loki-svc\ntempo-svc  — pas le root", 11.6, 2.5, 3.9, 0.8, fill=WHT, stroke=SEC, font=0.10, bold=True)

    p.box("minio-01\nzone A\n/data/minio", 0.45, 3.6, 3.55, 1.15, fill=WHT, stroke=NAVY, font=0.11, bold=True)
    p.box("minio-02\nzone B\n/data/minio", 4.2, 3.6, 3.55, 1.15, fill=WHT, stroke=NAVY, font=0.11, bold=True)
    p.box("minio-03\nzone C\n/data/minio", 7.95, 3.6, 3.55, 1.15, fill=WHT, stroke=NAVY, font=0.11, bold=True)
    p.box("minio-04\nzone A\n/data/minio", 11.7, 3.6, 3.8, 1.15, fill=WHT, stroke=NAVY, font=0.11, bold=True)

    p.box("Erasure coding : jeux formés à l'initialisation, non modifiables ensuite  ·  commande identique  ·  {1...4} (trois points)\nRépertoires vides au premier démarrage  ·  MINIO_ROOT_* dans EnvironmentFile 0600  ·  certificats /opt/minio/certs",
         0.45, 4.9, 15.05, 0.9, fill=WHT, stroke=SEC, font=0.10)
    p.box("Seaux : lgtm-mimir   lgtm-loki   lgtm-tempo   lgtm-admin    ·    Supervision : métriques Prometheus (doc MinIO de la version) + journaux vers Loki\nKubernetes : opérateur ou chart officiel, 4 pods, anti-affinité, cert-manager, Secret, NetworkPolicy. Préprod : obs-pp.exemple.local. Modifier uniquement variables/environnements.env.",
         0.45, 5.95, 15.05, 1.15, fill=WHT, stroke=NAVY, font=0.10)

    footer(p, "Scénario B. Procédures : Annexe_Stockage_objet_S3_MinIO.md et annexes C des runbooks. Licence AGPLv3 à examiner. Non testé.")
    return p



def d_hitachi() -> Page:
    p = Page("8 - Scénario A — Hitachi HCP / VSP One Object")
    header(p, "Scénario A — Stockage objet Hitachi existant (HCP HS3 ou VSP One Object)",
           "ADR-002 et checklist. STOCKAGE_OBJET_SCENARIO=hitachi. Côté consommateur LGTM. Non testé.")

    p.zone("Décision  ·  checklist avec l'équipe stockage", 0.25, 0.9, 15.5, 1.05, fill=OK_BG, stroke=OK)
    p.box("HCP avec HS3, ou VSP One Object, et critères essentiels OK  →  ce scénario.\n"
          "HNAS seul (NFS, SMB, FTP, iSCSI) : pas d'API S3 serveur. Data Migrator to Cloud = client, pas un endpoint.\n"
          "NFS comme backend des blocs : rejeté (documentation Grafana Labs : Mimir, Loki scalable, Tempo distribuée).",
         0.4, 1.1, 15.2, 0.75, fill=WHT, stroke=OK, font=0.105, bold=True, align=0)

    p.zone("Équipe stockage — à fournir", 0.25, 2.1, 5.15, 3.35, fill=SEC_BG, stroke=SEC)
    p.box("Produit et version\nHCP et/ou VSP One Object", 0.4, 2.4, 4.85, 0.55, fill=WHT, stroke=SEC, font=0.10, bold=True)
    p.box("Tenant dédié par environnement\n(préprod, prod)", 0.4, 3.05, 4.85, 0.55, fill=WHT, stroke=SEC, font=0.10, bold=True)
    p.box("Espaces de noms = seaux S3\nlgtm-mimir  ·  lgtm-loki\nlgtm-tempo  ·  lgtm-admin", 0.4, 3.7, 4.85, 0.75, fill=WHT, stroke=SEC, font=0.10, bold=True)
    p.box("HS3 activé  ·  quotas  ·  HTTPS\nCA  ·  comptes moindre privilège\nclés 0600  ·  versioning / réplication", 0.4, 4.55, 4.85, 0.75, fill=WHT, stroke=SEC, font=0.10)

    p.zone("Point de service objet", 5.55, 2.1, 5.0, 3.35, fill=TEAL_BG, stroke=TEAL)
    ep = p.box("HCP  —  tenant = endpoint\nhttps://lgtm.hcp.exemple.local\n(exemple fictif)\nAuth. AWS : sans /hs3\nSeau = namespace",
         5.7, 2.4, 4.7, 1.55, fill=WHT, stroke=TEAL, font=0.10, bold=True)
    p.box("VSP One Object\nendpoint fourni par le stockage\nAPI S3 documentée Hitachi",
         5.7, 4.1, 4.7, 0.85, fill=WHT, stroke=TEAL, font=0.10, bold=True)

    p.zone("Consommateurs LGTM", 10.7, 2.1, 5.05, 3.35, fill=MIMIR_BG, stroke=MIMIR)
    m = p.box("Mimir\nbucket lgtm-mimir\ninsecure: false", 10.85, 2.4, 4.75, 0.7, fill=WHT, stroke=MIMIR, font=0.10, bold=True)
    l = p.box("Loki\nbucket_lookup_type: path\nsi path-style", 10.85, 3.2, 4.75, 0.7, fill=WHT, stroke=LOKI, font=0.10, bold=True)
    te = p.box("Tempo\nforcepathstyle si path-style", 10.85, 4.0, 4.75, 0.6, fill=WHT, stroke=TEMPO, font=0.10, bold=True)
    p.box("S3_CA_FILE  ·  S3_FORCE_PATH_STYLE\nS3_ENDPOINT  ·  secrets fichier 0600", 10.85, 4.7, 4.75, 0.6, fill=WHT, stroke=NAVY, font=0.09)

    p.edge(ep, m, color=TEAL)
    # edges from center to consumers may look messy; skip extra edges

    p.zone("Adressage et vigilance", 0.25, 5.6, 15.5, 1.75, fill=WARN_BG, stroke=WARN)
    p.box("Path-style : https://<tenant>.<domaine>/<seau>   ·   Virtual-hosted : https://<seau>.<tenant>.<domaine>  (DNS joker souvent requis).\n"
          "HCP documente les deux. Qualifier en préprod. Mimir : ne pas préfixer l'endpoint par le nom du seau.\n"
          "API (matrices Hitachi) : ListObjectsV2 et DeleteObjects pris en charge ; HCP DeleteObjects : pas d'objets sous rétention ou hold — à confirmer.\n"
          "Multipart documenté (VSP One Object : fully supported). Pas de certification Grafana × Hitachi trouvée : qualifier en préprod.",
         0.4, 5.8, 15.2, 1.4, fill=WHT, stroke=WARN, font=0.105, align=0)

    footer(p, "Scénario A. Procédure : architecture/annexes/Annexe_Stockage_objet_Hitachi_HCP_S3.md et annexes D des runbooks. Non testé. Exemples fictifs.")
    return p


def all_pages():
    return [d_archi_vm(), d_archi_k8s(), d_flux(), d_securite(), d_ha(), d_scom_appd(), d_minio(), d_hitachi()]


FILENAMES = [
    ("01_architecture_vm", "1 - Architecture VM RHEL 8"),
    ("02_architecture_k8s", "2 - Architecture Kubernetes"),
    ("03_flux_donnees", "3 - Flux de données"),
    ("04_flux_securite_auth", "4 - Flux de sécurité et d'authentification"),
    ("05_topologie_ha", "5 - Topologie HA et bascule"),
    ("06_integration_scom_appd", "6 - Intégration SCOM 2019 et AppDynamics on-prem"),
    ("07_stockage_objet_minio", "7 - Scénario B — MinIO distribué"),
    ("08_stockage_objet_hitachi", "8 - Scénario A — Hitachi HCP / VSP One Object"),
]


def main():
    pages = all_pages()
    written = []
    # combined
    comb = OUT / "00_lgtm_prod_tous_diagrammes.vsdx"
    write_vsdx(comb, pages, "Plateforme LGTM préprod/prod — tous les diagrammes")
    written.append(comb)
    for (fn, _name), pg in zip(FILENAMES, pages):
        vp = OUT / f"{fn}.vsdx"
        write_vsdx(vp, [pg], pg.name)
        written.append(vp)
        png = OUT / f"{fn}.png"
        render_png(pg, png, dpi=150)
        written.append(png)
    print("écrit :")
    for w in written:
        print(f"  {w}  ({w.stat().st_size} octets)")


if __name__ == "__main__":
    main()
