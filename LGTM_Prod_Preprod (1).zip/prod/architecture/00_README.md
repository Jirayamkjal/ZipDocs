# Architecture — Plateforme LGTM préproduction et production

Ce dossier décrit l'architecture cible de la plateforme d'observabilité LGTM
(Loki, Grafana, Tempo, Mimir) avec Kafka, OpenTelemetry Collector, intégration
Elasticsearch **8.19.0** protégé par ReadonlyREST **Enterprise 1.72.0**, authentification **LDAP** (mécanisme principal, Grafana OSS), vue unique,
et intégration logique de SCOM 2019 et d'AppDynamics on-premises.

Il est autonome : il ne suppose pas la lecture d'un autre runbook. Les deux
modes de déploiement (machines virtuelles RHEL 8 et Kubernetes) partagent
cette architecture logique.

## Contenu

| Document | Rôle |
|---|---|
| [01_Document_architecture.md](01_Document_architecture.md) | Vue d'ensemble, flux, matrice réseau, exigences non fonctionnelles |
| [02_Etude_impact.md](02_Etude_impact.md) | Impacts sur l'existant, risques, plan de transition |
| [adr/](adr/) | Décisions d'architecture (une par fichier, format ADR) |
| [diagrammes/](diagrammes/) | Fichiers Visio (`.vsdx`) éditables, aperçus PNG, générateur |
| [`../variables/`](../variables/) | DNS, VIP, plan d'adressage — **modifier ici seulement** |
| [annexes/Checklist_decision_stockage_objet.md](annexes/Checklist_decision_stockage_objet.md) | Étape de décision : HCP / VSP One Object (A) ou MinIO (B) ; HNAS seul insuffisant |
| [annexes/Annexe_Stockage_objet_Hitachi_HCP_S3.md](annexes/Annexe_Stockage_objet_Hitachi_HCP_S3.md) | Scénario A — consommateur HCP (HS3) ou VSP One Object |
| [annexes/Annexe_Stockage_objet_S3_MinIO.md](annexes/Annexe_Stockage_objet_S3_MinIO.md) | Scénario B — MinIO distribué si aucun S3 serveur |
| Annexes B des runbooks | SSO Kerberos / OIDC (complément optionnel) |

## Décisions (ADR)

| ADR | Sujet |
|---|---|
| [ADR-001](adr/ADR-001_Kafka_tampon.md) | Kafka comme tampon |
| [ADR-002](adr/ADR-002_Stockage_objet.md) | Stockage objet : scénario A Hitachi (HCP / VSP One Object) ou B MinIO ; NFS / HNAS rejeté |
| [ADR-003](adr/ADR-003_VM_vs_Kubernetes.md) | Deux réalisations : VM et Kubernetes |
| [ADR-004](adr/ADR-004_ROR_vs_XPack.md) | ReadonlyREST **Enterprise 1.72.0** (ES **8.19.0**) plutôt que X-Pack Security |
| [ADR-005](adr/ADR-005_Grafana_OSS_ACL_sync.md) | Grafana OSS + composant ACL |
| [ADR-006](adr/ADR-006_Authentification_LDAP.md) | LDAP / Active Directory — authentification **principale** |
| [ADR-007](adr/ADR-007_Strategie_PKI_certificats.md) | PKI, SAN, rotation |
| [ADR-008](adr/ADR-008_Integration_SCOM_AppDynamics.md) | SCOM 2019 et AppDynamics on-premises |
| [ADR-009](adr/ADR-009_Strategie_HA.md) | Haute disponibilité |
| [ADR-010](adr/ADR-010_Vue_one_screen.md) | Vue unique Grafana |
| [ADR-011](adr/ADR-011_SSO_Grafana_OSS.md) | SSO Grafana OSS — **complément optionnel** (annexe) |

## Diagrammes Visio

Fichier unique multi-pages : [`diagrammes/00_lgtm_prod_tous_diagrammes.vsdx`](diagrammes/00_lgtm_prod_tous_diagrammes.vsdx).

| Page | Visio | Aperçu |
|---|---|---|
| Architecture VM RHEL 8 | [01_architecture_vm.vsdx](diagrammes/01_architecture_vm.vsdx) | ![VM](diagrammes/01_architecture_vm.png) |
| Architecture Kubernetes | [02_architecture_k8s.vsdx](diagrammes/02_architecture_k8s.vsdx) | [PNG](diagrammes/02_architecture_k8s.png) |
| Flux de données | [03_flux_donnees.vsdx](diagrammes/03_flux_donnees.vsdx) | [PNG](diagrammes/03_flux_donnees.png) |
| Sécurité, LDAP, ROR, certificats | [04_flux_securite_auth.vsdx](diagrammes/04_flux_securite_auth.vsdx) | [PNG](diagrammes/04_flux_securite_auth.png) |
| Topologie HA et bascule | [05_topologie_ha.vsdx](diagrammes/05_topologie_ha.vsdx) | [PNG](diagrammes/05_topologie_ha.png) |
| Intégration SCOM et AppDynamics | [06_integration_scom_appd.vsdx](diagrammes/06_integration_scom_appd.vsdx) | [PNG](diagrammes/06_integration_scom_appd.png) |
| Stockage objet — scénario B MinIO | [07_stockage_objet_minio.vsdx](diagrammes/07_stockage_objet_minio.vsdx) | [PNG](diagrammes/07_stockage_objet_minio.png) |
| Stockage objet — scénario A Hitachi | [08_stockage_objet_hitachi.vsdx](diagrammes/08_stockage_objet_hitachi.vsdx) | [PNG](diagrammes/08_stockage_objet_hitachi.png) |

Les `.vsdx` sont des paquets OPC Visio 2013 (formes et connecteurs éditables). Ils ont été validés (structure zip, XML bien formé, réouverture par la bibliothèque `vsdx`). Le générateur est `_gen_visio.py`.

## Runbooks associés

- `../Runbook_LGTM_Prod_VM_RHEL8.md` — déploiement sur machines virtuelles
- `../Runbook_LGTM_Prod_Kubernetes.md` — déploiement Kubernetes
- `../scripts/` — composant `grafana_acl_sync`
- `../dashboards/one_screen_home.json` — tableau de bord d'accueil
