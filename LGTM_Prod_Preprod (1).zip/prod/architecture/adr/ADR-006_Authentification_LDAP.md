# ADR-006 — Authentification principale : LDAP / Active Directory (Grafana OSS)

- **Statut :** accepté — mécanisme **principal** d'authentification des utilisateurs
- **Date :** 2026-11-12
- **Décideurs :** architecture / identité / exploitation
- **Lié à :** ADR-005 (équipes et dossiers via `grafana_acl_sync`), ADR-004 (même annuaire pour ReadonlyREST Enterprise), ADR-011 (SSO optionnel, en annexe)

## Contexte

Les utilisateurs de la plateforme d'observabilité doivent s'authentifier contre l'annuaire déjà en place (**Active Directory**). Grafana est déployé en **édition OSS** (version de référence 13.2.4) : l'authentification LDAP / LDAPS, ainsi que le mapping des groupes vers les rôles d'organisation (Admin, Editor, Viewer), sont des fonctions documentées de cette édition ([Configure LDAP authentication](https://grafana.com/docs/grafana/latest/setup-grafana/configure-access/configure-authentication/ldap/)).

La synchronisation automatique vers les *équipes* Grafana (**Team Sync**) et la synchronisation LDAP « active » en arrière-plan sont des fonctions **Grafana Enterprise / Cloud**. Elles ne sont pas utilisées. Les équipes, dossiers et permissions de tableaux de bord sont posés par le composant OSS `grafana_acl_sync.py` (ADR-005), qui lit les **mêmes groupes AD**.

ReadonlyREST **Enterprise** (ADR-004) s'appuie sur le **même annuaire** (connecteur `ldaps`, règle `ldap_auth`) pour l'accès à Elasticsearch et, le cas échéant, les tenancies Kibana.

## Décision

**LDAP / LDAPS est le mécanisme d'authentification principal** de Grafana OSS, en préproduction comme en production.

1. Connexion LDAPS vers les contrôleurs de domaine, port **636**, vérification du certificat (`ssl_skip_verify = false`), CA interne dans le truststore de Grafana. Compte de liaison en lecture seule, mot de passe dans un fichier `0640` (`ldap.toml`) ou mécanisme d'environnement documenté par la version, **jamais** sur la ligne de commande.
2. Filtre `sAMAccountName`, bases DN et `group_mappings` vers Org Admin / Editor / Viewer (premier mapping correspondant). Attribut `memberOf` ; à défaut, `group_search_*` selon la documentation officielle.
3. Compte d'administration **local** Grafana conservé au coffre, pour l'urgence si l'annuaire est indisponible.
4. Les **mêmes groupes AD** alimentent :
   - les rôles d'organisation Grafana (`group_mappings`) ;
   - les équipes, dossiers et tableaux de bord (`grafana_acl_sync.py`, toutes les 15 minutes) ;
   - l'ACL ReadonlyREST Enterprise (`ldap_auth`, motifs d'index, tenancies Kibana).
5. Un **SSO** (Kerberos via Auth Proxy, ou OIDC vers AD FS) peut venir **en complément**, uniquement si l'organisation le souhaite. Il est documenté en **annexe** (ADR-011). Il ne remplace pas LDAP comme socle.

Les FQDN des DC, le port et les DN d'exemple se définissent dans [`variables/environnements.env`](../../variables/environnements.env) — **modifier ici seulement**.

Les procédures sont **non testées** contre un AD de production dans ce dépôt.

## Conséquences

- **Positives :** un seul annuaire, déjà connu des équipes ; pas de licence Grafana Enterprise pour s'authentifier ni pour mapper les rôles ; alignement avec ROR Enterprise.
- **Négatives :** Team Sync Grafana n'est pas disponible (script ACL) ; une indisponibilité AD empêche les nouvelles connexions (compte local d'urgence, sessions déjà ouvertes).
- **Réseau :** Grafana, `grafana_acl_sync` et les nœuds Elasticsearch (ROR) vers les DC, **LDAPS 636**.

## Alternatives écartées

| Alternative | Motif |
|---|---|
| SSO Kerberos ou OIDC comme mécanisme *principal* dès le jour 1 | Plus complexe (keytab, AD FS) ; LDAP couvre le besoin d'identité et de rôles. Le SSO reste disponible en annexe. |
| SAML Grafana | Fonction Grafana Enterprise, hors édition retenue. |
| Comptes locaux Grafana uniquement | Pas de révocation centralisée, pas d'alignement avec les groupes métier. |
