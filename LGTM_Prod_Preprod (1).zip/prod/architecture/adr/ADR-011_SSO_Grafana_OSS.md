# ADR-011 — SSO Grafana en édition OSS

- **Statut :** accepté comme **complément optionnel** (annexe) — LDAP demeure le mécanisme **principal** (ADR-006)
- **Date :** 2026-11-12
- **Décideurs :** architecture / exploitation / identité
- **Lié à :** ADR-006 (authentification principale LDAP), ADR-005, ADR-007

## Contexte

Grafana est déployé en **édition OSS** (version de référence **13.2.4**). Plusieurs fonctions d'identité et de gouvernance souvent associées à un SSO « complet » sont documentées par Grafana Labs comme disponibles uniquement dans **Grafana Enterprise** et Grafana Cloud :

| Fonction | Statut officiel | Source |
|---|---|---|
| **SAML** | Enterprise / Cloud | [Configure authentication](https://grafana.com/docs/grafana/latest/setup-grafana/configure-access/configure-authentication/) — « Team sync, active sync, and SAML are available in Grafana Enterprise and Grafana Cloud. They aren’t available in Grafana open source. » ; [auth.saml](https://grafana.com/docs/grafana/latest/setup-grafana/configure-grafana/enterprise-configuration/) |
| **Team Sync** (synchronisation des équipes Grafana avec les groupes de l'IdP, y compris Generic OAuth, Auth Proxy et LDAP) | Enterprise / Cloud | [Configure Team Sync](https://grafana.com/docs/grafana/latest/setup-grafana/configure-access/configure-team-sync/) |
| **Permissions fines sur les sources de données** (onglet Permissions : query / edit / admin par utilisateur ou équipe) | Enterprise / Cloud | [Data source permissions](https://grafana.com/docs/grafana/latest/administration/data-source-management/) |
| **Auditing** natif (`[auditing]`, export fichier / Loki / console) | Enterprise / Cloud | [Audit a Grafana instance](https://grafana.com/docs/grafana/latest/setup-grafana/configure-security/audit-grafana/) |
| **Greffon AppDynamics** `dlopes7-appdynamics-datasource` | Enterprise | [documentation du greffon](https://grafana.com/docs/plugins/dlopes7-appdynamics-datasource/latest/) ; ADR-008 |

Le besoin d'un **SSO** (ouverture de session unique, idéalement intégrée au poste Windows du domaine) reste légitime en OSS. Il faut s'appuyer uniquement sur des mécanismes documentés pour l'édition open source, et compenser honnêtement ce qui manque.

L'annuaire est **Active Directory** (déjà retenu, ADR-006). Les contrôleurs sont des **Windows Server**. Un rôle **AD FS** (Active Directory Federation Services) peut exister ou non : il n'est pas présumé installé.

## Options examinées (OSS)

### Option A — LDAP seul (déjà retenu, ADR-006)

Connexion par identifiant / mot de passe AD, `group_mappings` vers Org Admin / Editor / Viewer. Documenté pour Grafana OSS. **Ce n'est pas un SSO** : l'utilisateur saisit un mot de passe dans Grafana. Conservé comme socle et comme secours.

### Option B — Generic OAuth / OIDC vers AD FS (Windows Server)

Grafana OSS expose `[auth.generic_oauth]` ([Configure Generic OAuth](https://grafana.com/docs/grafana/latest/setup-grafana/configure-access/configure-authentication/generic-oauth/)). AD FS documente OpenID Connect / OAuth : points d'autorisation et de jeton `https://<fqdn-adfs>/adfs/oauth2/authorize` et `.../adfs/oauth2/token`, découverte `https://<fqdn-adfs>/adfs/.well-known/openid-configuration` ([AD FS OpenID Connect/OAuth concepts](https://learn.microsoft.com/en-us/windows-server/identity/ad-fs/development/ad-fs-openid-connect-oauth-concepts), [flux](https://learn.microsoft.com/en-us/windows-server/identity/ad-fs/overview/ad-fs-openid-connect-oauth-flows-scenarios)).

**Mapping des rôles (OSS) :** `role_attribute_path` (expression JMESPath, documentée sans mention Enterprise).

**Mapping des organisations (OSS) :** `org_attribute_path` et `org_mapping` sont documentés dans la même page Generic OAuth. Grafana Labs les décrit comme **generally available dans Grafana OSS et Enterprise à partir de Grafana 11.2.0** (27 août 2024) : [Map org-specific user roles](https://grafana.com/whats-new/map-org-specific-user-roles-from-your-oauth-provider/), [notes 11.2](https://grafana.com/blog/grafana-11-2-release-all-the-new-features/). La version de référence **13.2.4** les inclut donc. Contrainte documentée : `org_attribute_path` doit renvoyer un **tableau**, pas une chaîne. Si `org_mapping` et `role_attribute_path` sont tous deux définis, Grafana attribue le rôle le plus élevé des deux.

**Team Sync** sur Generic OAuth reste **Enterprise** (note explicite sur la même page).

Cette option **exige AD FS** (ou un autre fournisseur OIDC). Sans AD FS, elle n'est pas réalisable telle quelle.

### Option C — Auth Proxy + Apache `mod_auth_gssapi` (Kerberos, SSO intégré Windows)

Grafana OSS permet à un reverse proxy d'authentifier l'utilisateur et de transmettre l'identité dans un en-tête : `[auth.proxy]`, `header_name = X-WEBAUTH-USER`, `whitelist` des **adresses IP source TCP du proxy** (pas l'IP du poste, les en-têtes `X-Forwarded-For` ne sont volontairement pas utilisés pour cette liste — [Configure auth proxy](https://grafana.com/docs/grafana/latest/setup-grafana/configure-access/configure-authentication/auth-proxy/)).

Apache HTTP Server, avec le module **`mod_auth_gssapi`**, réalise une authentification **Kerberos / Negotiate** (SSO intégré Windows). Un compte de service AD, un SPN `HTTP/<fqdn-grafana>` et un **keytab** AES-256 sont produits avec les outils Microsoft (`setspn`, `ktpass` — [ktpass](https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/ktpass)). Grafana est lié à `127.0.0.1` ; seuls le proxy (en HTTPS, certificat SAN = FQDN que l'utilisateur tape) et l'exploitation locale l'atteignent. Le champ `whitelist` doit contenir exclusivement l'adresse du proxy (en colocation : `127.0.0.1`).

Les en-têtes optionnels (`headers = Role:… Groups:…`) existent en OSS ; la **synchronisation des équipes** à partir de `Groups` est Team Sync, donc Enterprise. Le `sync_ttl` documente une combinaison possible avec l'intégration LDAP Grafana (intervalle de synchronisation) — à vérifier en conditions réelles (**non testé**).

### Option D — Acheter Grafana Enterprise

Donnerait SAML, Team Sync, permissions de sources, auditing natif, greffon AppDynamics. **Non supposé.** Compatible plus tard avec le reste de l'architecture (ADR-005).

## Décision

En **édition OSS**, sans licence Grafana Enterprise, **LDAP est et reste le mécanisme principal** (ADR-006). Le SSO décrit ici est **facultatif** et documenté en annexe des runbooks. Il ne s'active que sur décision d'exploitation, une fois LDAP en service.

1. **LDAP** (ADR-006) : authentification et mapping Org Admin / Editor / Viewer ; compte d'administration local d'urgence. Socle obligatoire.
2. **SSO intégré Windows (optionnel, postes joints au domaine) :** Apache HTTP Server + `mod_auth_gssapi` (Kerberos) devant Grafana, `[auth.proxy]`, en-tête `X-WEBAUTH-USER`, `whitelist` du proxy, Grafana écoute uniquement en local, HTTPS sur le proxy, SAN = FQDN du VIP (`${GRAFANA_FQDN}`). Compte de service AD, SPN `HTTP/${GRAFANA_FQDN}`, keytab **AES256-SHA1**. En haute disponibilité, le SPN et le keytab portent le **FQDN du VIP**, pas le nom d'une instance : le même keytab est déployé sur chaque Apache derrière le VIP.
3. **Fédération OIDC (optionnelle, si AD FS est déployé) :** `[auth.generic_oauth]` vers AD FS, avec `role_attribute_path` et, le cas échéant, `org_attribute_path` + `org_mapping` (disponibles en OSS depuis Grafana 11.2, donc en 13.2.4). Grafana est le client OIDC ; le secret du client est dans un fichier `0600`, jamais en ligne de commande. L'URL de rappel est `${GRAFANA_URL}/login/generic_oauth`. **Sans AD FS, cette voie n'est pas ouverte.**
4. **Ne pas** s'appuyer sur SAML, Team Sync, les permissions fines de sources ni l'auditing natif Grafana.

**Compensations OSS :**

- **Équipes et dossiers :** le composant déjà retenu `grafana_acl_sync.py` (ADR-005) lit les groupes AD et pose les équipes, dossiers et permissions de dossiers. Il reste le substitut de Team Sync.
- **Isolation des sources de données :** en OSS, un utilisateur ne voit que les sources des **organisations** Grafana auxquelles il appartient (comportement standard des organisations, distinct des permissions fines Enterprise). Le `org_mapping` OIDC, ou l'affectation d'organisation LDAP / manuelle, sert à isoler les sources par organisation. Ce n'est **pas** équivalent à l'onglet Permissions Enterprise (restriction *query* à l'intérieur d'une même organisation).
- **Piste d'audit :** l'auditing natif `[auditing]` n'existe pas en OSS. Compensation : journaux **standard** de Grafana (`journald` / fichier, authentification, erreurs) et journaux d'accès **Apache** (ou Ingress), expédiés vers **Loki** par l'agent déjà prévu (journald / fichier). Ce n'est **pas** le journal d'audit structuré Enterprise (objets JSON des actions UI/API, export Loki officiel). À traiter comme une piste d'exploitation, pas comme un équivalent de conformité.

Les FQDN, le domaine Kerberos, le compte de service et, le cas échéant, l'URL AD FS se définissent **uniquement** dans [`variables/environnements.env`](../../variables/environnements.env).

Toutes les procédures d'implémentation sont **non testées** dans ce dépôt.

## Conséquences

- **Positives :** SSO possible en OSS (Kerberos pour les postes du domaine ; OIDC si AD FS) ; `org_mapping` utilisable en 13.2.4 ; pas d'achat Enterprise obligatoire pour s'authentifier.
- **Négatives :** pas de SAML ; pas de Team Sync (script ACL) ; pas de permissions fines de sources (isolation par organisation seulement) ; pas d'auditing natif ; Kerberos est exigeant (horloge, SPN unique, keytab / kvno, DNS direct et inverse, zone Intranet du navigateur, pas de repli NTLM souhaitable).
- **Réseau :** flux nouveaux — postes → VIP Grafana **443** (Apache) ; Apache → Grafana **3000** en local seulement (le port 3000 n'est plus exposé aux utilisateurs) ; Grafana ou Apache → DC **88** (Kerberos) et déjà **636** (LDAPS) ; si AD FS : Grafana → AD FS **443**, navigateurs → AD FS **443**.
- **Secrets :** keytab `0640` (utilisateur du service HTTP) ; secret client OAuth en fichier `0600` ; `ktpass` et les comptes AD se saisissent par invite (`-pass *`, `Read-Host -AsSecureString`), jamais en argument.
- **HA :** un seul SPN `HTTP/${GRAFANA_FQDN}` ; keytab identique sur les nœuds Apache ; `whitelist` = adresses de ces Apache vues par Grafana (souvent `127.0.0.1` si Apache est colocalisé).
- **Si une licence Enterprise est acquise plus tard :** SAML, Team Sync, permissions de sources et auditing peuvent remplacer ou compléter ces compensations, sans invalider Kerberos ni OIDC déjà en place.

## Alternatives écartées

| Alternative | Motif |
|---|---|
| SAML en OSS | Non disponible (documentation officielle). |
| Auth Proxy sans `whitelist` ni liaison locale | Usurpation de l'en-tête `X-WEBAUTH-USER` depuis le réseau. |
| Keytab RC4 / mot de passe dans `ktpass -pass` en clair sur la ligne de commande | Cryptographie faible ; secret dans l'historique. |
| Traiter `org_attribute_path` / `org_mapping` comme Enterprise | Contredit la documentation 11.2 (GA OSS). Ils **sont** utilisables en 13.2.4 ; Team Sync, lui, ne l'est pas. |
| oauth2-proxy comme unique voie officielle | Outil communautaire utile en Kubernetes, pas un composant Grafana Labs ; la voie officielle OIDC est `[auth.generic_oauth]`. |
