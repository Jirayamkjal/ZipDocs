# ADR-004 — ReadonlyREST Enterprise plutôt que X-Pack Security devant Elasticsearch

- **Statut :** accepté (contrainte d'environnement existante — **ReadonlyREST Enterprise 1.72.0** sur **Elasticsearch 8.19.0**)
- **Date :** 2026-11-12
- **Décideurs :** déjà en vigueur sur les environnements Elasticsearch 8 RHEL
- **Versions :** `ES_VERSION=8.19.0`, `ROR_VERSION=1.72.0` dans [`variables/environnements.env`](../../variables/environnements.env) — paquet greffon ES `readonlyrest-1.72.0_es8.19.0.zip` (le build **doit** correspondre exactement à la version Elasticsearch)
- **Sources :** [For Elasticsearch](https://docs.readonlyrest.com/elasticsearch) (installation, patch, ACL), [Audit](https://docs.readonlyrest.com/elasticsearch/audit), [For Kibana](https://docs.readonlyrest.com/kibana), [changelog 1.72.0](https://docs.readonlyrest.com/changelog) (11 octobre 2026)

## Contexte

Les environnements préprod et prod **Elasticsearch 8.19.0** sont déjà protégés par **ReadonlyREST (ROR) en édition Enterprise 1.72.0**, qui assure TLS et le contrôle d'accès. L'API `_security/*` d'Elasticsearch n'est **pas** le mécanisme d'authentification en vigueur : une tentative de création de clé d'API via `POST /_security/api_key` se solde par une erreur du type « no handler ». **Ne pas** appeler cette API.

Le greffon Elasticsearch (fondation, documentée pour toutes les éditions) fournit le connecteur LDAP, les règles d'ACL, JWT, `proxy_auth` et la collecte d'événements d'audit. Le **greffon Kibana Enterprise** ajoute, d'après la documentation officielle : l'application de paramétrage en grappe (rechargement des ACL **à chaud**, en quelques secondes, sans redémarrer Elasticsearch), la **multi-tenancy** Kibana (indices `.kibana_<tenancy>`, sélecteur de tenancy), l'**impersonation**, SAML / OIDC Kibana (`ror_kbn_auth`), un tableau de bord d'audit, et le gabarit de tenancy. Le rechargement à chaud via l'interface ou l'API est documenté pour les abonnés **PRO et Enterprise** ([Cluster-wide Settings](https://docs.readonlyrest.com/kibana)).

## Décision

Conserver **ROR Enterprise comme unique moteur d'authentification et d'autorisation** devant Elasticsearch, et **en tirer parti** :

- **Comptes de service** (`otel-writer` en écriture, `grafana-reader` en lecture) : HTTP Basic, mot de passe via `auth_key_pbkdf2` (voir [documentation ROR](https://docs.readonlyrest.com/elasticsearch)), droits limités aux motifs d'index nécessaires et à `cluster:monitor/*`. Pas de `_security/api_key`.
- **Connecteur `ldaps`** et règle `ldap_auth` (raccourci de `ldap_authentication` + `ldap_authorization`) : **mêmes groupes AD** que Grafana OSS (ADR-006), vers des motifs d'index et, le cas échéant, des tenancies Kibana (`groups_any_of`). LDAPS 636, vérification des certificats (`ssl_trust_all_certs: false`).
- **Audit** : `audit.enabled: true` et une sortie `index` (modèle par défaut `readonlyrest_audit-YYYY-MM-DD`, voir [Audit configuration](https://docs.readonlyrest.com/elasticsearch/audit)). Protéger l'index d'audit par un bloc `forbid` en tête de l'ACL (les événements d'audit internes de ROR **contournent** l'ACL, d'après cette documentation). Charger le tableau de bord d'audit depuis l'application Kibana ROR (documenté pour toutes les éditions du greffon Kibana).
- **Multi-tenancy Kibana** (Enterprise) : isoler les objets Kibana par tenancy (`kibana.index`, par exemple `.kibana_obs`), sélecteur de tenancy, éventuellement un index gabarit (`readonlyrest_kbn.kibanaIndexTemplate`). Activée par défaut en Enterprise ; à désactiver explicitement seulement si on veut le comportement PRO/Free (`readonlyrest_kbn.multiTenancyEnabled: false`).
- **Rechargement à chaud** : modifier l'ACL depuis l'application Kibana « ReadonlyREST » (enregistrement dans l'index `.readonlyrest`). Un redémarrage d'Elasticsearch n'est plus le chemin normal. `readonlyrest.force_load_from_file: true` reste le **moyen de secours** documenté si les réglages dans l'index sont corrompus ([For Kibana](https://docs.readonlyrest.com/kibana)).
- **JWT** et **`proxy_auth`** : disponibles (toutes éditions du greffon ES ; passthrough Kibana documenté). Pertinents si l'on place Kibana derrière un mandataire déjà authentifié, ou pour un lien JWT. Ils **ne remplacent pas** LDAP comme socle. L'exportateur otelcol et Grafana conservent HTTP Basic.
- **SAML / OIDC Kibana** (`ror_kbn_auth`) : fonctions Enterprise, complémentaires, hors mécanisme principal (LDAP).
- **Impersonation** (Enterprise) : utile au diagnostic, à activer seulement selon la [documentation d'impersonation](https://docs.readonlyrest.com/develop/examples/impersonation).
- Les blocs spécialisés sont **placés avant** tout bloc plus large. L'ordre est déterminant. Les blocs qui authentifient les utilisateurs Kibana doivent être **en tête** (documentation Kibana ROR).

Les procédures correspondantes sont **non testées** dans ce dépôt contre ROR 1.72.0 / ES 8.19.0. Caler la syntaxe YAML sur la documentation officielle de **cette** version ([For Elasticsearch](https://docs.readonlyrest.com/elasticsearch)). Ne pas inventer de clés absentes de cette documentation. En particulier, le paramètre `ssl_hostname_verification` du connecteur LDAP n'apparaît **pas** dans 1.72.0 (il est introduit dans le changelog **1.73.1**, 12 novembre 2026) : ne pas le documenter ni le configurer comme s'il existait en 1.72.0.

## Versions, installation hors ligne et patch (documentation officielle)

Sources : [Installing the plugin](https://docs.readonlyrest.com/elasticsearch), [Upgrading the plugin](https://docs.readonlyrest.com/elasticsearch), [Upgrading Elasticsearch](https://docs.readonlyrest.com/elasticsearch), [changelog](https://docs.readonlyrest.com/changelog).

**Exigences Java** (tableau officiel) : pour Elasticsearch **8.x**, Java **17** au minimum. Elasticsearch 8 embarque un JDK dans `jdk/` qui satisfait cette exigence. Si `ES_JAVA_HOME` (ou `JAVA_HOME`) pointe ailleurs, ce JDK doit aussi être en 17 ou plus.

**Paquet Elasticsearch :** `readonlyrest-1.72.0_es8.19.0.zip` (schéma officiel `readonlyrest-<ROR_VERSION>_es<ES_VERSION>.zip`). Vérifier l'empreinte SHA-256 du lot hors ligne avant installation. Chemin **absolu**, préfixe `file://` (**trois** barres : `file:///` + chemin). ES arrêté pour une mise à jour. Répertoire d'installation Elasticsearch (souvent `/usr/share/elasticsearch` sur RHEL) :

```
# Installation (documentation officielle) — NON TESTÉ dans ce dépôt
bin/elasticsearch-plugin install file:///chemin/absolu/readonlyrest-1.72.0_es8.19.0.zip
```

À l'invite « plugin requires additional permissions », répondre **`y`**.

**Patch obligatoire** pour Elasticsearch ≥ 6.7.0. Pour Elasticsearch **8.3.x ou plus** (donc **8.19.0**), le patch **exige les privilèges root**. Depuis la racine d'installation ES :

```
# Depuis /usr/share/elasticsearch (ou --es-path). Root requis pour ES 8.3+.
jdk/bin/java -jar plugins/readonlyrest/ror-tools.jar patch --I_UNDERSTAND_AND_ACCEPT_ES_PATCHING=yes
jdk/bin/java -jar plugins/readonlyrest/ror-tools.jar verify
```

Sans le drapeau `--I_UNDERSTAND_AND_ACCEPT_ES_PATCHING=yes`, le patcher est interactif. Si le répertoire `jdk/` est absent, utiliser `$JAVA_HOME/bin/java` (documentation officielle). En cas de problème : `ror-tools.jar --help`.

**Mise à jour du greffon** (ordre officiel) : arrêter Elasticsearch → `unpatch` → `elasticsearch-plugin remove readonlyrest` → installer le nouveau zip → `patch` → redémarrer. **Mise à jour d'Elasticsearch** : unpatch et désinstallation **avant** l'upgrade ES, puis installation du build ROR **aligné** sur la nouvelle version ES et re-patch. Un upgrade ES sans cette séquence « may cause corruption of the ES installation » (avertissement officiel).

**Greffon Kibana Enterprise.** Schéma de nom documenté : `readonlyrest_kbn_universal-<ROR_VERSION>_es<version Kibana>.zip`. Pour une Kibana **8.19.0**, le nom attendu est du type `readonlyrest_kbn_universal-1.72.0_es8.19.0.zip`. **Vérifier le nom exact du fichier livré par le portail client, ne pas le renommer.** Installation : `bin/kibana-plugin install file:///chemin/absolu/readonlyrest_kbn_universal-1.72.0_es8.19.0.zip`. Patch Kibana (obligatoire depuis Kibana 7.9, documentation [For Kibana](https://docs.readonlyrest.com/kibana)) : pour Kibana **8.15.0 et plus** (donc 8.19.0), sur Linux, depuis la racine Kibana : `node/glibc-217/bin/node plugins/readonlyrestkbn/ror-tools.js patch`. Aligner `KIBANA_VERSION` sur la version Kibana réellement déployée.

**Points du changelog 1.72.0** (11 octobre 2026) à prendre en compte, **sans inventer** de YAML hors documentation :

- Si Kibana est derrière un équilibreur ou un mandataire : renseigner `readonlyrest_kbn.trusted_proxies` dans `kibana.yml` (valeurs documentées : `none`, `all`, ou une liste d'IP / CIDR). Sans cela, Elasticsearch reçoit l'adresse du mandataire, et une règle `x_forwarded_for` sur les réseaux utilisateurs cesse de fonctionner ; c'est aussi le correctif d'une usurpation d'`X-Forwarded-For`.
- Sortie d'audit de type `index` ou `data_stream` : un *ingest pipeline* optionnel est documenté à partir de 1.72.0 ; un cluster d'audit distant peut utiliser le mode `failover`. Caler la syntaxe sur la [documentation Audit](https://docs.readonlyrest.com/elasticsearch/audit) de cette version.
- Correctifs de sécurité (CVE côté Kibana et Elasticsearch, restrictions SQL / ES|QL).

## Alternatives

| Alternative | Pourquoi elle n'est pas retenue |
|---|---|
| Réactiver X-Pack Security (clés d'API `_security/api_key`) | Changerait le modèle déjà déployé ; conflit de responsabilité avec ROR. Si `xpack.security.enabled` est vrai, c'est le SSL X-Pack qui s'applique, tandis que l'ACL ROR reste le moteur d'auth — ce n'est pas une raison pour migrer l'auth vers X-Pack. |
| Laisser ES ouvert sur le réseau interne | Inacceptable en préprod et prod. |
| Traiter ROR comme une édition gratuite | Contredit la licence Enterprise déjà en place ; on se priverait du rechargement à chaud, de la multi-tenancy et de l'interface de paramétrage. |

## Conséquences

- **Positives :** un seul moteur d'identité sur ES ; même annuaire AD que Grafana ; moindre privilège par bloc ; audit exploitable ; tenancies Kibana si plusieurs équipes partagent le même cluster ; pas de redémarrage pour chaque changement d'ACL.
- **Négatives :** pas de clés d'API Elasticsearch natives ; otelcol et Grafana utilisent utilisateur / mot de passe (fichiers `0600` / `$__file{}`) ; liste exacte des `actions` à ajuster en préprod si un 403 apparaît (marqué **non testé** pour l'exportateur otelcol-contrib contre ROR dans ce dépôt).
- **Attention :** `auth_key` en clair est documenté par ROR pour les tests seulement ; en production, utiliser `auth_key_pbkdf2`. Les secrets de liaison LDAP et `signature_key` (`ror_kbn`) passent par des variables d'environnement ou des fichiers `0600`, jamais en clair dans un dépôt.
