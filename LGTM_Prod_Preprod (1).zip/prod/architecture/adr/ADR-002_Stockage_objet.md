# ADR-002 — Stockage objet pour Mimir, Loki et Tempo

- **Statut :** accepté (chemin à trancher par la **checklist de décision** : scénario A Hitachi / S3 existant, ou scénario B MinIO)
- **Date :** 2026-11-12
- **Décideurs :** architecture / exploitation / stockage
- **Procédures :** [checklist](../annexes/Checklist_decision_stockage_objet.md), [annexe scénario A — Hitachi HCP / VSP One Object](../annexes/Annexe_Stockage_objet_Hitachi_HCP_S3.md), [annexe scénario B — MinIO](../annexes/Annexe_Stockage_objet_S3_MinIO.md), annexes des runbooks

## Contexte

En mode monolithique avec disque local, Mimir, Loki et Tempo ne tolèrent pas la perte d'un nœud sans perte de données historiques. Les modes de production documentés par Grafana Labs (microservices ou simple-scalable / distributed) s'appuient sur un **stockage objet compatible S3** pour les blocs et index de long terme.

L'organisation peut déjà disposer d'un stockage objet Hitachi : **HCP** (API *Hitachi API for Amazon S3*, HS3) ou **VSP One Object** (ex HCP Cloud Scale, API S3). Un **HNAS** n'expose pas d'API S3 serveur (NFS, SMB, FTP, iSCSI) ; Data Migrator to Cloud est un **client** S3, pas un endpoint pour LGTM.

## Décision

Les trois stockages LGTM utilisent un **backend objet S3 compatible**, avec des **seaux distincts** (`lgtm-mimir`, `lgtm-loki`, `lgtm-tempo`, éventuellement `lgtm-admin`). Les noms, le point d'entrée, la CA, le style d'adressage et le scénario se définissent dans [`variables/environnements.env`](../../variables/environnements.env) — **modifier ici seulement** (`STOCKAGE_OBJET_SCENARIO`, `S3_ENDPOINT`, `S3_CA_FILE`, `S3_FORCE_PATH_STYLE`, `S3_BUCKET_*`).

**Étape de décision obligatoire**, avant tout déploiement Mimir / Loki / Tempo et avant de commander des VM ou un pool MinIO : remplir la [checklist](../annexes/Checklist_decision_stockage_objet.md) avec l'équipe stockage (y compris : avez-vous un HCP / VSP One Object ? un HNAS seul **ne suffit pas**). Décision écrite, datée.

Deux scénarios, dans cet ordre :

1. **Scénario A — stockage objet Hitachi existant** (`STOCKAGE_OBJET_SCENARIO=hitachi`), **prioritaire** si un HCP (HS3 activé) ou un VSP One Object est disponible et si **tous** les critères essentiels sont remplis (API S3 serveur réellement utilisable, TLS avec vérification, IAM moindre privilège, capacité, réseau). Demander à l'équipe stockage un tenant / des espaces de noms dédiés par environnement et par usage, les quotas, le certificat et la CA, les comptes de service et les clés, le style path-style ou virtual-hosted, le versioning et la réplication. Câbler Mimir, Loki et Tempo comme dans l'annexe A. Un autre S3 compatible déjà qualifié (non Hitachi) suit le même câblage consommateur, sans déployer MinIO.
2. **Scénario B — aucun stockage objet S3** (`STOCKAGE_OBJET_SCENARIO=minio`) : **MinIO en mode distribué**, documenté en annexe (machines virtuelles RHEL 8 et Kubernetes) : au moins **quatre nœuds**, erasure coding, TLS, politiques IAM, comptes d'application, sauvegarde et supervision. **Avant** toute installation : faire examiner la licence **AGPLv3** de l'édition communautaire MinIO (ou une offre commerciale).

Identifiants dans des fichiers `0600`, jamais sur la ligne de commande. Chiffrement en transit (TLS, `insecure: false`). Chiffrement au repos : selon le service retenu (disques LUKS, mécanismes HCP / VSP One Object ou MinIO), **à confirmer**.

Les procédures d'annexe sont **non testées** dans ce dépôt.

## Alternatives

| Alternative | Décision |
|---|---|
| HCP (HS3) ou VSP One Object déjà exploité | **Scénario A**, à retenir si les critères essentiels sont remplis. |
| Autre S3 compatible déjà en production (Ceph RGW, etc.) | Acceptable : même câblage consommateur que le scénario A. |
| MinIO distribué | **Scénario B**, si aucun S3 serveur n'est disponible. Licence AGPLv3 à valider. |
| **HNAS seul** (NFS, SMB, FTP, iSCSI) ou Data Migrator to Cloud comme « endpoint S3 » | **Rejeté.** HNAS n'expose pas d'API S3 serveur. Data Migrator est un client vers HCP / VSP One Object / un autre S3. |
| **NFS** ou système de fichiers partagé comme backend des blocs Mimir / Loki / Tempo | **Rejeté.** Grafana Labs : NFS non pris en charge pour le disque local Mimir ([hardware requirements](https://grafana.com/docs/mimir/latest/set-up/hardware-requirements/)) ; Loki *scalable* exige un objet S3 ou MinIO en production ([configure storage](https://grafana.com/docs/loki/latest/setup/install/helm/configure-storage/)) ; Tempo distribuée s'appuie sur un stockage objet ([architecture](https://grafana.com/docs/tempo/latest/reference-tempo-architecture/object-storage/)). |
| Disque local uniquement (mode laboratoire) | Pas de réplication des blocs historiques. Acceptable uniquement en démonstration, pas en préprod ni prod. |

## Conséquences

- **Positives :** les nœuds Mimir / Loki / Tempo deviennent des travailleurs interchangeables ; la rétention se scale sur l'objet ; restauration d'un nœud sans recopier l'historique. Le scénario A réutilise un investissement stockage existant et évite quatre VM MinIO ainsi que l'examen de licence AGPLv3.
- **Négatives :** dépendance à la disponibilité du service objet ; compétence MinIO si le scénario B est retenu ; licence à valider pour MinIO ; écarts d'API S3 possibles (notamment limites HCP sur `DeleteObjects` en présence de rétention) à qualifier en préprod.
- **Ouvert (à confirmer) :** résultat de la checklist (`STOCKAGE_OBJET_SCENARIO`) ; style path-style ou virtual-hosted ; rétention par signal et interaction avec une rétention Hitachi ; cycle de vie ; chiffrement au repos côté objet ; sauvegarde des seaux ; licence AGPLv3 si le scénario B est retenu.
