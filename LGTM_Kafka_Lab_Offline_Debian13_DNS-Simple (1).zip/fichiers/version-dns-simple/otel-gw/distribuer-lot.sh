#!/bin/bash
# distribuer-lot.sh (VM otel-gw, root) - envoie à chaque VM seulement les fichiers qui la concernent,
# depuis le lot déjà VÉRIFIÉ (/opt/lgtm-bundle), puis recontrôle les empreintes SUR la VM de destination.
# Prérequis : compte « admin » (sudo) sur chaque VM, SSH joignable ; le mot de passe est demandé à chaque VM.
set -euo pipefail
LOT=${LOT:-/opt/lgtm-bundle}
SSH=${SSH:-ssh}
UTIL=${UTIL:-admin}
# Noms complets des VM, résolus par le DNS du DC (à adapter au domaine)
declare -A IP=( [kafka01]='kafka01.lab.example.test' [mimir01]='mimir01.lab.example.test' [loki01]='loki01.lab.example.test' \
                [tempo01]='tempo01.lab.example.test' [grafana01]='grafana01.lab.example.test' [elk]='elk.lab.example.test' )
NE=node_exporter/node_exporter-1.12.1.linux-amd64.tar.gz
OC=otelcol-contrib/otelcol-contrib_0.164.0_linux_amd64.deb
declare -A LISTE=(
  [kafka01]="$NE kafka/kafka_2.13-4.4.0.tgz java/OpenJDK25U-jre_x64_linux_hotspot_25.0.5_8.tar.gz"
  [mimir01]="$NE $OC mimir/mimir-3.2.3_amd64.deb mimir/mimirtool_3.2.3_amd64.deb"
  [loki01]="$NE $OC loki/loki_3.7.9_amd64.deb"
  [tempo01]="$NE $OC tempo/tempo_3.1.1_linux_amd64.deb"
  [grafana01]="$NE grafana/grafana_13.2.4_38252365904_linux_amd64.deb debian/adduser_3.152_all.deb"
  [elk]="$NE $OC"
)
cd "$LOT"
for vm in "${!LISTE[@]}"; do
  [ -n "${1:-}" ] && [ "$1" != "$vm" ] && continue          # option : ./distribuer-lot.sh loki01
  echo "== $vm (${IP[$vm]})"
  # shellcheck disable=SC2086
  tar -cf - ${LISTE[$vm]} lgtm-sha256-attendus | \
    $SSH "$UTIL@${IP[$vm]}" 'rm -rf /var/tmp/lgtm-lot && mkdir -p /var/tmp/lgtm-lot && tar -xf - -C /var/tmp/lgtm-lot && cd /var/tmp/lgtm-lot && sha256sum -c --ignore-missing --strict lgtm-sha256-attendus'
done
echo "Distribution terminée : chaque VM a recontrôlé ses fichiers (lignes « OK » ci-dessus)."
