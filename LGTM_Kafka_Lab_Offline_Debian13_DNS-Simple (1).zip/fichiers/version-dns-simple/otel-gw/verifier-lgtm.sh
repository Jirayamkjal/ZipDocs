#!/bin/bash
# verifier-lgtm.sh - vérification hors ligne du lot LGTM + Kafka (à lancer sur otel-gw, VM de réception du lot,
# dans le dossier lgtm-telechargement). Chaque VM recontrôle ensuite ses fichiers avec lgtm-sha256-attendus.
# Usage : cd /var/tmp/lgtm-telechargement && bash /var/tmp/verifier-lgtm.sh
set -u
ECHEC=0
ok(){ printf '  [OK]    %s\n' "$1"; }
ko(){ printf '  [ECHEC] %s\n' "$1"; ECHEC=1; }

echo "1) Intégrité du transfert (manifeste produit sous Windows)"
sha256sum -c --strict --quiet MANIFEST-SHA256.txt && ok "MANIFEST-SHA256.txt" || ko "MANIFEST-SHA256.txt"

echo "2) Empreintes amont épinglées dans le runbook (écrites sur le serveur, pas transférées)"
sha256sum -c --strict --quiet /var/tmp/lgtm-sha256-attendus && ok "lgtm-sha256-attendus" || ko "lgtm-sha256-attendus"

echo "3) Recoupement avec les fichiers d'empreintes publiés par chaque projet"
for d in prometheus node_exporter tempo windows; do
  f=$(ls "$d"/SHA256SUMS "$d"/sha256sums.txt 2>/dev/null | head -1)
  (cd "$d" && sha256sum --ignore-missing --strict --quiet -c "$(basename "$f")") && ok "$d/$(basename "$f")" || ko "$d/$(basename "$f")"
done
# Fichiers d'empreinte « valeur seule » (sans nom de fichier) : Grafana .sha256, Mimir -sha-256, OTel .sha256
for s in grafana/*.deb.sha256 mimir/*-sha-256 otelcol-contrib/*.sha256 windows/*.msi.sha256; do
  cible="${s%.sha256}"; cible="${cible%-sha-256}"
  echo "$(tr -d ' \r\n' < "$s")  $cible" | sha256sum -c --strict --quiet && ok "$s" || ko "$s"
done

echo "4) Chaîne GPG du dépôt APT Grafana (InRelease signé -> Packages.gz -> .deb)"
EMPREINTE_GRAFANA=B53AE77BADB630A683046005963FA27710458545
rm -f /tmp/InRelease.verifie   # sqv refuse d'écraser un fichier de sortie existant
signataire=$(sqv --keyring=grafana/gpg-full.key --cleartext --output=/tmp/InRelease.verifie grafana-apt/InRelease 2>/dev/null)
[ "$signataire" = "$EMPREINTE_GRAFANA" ] && ok "InRelease signé par $signataire" || ko "signature InRelease (obtenu : '${signataire}')"
attendu=$(awk '/^SHA256:/{f=1;next} /^[A-Za-z]/{f=0} f && $3=="main/binary-amd64/Packages.gz"{print $1}' /tmp/InRelease.verifie)
echo "$attendu  grafana-apt/Packages.gz" | sha256sum -c --strict --quiet && ok "Packages.gz conforme à InRelease" || ko "Packages.gz"
zcat grafana-apt/Packages.gz | awk 'BEGIN{RS="";FS="\n"} {fn="";sh=""; for(i=1;i<=NF;i++){if($i~/^Filename: /)fn=substr($i,11); if($i~/^SHA256: /)sh=substr($i,9)} n=split(fn,a,"/"); if(sh!="") print sh"  "a[n]}' > /tmp/grafana-apt-sha256
for deb in grafana/grafana_*.deb mimir/mimir-*.deb mimir/mimirtool_*.deb loki/loki_*.deb tempo/tempo_*.deb; do
  b=$(basename "$deb"); h=$(awk -v n="$b" '$2==n{print $1; exit}' /tmp/grafana-apt-sha256)
  [ -n "$h" ] && echo "$h  $deb" | sha256sum -c --strict --quiet && ok "$b (index APT signé)" || ko "$b absent ou différent dans l'index APT signé"
done

echo "5) Apache Kafka : SHA-512 publiée + signature .asc (fichier KEYS du projet)"
EMPREINTE_KAFKA=1817905E3B2708B11A24B88E9AFA6F66CC8C3534   # responsable de la version 4.4.0 (vérifié le 28 oct. 2026)
k=$(ls kafka/kafka_*.tgz | head -1)
# Le .sha512 d'Apache est au format « gpg --print-md » (majuscules, espaces, retours à la ligne) : on le normalise
publie=$(cut -d: -f2- "$k.sha512" | tr -d ' \r\n' | tr 'A-F' 'a-f')
calcule=$(sha512sum "$k" | cut -d' ' -f1)
[ -n "$publie" ] && [ "$publie" = "$calcule" ] && ok "$(basename "$k") SHA-512" || ko "$(basename "$k") SHA-512"
signataire=$(sqv --keyring=kafka/KEYS "$k.asc" "$k" 2>/dev/null)
[ "$signataire" = "$EMPREINTE_KAFKA" ] && ok "$(basename "$k") signé par $signataire" || ko "signature Kafka (obtenu : '${signataire}')"

echo "6) Java (Eclipse Temurin JRE) : SHA-256 publiée + signature (clé Adoptium)"
EMPREINTE_ADOPTIUM=3B04D753C9050D9A5D343F39843C48A565F8F04B
j=$(ls java/OpenJDK*.tar.gz | head -1)
(cd java && sha256sum -c --strict --quiet "$(basename "$j").sha256.txt") && ok "$(basename "$j") SHA-256" || ko "$(basename "$j") SHA-256"
signataire=$(sqv --keyring=java/adoptium-public.key "$j.sig" "$j" 2>/dev/null)
[ "$signataire" = "$EMPREINTE_ADOPTIUM" ] && ok "$(basename "$j") signé par $signataire" || ko "signature Temurin (obtenu : '${signataire}')"

echo
[ "$ECHEC" -eq 0 ] && echo "RÉSULTAT : tout est conforme, l'installation peut commencer." || { echo "RÉSULTAT : au moins une vérification a échoué. NE RIEN INSTALLER."; exit 1; }
