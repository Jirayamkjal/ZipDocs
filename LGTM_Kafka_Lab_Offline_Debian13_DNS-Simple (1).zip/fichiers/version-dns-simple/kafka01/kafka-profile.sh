export JAVA_HOME=/opt/java/current
export PATH="$PATH:/opt/kafka/current/bin"
