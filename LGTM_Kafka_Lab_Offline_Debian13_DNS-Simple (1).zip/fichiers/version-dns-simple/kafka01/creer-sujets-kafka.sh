#!/bin/bash
# creer-sujets-kafka.sh (VM kafka01) - création EXPLICITE des sujets OTLP (auto.create.topics.enable=false)
# Rétention : 24 h OU la taille maximale par partition, la première limite atteinte l'emporte.
# Taille maximale théorique des données : (2 + 1 + 1) Gio x 3 partitions = 12 Gio (+ un segment actif par partition).
set -eu
export JAVA_HOME=${JAVA_HOME:-/opt/java/current}
K=${KAFKA_BIN:-/opt/kafka/current/bin}
B=127.0.0.1:9092
creer() {  # $1=sujet  $2=retention.bytes par partition
  if "$K/kafka-topics.sh" --bootstrap-server "$B" --list | grep -qx "$1"; then
    echo "existe déjà : $1"
  else
    "$K/kafka-topics.sh" --bootstrap-server "$B" --create --topic "$1" \
      --partitions 3 --replication-factor 1 \
      --config retention.ms=86400000 \
      --config retention.bytes="$2" \
      --config segment.bytes=268435456 \
      --config max.message.bytes=1048588
  fi
}
creer otlp_logs    2147483648   # 2 Gio par partition
creer otlp_metrics 1073741824   # 1 Gio par partition
creer otlp_spans   1073741824   # 1 Gio par partition
"$K/kafka-topics.sh" --bootstrap-server "$B" --describe --topic 'otlp_.*' | grep -v '^\s'
