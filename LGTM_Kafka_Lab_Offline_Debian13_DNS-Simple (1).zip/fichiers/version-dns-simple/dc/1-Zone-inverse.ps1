﻿Get-DnsServerZone | Format-Table ZoneName, IsReverseLookupZone, IsDsIntegrated
# Si « 2.0.192.in-addr.arpa » n'apparaît pas :
Add-DnsServerPrimaryZone -NetworkId "192.0.2.0/24" -ReplicationScope Domain
