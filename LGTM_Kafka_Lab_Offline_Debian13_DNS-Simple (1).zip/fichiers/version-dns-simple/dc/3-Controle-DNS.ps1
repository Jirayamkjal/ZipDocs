﻿Get-DnsServerResourceRecord -ZoneName "lab.example.test" -RRType A | Format-Table HostName, @{n='IP';e={$_.RecordData.IPv4Address}}
Resolve-DnsName kafka01.lab.example.test
Resolve-DnsName 192.0.2.21        # PTR : doit répondre kafka01.lab.example.test
