﻿Add-DnsServerResourceRecordA -ZoneName "lab.example.test" -Name "kafka01"   -IPv4Address "192.0.2.21" -CreatePtr
Add-DnsServerResourceRecordA -ZoneName "lab.example.test" -Name "otel-gw"   -IPv4Address "192.0.2.22" -CreatePtr
Add-DnsServerResourceRecordA -ZoneName "lab.example.test" -Name "mimir01"   -IPv4Address "192.0.2.23" -CreatePtr
Add-DnsServerResourceRecordA -ZoneName "lab.example.test" -Name "loki01"    -IPv4Address "192.0.2.24" -CreatePtr
Add-DnsServerResourceRecordA -ZoneName "lab.example.test" -Name "tempo01"   -IPv4Address "192.0.2.25" -CreatePtr
Add-DnsServerResourceRecordA -ZoneName "lab.example.test" -Name "grafana01" -IPv4Address "192.0.2.26" -CreatePtr
Add-DnsServerResourceRecordA -ZoneName "lab.example.test" -Name "elk"       -IPv4Address "192.0.2.11" -CreatePtr   # seulement si « elk » n'existe pas déjà
