# 05 – Dimensionnement de l'infrastructure

> Valeurs de **démonstration** pour un hôte Hyper-V de **32 Go**. Procédure : runbook §4 (`Creer-VM-LGTM-Kafka.ps1`) et §5.7 (limites).

## 1. VM du lab

| VM | Rôle | vCPU | RAM démarrage | RAM min / max | Disque (VHDX dynamique) | État |
|---|---|---|---|---|---|---|
| DC | AD DS, DNS ; agents | 1 | 2 Go | 1 / 2 Go | existant | **inchangée** |
| ELK | ES 9, Kibana, ElastAlert 2 ; agents | 2 | 3 Go | 2 / 4 Go | existant | **inchangée** jusqu'à la phase 6 |
| AppDynamics | contrôleur (retour arrière) | – | – | – | existant | éteinte |
| kafka01 | Kafka 4.4.0 KRaft, Temurin 25 | 2 | 3 Go | 2 / 4 Go | 40 Go | nouvelle |
| otel-gw | passerelle, consommateur ELK, `kafka_metrics`, Prometheus agent | 2 | 2 Go | 1,5 / 3 Go | 20 Go | nouvelle |
| mimir01 | Mimir + Alertmanager, consommateur | 2 | 3 Go | 2 / 4 Go | 40 Go | nouvelle |
| loki01 | Loki, consommateur | 2 | 2 Go | 1,5 / 3 Go | 40 Go | nouvelle |
| tempo01 | Tempo, consommateur | 1 | 2 Go | 1,5 / 3 Go | 30 Go | nouvelle |
| grafana01 | Grafana | 1 | 2 Go | 1 / 3 Go | 20 Go | nouvelle |
| **Nouvelles VM** | | **10** | **14 Go** | **9,5 / 20 Go** | **190 Go** max | |
| **Total actif** | | **13** | **19 Go** | **12,5 / 26 Go** | | |

## 2. Budget de l'hôte Hyper-V (32 Go)

```mermaid
pie showData
  title RAM maximale par VM (Go) - 26 Go sur 32, 6 Go pour Windows
  "DC" : 2
  "ELK" : 4
  "kafka01" : 4
  "otel-gw" : 3
  "mimir01" : 4
  "loki01" : 3
  "tempo01" : 3
  "grafana01" : 3
  "Windows (hôte)" : 6
```

| Situation | RAM des VM | Reste pour Windows |
|---|---|---|
| Démarrage (valeurs *startup*) | 19 Go | 13 Go |
| Minimum (mémoire dynamique au repos) | 12,5 Go | 19,5 Go |
| Toutes les VM à leur maximum | 26 Go | **6 Go** (limite basse demandée : 6 à 8 Go) |

- **Processeur :** 13 vCPU ; avec **8 processeurs logiques ou plus** (hypothèse, non vérifiée), le rapport est d'environ **1,6 vCPU par processeur logique**, raisonnable pour un lab où les services attendent la plupart du temps. Relever la valeur réelle : `Get-VMHost | Select-Object LogicalProcessorCount`.
- **Variante 4 processeurs logiques** (non testée) : les six nouvelles VM à **1 vCPU** (9 vCPU, ≈ 2,3 par processeur). DC et ELK inchangés. Démarrages et rattrapages plus lents.
- **Si l'hôte manque de RAM** : baisser d'abord les maximums de grafana01 et tempo01 (3 → 2,5 Go), jamais sous la somme des `MemoryMax` de la VM (§3) + 300 Mo.

## 3. Budget mémoire par VM

| VM (RAM min) | Service | `MemoryHigh` / `MemoryMax` | Limite interne | Mesuré au repos (test) |
|---|---|---|---|---|
| kafka01 (2 Go) | `kafka` | 1536M / 1792M | *heap* `-Xms1g -Xmx1g` | ≈ 540 Mo |
| kafka01 | `node_exporter` | – / 64M | – | ≈ 20 Mo |
| otel-gw (1,5 Go) | `otelcol-contrib` (passerelle + ELK + `kafka_metrics`) | 690M / 768M | `GOMEMLIMIT=600MiB`, `memory_limiter` 600/120 | ≈ 210 Mo |
| otel-gw | `prometheus` (agent) | 230M / 256M | `GOMEMLIMIT=200MiB` | 115–130 Mo |
| mimir01 (2 Go) | `mimir` | 1380M / 1536M | `GOMEMLIMIT=1200MiB` | 150–215 Mo |
| mimir01, loki01, tempo01 | `otelcol-contrib` (consommateur) | 345M / 384M | `GOMEMLIMIT=300MiB`, `memory_limiter` 300/60 | ≈ 205 Mo |
| loki01 (1,5 Go) | `loki` | 920M / 1024M | `GOMEMLIMIT=800MiB` | ≈ 160 Mo |
| tempo01 (1,5 Go) | `tempo` | 920M / 1024M | `GOMEMLIMIT=800MiB` | 120–135 Mo |
| grafana01 (1 Go) | `grafana-server` | 690M / 768M | `GOMEMLIMIT=600MiB` | 360–380 Mo |

Somme des `MemoryMax` par VM (node_exporter compris) : kafka01 1,81 Gio ; otel-gw 1,06 Gio ; mimir01 1,94 Gio ; loki01 1,44 Gio ; tempo01 1,44 Gio ; grafana01 0,81 Gio. Chaque somme reste **sous le minimum** de la mémoire dynamique de la VM, avec une marge de 64 Mio (mimir01, loki01, tempo01) à 450 Mio (otel-gw), et **sous le maximum** avec au moins 1 Gio pour Debian et le cache. Les limites sont des plafonds : au repos, chaque service en est loin (dernière colonne), et Hyper-V ajoute de la RAM jusqu'au maximum quand la VM en demande.

**Kafka et le cache de pages.** Kafka lit et écrit ses segments à travers le **cache de pages** du noyau, pas dans le *heap* Java. Le *heap* est fixé à 1 Go ; le reste de la RAM de kafka01 sert de cache. `MemoryMax` compte une partie de ce cache dans la cgroup : le noyau le libère avant d'atteindre la limite. Comportement non mesuré sous charge (annexe A du runbook).

## 4. Agents sur les VM existantes (sans changer leurs ressources)

| VM | Agent | Limite | Point de vigilance |
|---|---|---|---|
| ELK | `node_exporter` | 64M | – |
| ELK | `otelcol-contrib` (journald) | 288M / 320M, `GOMEMLIMIT=256MiB` | RAM disponible de la VM ELK (2–4 Go) avec ES, Kibana, ElastAlert 2 : surveiller `node_memory_MemAvailable_bytes{vm="elk"}`, le *swap* et les redémarrages ; **signaler**, ne pas agrandir la VM |
| DC | `windows_exporter`, `otelcol-contrib` | `GOMEMLIMIT=200MiB` | pas de limite dure sous Windows |

## 5. Disques

| VM | Données | Plafond | Taille VHDX |
|---|---|---|---|
| kafka01 | `/var/lib/kafka/data` | `otlp_logs` 3 × 2 Gio + `otlp_metrics` 3 × 1 Gio + `otlp_spans` 3 × 1 Gio = **12 Gio**, + 9 segments actifs ≤ 2,25 Gio ; sujets internes faibles | 40 Go |
| kafka01 | `/var/log/kafka` | 7 jours (`tmpfiles.d`) ; GC 50 Mo | (inclus) |
| mimir01 | `/var/lib/mimir` | 15 jours, ≤ 150 000 séries | 40 Go |
| loki01 | `/var/lib/loki` | 168 h | 40 Go |
| tempo01 | `/var/tempo` | 72 h | 30 Go |
| otel-gw | `/var/lib/prometheus` (WAL), `/opt/lgtm-bundle` (≈ 1,1 Go) | WAL vidé après envoi | 20 Go |
| grafana01 | `/var/lib/grafana` | base SQLite | 20 Go |

Contrôles : `df -h /`, `du -sh <dossier>`, alerte `KafkaDisqueFaible`, tableau node_exporter dans Grafana.

## 6. Fin de la migration (phase 6)

Après le retrait d'ELK : le pipeline `logs/elk` disparaît (otel-gw peut redescendre à 2 Go max), la VM ELK est éteinte (−3 Go au démarrage) et AppDynamics est supprimée. Total actif : DC + six VM = 11 vCPU, 16 Go au démarrage.

## 7. Commandes Hyper-V

Création des six VM : runbook §4.3 (`Creer-VM-LGTM-Kafka.ps1`, sans aucune modification de DC ni d'ELK). Contrôle :

```powershell
Get-VM | Select-Object Name, State, ProcessorCount, @{n='Demarrage_Go';e={$_.MemoryStartup/1GB}}, @{n='Min_Go';e={$_.MemoryMinimum/1GB}}, @{n='Max_Go';e={$_.MemoryMaximum/1GB}} | Format-Table -AutoSize
```
