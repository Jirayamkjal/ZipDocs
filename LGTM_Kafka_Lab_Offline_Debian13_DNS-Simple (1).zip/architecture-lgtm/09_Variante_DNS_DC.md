# 09 – Variante DNS du DC (noms DNS à la place des adresses)

> Décision ajoutée le 29 oct. 2026 (ADR-014). Procédure : [`../Runbook_LGTM_Kafka_Offline_Debian13_DNS-DC.md`](../Runbook_LGTM_Kafka_Offline_Debian13_DNS-DC.md) (section P, §4.3 à §4.7, §5.0, §8.1). La version **adresses IP** ([`../Runbook_LGTM_Kafka_Offline_Debian13.md`](../Runbook_LGTM_Kafka_Offline_Debian13.md)) reste valable et inchangée : choisis l'une **ou** l'autre pour tout le lab.

<a id="adr-014"></a>
## ADR-014 – Le DNS intégré à AD du DC résout les noms du lab ; paramètres en un seul endroit

**Statut.** Acceptée (variante). N'annule aucune autre ADR ; ADR-013 (ressources de DC et ELK inchangées) s'applique toujours.

**Contexte.** Le lab a déjà un contrôleur de domaine avec le rôle DNS, utilisé comme serveur DNS par les VM. La version IP place des adresses (`<ip-…>`) dans chaque configuration et une copie de tous les noms dans `/etc/hosts` de chaque VM : un changement d'adresse touche une dizaine de fichiers sur sept VM.

**Décision.**
1. **Zone directe** du domaine AD (existante) et **zone inverse intégrée à AD** (créée) sur le DC ; un **A + PTR statique** par VM du lab ; CNAME facultatifs pour les humains ; **aucun redirecteur** (lab hors ligne).
2. Les VM Linux ont le DC comme **seul** serveur DNS (`/etc/resolv.conf` statique, `search <domaine>`) et seulement **leur propre** ligne dans `/etc/hosts`.
3. Toutes les configurations utilisent des **FQDN** (`advertised.listeners` de Kafka, exportateurs et récepteurs OTel, cibles Prometheus, URL de Mimir, Loki, Tempo, sources de Grafana, agents du DC et d'ELK vers otel-gw), **sauf** la boucle locale (`127.0.0.1`) et le **pare-feu nftables** (adresses).
4. **Aucune valeur en dur** : domaine, adresses, noms d'hôtes sont définis une seule fois dans `lab-params.psd1` (Windows) ; `lab.env` (Linux, `/etc/lgtm/lab.env`) en est généré ; les configurations sont des **gabarits** `${VARIABLE}` rendus par `lgtm-rendre` (`envsubst` avec liste explicite, ou `sed`) et `Rendre-Gabarit.ps1`.
5. Le DC démarre **en premier** (Hyper-V `AutomaticStartDelay` 0 s), sans modifier ses ressources.

**Conséquences.**
- (+) Changer une adresse = `lab-params.psd1` + enregistrement A/PTR + nouveau rendu ; aucune édition manuelle de configuration.
- (+) Noms lisibles dans les journaux, les étiquettes `instance` de Prometheus (FQDN) et les outils Kafka (PTR).
- (−) **Dépendance au DC** pour toute nouvelle connexion (les connexions ouvertes continuent : constaté en test). Mitigation : ordre de démarrage, `timeout:2 attempts:2`, secours `/etc/hosts` commenté (activé seulement pendant une panne).
- (−) **Kafka** : le nom de `advertised.listeners` doit être résolu par **chaque** client ; s'il ne l'est pas, Kafka démarre normalement mais les clients échouent après l'amorçage (constaté en test). C'est le point à contrôler en premier en cas de panne.
- (−) **TLS** : les certificats doivent porter les FQDN dans leurs SAN (Elasticsearch : `ES_HOST`) ; AD CS en option.
- (=) Pare-feu : adresses gardées, car `nft` ne résout un nom qu'au chargement (constaté) ; elles viennent quand même de `lab.env`.

**Alternatives écartées.** `/etc/hosts` partout (c'est la version IP : pas de PTR, copie à tenir sur 7 VM) ; `systemd-resolved` (absent de l'ISO netinst, pas nécessaire) ; second serveur DNS Linux (dnsmasq/bind) en secours (nouvelle VM ou nouveau service, contraire à la sobriété du lab ; à réévaluer si le DC devient un point de panne gênant) ; jonction des VM Linux au domaine (`realmd`/`sssd`, paquets hors ISO, mises à jour dynamiques sécurisées : hors périmètre) ; noms dans nftables (dépendance au DNS au démarrage).

## Enregistrements DNS sur le DC

Valeurs d'**exemple** (domaine `lab.example.test`, réseau de documentation 192.0.2.0/24) ; les vraies valeurs viennent de `lab-params.psd1`. Script : `Creer-DNS-Lab.ps1` (idempotent, `-Simulation`).

| Zone | Nom | Type | Valeur (exemple) | Variable | Créé par |
|---|---|---|---|---|---|
| `LAB_DOMAIN` (existante, AD) | `dc01` | A | 192.0.2.10 | `DC_HOST` / `DC_IP` | le DC lui-même (existant) |
| `LAB_DOMAIN` | `elk` | A | 192.0.2.11 | `ELK_*` | script (s'il manque ; jamais modifié s'il existe) |
| `LAB_DOMAIN` | `kafka01` | A | 192.0.2.21 | `KAFKA01_*` | script |
| `LAB_DOMAIN` | `otel-gw` | A | 192.0.2.22 | `OTELGW_*` | script |
| `LAB_DOMAIN` | `mimir01` | A | 192.0.2.23 | `MIMIR01_*` | script |
| `LAB_DOMAIN` | `loki01` | A | 192.0.2.24 | `LOKI01_*` | script |
| `LAB_DOMAIN` | `tempo01` | A | 192.0.2.25 | `TEMPO01_*` | script |
| `LAB_DOMAIN` | `grafana01` | A | 192.0.2.26 | `GRAFANA01_*` | script |
| `LAB_REVERSE_ZONE` (créée, AD, mises à jour sécurisées) | `10`, `11`, `21`…`26` | PTR | `<hôte>.<domaine>.` | dérivés | script (`-CreatePtr`, ou PTR seul si l'A existait) |
| `LAB_DOMAIN` | `grafana`, `kafka` (facultatif) | CNAME | `grafana01`, `kafka01` | `CNAMES` | script ; **jamais** utilisés dans les configurations |
| – | redirecteurs | – | **aucun** | – | – |

## Ordre de démarrage (Hyper-V)

```mermaid
flowchart LR
  DC["DC (DNS)<br/>0 s"] --> ELK["ELK<br/>120 s"] --> K["kafka01<br/>180 s"] --> S["mimir01, loki01, tempo01<br/>240 s"] --> G["otel-gw, grafana01<br/>300 s"]
```

| VM | `AutomaticStartDelay` | Raison |
|---|---|---|
| DC | 0 s | serveur DNS de tout le lab |
| ELK | 120 s | après le DNS |
| kafka01 | 180 s | les consommateurs et la passerelle en dépendent |
| mimir01, loki01, tempo01 | 240 s | stockages + consommateurs Kafka |
| otel-gw, grafana01 | 300 s | passerelle (producteur) et consultation en dernier |

Seuls `-AutomaticStartAction` et `-AutomaticStartDelay` sont réglés sur DC et ELK : **aucune** modification de vCPU, RAM ou disque (ADR-013). Les délais sont à ajuster après mesure du temps réel de démarrage du DNS du DC.

## Ce qui change par rapport à la version IP

| Sujet | Version IP | Variante DNS du DC |
|---|---|---|
| Valeurs du lab | `<ip-…>` remplacés par `ip-lab.sed` | `lab-params.psd1` → `lab.env` → gabarits `${…}` (`lgtm-rendre`, `Rendre-Gabarit.ps1`) |
| Résolution | `/etc/hosts` complet sur chaque VM | DNS du DC ; `/etc/hosts` = la VM seule (+ secours commenté) |
| Kafka `advertised.listeners` | `PLAINTEXT://<ip-kafka01>:9092` | `PLAINTEXT://${KAFKA01_FQDN}:9092` |
| Elasticsearch | `elk.lab.local` (exemple) ajouté à `/etc/hosts` | `ES_HOST` (défaut `ELK_FQDN`), présent dans les SAN du certificat |
| Prometheus | `instance` = adresse | `instance` = FQDN ; étiquette `vm` inchangée |
| nftables | adresses | adresses (venant de `lab.env`) |
| Préparation Windows | – | `Creer-DNS-Lab.ps1` sur le DC ; ordre de démarrage dans `Creer-VM-LGTM-Kafka.ps1` |
| Lot hors ligne | 32 fichiers + manifeste | + `lab/` (lab.env, scripts, gabarits) ; + `debian-dns/` (facultatif, `dig`) |
| Contrôles | `verifier-lgtm.sh` | + étape 7 et `verifier-dns.sh` |

## Panne du DNS et garde-fous

- **Avant tout changement** : `verifier-dns.sh` doit finir par `RÉSULTAT DNS : conforme.` (ajouté à la liste de contrôle de [GUARDRAILS.md](GUARDRAILS.md)).
- **Pendant une panne du DC** : les flux ouverts continuent ; activer le secours `/etc/hosts` seulement si une reprise est nécessaire, puis le **désactiver** dès que le DC répond (`verifier-dns.sh` signale `[ATTN]` tant qu'il est actif).
- **Changement d'adresse ou de nom** : `lab-params.psd1` d'abord, puis `Creer-DNS-Lab.ps1` (il signale l'écart sans modifier : corriger l'A/PTR à la main), nouveau `lab.env`, distribution, `lgtm-rendre -i` des fichiers concernés, validation, redémarrage. Pour kafka01 : tous les clients doivent résoudre le nouveau nom **avant** le redémarrage de Kafka.
- **Ne jamais** modifier les ressources du DC pour « accélérer » le DNS ; ne pas ajouter de redirecteur vers Internet.

## Points non vérifiés

Cmdlets DnsServer et Hyper-V exécutées seulement en simulation ; PowerShell 5.1 non testé ; contenu exact des fichiers réseau écrits par l'installateur Debian ; comportement d'un DC réellement muet (délais) ; certificat d'ES et AD CS. Détail : annexe A du runbook DNS (points 15 et 19 à 26).
