# Garde-fous – Lab LGTM hors ligne (Debian 13, Hyper-V)

> Règles **obligatoires** pour toute intervention sur les six VM du projet (kafka01, otel-gw, mimir01, loki01, tempo01, grafana01), la VM ELK, le DC ou l'hôte Hyper-V. Elles complètent `../Runbook_LGTM_Kafka_Offline_Debian13.md` (procédures) et [06_Securite.md](06_Securite.md) (mesures de sécurité). En cas de conflit, le garde-fou l'emporte : on s'arrête et on corrige la procédure.

## 1. Hors ligne uniquement

- Les VM Debian 13 **n'accèdent jamais à Internet** : pas de `apt update` vers un miroir externe, pas de `wget`/`curl` vers l'extérieur, pas de `grafana cli plugins install`, pas de `curl … | sh`.
- **Seul le poste Windows télécharge**, avec `Telecharger-LGTM-Kafka.ps1` et les versions épinglées (Kafka et Java compris). Il ne vérifie ni n'installe rien.
- Tout fichier qui entre dans une VM passe par le lot hors ligne (manifeste + archive + `scp`) et par `verifier-lgtm.sh` (sur otel-gw), puis `distribuer-lot.sh` qui revérifie les empreintes sur chaque VM.
- Grafana garde son drop-in `offline.conf` (aucun appel sortant) ; Mimir et Loki gardent `usage_stats` / `analytics` désactivés. Les VM ne joignent que les adresses du lab (pare-feu nftables, runbook §5.7).

## 2. Pas de Docker

- Aucun moteur de conteneurs (Docker, Podman, containerd) sur les VM du lab.
- Uniquement des paquets `.deb` officiels ou des archives binaires officielles, lancés en **services systemd** (ADR-001).

## 3. Vérification avant toute installation

Aucun `dpkg -i`, aucune copie de binaire dans `/usr/local/bin`, aucune décompression dans `/opt/kafka` ou `/opt/java`, aucune installation de MSI tant que **toutes** les vérifications ne sont pas au vert :

| Contrôle | Commande | Attendu |
|---|---|---|
| Manifeste du transfert | `sha256sum -c --strict MANIFEST-SHA256.txt` (fait par `verifier-lgtm.sh`) | toutes les lignes `OK` |
| Empreintes publiées | `sha256sum -c` sur `SHA256SUMS`, `sha256sums.txt`, `*.sha256`, `*-sha-256` | `OK` |
| Archive Kafka | `sha512sum` comparé à `kafka_2.13-4.4.0.tgz.sha512` ; `sqv --keyring=kafka/KEYS kafka_2.13-4.4.0.tgz.asc kafka_2.13-4.4.0.tgz` | `OK` ; signataire `1817905E3B2708B11A24B88E9AFA6F66CC8C3534` |
| JRE Temurin | `sha256sum -c` sur le `.sha256.txt` ; `sqv --keyring=java/adoptium-public.key <archive>.sig <archive>` | `OK` ; signataire `3B04D753C9050D9A5D343F39843C48A565F8F04B` |
| Index APT Grafana signé | `sqv --keyring gpg-full.key --output /tmp/InRelease.verifie InRelease` puis comparaison des SHA-256 de `Packages.gz` | signature valide (empreinte `B53AE77BADB630A683046005963FA27710458545`) et empreintes identiques |
| Empreintes attendues du runbook (Kafka et Java compris) | `sha256sum -c --strict lgtm-sha256-attendus` | `OK` |
| ISO Debian | `sqv` sur `SHA256SUMS.sign` (clé `DF9B9C49EAA9298432589D76DA87E80D6294BE9B`) puis `sha256sum -c` | signature valide et `OK` |
| MSI sur le DC | `Get-FileHash -Algorithm SHA256` | égal à la valeur de `lgtm-sha256-attendus` |

Une seule erreur = **arrêt**. On ne contourne pas (`--force`, `--ignore`, édition du fichier d'empreintes) : on retélécharge le fichier depuis le poste Windows.

## 4. Checkpoint Hyper-V avant chaque changement

Avant **toute** modification (paquet, configuration, unité systemd, ressources de VM, règle de pare-feu) :

```powershell
# PowerShell en administrateur, sur l'hôte Hyper-V
$vm = "loki01"     # ou kafka01, otel-gw, mimir01, tempo01, grafana01, ELK, DC
Checkpoint-VM -Name $vm -SnapshotName "avant-<objet>-$(Get-Date -Format yyyyMMdd-HHmm)"
Get-VMSnapshot -VMName $vm | Sort-Object CreationTime | Select-Object -Last 3 Name, CreationTime
```

- Les checkpoints automatiques sont désactivés sur les six nouvelles VM (`AutomaticCheckpointsEnabled $false`, posé par `Creer-VM-LGTM-Kafka.ps1`) : le checkpoint est **manuel et explicite**.
- Un changement qui touche plusieurs VM (par exemple un nouveau sujet Kafka et son consommateur) prend un checkpoint de **chaque** VM touchée, avec le même nom.
- **kafka01** : prendre le checkpoint de préférence service arrêté (`systemctl stop kafka`) ; un checkpoint « à chaud » restauré ramène Kafka en arrière alors que les consommateurs ont déjà validé des offsets plus récents (voir §9).
- Un checkpoint n'est pas une sauvegarde : il dépend du disque de la VM. Garder au plus 3 à 5 checkpoints par VM (les disques différentiels consomment l'espace de l'hôte) et faire un `Export-VM` hebdomadaire (voir [08_Exploitation_supervision.md](08_Exploitation_supervision.md)).

## 5. Secrets

- **Aucun secret** dans un fichier versionné, un dépôt git, une capture d'écran, un ticket, un courriel, un document de ce dossier ou le journal des changements.
- Les clés API Elasticsearch sont saisies **sans écho** (`read -rsp`) et stockées uniquement dans :
  - sur **otel-gw** : `/etc/otelcol-contrib/otelcol-contrib.conf` (`root:root`, `0600`) sous la forme `ES_OTEL_API_KEY=` suivi de la valeur (jamais recopiée ailleurs) ; clé nommée `otelcol-otel-gw` ;
  - sur **grafana01** : `/etc/grafana/es-grafana-apikey` (`root:grafana`, `0640`) ; clé nommée `grafana-grafana01`.
- Aucune clé ES sur kafka01, mimir01, loki01 ni tempo01. Les messages Kafka ne contiennent pas de secret, mais contiennent les **journaux** (données potentiellement sensibles) : ne pas copier `/var/lib/kafka/data` hors du lab.
- **Masquage** : dans toute trace écrite, la variable apparaît sans valeur, `ES_OTEL_API_KEY=`. Ne jamais lancer `cat`, `systemctl show -p Environment`, `env` ou `ps e` sur un service qui porte une clé quand l'écran est partagé ou enregistré.
- Pour vérifier qu'une clé est présente : `grep -c '^ES_OTEL_API_KEY=' /etc/otelcol-contrib/otelcol-contrib.conf` (renvoie un nombre, jamais la valeur).
- Clés API ES : **`"expiration": "90d"`** obligatoire, rôle limité (**moindre privilège**) :
  - écriture (otelcol) : `monitor` + `auto_configure`, `create_doc` sur `logs-*` ;
  - lecture (Grafana) : `read`, `view_index_metadata` sur `logs-*` ;
  - jamais de clé `superuser`, jamais la clé ou le mot de passe du compte `elastic`.
- Les sauvegardes de configuration **excluent** les fichiers de secrets (commande au §4 de [08_Exploitation_supervision.md](08_Exploitation_supervision.md)).
- Mot de passe Grafana `admin` changé à la première connexion ; il n'est écrit nulle part.

## 6. Limites mémoire et disque

Chaque service porte une limite ; on ne la supprime pas pour « régler » un problème. La somme des `MemoryMax` d'une VM reste sous sa RAM **minimale** ([05_Dimensionnement_infra.md](05_Dimensionnement_infra.md), §3).

| VM | Service | `MemoryHigh` | `MemoryMax` | Limite interne | Autre |
|---|---|---|---|---|---|
| kafka01 | `kafka` | 1536M | 1792M | tas Java `-Xms1g -Xmx1g` | `LimitNOFILE=100000` |
| otel-gw | `otelcol-contrib` (passerelle + `elk-es`) | 690M | 768M | `GOMEMLIMIT=600MiB` | `memory_limiter` 600 / 120 MiB, **en premier processeur** |
| otel-gw | `prometheus` (agent) | 230M | 256M | `GOMEMLIMIT=200MiB` | – |
| mimir01 | `mimir` | 1380M | 1536M | `GOMEMLIMIT=1200MiB` | `max_global_series_per_user: 150000`, `ingestion_rate: 20000` |
| loki01 | `loki` | 920M | 1024M | `GOMEMLIMIT=800MiB` | – |
| tempo01 | `tempo` | 920M | 1024M | `GOMEMLIMIT=800MiB` | – |
| mimir01, loki01, tempo01 | `otelcol-contrib` (consommateur) | 345M | 384M | `GOMEMLIMIT=300MiB` | `memory_limiter` 300 / 60 MiB |
| grafana01 | `grafana-server` | 690M | 768M | `GOMEMLIMIT=600MiB` | – |
| les 6 | `node_exporter` | – | 64M | – | – |
| ELK | `otelcol-contrib` (agent) | 288M | 320M | `GOMEMLIMIT=256MiB` | `memory_limiter` 200 / 40 MiB |
| DC | `otelcol-contrib` (agent) | – | – | `GOMEMLIMIT=200MiB` | `memory_limiter` 200 / 40 MiB |

Disque et rétention (plafonds) :

| Données | VM | Plafond |
|---|---|---|
| Kafka, par sujet | kafka01 | `retention.ms=86400000` (24 h) **et** `retention.bytes` par partition : 2 Gio (`otlp_logs`), 1 Gio (`otlp_metrics`, `otlp_spans`) ; 3 partitions ; `segment.bytes=268435456` |
| Kafka, total théorique | kafka01 | 12 Gio de messages + segments actifs (≈ 2,25 Gio) sur un disque de 40 Go ; alerte `KafkaDisqueFaible` < 20 % libre |
| Kafka, taille d'un message | kafka01 / otel-gw | `max.message.bytes=1048588` (sujet) ; `producer.max_message_bytes` ≤ 1 000 000 (passerelle) |
| Journaux de Kafka | kafka01 | fichiers de `/var/log/kafka` supprimés après 7 jours (`/etc/tmpfiles.d/kafka.conf`) ; GC 5 × 10 Mo |
| Mimir | mimir01 | 15 jours (`compactor_blocks_retention_period: 15d`) |
| Loki | loki01 | 7 jours (`retention_period: 168h`, `retention_enabled: true`) |
| Tempo | tempo01 | 72 h (`overrides.defaults.compaction.block_retention: 72h`) |
| Journal systemd | chaque VM | `SystemMaxUse=300M` |
| Disques | chaque VM | taille du §4.1 du runbook ; contrôle manuel si `/` dépasse 80 % (`df -h /`, ou `node_filesystem_avail_bytes` dans Grafana) ; alerte `KafkaDisqueFaible` pour kafka01 |

Toute hausse d'une limite ou d'une rétention se justifie dans le journal des changements (mesure `systemd-cgtop -m`, `du -sh` ou `kafka-log-dirs.sh` à l'appui), et reste compatible avec le budget de la VM ([05_Dimensionnement_infra.md](05_Dimensionnement_infra.md)).

## 6 bis. Kafka

| Règle | Détail |
|---|---|
| **Pas de création automatique de sujet** | `auto.create.topics.enable=false` sur le broker **et** `allow_auto_topic_creation: false` sur l'exportateur de la passerelle. Ne jamais réactiver : un sujet mal nommé serait créé avec les valeurs par défaut, **sans plafond de disque**. |
| **Sujets créés uniquement par `creer-sujets-kafka.sh`** | Le script pose partitions, `retention.ms`, `retention.bytes`, `segment.bytes`, `max.message.bytes`. Un nouveau sujet = modifier le script (avec plafonds) puis l'exécuter ; pas de `kafka-topics.sh --create` à la main sans ces options. |
| **Jamais `kafka-storage.sh format` sur des données existantes** | Le formatage n'est fait qu'une fois, à l'installation. L'option `--ignore-formatted` n'est **pas** un moyen de « réparer ». Reformater = perdre tous les messages, offsets et métadonnées. |
| **Pas de suppression de groupe ni de remise à zéro d'offsets à la légère** | Toujours : consommateur arrêté, `--dry-run` d'abord, décision écrite dans le journal. `--to-latest` **perd** les messages en attente ; `--to-earliest` **duplique** jusqu'à 24 h de données. Supprimer `elk-es` uniquement en phase 6. |
| **L'alerte de retard reste en place** | Le groupe de règles `lab-kafka` (`KafkaRetardConsommateur`, `KafkaConsommateurAbsent`, `KafkaMetriquesAbsentes`, `KafkaDisqueFaible`) et le récepteur `kafka_metrics` d'otel-gw ne sont jamais retirés ni mis en sourdine durablement. |
| **PLAINTEXT 9092 uniquement depuis les VM listées** | nftables de kafka01 : 9092 accepté seulement depuis otel-gw, mimir01, loki01, tempo01 ; 9093 (contrôleur) sur `127.0.0.1` seulement. Pas de NAT, pas d'exposition hors du vSwitch. |
| **Un seul producteur** | Seule la passerelle otel-gw écrit dans `otlp_*` ; les outils console ne servent qu'aux tests (`kafka-console-producer.sh` interdit sur ces sujets hors exercice noté au journal). |
| **Un groupe par destination** | Nommage `lgtm-<stockage>` ou `elk-es` ; deux consommateurs différents ne partagent jamais un `group_id`. |
| **Mises à jour** | Kafka et Java changent par le lien `current` (retour arrière = ancien lien) ; `metadata.version` n'est augmentée qu'après validation de la nouvelle version (irréversible). |

## 6 ter. Ressources des VM

- **Ne jamais modifier les ressources de DC et ELK** (DC : 1 vCPU, 2 Go, dynamique 1–2 Go ; ELK : 2 vCPU, 3 Go, dynamique 2–4 Go). Aucun `Set-VM`, `Set-VMMemory` ni `Set-VMProcessor` sur ces deux VM. Si ElastAlert 2 ou les agents manquent de mémoire sur ELK, c'est un **point de vigilance** à remonter, pas un changement.
- Les six nouvelles VM se partagent le reste du budget de l'hôte ; garder **au moins 6 Go** pour Windows quand toutes les VM sont à leur maximum ([05_Dimensionnement_infra.md](05_Dimensionnement_infra.md)).

## 7. Valider avant de redémarrer

Aucun `systemctl restart` ou `reload` sans validation réussie de la configuration **avec le binaire installé**. Les commandes Mimir, mimirtool, Loki, Tempo, promtool et otelcol-contrib ont été testées le 28 oct. 2026 : elles renvoient un code non nul sur une clé inconnue ou une erreur de syntaxe.

| Outil | Commande de validation |
|---|---|
| Mimir | `mimir --config.file=/etc/mimir/config.yml -print.config >/dev/null` |
| Alertmanager de Mimir | `mimirtool alertmanager verify /etc/mimir/alertmanager-fallback.yml` (ou le fichier à charger) |
| Règles Mimir | `mimirtool rules lint <fichier>` |
| Loki | `loki -config.file=/etc/loki/config.yml -verify-config` |
| Tempo | `tempo -config.file=/etc/tempo/config.yml -config.verify=true` |
| Prometheus (agent) | `promtool check config --agent /etc/prometheus/prometheus.yml` |
| otelcol-contrib | `otelcol-contrib validate --config=/etc/otelcol-contrib/config.yaml` |
| otelcol-contrib (DC) | `& "<chemin>\otelcol-contrib.exe" validate --config="<chemin>\config.yaml"` (non testé hors Windows) |
| Grafana | pas de validateur : `systemctl restart grafana-server` puis `journalctl -u grafana-server -n 50 --no-pager` et `wget -qO- http://127.0.0.1:3000/api/health` |
| Kafka (`server.properties`) | pas de validateur : `systemctl restart kafka`, `journalctl -u kafka -n 50 --no-pager`, puis `kafka-metadata-quorum.sh --bootstrap-server 127.0.0.1:9092 describe --status` |
| Sujets Kafka | `kafka-topics.sh --bootstrap-server 127.0.0.1:9092 --describe --topic <sujet>` et `kafka-configs.sh … --describe` après le script |
| Unités systemd | `systemd-analyze verify /etc/systemd/system/<unité>.service` puis `systemctl daemon-reload` (testé hors PID 1 : pas de vérification complète des dépendances) |
| nftables | `nft -c -f /etc/nftables.conf` (testé sur l'exemple de loki01) |

Après le redémarrage : `systemctl is-active <service>`, `journalctl -u <service> -n 50 --no-pager`, et le contrôle de santé du service ([08_Exploitation_supervision.md](08_Exploitation_supervision.md), §1).

## 8. Procédure de retour arrière

Du plus léger au plus lourd ; s'arrêter au premier niveau qui rétablit le service :

| Niveau | Quand | Action |
|---|---|---|
| 1. Configuration | une modification de fichier casse un service | restaurer la copie `fichier.AAAAMMJJ-HHMM` faite avant la modification (voir §10), valider (§7), redémarrer |
| 2. Service | un composant pose problème | `systemctl disable --now <service>` ; la façade continue pour les autres signaux |
| 3. Routage Strangler Fig | la nouvelle destination est en défaut | arrêter le consommateur de la VM concernée (`systemctl stop otelcol-contrib`) : ses messages attendent 24 h dans Kafka ; ou retirer le pipeline de la passerelle, `otelcol-contrib validate`, redémarrer. ELK (`elk-es`) reste la référence jusqu'à la phase 6 |
| 4. Paquet | une mise à jour échoue | `dpkg -i` de l'ancien `.deb` conservé dans `/opt/lgtm-bundle` (vérifié), valider, redémarrer |
| 5. VM | état incertain ou plusieurs composants touchés | `Restore-VMCheckpoint -VMName <vm> -Name <checkpoint> -Confirm:$false`, puis `Start-VM`. Pour **kafka01** : arrêter d'abord les consommateurs, puis après restauration contrôler les groupes (`--describe`) ; des offsets validés plus loin que la fin restaurée sont possibles (comportement de reprise selon `auto.offset.reset`, non testé) |
| 6. Projet | abandon | runbook §9 (désinstallation), révocation des clés API ES, `Start-VM AppDynamics` si nécessaire |

Après tout retour arrière : noter la cause et le niveau utilisé dans le journal des changements.

## 9. À ne jamais faire

| Interdit | Pourquoi |
|---|---|
| `elastalert-create-index --recreate` (ou supprimer les index `elastalert_status*`) | supprime les index de suivi d'ElastAlert 2 : historique, silences et état des règles perdus |
| Exposer Elasticsearch (mono-nœud) hors du vSwitch du lab (NAT, redirection de port, `network.host` public) | un seul nœud, aucune redondance ; données et API d'administration exposées |
| Installer Docker, Podman ou une image de conteneur | contraire à ADR-001 |
| `apt update` / `apt install` vers Internet, `curl … \| sh`, `grafana cli plugins install` | contraire au mode hors ligne ; contenu non vérifié |
| Installer un fichier dont une vérification a échoué, ou modifier `lgtm-sha256-attendus` pour « faire passer » un fichier | casse la chaîne de confiance |
| `dpkg --force-all`, `--force-depends` | dépendances incohérentes, retour arrière difficile |
| Afficher, copier ou capturer la valeur d'une clé API ; la mettre dans un YAML, un ticket ou git | fuite de secret |
| Créer une clé API ES sans expiration ou avec le rôle `superuser` | moindre privilège, durée de vie limitée |
| Retirer `memory_limiter` d'otelcol, ou le placer après `batch` | risque d'OOM et de perte de toutes les données en mémoire |
| Supprimer `MemoryMax` / `GOMEMLIMIT` d'un service | un service peut affamer toute la VM |
| Redémarrer un service sans validation de sa configuration | panne évitable |
| Supprimer `/var/lib/mimir`, `/var/lib/loki` ou `/var/tempo` service démarré | corruption des blocs et du WAL |
| Ouvrir les ports HTTP/gRPC de Mimir, Loki, Tempo, de la passerelle ou de Kafka au-delà des VM listées au pare-feu (runbook §5.7), ou désactiver nftables | ces API n'ont pas d'authentification (`multitenancy_enabled: false`, Kafka en PLAINTEXT) : elles ne sont protégées que par le filtrage |
| Lier `memberlist` ou le contrôleur Kafka (9093) à autre chose que `127.0.0.1` | mono-nœud : aucune raison de les exposer |
| `kafka-storage.sh format` sur kafka01 déjà en service, supprimer `/var/lib/kafka/data` | perte de tous les messages, offsets et de l'identité du cluster |
| `auto.create.topics.enable=true`, `allow_auto_topic_creation: true`, sujet créé sans plafonds | disque de kafka01 non borné |
| `kafka-consumer-groups.sh --reset-offsets --execute` sans `--dry-run` ou consommateur démarré ; `--delete` d'un groupe hors phase 6 | perte ou duplication de données ; Kafka refuse de toute façon si le groupe a des membres actifs |
| Retirer le groupe de règles `lab-kafka` ou le récepteur `kafka_metrics` | plus d'alerte de retard : un stockage en panne passerait inaperçu jusqu'à expiration des messages |
| Modifier vCPU ou mémoire de DC ou ELK | contrainte du lab : ces VM restent aux valeurs du plan |
| Ajouter un processeur `batch` ou une file d'envoi aux consommateurs | les offsets seraient validés avant l'écriture : perte possible (ADR-009) |
| Activer `multitenancy_enabled` sans mettre à jour Prometheus, otelcol, Tempo, Loki et Grafana | toutes les écritures et lectures échouent (en-tête `X-Scope-OrgID` manquant) |
| Retirer le pipeline `logs/elk` (exportateur `elasticsearch`) avant la fin des critères de la phase 3 | perte de la comparaison et du retour arrière |
| Changer plusieurs composants dans le même changement | impossible d'identifier la cause d'une panne |

## 10. Journal des changements

Chaque changement ajoute une ligne **avant** l'intervention (statut « prévu ») et la complète **après** (statut « fait » ou « annulé »). Emplacement conseillé : `/var/log/lgtm-changements.md` sur otel-gw (copie dans le dossier du lab) ; une seule ligne même si le changement touche plusieurs VM. **Aucun secret** : écrire `ES_OTEL_API_KEY=` sans valeur.

| Date (heure de Toronto) | Auteur | VM | Composant | Changement | Checkpoint | Validation | Résultat | Retour arrière |
|---|---|---|---|---|---|---|---|---|
| 2026-10-28 15:00 (exemple) | Karim | kafka01 | sujet `otlp_logs` | `retention.bytes` 2 Gio → 3 Gio par partition (`kafka-configs.sh --alter`) | `avant-kafka-retention-20261028-1500` | `kafka-configs.sh --describe` OK, `df -h /` 35 % | fait | `--alter` retour à 2147483648 |
| 2026-10-28 16:00 (exemple) | Karim | loki01, kafka01 | loki | `retention_period` 168h → 240h | `avant-loki-retention-20261028-1600` | `loki -verify-config` OK | fait | niveau 1 si disque > 80 % |
| AAAA-MM-JJ HH:MM | | | | | | | prévu / fait / annulé | |

Copie de sécurité d'un fichier avant modification :

```bash
f=/etc/loki/config.yml; cp -a "$f" "$f.$(date +%Y%m%d-%H%M)"
```

## 11. Liste de contrôle avant changement

- [ ] Le changement est décrit dans le journal (§10), avec un seul composant.
- [ ] Les notes de version (pour une mise à jour) ont été lues.
- [ ] Les nouveaux fichiers viennent du lot hors ligne et `verifier-lgtm.sh` (ou l'équivalent) est au vert (§3).
- [ ] Checkpoint Hyper-V pris pour chaque VM touchée (§4) ; jamais de changement de ressources de DC ou ELK (§6 ter).
- [ ] Copie de sécurité du fichier modifié (§10).
- [ ] Aucun secret dans les fichiers, commandes, captures ou notes (§5).
- [ ] Les limites mémoire et les rétentions (Kafka compris) restent dans le budget (§6).
- [ ] Pour Kafka : pas de création automatique de sujet, pas de formatage, pas de remise à zéro d'offsets sans `--dry-run` (§6 bis).
- [ ] La validation de la configuration a réussi (§7).
- [ ] Le niveau de retour arrière est identifié (§8).
- [ ] Le changement ne figure pas dans la liste des interdits (§9).
- [ ] **Variante DNS du DC** : `verifier-dns.sh` affiche `RÉSULTAT DNS : conforme.` avant et après le changement ; aucun secours `/etc/hosts` actif ; une adresse ou un nom ne change que dans `lab-params.psd1` puis sur le DC, jamais à la main dans un fichier rendu ([09](09_Variante_DNS_DC.md)).
- [ ] Après le changement : `systemctl is-active`, journal du service, contrôles de santé, `up` dans Mimir, **retard des groupes Kafka proche de 0**.
