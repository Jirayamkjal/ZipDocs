# 07 – Plan de migration Strangler Fig

> Reprend les phases 0 à 6 de `../Plan_integration_observabilite_lab.md` (section 3), avec les choix de ce dossier : **Kafka** entre l'ingestion et les stockages, **une VM par service**, **Mimir** pour les métriques, **Alertmanager de Mimir**. Les dates du plan sont indicatives.

## 1. Principe

Le motif Strangler Fig remplace un système par morceaux : on place une **façade** devant l'ancien système, on construit la nouvelle capacité à côté, on bascule les consommateurs, puis on retire l'ancienne capacité. Ici :

- façade d'**entrée** : la passerelle **otel-gw** (OTLP 4317/4318), qui écrit dans Kafka ;
- **point de bascule** : les **groupes de consommateurs Kafka**. ELK (`elk-es`) et Loki (`lgtm-loki`) lisent le **même** sujet `otlp_logs`, chacun à son rythme. Ajouter une destination = ajouter un groupe ; retirer ELK = arrêter et supprimer `elk-es` ;
- façade de **consultation** : Grafana (grafana01), avec Elasticsearch comme source transitoire.

```mermaid
flowchart LR
  P0["0. Préparation<br/>lot vérifié, 6 VM créées,<br/>DC et ELK inchangées"] --> P1["1. Façades<br/>kafka01, otel-gw, stockages,<br/>Grafana"]
  P1 --> P2["2. Métriques<br/>exporteurs → Prometheus agent → Mimir"]
  P2 --> P3["3. Journaux<br/>otlp_logs lu par lgtm-loki ET elk-es"]
  P3 --> P4["4. Traces<br/>otlp_spans → Tempo, remplace AppD"]
  P4 --> P5["5. Alertes<br/>ruler + Alertmanager Mimir"]
  P5 --> P6["6. Retrait<br/>groupe elk-es supprimé,<br/>ELK et AppD éteintes"]
```

## 2. Boucle de décision à chaque phase

```mermaid
flowchart TD
  A[Checkpoint Hyper-V des VM touchées<br/>et entrée au journal des changements] --> B[Activer la nouvelle capacité<br/>nouveau groupe de consommateurs ou pipeline]
  B --> C{Critère de passage atteint ?<br/>dont retard des groupes proche de 0}
  C -- Oui --> D[Basculer la consultation<br/>vers Grafana]
  D --> E[Arrêter l'ancienne capacité<br/>ou son groupe]
  E --> F[Phase suivante]
  C -- Non --> G{Corrigible rapidement ?}
  G -- Oui --> B
  G -- Non --> H[Retour arrière :<br/>arrêter le consommateur, retirer le pipeline,<br/>ou restaurer le checkpoint]
  H --> A
```

## 3. Détail des phases

| Phase | Capacité remplacée | Actions (renvoi au runbook) | Critère de passage (vérifiable) | Retour arrière |
|---|---|---|---|---|
| **0. Préparation** | – | Lot téléchargé et vérifié (§3) ; checkpoints de DC et ELK **sans modifier leurs ressources** ; création des six VM (§4.3) ; Debian, adresses, `/etc/hosts` (§4.4) ; distribution (§3.9). | `verifier-lgtm.sh` sans erreur ; chaque VM a ses lignes `OK` ; `Get-VM` conforme au §4.1 du runbook, **DC et ELK aux valeurs du plan**. | Supprimer les nouvelles VM ; DC et ELK n'ont pas changé. |
| **1. Façades** | Point d'entrée, point de consultation | kafka01 (§5.1) : formatage KRaft, sujets créés ; mimir01, loki01, tempo01 avec consommateurs (§5.2–5.4) ; otel-gw (§5.5) ; grafana01 (§5.6) ; test de bout en bout (§7.1–7.2). | Tous les services `active` ; quatre groupes visibles (`kafka-consumer-groups.sh --list`) ; test du §7 réussi (journal, métrique, trace retrouvés) ; sources Grafana « OK ». | `systemctl disable --now` sur les nouvelles VM ; rien n'a changé sur ELK. |
| **2. Métriques** | Métriques système | `node_exporter` sur ELK (§6.1) et sur chaque nouvelle VM ; `windows_exporter` sur le DC (§6.2) ; tableaux de métriques dans Grafana. | `up{job="node"}` (7 VM) et `up{job="windows"}` = 1 dans Mimir pendant 24 h ; `kafka_consumer_group_lag` présent pour les 4 groupes. | Arrêter les exporteurs ; tableaux Kibana inchangés. |
| **3. Journaux** | Collecte et recherche de journaux | Agents `otelcol-contrib` sur ELK (journald) et le DC vers otel-gw ; **double consommation** de `otlp_logs` par `lgtm-loki` et `elk-es` ; comparaison KQL / LogQL ; exercice de panne (§7.3) ; puis arrêt de Logstash. | Pendant 2 à 3 jours : retard de `lgtm-loki` et `elk-es` proche de 0 (pas d'alerte `KafkaRetardConsommateur`), mêmes volumes dans Loki et ES (écart expliqué), requêtes de démo équivalentes ; panne de Loki rattrapée sans perte. | `systemctl enable --now logstash` ; arrêter le consommateur de loki01 (`systemctl stop otelcol-contrib`) : ELK continue via `elk-es`. |
| **4. Traces** | APM (AppDynamics) | Application de démo instrumentée (OTel .NET ou Java), OTLP vers otel-gw ; `otlp_spans` → `lgtm-tempo` → Tempo ; corrélations traces ↔ journaux ↔ métriques. | Une transaction se suit de bout en bout dans Grafana (Tempo → Loki → Mimir) ; carte des services affichée ; retard de `lgtm-tempo` proche de 0. | `Start-VM AppDynamics`. |
| **5. Alertes** | Alertes Kibana / ElastAlert 2 | Règles de métriques dans le *ruler* de Mimir (`lab-sante`, `lab-kafka`, puis règles métier), règles de journaux dans le *ruler* de Loki, Alertmanager vers le webhook ITSM. | `LabWatchdog` arrive au récepteur ; `CibleInjoignable` se déclenche quand on arrête un exporteur ; `KafkaConsommateurAbsent` quand on arrête un consommateur plus de 5 min. | Garder ElastAlert 2 en parallèle ; recharger `lab-null`. |
| **6. Retrait** | Ancien système | Retirer le pipeline `logs/elk`, le récepteur `kafka/elk` et l'exportateur `elasticsearch` d'otel-gw ; supprimer le groupe `elk-es` ; révoquer les clés API ES ; ES en lecture seule pendant l'observation, puis éteindre ELK ; exporter puis supprimer AppDynamics. | Plus aucune consultation de Kibana pendant la période d'observation ; aucune alerte manquée par rapport à ElastAlert 2. | Rallumer ELK ; rétablir le pipeline `logs/elk` (nouvelle clé API) : un **nouveau** groupe `elk-es` relit au plus 24 h (`initial_offset: earliest`). |

## 4. Routage par phase

```mermaid
flowchart LR
  subgraph F1[Phases 0-1]
    S1[Sources] --> L1[Logstash] --> E1[(ES)] --> K1[Kibana]
    E1 --> G1[Grafana]
  end
  subgraph F3[Phases 2-5 : coexistence]
    S3[Sources] --> C3[otel-gw]
    C3 --> KF[(Kafka<br/>otlp_*)]
    KF -- lgtm-loki --> L3[(Loki)]
    KF -- elk-es --> E3[(ES)]
    KF -- lgtm-tempo --> T3[(Tempo)]
    KF -- lgtm-mimir --> M3[(Mimir)]
    X3[Exporteurs] --> P3[Prometheus agent] --> M3
    E3 --> G3[Grafana]
    M3 --> G3
    L3 --> G3
    T3 --> G3
  end
  subgraph F6[Phase 6 : cible]
    S6[Sources] --> C6[otel-gw] --> KF6[(Kafka)]
    KF6 -- lgtm-loki --> L6[(Loki)]
    KF6 -- lgtm-tempo --> T6[(Tempo)]
    KF6 -- lgtm-mimir --> M6[(Mimir)]
    X6[Exporteurs] --> P6[Prometheus agent] --> M6
    M6 --> G6[Grafana]
    L6 --> G6
    T6 --> G6
    M6 --> A6[Alertmanager Mimir] --> I6[ITSM]
  end
  F1 ==> F3 ==> F6
```

## 5. Commandes de contrôle des critères

```bash
# Phase 1 (kafka01) : sujets et groupes
kafka-topics.sh --bootstrap-server 127.0.0.1:9092 --list
kafka-consumer-groups.sh --bootstrap-server 127.0.0.1:9092 --list           # lgtm-mimir, lgtm-loki, lgtm-tempo, elk-es

# Phase 2 (mimir01) : cibles scrapées
wget -qO- 'http://127.0.0.1:9009/prometheus/api/v1/query?query=up' | tr ',' '\n' | grep -E '"job"|"vm"|"value"'

# Phase 3 (kafka01) : les deux groupes de otlp_logs à jour
kafka-consumer-groups.sh --bootstrap-server 127.0.0.1:9092 --describe --group lgtm-loki
kafka-consumer-groups.sh --bootstrap-server 127.0.0.1:9092 --describe --group elk-es
# Phase 3 (mimir01) : retard par groupe dans le temps (aussi dans Grafana)
wget -qO- 'http://127.0.0.1:9009/prometheus/api/v1/query?query=sum%20by%20(group)(kafka_consumer_group_lag)'; echo
# Phase 3 (loki01) : présence des journaux de chaque source
wget -qO- 'http://127.0.0.1:3100/loki/api/v1/label/service_namespace/values'   # attendu : elk, dc

# Phase 5 (mimir01) : alertes actives
wget -qO- http://127.0.0.1:9009/alertmanager/api/v2/alerts | tr ',' '\n' | grep alertname

# Phase 6 (kafka01) : suppression du groupe ELK, consommateur déjà retiré d'otel-gw
kafka-consumer-groups.sh --bootstrap-server 127.0.0.1:9092 --describe --group elk-es   # attendu : has no active members
kafka-consumer-groups.sh --bootstrap-server 127.0.0.1:9092 --delete --group elk-es
```

> `kafka-consumer-groups.sh --delete` refuse un groupe qui a encore des membres actifs : retirer d'abord le pipeline `logs/elk` et redémarrer otel-gw. Comportement documenté par Kafka, non testé dans ce lab.

## 6. Ressources par phase

| Phase | VM allumées | vCPU | RAM de démarrage |
|---|---|---|---|
| 0 | DC, ELK (+ installation des nouvelles VM) | 3 | 5 Go |
| 1 à 5 | DC, ELK, kafka01, otel-gw, mimir01, loki01, tempo01, grafana01 | 13 | 19 Go |
| 6 (après retrait) | DC, kafka01, otel-gw, mimir01, loki01, tempo01, grafana01 | 11 | 16 Go |

## 7. Retour arrière global

1. **Niveau consommateur** : arrêter le consommateur d'un stockage (`systemctl stop otelcol-contrib` sur la VM) ; ses messages attendent 24 h dans Kafka.
2. **Niveau routage** : retirer un pipeline de la passerelle (par exemple `logs/elk`), valider (`otelcol-contrib validate --config=/etc/otelcol-contrib/config.yaml`), redémarrer.
3. **Niveau service ou VM** : `systemctl disable --now <service>`, ou `Restore-VMCheckpoint` du checkpoint pris avant la phase ([GUARDRAILS.md](GUARDRAILS.md), §8).
4. **Désinstallation complète** : runbook §9 ; DC et ELK n'ont pas été modifiés (seulement leurs agents).
