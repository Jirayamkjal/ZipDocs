# 06 – Sécurité

> Périmètre : lab de démonstration sur un vSwitch Hyper-V interne, sans accès Internet pour les VM Linux. Les mesures ci-dessous sont celles du runbook ; les compléments marqués **(non testé)** sont des recommandations qui n'ont pas été jouées. Règles obligatoires : [GUARDRAILS.md](GUARDRAILS.md).

## 1. Principes

1. **Aucun secret dans un fichier versionné, une capture d'écran, un ticket ou un document** (y compris ce dossier). Les valeurs de clé sont saisies **sans écho** (`read -rsp`) et ne sont jamais affichées (`grep -c` pour vérifier leur présence).
2. **Moindre privilège** : un utilisateur système par service, des clés API limitées à leur usage ; les API d'écriture des stockages restent sur `127.0.0.1` ; les ports exposés sur le réseau du lab sont filtrés par adresse source (nftables).
3. **Chaîne d'approvisionnement vérifiée** : aucun paquet n'est installé sans contrôle d'empreinte et de signature (ADR-002).
4. **Aucun appel sortant** depuis les VM Linux.

## 2. Comptes et utilisateurs système

| Utilisateur | Créé par | Service | Shell | Droits particuliers |
|---|---|---|---|---|
| `mimir` | paquet `mimir` | `mimir` | aucun (`nologin`) | propriétaire de `/var/lib/mimir` |
| `loki` | paquet `loki` (groupe `nogroup`) | `loki` | aucun | propriétaire de `/var/lib/loki` |
| `tempo` | paquet `tempo` | `tempo` | aucun | propriétaire de `/var/tempo` (0700) |
| `kafka` | runbook §5.1 (`useradd --system`, home `/var/lib/kafka`) | `kafka` (kafka01) | aucun (`nologin`) | propriétaire de `/var/lib/kafka` et `/var/log/kafka` ; lit `/etc/kafka` (groupe) ; **ne possède pas** `/opt/kafka` ni `/opt/java` (root) |
| `otelcol-contrib` | paquet `otelcol-contrib` | `otelcol-contrib` | aucun | sur ELK : membre de `systemd-journal` (lecture du journal) |
| `grafana` | paquet `grafana` | `grafana-server` | aucun | lit la clé API ES de lecture |
| `prometheus` | runbook §5.5 (`useradd --system`, otel-gw) | `prometheus` | aucun | propriétaire de `/var/lib/prometheus` |
| `node_exporter` | runbook §5.0 (chaque VM Linux) | `node_exporter` | aucun | – |
| `admin` | installation Debian | – | bash | `sudo` ; mot de passe root vide à l'installation (root verrouillé) |

Les unités `kafka`, `prometheus` et `node_exporter` (écrites par le runbook) ajoutent `NoNewPrivileges=true`, `ProtectSystem=full` et `ProtectHome=true` (unités vérifiées avec `systemd-analyze verify`).

## 3. Permissions des fichiers sensibles

| Fichier | Propriétaire | Mode | Contenu |
|---|---|---|---|
| `/etc/otelcol-contrib/otelcol-contrib.conf` (otel-gw) | root:root | **0600** | `ES_OTEL_API_KEY=` (clé d'écriture ES), lu par systemd (`EnvironmentFile`) |
| `/etc/otelcol-contrib/config.yaml` | root:otelcol-contrib | 0640 | référence `${env:ES_OTEL_API_KEY}`, jamais la valeur |
| `/etc/grafana/es-grafana-apikey` (grafana01) | root:grafana | 0640 | clé de lecture ES |
| `/etc/grafana/provisioning/datasources/lgtm.yaml` | root:grafana | 0640 | `$__file{...}`, jamais la valeur |
| `/etc/mimir/config.yml`, `alertmanager-fallback.yml` | root:mimir | 0640 | aucune donnée secrète (mais futurs webhooks ITSM) |
| `/etc/prometheus/prometheus.yml` | root:prometheus | 0640 | aucune donnée secrète |
| `/etc/loki/config.yml`, `/etc/tempo/config.yml` | root:root | 0644 | aucune donnée secrète |
| `/etc/otelcol-contrib/es-http-ca.crt`, `/etc/grafana/es-http-ca.crt` | root:(groupe du service) | 0644 | certificat CA public (pas un secret) |
| `/etc/kafka/server.properties`, `/etc/kafka/cluster-id` (kafka01) | root:kafka | 0640 | aucune donnée secrète (identifiant du cluster) |
| `/var/lib/kafka/data` (kafka01) | kafka:kafka | 0750 | **contenu des messages** : journaux applicatifs, attributs ; à traiter comme les données d'Elasticsearch |
| `/opt/lgtm-bundle` (otel-gw) | root | `go-w` | lot vérifié, en lecture seule pour les autres |

Contrôle rapide (n'affiche aucune valeur) :

```bash
stat -c '%U:%G %a %n' /etc/otelcol-contrib/otelcol-contrib.conf /etc/grafana/es-grafana-apikey /etc/grafana/provisioning/datasources/lgtm.yaml
grep -c '^ES_OTEL_API_KEY=' /etc/otelcol-contrib/otelcol-contrib.conf   # attendu : 1
```

## 4. Clés API Elasticsearch

| Nom | Utilisée par | Privilèges (rôle limité) | Expiration | Stockage |
|---|---|---|---|---|
| `otelcol-otel-gw` | consommateur `elk-es` (otel-gw) | cluster `monitor` ; index `logs-*` : `auto_configure`, `create_doc` | **`"expiration": "90d"`** | `ES_OTEL_API_KEY=` dans `otelcol-contrib.conf` (0600) |
| `grafana-grafana01` | datasource Grafana transitoire | index `logs-*` : `read`, `view_index_metadata` | **`"expiration": "90d"`** | `/etc/grafana/es-grafana-apikey` (0640) |

Règles :

- Création dans Kibana > Dev Tools avec un compte administrateur ; **pas de capture d'écran de la réponse** ; seule la valeur `encoded` est copiée, puis saisie sans écho.
- Dans toute trace écrite (ticket, journal de changement, capture), la variable apparaît **masquée** : `ES_OTEL_API_KEY=`.
- **Rotation** avant 90 jours : créer une nouvelle clé, la saisir, redémarrer le service, vérifier, puis révoquer l'ancienne.
- **Révocation** à la fin de la phase 6 (ou en cas de doute) : `DELETE /_security/api_key` avec `{ "name": "otelcol-otel-gw" }` puis `{ "name": "grafana-grafana01" }`.
- Les privilèges exacts n'ont **pas été testés** contre Elasticsearch 9 (annexe A du runbook) : si ES renvoie `403`, ajouter le privilège manquant indiqué par le message, pas un rôle `superuser`.

Liste des clés existantes (n'affiche pas les valeurs) : `GET /_security/api_key?name=otelcol-otel-gw`.

## 5. Chiffrement (TLS)

| Flux | État dans le runbook | Commentaire |
|---|---|---|
| otel-gw et grafana01 → Elasticsearch :9200 | **TLS** vérifié par le CA HTTP d'ES (`ca_file`, `tlsCACert`) | Le nom utilisé (`elk.lab.local` est un exemple) doit figurer dans le SAN du certificat d'ES. |
| Agents → passerelle otel-gw :4317 | **sans TLS** (`tls.insecure: true`) | Réseau Hyper-V interne. |
| Clients → Kafka :9092 | **`PLAINTEXT`** : ni TLS ni authentification | Voir §7. |
| Grafana → Mimir, Loki, Tempo ; Prometheus → Mimir ; Tempo, Loki → Mimir | **HTTP** sans authentification | Filtrage nftables par source. |
| Navigateur → Grafana :3000 | **HTTP** | Mot de passe `admin` changé à la première connexion. |
| Services internes (127.0.0.1) | sans TLS | Boucle locale uniquement. |
| Transferts Windows → Linux | SSH | – |

**Option TLS pour OTLP et Grafana (non testé).** Avec une petite autorité de certification de lab créée sur otel-gw par `openssl` (présence à vérifier : `dpkg -l openssl` ; sinon l'ajouter au lot hors ligne) :

- collecteur : `receivers.otlp.protocols.grpc.tls.cert_file` / `key_file` ; agents : `exporters.otlp_grpc/otel-gw.tls.ca_file` au lieu de `insecure: true` ([configuration TLS du Collector](https://github.com/open-telemetry/opentelemetry-collector/blob/main/config/configtls/README.md)) ;
- Grafana : `[server] protocol = https`, `cert_file`, `cert_key` ([configuration Grafana](https://grafana.com/docs/grafana/latest/setup-grafana/configure-grafana/)).

Clés privées en `0640 root:<groupe du service>` ; jamais dans le lot hors ligne ni dans git.

## 6. Grafana

- Compte initial `admin` / `admin` : **changé à la première connexion** (Grafana l'exige).
- Aucun appel sortant : `GF_ANALYTICS_REPORTING_ENABLED=false`, `GF_ANALYTICS_CHECK_FOR_UPDATES=false`, `GF_ANALYTICS_CHECK_FOR_PLUGIN_UPDATES=false`, `GF_NEWS_NEWS_FEED_ENABLED=false`, `GF_PLUGINS_PREINSTALL_DISABLED=true` (drop-in `offline.conf`).
- Datasources provisionnées ; les secrets sont lus par `$__file{}` et ne figurent pas dans le YAML.
- Créer des comptes nominatifs avec le rôle **Viewer** pour la consultation ; garder `admin` pour l'administration.

## 7. Réseau et Kafka

- **Exposés sur le réseau du lab :** 22 (SSH, toutes), 4317/4318 (otel-gw), **9092 (kafka01)**, 9009 (mimir01), 3100 (loki01), 3200 (tempo01), 3000 (grafana01), 8888 (consommateurs), 9100 (node_exporter). Tout le reste écoute sur `127.0.0.1`, dont le **contrôleur KRaft (9093)** ([03_Matrice_reseau_ports.md](03_Matrice_reseau_ports.md)).
- **Kafka sans authentification ni chiffrement (`PLAINTEXT`) — choix du lab, signalé :** toute machine qui joint 9092 peut lire tous les sujets (donc tous les journaux), produire de faux messages, créer des groupes ou en remettre les offsets à zéro. Mesures dans le lab : vSwitch interne sans Internet, **nftables** sur kafka01 (seules otel-gw, mimir01, loki01, tempo01 peuvent joindre 9092), création automatique des sujets désactivée.
- **Pour aller plus loin (non testé) :** écouteur `SASL_SSL` (TLS + SCRAM-SHA-512) et ACL Kafka (`StandardAuthorizer` en KRaft), un compte par client (passerelle en écriture, un compte en lecture par groupe) ; documentation : [sécurité Kafka 4.4](https://kafka.apache.org/44/security/). Les secrets SCRAM suivraient les mêmes règles que les clés API ES (fichier 0600, saisie sans écho).
- Mimir, Loki et Tempo : `multitenancy_enabled: false` / `auth_enabled: false` ; ports HTTP filtrés par source.
- Elasticsearch est **mono-nœud** : il ne doit **pas** être exposé hors du vSwitch du lab.
- Filtrage `nftables` : exemple vérifié avec `nft -c` (runbook §5.7), non appliqué sur une vraie VM.

## 8. Chaîne d'approvisionnement

| Contrôle | Où | Outil |
|---|---|---|
| Empreintes publiées par les projets | otel-gw | `sha256sum -c --strict` |
| Index APT Grafana signé (Grafana, Mimir, mimirtool, Loki, Tempo) | otel-gw | `sqv` + `gpg-full.key` (empreinte `B53AE77BADB630A683046005963FA27710458545`, expire le 22 août 2027) |
| Kafka 4.4.0 | otel-gw | `.sha512` + `sqv` avec `KEYS` (signataire `1817905E3B2708B11A24B88E9AFA6F66CC8C3534`) |
| Temurin 25.0.5+8 | otel-gw | `.sha256.txt` + `sqv` avec la clé Adoptium (`3B04D753C9050D9A5D343F39843C48A565F8F04B`) |
| Empreintes attendues du runbook | otel-gw, puis **chaque VM** après distribution, DC | `lgtm-sha256-attendus`, `Get-FileHash` |
| ISO Debian | ELK | `sqv` + clé `DF9B9C49EAA9298432589D76DA87E80D6294BE9B` |
| Manifeste du transfert | otel-gw | `MANIFEST-SHA256.txt` (détecte une altération pendant le transfert) |

**À surveiller :** la clé APT Grafana expire le **22 août 2027** ; la clé du signataire de Kafka 4.4.0 expire le **20 août 2028** (lu dans `KEYS`). `KEYS` vient du même serveur que l'archive : il protège d'un miroir altéré, pas d'une compromission d'Apache elle-même. Java (Temurin) n'est pas mis à jour par `apt` : suivre les versions trimestrielles d'Adoptium et refaire un lot.
