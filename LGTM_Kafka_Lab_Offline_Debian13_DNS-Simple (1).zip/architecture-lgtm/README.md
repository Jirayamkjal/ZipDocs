# Lab LGTM + Kafka hors ligne – Debian 13 sur Hyper-V (une VM par service)

## Objet

Ce dossier décrit l'architecture et l'exploitation de la pile d'observabilité **LGTM** du lab, dont l'ingestion passe par **Apache Kafka** :

- **L**oki pour les journaux, **G**rafana pour la consultation, **T**empo pour les traces, **M**imir pour les métriques ;
- **OpenTelemetry Collector contrib** comme passerelle (otel-gw) qui **produit** dans Kafka, et comme **consommateur** Kafka devant chaque stockage ;
- **Apache Kafka 4.4 en mode KRaft** (kafka01) comme **tampon** entre l'ingestion et les stockages, et comme support de la **double consommation ELK + Loki** (un groupe de consommateurs chacun) ;
- **une VM Debian 13 par service**, **sans accès Internet**, en **services systemd natifs** (pas de Docker) ;
- pour remplacer progressivement ELK et AppDynamics selon le plan **Strangler Fig** du lab.

La procédure pas à pas est dans le runbook ; ce dossier explique **pourquoi** et **comment exploiter**.

## Carte des documents

| Document | Pour qui / quand |
|---|---|
| [`../Runbook_LGTM_Kafka_Offline_Debian13_DNS-DC.md`](../Runbook_LGTM_Kafka_Offline_Debian13_DNS-DC.md) (+ `.docx`) | **Procédure, variante DNS du DC** : mêmes étapes, mais les noms sont résolus par le DNS intégré à AD du DC (A + PTR), toutes les configurations utilisent des FQDN, et toutes les valeurs du lab viennent d'un seul fichier de paramètres (`lab-params.psd1` → `/etc/lgtm/lab.env`). Décision : [09](09_Variante_DNS_DC.md) |
| [`../Runbook_LGTM_Kafka_Offline_Debian13.md`](../Runbook_LGTM_Kafka_Offline_Debian13.md) (+ `.docx`, schémas dans `../lgtm-diagrams/`) | **Procédure, version adresses IP (sans DNS)**, inchangée : initiation Kafka, téléchargement (Windows), vérification et distribution (Linux), création des VM Hyper-V, installation VM par VM, agents, tests de bout en bout, dépannage, sources, points non vérifiés |
| [GUARDRAILS.md](GUARDRAILS.md) | **À lire avant toute intervention** : règles obligatoires et liste de contrôle |
| [00_README.md](00_README.md) | Index numéroté du dossier |
| `diagrammes/` | Rendus PNG des schémas Mermaid de ce dossier (générés avec mermaid-cli) |
| [01_Vue_ensemble_architecture.md](01_Vue_ensemble_architecture.md) | Contexte, composants, vues logique et physique, rôle de chaque VM |
| [02_Flux_de_donnees.md](02_Flux_de_donnees.md) | Pipelines, sujets et groupes Kafka, double consommation ELK / Loki, séquences |
| [03_Matrice_reseau_ports.md](03_Matrice_reseau_ports.md) | Flux réseau et ports (dont Kafka 9092/9093), filtrage nftables |
| [04_Decisions_architecture_ADR.md](04_Decisions_architecture_ADR.md) | Décisions d'architecture (ADR-001 à ADR-013) |
| [05_Dimensionnement_infra.md](05_Dimensionnement_infra.md) | vCPU, RAM, disque par VM sur un hôte de 32 Go, limites par service |
| [06_Securite.md](06_Securite.md) | Comptes, permissions, réseau (Kafka sans authentification dans le lab), TLS, clés API |
| [07_Plan_migration_Strangler_Fig.md](07_Plan_migration_Strangler_Fig.md) | Phases, critères, rôle des groupes de consommateurs, retour arrière |
| [08_Exploitation_supervision.md](08_Exploitation_supervision.md) | Santé, retard des consommateurs, disque Kafka, sauvegardes, mises à jour hors ligne |
| [09_Variante_DNS_DC.md](09_Variante_DNS_DC.md) | ADR-014 : DC comme DNS, enregistrements A/PTR, ordre de démarrage, différences avec la version IP, panne du DNS |
| [`../Plan_integration_observabilite_lab.md`](../Plan_integration_observabilite_lab.md) | Plan d'origine (non modifié ; les écarts sont justifiés au §4.2 du runbook) |
| `../Runbook_LGTM_Offline_Debian13.v1-obs-lgtm.md.bak`, `../architecture-lgtm.v1-obs-lgtm.bak/` | Version précédente (une seule VM obs-lgtm, sans Kafka), conservée pour comparaison |

## Quelle version du runbook ?

| Ton lab | Runbook |
|---|---|
| Les VM utilisent le **DC comme serveur DNS** (cas du lab actuel) | `Runbook_LGTM_Kafka_Offline_Debian13_DNS-DC` |
| Pas de DNS utilisable, ou test rapide | `Runbook_LGTM_Kafka_Offline_Debian13` (adresses + `/etc/hosts`) |

Ne mélange pas les deux sur un même lab : les fichiers de configuration diffèrent (`${…_FQDN}` contre `<ip-…>`).

## Prérequis

| Élément | Exigence |
|---|---|
| Hôte Hyper-V | Windows avec le rôle Hyper-V ; **32 Go de RAM** ; **8 processeurs logiques ou plus supposés** (variante 4 processeurs dans [05](05_Dimensionnement_infra.md)) ; ≈ 190 Go de disque au maximum pour les six VHDX dynamiques |
| Poste Windows connecté | PowerShell 5.1 ou 7, `curl.exe` et `tar.exe` (fournis avec Windows 10 1809+ / 11), client OpenSSH ; ≈ 4 Go libres (lot, ISO, archive) |
| VM existantes (ressources **inchangées**) | DC (Windows Server, AD DS, DNS ; 1 vCPU, 2 Go) ; ELK sous Debian 13 avec Elasticsearch 9 sécurisé (TLS sur 9200, CA HTTP disponible), Kibana, ElastAlert 2 (2 vCPU, 3 Go) ; AppDynamics éteinte |
| Réseau | vSwitch du lab, adresses IPv4 fixes pour les six nouvelles VM ; SSH (22) du poste Windows vers otel-gw et ELK, et d'otel-gw vers les autres VM Linux |
| Droits | administrateur Hyper-V, `sudo` sur les VM Linux, administrateur local sur le DC, compte Kibana pouvant créer des clés API |
| Outils Linux | présents sur Debian 13 netinst : `sqv`, `sha256sum`, `wget`, `tar`, `systemd`, `nftables` (`curl` est absent) |

## Démarrage rapide (ordre d'exécution)

1. Lire [GUARDRAILS.md](GUARDRAILS.md) et l'initiation Kafka (runbook §2).
2. **Téléchargement** sur le poste Windows : `Telecharger-LGTM-Kafka.ps1` → manifeste → archive `lgtm-bundle-<date>.tar` (runbook §3.1–3.6) ; ISO vérifiée sur la VM ELK (§3.8.1).
3. **Hyper-V** : checkpoints de DC et ELK (sans changer leurs ressources), création des six VM avec `Creer-VM-LGTM-Kafka.ps1`, installation de Debian, adresses fixes, `/etc/hosts` (runbook §4).
4. **Réception et vérification** du lot sur otel-gw (`verifier-lgtm.sh`, dont Kafka et Temurin), puis **distribution** à chaque VM (`distribuer-lot.sh`, recontrôle sur la VM) (§3.7–3.9). Arrêt à la première erreur.
5. **Installation VM par VM** : kafka01 (formatage KRaft, sujets créés à la main), mimir01, loki01, tempo01 (chacune avec son consommateur), otel-gw (passerelle, consommateur ELK, Prometheus agent), grafana01 (§5).
6. **Agents** sur ELK et le DC, vers otel-gw (§6).
7. **Tests de bout en bout** : un journal, une métrique, une trace suivis dans Kafka puis dans Grafana et Kibana ; panne simulée de Loki (§7). Checkpoints.
8. **Migration** phase par phase ([07](07_Plan_migration_Strangler_Fig.md)).

## Conventions

- **Langue** : français ; noms de commandes, fichiers et paramètres en anglais tels que les outils les attendent.
- **Espaces réservés (version IP)** : `<ip-dc>`, `<ip-elk>`, `<ip-kafka01>`, `<ip-otel-gw>`, `<ip-mimir01>`, `<ip-loki01>`, `<ip-tempo01>`, `<ip-grafana01>`, `<vSwitch du lab>`, `<V>` (version). Ils sont remplacés sur chaque VM par `sed -f /root/ip-lab.sed` (runbook §4.4). `elk.lab.local` est un **exemple** de nom présent dans le certificat d'Elasticsearch.
- **Variables (variante DNS)** : `${LAB_DOMAIN}`, `${KAFKA01_FQDN}`, `${OTELGW_IP}`… définies une seule fois dans `lab-params.psd1` ; valeurs d'**exemple** `lab.example.test` et `192.0.2.0/24` (réservées à la documentation, RFC 2606/6761 et 5737), à remplacer.
- **Invites** : blocs `powershell` sur l'hôte ou le poste Windows (administrateur), blocs `bash` en `root` sur la VM indiquée.
- **Fichiers créés dans les VM** : heredoc avec le délimiteur `EOF2`, première ligne de commentaire = chemin du fichier et VM.
- **Secrets** : jamais écrits ; la variable apparaît masquée, `ES_OTEL_API_KEY=`.
- **Statut des informations** : « vérifié » = constaté le 28 oct. 2026 (API, page officielle ou test) ; « non testé » / « à vérifier » = signalé comme tel, et listé dans l'annexe A du runbook.
- **Heures** : heure de Toronto (America/Toronto) dans le journal des changements.
- **Unités** : `M` / `MiB` / `Gio` comme dans systemd, Go et Kafka ; Go / Mo dans le texte.

## Versions épinglées (vérifiées le 28 oct. 2026)

| Composant | Version | VM | Artefact |
|---|---|---|---|
| **Apache Kafka** (Scala 2.13) | **4.4.0** | kafka01 | `kafka_2.13-4.4.0.tgz` (+ `.sha512`, `.asc`, `KEYS`) |
| **Eclipse Temurin JRE** | **25.0.5+8** (LTS) | kafka01 | `OpenJDK25U-jre_x64_linux_hotspot_25.0.5_8.tar.gz` (+ `.sha256.txt`, `.sig`, clé Adoptium) |
| Grafana OSS | **13.2.4** (build 38252365904) | grafana01 | `grafana_13.2.4_38252365904_linux_amd64.deb` |
| Grafana Mimir + mimirtool | **3.2.3** | mimir01 | `mimir-3.2.3_amd64.deb`, `mimirtool_3.2.3_amd64.deb` |
| Grafana Loki | **3.7.9** | loki01 | `loki_3.7.9_amd64.deb` |
| Grafana Tempo | **3.1.1** | tempo01 | `tempo_3.1.1_linux_amd64.deb` |
| OpenTelemetry Collector contrib | **0.164.0** | otel-gw, mimir01, loki01, tempo01, ELK, DC | `otelcol-contrib_0.164.0_linux_amd64.deb`, `otelcol-contrib_0.164.0_windows_x64.msi` |
| Prometheus (mode agent) | **3.15.1** | otel-gw | `prometheus-3.15.1.linux-amd64.tar.gz` |
| node_exporter | **1.12.1** | toutes les VM Linux | `node_exporter-1.12.1.linux-amd64.tar.gz` |
| windows_exporter | **0.32.0** | DC | `windows_exporter-0.32.0-amd64.msi` |
| Debian | **13.7.0** netinst | nouvelles VM | `debian-13.7.0-amd64-netinst.iso` |
| adduser (Debian) | **3.152** | secours | `adduser_3.152_all.deb` |

Non retenus : Grafana 13.3.0 (absent de l'index APT signé le 28 oct. 2026), paquet Debian `openjdk-21-jre-headless` (une dizaine de dépendances absentes de l'ISO, [ADR-012](04_Decisions_architecture_ADR.md#adr-012)), Grafana Alloy (doublon avec otelcol-contrib, [ADR-004](04_Decisions_architecture_ADR.md#adr-004)), Alertmanager autonome ([ADR-005](04_Decisions_architecture_ADR.md#adr-005)), *ingest storage* de Mimir ([ADR-003](04_Decisions_architecture_ADR.md#adr-003)).
