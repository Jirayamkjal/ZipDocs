# 03 – Matrice réseau et ports

> Toutes les VM sont sur le vSwitch du lab, sans accès Internet (sauf le poste Windows de téléchargement). Adresses : espaces réservés `<ip-…>` (runbook §4.4).

## 1. Flux entre machines

| # | Source | Destination | Port | Protocole | Objet |
|---|---|---|---|---|---|
| 1 | Poste Windows | ELK | 22 | SSH (scp) | ISO Debian à vérifier |
| 2 | Poste Windows | otel-gw | 22 | SSH (scp) | lot hors ligne (archive + empreinte) |
| 3 | otel-gw | kafka01, mimir01, loki01, tempo01, grafana01, ELK | 22 | SSH | `distribuer-lot.sh` (fichiers de chaque VM) |
| 4 | ELK, DC, application | otel-gw | 4317 (4318) | OTLP gRPC (HTTP) | journaux, traces, métriques OTLP |
| 5 | otel-gw | kafka01 | **9092** | Kafka (`PLAINTEXT`) | passerelle : **production** dans `otlp_*` ; consommateur `elk-es` ; `kafka_metrics` |
| 6 | mimir01, loki01, tempo01 | kafka01 | **9092** | Kafka (`PLAINTEXT`) | consommateurs `lgtm-mimir`, `lgtm-loki`, `lgtm-tempo` |
| 7 | otel-gw | ELK | 9200 | HTTPS | consommateur `elk-es` → Elasticsearch (phases 1 à 5) |
| 8 | otel-gw | mimir01 | 9009 | HTTP | Prometheus `remote_write` ; `kafka_metrics` en OTLP HTTP |
| 9 | otel-gw | toutes les VM Linux | 9100 | HTTP | scrape node_exporter |
| 10 | otel-gw | DC | 9182 | HTTP | scrape windows_exporter |
| 11 | otel-gw | mimir01 :9009, loki01 :3100, tempo01 :3200, grafana01 :3000 | – | HTTP | scrape `lgtm-self` |
| 12 | otel-gw | mimir01, loki01, tempo01 | 8888 | HTTP | métriques internes des consommateurs |
| 13 | tempo01 | mimir01 | 9009 | HTTP | *metrics-generator* (`/api/v1/push`) |
| 14 | loki01 | mimir01 | 9009 | HTTP | *ruler* de Loki → Alertmanager de Mimir |
| 15 | grafana01 | mimir01 :9009, loki01 :3100, tempo01 :3200 | – | HTTP | requêtes des sources de données |
| 16 | grafana01 | ELK | 9200 | HTTPS | source Elasticsearch transitoire (clé API lecture) |
| 17 | Postes d'administration | grafana01 | 3000 | HTTP | interface Grafana |
| 18 | Toutes les VM | DC | 53, 123 | DNS, NTP | résolution, heure (`systemd-timesyncd`) |

Flux **locaux** (127.0.0.1, jamais sur le réseau) : consommateur → Mimir `:9009/otlp`, → Loki `:3100/otlp`, → Tempo `:4417` (OTLP gRPC) ; contrôleur KRaft `:9093` ; gRPC de Mimir (9097), Loki (9096), Tempo (9095) ; memberlist de Mimir (7946) ; Prometheus `:9090` ; passerelle `:8888`.

## 2. Ports d'écoute par VM

| VM | Port | Service | Adresse d'écoute | Qui s'y connecte |
|---|---|---|---|---|
| kafka01 | **9092** | Kafka, écouteur `PLAINTEXT` (clients) | 0.0.0.0 ; annoncé `<ip-kafka01>:9092` | otel-gw, mimir01, loki01, tempo01 |
| kafka01 | **9093** | Kafka, écouteur `CONTROLLER` (KRaft) | 127.0.0.1 | le broker lui-même (un seul votant) |
| otel-gw | 4317 / 4318 | passerelle OTLP gRPC / HTTP | 0.0.0.0 | ELK, DC, application |
| otel-gw | 8888 | métriques internes de la passerelle | 127.0.0.1 | Prometheus local |
| otel-gw | 9090 | Prometheus agent | 127.0.0.1 (option de l'unité) | local |
| mimir01 | 9009 | Mimir HTTP (`/prometheus`, `/otlp`, `/api/v1/push`, `/alertmanager`) | 0.0.0.0 | grafana01, otel-gw, tempo01, loki01, consommateur local |
| mimir01 | 9097, 7946 | Mimir gRPC, memberlist | 127.0.0.1 | – |
| loki01 | 3100 | Loki HTTP | 0.0.0.0 | grafana01, otel-gw, consommateur local |
| loki01 | 9096 | Loki gRPC | 127.0.0.1 | – |
| tempo01 | 3200 | Tempo HTTP | 0.0.0.0 | grafana01, otel-gw |
| tempo01 | 4417 / 4418 | Tempo OTLP gRPC / HTTP | 127.0.0.1 | consommateur local |
| tempo01 | 9095 | Tempo gRPC | 127.0.0.1 | – |
| mimir01, loki01, tempo01 | 8888 | métriques internes du consommateur | 0.0.0.0 | otel-gw |
| grafana01 | 3000 | Grafana | 0.0.0.0 | postes d'administration, otel-gw |
| toutes les VM Linux | 9100 | node_exporter | 0.0.0.0 | otel-gw |
| toutes les VM Linux | 22 | SSH | 0.0.0.0 | postes d'administration ; otel-gw (distribution) |
| ELK | 9200 | Elasticsearch HTTPS (existant) | existant | otel-gw, grafana01 (voir #16) |
| DC | 9182 | windows_exporter | 0.0.0.0 (règle de pare-feu du MSI) | otel-gw |

> Vérifié en test pour Kafka : avec `listeners=PLAINTEXT://0.0.0.0:9092,CONTROLLER://127.0.0.1:9093`, `ss -ltnp` montre 9092 sur toutes les adresses et 9093 sur la boucle locale seulement.

## 3. Schéma

```mermaid
flowchart LR
  subgraph S[Sources]
    DC[DC :9182]
    ELK[ELK :9100 :9200]
  end
  GW[otel-gw<br/>:4317 :4318]
  K[kafka01<br/>:9092]
  M[mimir01<br/>:9009 :8888]
  L[loki01<br/>:3100 :8888]
  T[tempo01<br/>:3200 :8888]
  F[grafana01<br/>:3000]
  DC -- 4317 --> GW
  ELK -- 4317 --> GW
  GW -- 9092 produit / elk-es --> K
  M -- 9092 lgtm-mimir --> K
  L -- 9092 lgtm-loki --> K
  T -- 9092 lgtm-tempo --> K
  GW -- 9200 elk-es --> ELK
  GW -- 9009 remote_write --> M
  T -- 9009 --> M
  L -- 9009 ruler --> M
  F -- 9009 --> M
  F -- 3100 --> L
  F -- 3200 --> T
  F -. 9200 .-> ELK
  GW -. scrape 9100 / 9182 / 8888 .-> S
```

## 4. Filtrage recommandé (nftables)

Mimir, Loki, Tempo et Kafka n'ont **aucune authentification** dans ce lab : le filtrage par adresse source est la seule barrière ([06](06_Securite.md)). `nftables` est installé par défaut sur Debian 13 (priorité *important*, paquet présent sur l'ISO netinst). Exemple pour loki01 (fichier `nftables-exemple.conf` du runbook §5.7, syntaxe vérifiée avec `nft -c`, nftables 1.1.3) :

```text
table inet filtre {
  chain entree {
    type filter hook input priority filter; policy drop;
    iif lo accept
    ct state established,related accept
    ct state invalid drop
    meta l4proto { icmp, ipv6-icmp } accept
    tcp dport 22 accept
    ip saddr { <ip-grafana01>, <ip-otel-gw> } tcp dport 3100 accept
    ip saddr <ip-otel-gw> tcp dport { 8888, 9100 } accept
  }
}
```

| VM | Règles d'entrée à écrire (en plus de `lo`, `established`, ICMP, SSH) |
|---|---|
| kafka01 | `ip saddr { <ip-otel-gw>, <ip-mimir01>, <ip-loki01>, <ip-tempo01> } tcp dport 9092 accept` ; `ip saddr <ip-otel-gw> tcp dport 9100 accept` |
| otel-gw | `ip saddr { <ip-elk>, <ip-dc>, <app> } tcp dport { 4317, 4318 } accept` |
| mimir01 | `ip saddr { <ip-grafana01>, <ip-otel-gw>, <ip-tempo01>, <ip-loki01> } tcp dport 9009 accept` ; `ip saddr <ip-otel-gw> tcp dport { 8888, 9100 } accept` |
| tempo01 | `ip saddr { <ip-grafana01>, <ip-otel-gw> } tcp dport 3200 accept` ; `ip saddr <ip-otel-gw> tcp dport { 8888, 9100 } accept` |
| grafana01 | `ip saddr { <postes d'administration>, <ip-otel-gw> } tcp dport 3000 accept` ; `ip saddr <ip-otel-gw> tcp dport 9100 accept` |

Appliquer **une VM à la fois**, console Hyper-V ouverte, après un checkpoint (GUARDRAILS §4) : `nft -c -f /etc/nftables.conf && systemctl enable --now nftables`. Non appliqué sur de vraies VM (annexe A du runbook).
