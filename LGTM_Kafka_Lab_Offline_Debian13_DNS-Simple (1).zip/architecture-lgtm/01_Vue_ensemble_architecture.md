# 01 – Vue d'ensemble de l'architecture LGTM + Kafka du lab

> Procédure : [`../Runbook_LGTM_Kafka_Offline_Debian13.md`](../Runbook_LGTM_Kafka_Offline_Debian13.md). Décisions : [04_Decisions_architecture_ADR.md](04_Decisions_architecture_ADR.md).

## 1. Contexte

Le lab Hyper-V compte aujourd'hui un **DC** (Windows Server, AD DS, DNS), une VM **ELK** (Debian 13, Elasticsearch 9, Kibana, ElastAlert 2) et une VM **AppDynamics**, éteinte. Le plan `../Plan_integration_observabilite_lab.md` prévoit de remplacer ELK et AppDynamics par une pile ouverte, **par étapes** (Strangler Fig).

Cette version de l'architecture place **une VM par service** et fait passer toute l'ingestion OTLP par **Apache Kafka** :

- **Tampon :** si un stockage s'arrête, ses données attendent dans Kafka (24 h au plus) et sont écrites au redémarrage.
- **Double consommation :** ELK et Loki lisent **les mêmes journaux**, chacun avec **son groupe de consommateurs** et à son rythme. C'est le mécanisme central de la migration : retirer ELK revient à arrêter un consommateur, sans toucher aux sources.
- **Apprentissage :** chaque stockage a son consommateur, son retard (*lag*) et son cycle de redémarrage, visibles dans Grafana.

Contraintes : VM Linux **sans Internet** (seul un poste Windows télécharge), **pas de Docker**, Debian 13, hôte de **32 Go**, **ressources de DC et ELK inchangées**.

## 2. Composants

| Composant | Version | VM | Rôle |
|---|---|---|---|
| Apache Kafka (KRaft, broker + contrôleur) | 4.4.0 | kafka01 | Journal durable des messages OTLP : sujets `otlp_logs`, `otlp_metrics`, `otlp_spans` |
| Eclipse Temurin JRE | 25.0.5+8 | kafka01 | Java pour Kafka |
| otelcol-contrib (passerelle) | 0.164.0 | otel-gw | Reçoit l'OTLP (4317/4318) et **produit** dans Kafka ; consommateur ELK (`elk-es`) ; récepteur `kafka_metrics` |
| Prometheus (mode agent) | 3.15.1 | otel-gw | Collecte (*scrape*) des exporteurs et services, `remote_write` vers Mimir |
| otelcol-contrib (consommateurs) | 0.164.0 | mimir01, loki01, tempo01 | Lisent Kafka (`lgtm-mimir`, `lgtm-loki`, `lgtm-tempo`) et écrivent dans le stockage local |
| Grafana Mimir (+ Alertmanager intégré) | 3.2.3 | mimir01 | Métriques (15 j), règles, alertes |
| Grafana Loki | 3.7.9 | loki01 | Journaux (168 h) |
| Grafana Tempo | 3.1.1 | tempo01 | Traces (72 h), *metrics-generator* vers Mimir |
| Grafana | 13.2.4 | grafana01 | Consultation : Mimir, Loki, Tempo, Alertmanager, Elasticsearch (transitoire) |
| node_exporter | 1.12.1 | toutes les VM Linux | Métriques système |
| windows_exporter, otelcol-contrib (agent) | 0.32.0, 0.164.0 | DC | Métriques et journaux d'événements Windows |
| otelcol-contrib (agent journald) | 0.164.0 | ELK | Journaux d'Elasticsearch, Kibana, ElastAlert 2, SSH |

## 3. Vue logique

```mermaid
flowchart LR
  subgraph SRC[Sources]
    DC[DC<br/>agent otelcol<br/>windows_exporter]
    ELKA[ELK<br/>agent journald<br/>node_exporter]
    APP[Application de démo<br/>SDK OTel]
  end
  subgraph ING[otel-gw - collecte]
    GW[Passerelle OTLP<br/>:4317 / :4318]
    PROM[Prometheus agent]
    KM[kafka_metrics]
  end
  subgraph BUF[kafka01 - tampon]
    TL[(otlp_logs)]
    TM[(otlp_metrics)]
    TS[(otlp_spans)]
  end
  subgraph STO[Stockages - une VM chacun]
    CM[conso lgtm-mimir] --> MIM[(Mimir)]
    CL[conso lgtm-loki] --> LOK[(Loki)]
    CT[conso lgtm-tempo] --> TEM[(Tempo)]
  end
  CE[conso elk-es<br/>sur otel-gw] --> ES[(Elasticsearch<br/>VM ELK)]
  GRAF[grafana01]
  DC --> GW
  ELKA --> GW
  APP --> GW
  GW --> TL & TM & TS
  TL --> CL
  TL --> CE
  TM --> CM
  TS --> CT
  PROM -- remote_write --> MIM
  KM -- retard des groupes --> MIM
  TEM -- span-metrics --> MIM
  GRAF --> MIM & LOK & TEM
  GRAF -.-> ES
```

Trois couches indépendantes : **collecte** (otel-gw), **tampon** (kafka01), **stockage** (une VM par signal). Seules les métriques « tirées » par Prometheus et la supervision de Kafka vont directement à Mimir ([ADR-004](04_Decisions_architecture_ADR.md#adr-004), [02](02_Flux_de_donnees.md)).

## 4. Vue physique (Hyper-V)

```mermaid
flowchart TB
  subgraph HOST[Hôte Hyper-V - 32 Go - vSwitch du lab - aucun accès Internet pour les VM Linux]
    DC["DC (inchangée)<br/>1 vCPU · 2 Go (1-2)"]
    ELK["ELK (inchangée)<br/>2 vCPU · 3 Go (2-4)"]
    APPD["AppDynamics<br/>éteinte"]
    K["kafka01<br/>2 vCPU · 3 Go (2-4) · 40 Go"]
    G["otel-gw<br/>2 vCPU · 2 Go (1,5-3) · 20 Go"]
    M["mimir01<br/>2 vCPU · 3 Go (2-4) · 40 Go"]
    L["loki01<br/>2 vCPU · 2 Go (1,5-3) · 40 Go"]
    T["tempo01<br/>1 vCPU · 2 Go (1,5-3) · 30 Go"]
    F["grafana01<br/>1 vCPU · 2 Go (1-3) · 20 Go"]
  end
  WIN["Poste Windows connecté<br/>téléchargement seulement"]
  WIN -. "scp (lot)" .-> G
  WIN -. "scp (ISO)" .-> ELK
  G -. "distribuer-lot.sh (ssh)" .-> K & M & L & T & F & ELK
  style APPD fill:#ddd,stroke:#999,stroke-dasharray: 5 5
  style K fill:#fff4e5,stroke:#f29900
```

Total actif : **13 vCPU**, **19 Go** au démarrage (12,5 à 26 Go avec la mémoire dynamique) ; détail dans [05](05_Dimensionnement_infra.md).

## 5. Organisation de chaque VM

| VM | Binaires | Configuration | Données | Services systemd |
|---|---|---|---|---|
| kafka01 | `/opt/java/current` → `jdk-25.0.5+8-jre`, `/opt/kafka/current` → `kafka_2.13-4.4.0` | `/etc/kafka/server.properties`, `/etc/kafka/cluster-id` | `/var/lib/kafka/data` ; journaux `/var/log/kafka` (7 jours) | `kafka`, `node_exporter` |
| otel-gw | `.deb` otelcol-contrib, `/usr/local/bin/prometheus` | `/etc/otelcol-contrib/`, `/etc/prometheus/` | `/var/lib/prometheus` (WAL) ; lot de référence `/opt/lgtm-bundle` | `otelcol-contrib`, `prometheus`, `node_exporter` |
| mimir01 | `.deb` mimir, mimirtool, otelcol-contrib | `/etc/mimir/`, `/etc/otelcol-contrib/` | `/var/lib/mimir` | `mimir`, `otelcol-contrib`, `node_exporter` |
| loki01 | `.deb` loki, otelcol-contrib | `/etc/loki/`, `/etc/otelcol-contrib/` | `/var/lib/loki` | `loki`, `otelcol-contrib`, `node_exporter` |
| tempo01 | `.deb` tempo, otelcol-contrib | `/etc/tempo/`, `/etc/otelcol-contrib/` | `/var/tempo` | `tempo`, `otelcol-contrib`, `node_exporter` |
| grafana01 | `.deb` grafana | `/etc/grafana/`, drop-in `offline.conf` | `/var/lib/grafana` | `grafana-server`, `node_exporter` |

Toutes les VM : drop-ins de limites mémoire `/etc/systemd/system/<service>.service.d/limits.conf`, journal systemd plafonné à 300 Mo, bloc `/etc/hosts` du lab, `/root/ip-lab.sed`.

## 6. Hors périmètre

- Haute disponibilité : **un seul broker Kafka** (facteur de réplication 1), un seul nœud par stockage. Une panne disque de kafka01 perd au plus les messages non encore consommés.
- Authentification et chiffrement de Kafka (SASL, TLS) : non configurés dans le lab ([06](06_Securite.md)).
- Mimir *ingest storage* (Kafka interne à Mimir) : écarté ([ADR-003](04_Decisions_architecture_ADR.md#adr-003)).
- Stockage objet (S3, MinIO) : stockage `filesystem` local partout.
- Modification de DC et ELK : seuls des agents y sont ajoutés.

## 7. Documents liés

[02 – Flux](02_Flux_de_donnees.md) · [03 – Ports](03_Matrice_reseau_ports.md) · [04 – ADR](04_Decisions_architecture_ADR.md) · [05 – Dimensionnement](05_Dimensionnement_infra.md) · [06 – Sécurité](06_Securite.md) · [07 – Migration](07_Plan_migration_Strangler_Fig.md) · [08 – Exploitation](08_Exploitation_supervision.md) · [GUARDRAILS](GUARDRAILS.md)
