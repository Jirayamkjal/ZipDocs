# 02 – Flux de données

> Configurations complètes : runbook §5 (`otelcol-gw.yaml`, `otelcol-consommateur-*.yaml`, `prometheus.yml`). Notions Kafka : runbook §2.

## 1. Vue d'ensemble des flux

| Signal | Source | Entrée | Kafka (sujet) | Consommateur (groupe, VM) | Destination |
|---|---|---|---|---|---|
| Journaux | agents ELK (journald) et DC (journaux d'événements), application | passerelle OTLP, otel-gw | `otlp_logs` | `lgtm-loki` (loki01) **et** `elk-es` (otel-gw) | Loki **et** Elasticsearch (phases 1 à 5) |
| Traces | application de démo (SDK OTel) | passerelle OTLP | `otlp_spans` | `lgtm-tempo` (tempo01) | Tempo |
| Métriques OTLP | application, agents | passerelle OTLP | `otlp_metrics` | `lgtm-mimir` (mimir01) | Mimir (`/otlp`) |
| Métriques « tirées » | node_exporter, windows_exporter, services LGTM | Prometheus agent (otel-gw) | – (pas de Kafka) | – | Mimir (`/api/v1/push`) |
| Supervision de Kafka | broker kafka01 | récepteur `kafka_metrics` (otel-gw) | – (pas de Kafka) | – | Mimir (`/otlp`) |
| *span-metrics*, *service-graphs* | Tempo | *metrics-generator* (tempo01) | – | – | Mimir (`/api/v1/push`) |
| Alertes | règles du *ruler* de Mimir (et de Loki) | – | – | – | Alertmanager de Mimir |

Pourquoi deux flux de métriques évitent Kafka : Prometheus ne produit pas dans Kafka et son **WAL** sert déjà de tampon ; la supervision de Kafka doit rester visible **même si Kafka est saturé** ([ADR-004](04_Decisions_architecture_ADR.md#adr-004), [ADR-009](04_Decisions_architecture_ADR.md#adr-009)).

## 2. Pipelines de la passerelle (otel-gw)

```mermaid
flowchart LR
  subgraph R[Récepteurs]
    OTLP[otlp<br/>gRPC 4317 / HTTP 4318]
    KE[kafka/elk<br/>groupe elk-es]
    KM[kafka_metrics<br/>brokers, topics, consumers]
  end
  subgraph P[Processeurs]
    ML[memory_limiter<br/>600 / 120 MiB]
    B[batch]
  end
  subgraph E[Exportateurs]
    K[kafka<br/>otlp_proto, zstd, acks all]
    ES[elasticsearch<br/>sans file d'envoi]
    OM[otlp_http/mimir]
  end
  OTLP --> ML --> B --> K
  KE --> ML2[memory_limiter] --> ES
  KM --> ML3[memory_limiter] --> B3[batch] --> OM
```

| Pipeline | Récepteur | Processeurs | Exportateur | Remarque |
|---|---|---|---|---|
| `logs`, `metrics`, `traces` | `otlp` | `memory_limiter`, `batch` | `kafka` | un sujet par signal ; `allow_auto_topic_creation: false` |
| `logs/elk` | `kafka/elk` | `memory_limiter` | `elasticsearch` | **à retirer en phase 6** |
| `metrics/kafka` | `kafka_metrics` | `memory_limiter`, `batch` | `otlp_http/mimir` | retard des groupes `lgtm-.*` et `elk-es` |

**Partitionnement** (exportateur `kafka`) : `partition_traces_by_id` place tous les spans d'une trace dans la même partition ; `partition_logs_by_resource_attributes` garde ensemble les journaux d'une même source (ordre conservé). Constaté en test : cinq journaux d'une même source sont tous allés dans la partition 2 de `otlp_logs`.

## 3. Consommateurs (mimir01, loki01, tempo01, et `elk-es` sur otel-gw)

```mermaid
flowchart LR
  K[(Kafka<br/>sujet)] --> R[récepteur kafka<br/>group_id, initial_offset earliest]
  R --> ML[memory_limiter<br/>300 / 60 MiB]
  ML --> X[exportateur local<br/>sending_queue désactivée]
  X --> S[(Stockage<br/>127.0.0.1)]
  X -- succès --> C[offset validé<br/>message_marking.after]
  X -- échec --> BO[error_backoff<br/>1 s à 30 s, sans limite]
  BO --> R
```

**Livraison « au moins une fois » :** l'offset d'un message n'est validé qu'**après** l'écriture réussie dans le stockage. Trois réglages y contribuent ; les trois sont nécessaires :

| Réglage | Sans lui |
|---|---|
| `message_marking.after: true`, `on_error: false` | l'offset avance à la réception : un message refusé est perdu |
| pas de processeur `batch`, `sending_queue.enabled: false` | l'exportateur répond « OK » avant l'écriture : un refus ultérieur est perdu |
| `error_backoff` (`max_elapsed_time: 0`) | après une erreur, la partition reste en pause jusqu'au prochain rééquilibrage du groupe (README du récepteur 0.164.0) |

Conséquence : un **doublon** reste possible (arrêt brutal entre l'écriture et la validation de l'offset), jamais une perte tant que la rétention de Kafka (24 h) n'est pas dépassée.

## 4. Double consommation ELK / Loki (phases 1 à 5 du Strangler Fig)

```mermaid
sequenceDiagram
  participant A as Agent (ELK ou DC)
  participant G as otel-gw (passerelle)
  participant K as kafka01 : otlp_logs
  participant CL as loki01 : groupe lgtm-loki
  participant CE as otel-gw : groupe elk-es
  participant L as Loki
  participant E as Elasticsearch
  A->>G: OTLP gRPC (journaux)
  G->>K: produit (partition selon la source)
  par Chaque groupe lit à son rythme
    CL->>K: fetch depuis son offset
    CL->>L: POST /otlp/v1/logs
    L-->>CL: succès (2xx)
    CL->>K: valide l'offset (lgtm-loki)
  and
    CE->>K: fetch depuis son offset
    CE->>E: _bulk (logs-*.otel-default)
    E-->>CE: succès (2xx)
    CE->>K: valide l'offset (elk-es)
  end
```

- Les deux groupes ont **chacun leurs offsets** : Kafka ne supprime rien à la lecture. Un groupe en panne prend du retard sans ralentir l'autre (testé : Loki arrêté, retard 5 pour `lgtm-loki`, 0 pour `elk-es`, rattrapé sans perte).
- **Comparaison :** même `LOG-END-OFFSET`, donc même nombre de messages proposés aux deux destinations ; on compare ensuite les volumes dans Loki et dans Kibana (critère de la phase 3, [07](07_Plan_migration_Strangler_Fig.md)).
- **Retrait d'ELK (phase 6) :** retirer le pipeline `logs/elk` sur otel-gw, puis supprimer le groupe `elk-es` ; aucune source n'est touchée.

## 5. Métriques : Prometheus agent → Mimir

```mermaid
sequenceDiagram
  participant P as Prometheus agent (otel-gw)
  participant X as node_exporter / windows_exporter / services
  participant M as Mimir (mimir01)
  loop toutes les 30 s
    P->>X: GET /metrics
    X-->>P: exposition texte
  end
  P->>P: WAL local (/var/lib/prometheus)
  P->>M: remote_write /api/v1/push (snappy, protobuf)
  M-->>P: 200 (ou 4xx/5xx : nouvel essai depuis le WAL)
```

Jobs : `prometheus-agent`, `node` (7 VM Linux, étiquette `vm`), `windows` (DC), `lgtm-self` (Mimir, Loki, Tempo, Grafana, passerelle, trois consommateurs). `metric_name_validation_scheme: legacy` est obligatoire : Mimir 3.2.3 refuse les étiquettes UTF-8 (constaté en test).

## 6. Traces : application → Kafka → Tempo → Mimir

```mermaid
sequenceDiagram
  participant App as Application (SDK OTel)
  participant G as otel-gw
  participant K as kafka01 : otlp_spans
  participant C as tempo01 : groupe lgtm-tempo
  participant T as Tempo
  participant M as Mimir
  App->>G: OTLP (spans)
  G->>K: produit (clé = trace ID)
  C->>K: fetch
  C->>T: OTLP gRPC 127.0.0.1:4417
  T-->>C: OK puis offset validé
  T->>M: span-metrics, service-graphs (remote_write)
```

## 7. Alertes

```mermaid
flowchart LR
  KM[kafka_metrics<br/>otel-gw] --> M[(Mimir)]
  P[Prometheus agent] --> M
  M --> RU[ruler Mimir<br/>lab-sante, lab-kafka]
  LR[ruler Loki] -.-> AM
  RU --> AM[Alertmanager intégré<br/>récepteur lab-null]
  AM -.phase 5.-> ITSM[webhook ITSM]
```

| Groupe | Règle | Expression | Pendant |
|---|---|---|---|
| `lab-sante` | `CibleInjoignable` | `up == 0` | 5 min |
| `lab-sante` | `LabWatchdog` | `vector(1)` (toujours active) | – |
| `lab-kafka` | `KafkaRetardConsommateur` | `sum by (group, topic) (kafka_consumer_group_lag) > 5000` | 10 min |
| `lab-kafka` | `KafkaConsommateurAbsent` | `kafka_consumer_group_members{group=~"lgtm-.*\|elk-es"} == 0` | 5 min |
| `lab-kafka` | `KafkaMetriquesAbsentes` | `absent(kafka_brokers)` | 5 min |
| `lab-kafka` | `KafkaDisqueFaible` | espace libre de `/` sur kafka01 < 20 % | 10 min |

## 8. Évolution du routage par phase

| Phase | Journaux | Métriques | Traces |
|---|---|---|---|
| 0 | sources → Logstash → ES (existant) | – | AppDynamics (éteinte) |
| 1 | façades prêtes (otel-gw, kafka01, stockages, Grafana) ; sujets créés | Prometheus agent → Mimir (VM du lab) | – |
| 2 | – | + node_exporter ELK, windows_exporter DC | – |
| 3 | agents → otel-gw → `otlp_logs` → **`lgtm-loki` + `elk-es`** ; Logstash arrêté en fin de phase | inchangé | – |
| 4 | inchangé | inchangé | application → `otlp_spans` → `lgtm-tempo` |
| 5 | inchangé ; règles Loki | règles Mimir → Alertmanager → ITSM | inchangé |
| 6 | **pipeline `logs/elk` retiré, groupe `elk-es` supprimé** ; ES en lecture seule puis éteint | inchangé | inchangé |
