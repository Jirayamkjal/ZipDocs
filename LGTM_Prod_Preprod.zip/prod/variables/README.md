# Variables d'environnements — DNS, plan d'adressage et VIP

**Modifier ici seulement :** [`environnements.env`](environnements.env) et son équivalent YAML [`environnements.yaml`](environnements.yaml). Les deux fichiers décrivent les mêmes exemples fictifs (domaines `obs.exemple.local` en production et `obs-pp.exemple.local` en préproduction). Ils doivent rester alignés. Les commandes des runbooks et le rendu des modèles s'appuient sur le fichier `.env`.

## Chargement

```bash
export LGTM_ENV=prod          # ou : preprod
set -a
. /chemin/vers/variables/environnements.env
set +a
# Ensuite : echo "$GRAFANA_FQDN"  "$KAFKA_BOOTSTRAP"  "$APPD_URL"
```

## Rendu des modèles (envsubst)

```bash
# Tous les modèles de templates/ → variables/rendu/prod/ (ou preprod/)
LGTM_ENV=prod    ../scripts/rendre-config.sh
LGTM_ENV=preprod ../scripts/rendre-config.sh

# Un modèle isolé, ou liste des variables chargées
LGTM_ENV=prod ../scripts/rendre-config.sh --liste
LGTM_ENV=prod ../scripts/rendre-config.sh grafana.ini.tmpl /tmp/grafana.ini
```

Le script exige `envsubst` (paquet `gettext`). Le répertoire `variables/rendu/` est un produit généré : il peut être recréé à tout moment et n'est pas une source.

Aucun secret (mot de passe, jeton, clé S3) n'appartient à ces fichiers.

## SSO (Kerberos et AD FS)

Les variables `KRB_*`, `AUTH_PROXY_*`, `ADFS_*` et `OAUTH_REDIRECT_URL` sont dans le même fichier
(bloc « SSO Grafana OSS »). Aucun secret (keytab, client_secret) n'y figure. Voir
[ADR-011](../architecture/adr/ADR-011_SSO_Grafana_OSS.md) et les modèles
`grafana-auth-proxy.ini.tmpl`, `httpd-mod-auth-gssapi.conf.tmpl`,
`grafana-generic-oauth.ini.tmpl`, `krb5.conf.tmpl`.
