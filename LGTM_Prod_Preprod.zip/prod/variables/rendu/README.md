# Produit généré

Ce répertoire est **régénérable**. Il contient le rendu des modèles de
`variables/templates/` pour les environnements `prod` et `preprod`, produit par :

```bash
LGTM_ENV=prod    ./scripts/rendre-config.sh
LGTM_ENV=preprod ./scripts/rendre-config.sh
```

Ne pas y modifier les FQDN : changer `variables/environnements.env`, puis relancer
le script. Les fichiers rendus sont **non testés** tels quels (secrets et TLS à
compléter avant déploiement).
