#!/usr/bin/env python3
"""Substitution de variables style envsubst (fallback si gettext est absent).

Lit stdin, remplace ${NOM} pour les noms fournis en arguments (sans $),
écrit stdout. Les autres ${...} restent inchangés. N'évalue pas $NOM sans
accolades, conformément à un usage restrictif et prévisible.
"""
from __future__ import annotations

import os
import re
import sys


def main() -> int:
    names = sys.argv[1:]
    if not names:
        # sans liste : tous les ${IDENTIFIANT} présents dans l'environnement
        pattern = re.compile(r"\$\{([A-Za-z_][A-Za-z0-9_]*)\}")

        def repl_all(m: re.Match[str]) -> str:
            return os.environ.get(m.group(1), m.group(0))

        sys.stdout.write(pattern.sub(repl_all, sys.stdin.read()))
        return 0

    allowed = set(names)
    pattern = re.compile(r"\$\{([A-Za-z_][A-Za-z0-9_]*)\}")

    def repl(m: re.Match[str]) -> str:
        key = m.group(1)
        if key in allowed:
            return os.environ.get(key, m.group(0))
        return m.group(0)

    sys.stdout.write(pattern.sub(repl, sys.stdin.read()))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
