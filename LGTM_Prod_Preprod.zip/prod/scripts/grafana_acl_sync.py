#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Synchronisation des ACL Grafana à partir des groupes Active Directory.

Ce composant existe parce que la synchronisation d'équipes Grafana (Team Sync)
est une fonction de Grafana Enterprise / Grafana Cloud
(https://grafana.com/docs/grafana/latest/setup-grafana/configure-access/configure-team-sync/).
Grafana OSS mappe déjà les groupes LDAP vers les rôles d'organisation
(Admin / Editor / Viewer) au moment de la connexion
(https://grafana.com/docs/grafana/latest/setup-grafana/configure-access/configure-authentication/ldap/).
Ce script complète OSS : il crée les équipes, y inscrit les utilisateurs déjà
connus de Grafana, pose les permissions de dossiers et provisionne les
tableaux de bord.

Le script est idempotent : le relancer avec la même configuration ne crée pas
de doublons et remet les écarts à l'état désiré.

Usage :
  grafana_acl_sync.py --config acl-config.yaml [--dry-run] [--mock]
  grafana_acl_sync.py --help

Codes de sortie :
  0  succès
  1  erreur de configuration
  2  erreur LDAP
  3  erreur API Grafana
  4  succès partiel (certaines opérations ont échoué)
  5  dépendance manquante
"""
from __future__ import annotations

import argparse
import json
import logging
import os
import ssl
import sys
import urllib.error
import urllib.parse
import urllib.request
from pathlib import Path
from typing import Any

LOG = logging.getLogger("grafana_acl_sync")

EXIT_OK = 0
EXIT_CONFIG = 1
EXIT_LDAP = 2
EXIT_GRAFANA = 3
EXIT_PARTIAL = 4
EXIT_DEP = 5

PERM_FOLDER = {"View": 1, "Edit": 2, "Admin": 4}


# ---------------------------------------------------------------------------
# Utilitaires
# ---------------------------------------------------------------------------

def die(code: int, msg: str) -> "None":
    LOG.error(msg)
    sys.exit(code)


def read_secret_file(path: str, what: str) -> str:
    p = Path(path)
    if not p.is_file():
        die(EXIT_CONFIG, f"{what} : fichier introuvable : {path}")
    mode = p.stat().st_mode & 0o777
    if mode & 0o077:
        LOG.warning("%s : permissions %03o trop ouvertes (attendu 0600 ou 0640)", path, mode)
    value = p.read_text(encoding="utf-8").strip()
    if not value:
        die(EXIT_CONFIG, f"{what} : fichier vide : {path}")
    return value


def load_config(path: str) -> dict:
    try:
        import yaml  # type: ignore
    except ImportError:
        die(EXIT_DEP, "Le module PyYAML est requis (voir requirements.txt).")
    p = Path(path)
    if not p.is_file():
        die(EXIT_CONFIG, f"Fichier de configuration introuvable : {path}")
    with p.open(encoding="utf-8") as fh:
        data = yaml.safe_load(fh)
    if not isinstance(data, dict):
        die(EXIT_CONFIG, "La configuration doit être un document YAML (objet).")
    for key in ("grafana", "ldap", "mappings"):
        if key not in data:
            die(EXIT_CONFIG, f"Clé obligatoire manquante : {key}")
    if not data["mappings"]:
        die(EXIT_CONFIG, "La liste mappings est vide.")
    return data


# ---------------------------------------------------------------------------
# Client HTTP Grafana
# ---------------------------------------------------------------------------

class GrafanaClient:
    """Client de l'API HTTP Grafana (jeton de compte de service).

    Documentation :
    - comptes de service : https://grafana.com/docs/grafana/latest/administration/service-accounts/
    - dossiers : https://grafana.com/docs/grafana/latest/developer-resources/api-reference/http-api/folder/
    - tableaux de bord : https://grafana.com/docs/grafana/latest/developer-resources/api-reference/http-api/dashboard/
    """

    def __init__(self, url: str, token: str, verify_tls: bool = True, ca_file: str | None = None,
                 timeout: int = 30, mock: bool | None = None):
        self.url = url.rstrip("/")
        self.token = token
        self.timeout = timeout
        self.mock = mock if mock is not None else {}
        self._is_mock = isinstance(mock, dict)
        self._ctx = None
        if not self._is_mock:
            if verify_tls:
                self._ctx = ssl.create_default_context(cafile=ca_file) if ca_file else ssl.create_default_context()
            else:
                self._ctx = ssl._create_unverified_context()  # noqa: S323 — volontaire, uniquement si verify_tls=false
                LOG.warning("Vérification TLS Grafana désactivée (verify_tls: false).")

    def request(self, method: str, path: str, body: Any | None = None, expected: tuple[int, ...] = (200, 201)):
        if self._is_mock:
            return self._mock(method, path, body)
        url = self.url + path
        data = None
        headers = {
            "Authorization": f"Bearer {self.token}",
            "Accept": "application/json",
            "Content-Type": "application/json",
        }
        if body is not None:
            data = json.dumps(body).encode("utf-8")
        req = urllib.request.Request(url, data=data, headers=headers, method=method)
        try:
            with urllib.request.urlopen(req, context=self._ctx, timeout=self.timeout) as resp:
                raw = resp.read()
                code = resp.status
                payload = json.loads(raw.decode("utf-8")) if raw else {}
        except urllib.error.HTTPError as exc:
            raw = exc.read()
            try:
                payload = json.loads(raw.decode("utf-8")) if raw else {}
            except json.JSONDecodeError:
                payload = {"message": raw.decode("utf-8", errors="replace")}
            # Ne jamais journaliser l'en-tête Authorization
            LOG.error("Grafana %s %s → HTTP %s : %s", method, path, exc.code, _safe(payload))
            raise GrafanaError(exc.code, _safe(payload)) from None
        except urllib.error.URLError as exc:
            raise GrafanaError(0, f"connexion impossible : {exc.reason}") from None
        if code not in expected:
            raise GrafanaError(code, _safe(payload))
        return payload

    def _mock(self, method: str, path: str, body):
        store = self.mock
        LOG.debug("MOCK Grafana %s %s", method, path)
        if path == "/api/health":
            return {"database": "ok", "version": "mock"}
        if path == "/api/org/users" and method == "GET":
            return store.setdefault("users", [
                {"userId": 10, "login": "alice", "email": "alice@example.test"},
                {"userId": 11, "login": "bob", "email": "bob@example.test"},
                {"userId": 12, "login": "charlie", "email": "charlie@example.test"},
            ])
        if path.startswith("/api/teams/search"):
            return {"teams": list(store.setdefault("teams", {}).values()), "totalCount": len(store.get("teams", {}))}
        if path == "/api/teams" and method == "POST":
            teams = store.setdefault("teams", {})
            name = body["name"]
            if name in teams:
                return teams[name]
            tid = 100 + len(teams)
            teams[name] = {"id": tid, "name": name, "email": body.get("email", ""), "memberCount": 0}
            store.setdefault("members", {})[tid] = []
            return teams[name]
        if "/members" in path and method == "GET":
            tid = int(path.split("/")[3])
            return store.setdefault("members", {}).get(tid, [])
        if "/members" in path and method == "POST":
            tid = int(path.split("/")[3])
            store.setdefault("members", {}).setdefault(tid, []).append({"userId": body["userId"]})
            return {"message": "Member added"}
        if "/members/" in path and method == "DELETE":
            return {"message": "Member removed"}
        if path == "/api/folders" and method == "GET":
            return list(store.setdefault("folders", {}).values())
        if path == "/api/folders" and method == "POST":
            folders = store.setdefault("folders", {})
            uid = body.get("uid") or body["title"].lower().replace(" ", "-")
            folders[uid] = {"uid": uid, "title": body["title"], "id": 50 + len(folders)}
            return folders[uid]
        if path.endswith("/permissions") and method == "POST":
            return {"message": "Folder permissions updated"}
        if path.startswith("/api/folders/") and method == "GET":
            uid = path.rsplit("/", 1)[-1]
            return store.setdefault("folders", {}).get(uid, {"uid": uid, "title": uid})
        if path == "/api/dashboards/db" and method == "POST":
            return {"status": "success", "uid": body.get("dashboard", {}).get("uid", "dash"), "version": 1}
        return {"message": "mock-ok"}


class GrafanaError(Exception):
    def __init__(self, code: int, message: str):
        super().__init__(f"HTTP {code}: {message}")
        self.code = code
        self.message = message


def _safe(obj: Any) -> str:
    """Représentation journalisable, sans valeur de secret."""
    if isinstance(obj, dict):
        redacted = {k: ("***" if any(s in k.lower() for s in ("pass", "token", "secret", "key", "auth")) else v)
                    for k, v in obj.items()}
        return json.dumps(redacted, ensure_ascii=False)[:500]
    return str(obj)[:500]


# ---------------------------------------------------------------------------
# Client LDAP
# ---------------------------------------------------------------------------

class LdapClient:
    def __init__(self, cfg: dict, mock: dict | None = None):
        self.cfg = cfg
        self.mock = mock

    def members_of(self, group_dn: str) -> list[dict]:
        if self.mock is not None:
            return list(self.mock.get("groups", {}).get(group_dn, self.mock.get("default_members", [])))
        try:
            import ldap3  # type: ignore
            from ldap3 import ALL, SUBTREE, Tls, Connection, Server  # type: ignore
        except ImportError:
            die(EXIT_DEP, "Le module ldap3 est requis pour interroger AD (voir requirements.txt).")

        url = self.cfg["url"]
        bind_dn = self.cfg.get("bind_dn") or read_secret_file(self.cfg["bind_dn_file"], "bind_dn LDAP")
        bind_pw = read_secret_file(self.cfg["bind_password_file"], "mot de passe de liaison LDAP")
        ca = self.cfg.get("ca_file")
        use_ssl = url.lower().startswith("ldaps://")
        tls = None
        if use_ssl:
            tls = Tls(validate=ssl.CERT_REQUIRED if self.cfg.get("verify_tls", True) else ssl.CERT_NONE,
                      ca_certs_file=ca)
        # ldap3 prend l'hôte sans schéma
        from urllib.parse import urlparse
        parsed = urlparse(url)
        host = parsed.hostname
        port = parsed.port or (636 if use_ssl else 389)
        server = Server(host, port=port, use_ssl=use_ssl, tls=tls, get_info=ALL,
                        connect_timeout=self.cfg.get("timeout", 15))
        try:
            conn = Connection(server, user=bind_dn, password=bind_pw, auto_bind=True,
                              raise_exceptions=True, receive_timeout=self.cfg.get("timeout", 15))
        except Exception as exc:  # ldap3 exceptions
            # Ne jamais journaliser le mot de passe
            die(EXIT_LDAP, f"Liaison LDAP impossible (hôte {host}:{port}) : {exc.__class__.__name__}")
        finally:
            bind_pw = ""  # noqa: F841

        user_attr = self.cfg.get("user_id_attribute", "sAMAccountName")
        mail_attr = self.cfg.get("mail_attribute", "mail")
        member_attr = self.cfg.get("group_member_attribute", "member")
        nested = self.cfg.get("use_nested_groups", True)
        # Règle Microsoft LDAP_MATCHING_RULE_IN_CHAIN : membres imbriqués
        # https://learn.microsoft.com/en-us/windows/win32/adsi/search-filter-syntax
        if nested:
            filt = f"(&(objectClass=user)({member_attr}:1.2.840.113556.1.4.1941:={group_dn}))"
            base = self.cfg.get("user_search_base") or self.cfg["base_dn"]
        else:
            filt = "(objectClass=*)"
            base = group_dn
        attrs = [user_attr, mail_attr, "distinguishedName"]
        ok = conn.search(base, filt, SUBTREE, attributes=attrs)
        if not ok and not nested:
            # Repli : lire l'attribut member du groupe, puis chaque DN
            conn.search(group_dn, "(objectClass=*)", attributes=[member_attr])
            members = []
            if conn.entries:
                raw_members = conn.entries[0][member_attr].values if member_attr in conn.entries[0] else []
                for dn in raw_members:
                    if conn.search(dn, "(objectClass=user)", attributes=attrs) and conn.entries:
                        members.append(_entry_to_user(conn.entries[0], user_attr, mail_attr))
            conn.unbind()
            return members
        users = [_entry_to_user(e, user_attr, mail_attr) for e in conn.entries]
        conn.unbind()
        return [u for u in users if u.get("login")]


def _entry_to_user(entry, user_attr, mail_attr) -> dict:
    def val(attr):
        try:
            v = entry[attr].value
        except Exception:
            return ""
        return v if isinstance(v, str) else (v[0] if v else "")
    return {"login": val(user_attr), "email": val(mail_attr) or "", "dn": str(getattr(entry, "entry_dn", ""))}


# ---------------------------------------------------------------------------
# Synchronisation
# ---------------------------------------------------------------------------

class Sync:
    def __init__(self, cfg: dict, grafana: GrafanaClient, ldap: LdapClient, dry_run: bool):
        self.cfg = cfg
        self.g = grafana
        self.ldap = ldap
        self.dry = dry_run
        self.errors = 0
        self.changes = 0

    def run(self) -> int:
        LOG.info("Démarrage de la synchronisation (dry-run=%s)", self.dry)
        try:
            health = self.g.request("GET", "/api/health", expected=(200,))
            LOG.info("Grafana joint (database=%s)", health.get("database", "?"))
        except GrafanaError as exc:
            die(EXIT_GRAFANA, f"Grafana injoignable : {exc}")

        try:
            org_users = self.g.request("GET", "/api/org/users", expected=(200,))
        except GrafanaError as exc:
            die(EXIT_GRAFANA, f"Lecture des utilisateurs d'organisation : {exc}")
        by_login = {u.get("login", "").lower(): u for u in org_users}
        by_email = {u.get("email", "").lower(): u for u in org_users if u.get("email")}
        LOG.info("%d utilisateur(s) déjà présent(s) dans l'organisation Grafana", len(org_users))

        ror_blocks = []
        for mapping in self.cfg["mappings"]:
            try:
                self._sync_mapping(mapping, by_login, by_email, ror_blocks)
            except (GrafanaError, RuntimeError) as exc:
                LOG.error("Échec du mapping %s : %s", mapping.get("grafana_team") or mapping.get("ad_group"), exc)
                self.errors += 1

        emit = (self.cfg.get("ror") or {}).get("emit_file")
        if emit and ror_blocks:
            self._emit_ror(emit, ror_blocks)

        if self.errors:
            LOG.error("Terminé avec %d erreur(s), %d changement(s) appliqué(s).", self.errors, self.changes)
            return EXIT_PARTIAL
        LOG.info("Terminé avec succès, %d changement(s)%s.", self.changes, " (simulés)" if self.dry else "")
        return EXIT_OK

    def _sync_mapping(self, m: dict, by_login: dict, by_email: dict, ror_blocks: list) -> None:
        group_dn = m.get("ad_group") or m.get("ad_group_dn")
        if not group_dn:
            raise RuntimeError("ad_group manquant")
        team_name = m["grafana_team"]
        LOG.info("--- Groupe AD %s → équipe Grafana %s", group_dn, team_name)

        members = self.ldap.members_of(group_dn)
        LOG.info("LDAP : %d membre(s) dans le groupe", len(members))

        team = self._ensure_team(team_name, m.get("team_email", ""))
        team_id = team["id"]
        current = self._team_members(team_id)
        current_ids = {int(x.get("userId") or x.get("user_id")) for x in current}

        wanted_ids = set()
        missing_in_grafana = []
        for person in members:
            login = (person.get("login") or "").lower()
            email = (person.get("email") or "").lower()
            user = by_login.get(login) or by_email.get(email)
            if not user:
                missing_in_grafana.append(person.get("login") or person.get("dn"))
                continue
            uid = int(user.get("userId") or user.get("user_id") or user.get("id"))
            wanted_ids.add(uid)
            if uid not in current_ids:
                self._add_member(team_id, uid, person.get("login"))
        if missing_in_grafana:
            LOG.warning(
                "Utilisateurs AD absents de Grafana (ils apparaîtront après leur première connexion LDAP) : %s",
                ", ".join(str(x) for x in missing_in_grafana[:20])
                + ("…" if len(missing_in_grafana) > 20 else ""),
            )

        if m.get("remove_extra_members", True):
            for uid in current_ids - wanted_ids:
                # Ne pas retirer les membres ajoutés manuellement si indiqué
                self._remove_member(team_id, uid)

        for folder in m.get("folders") or []:
            self._ensure_folder_perm(folder, team_id, team_name)

        for dash in m.get("dashboards") or []:
            self._provision_dashboard(dash)

        if m.get("ror_indices"):
            ror_blocks.append({
                "name": f"ldap-{team_name}",
                "ad_group": m.get("ad_group_cn") or group_dn,
                "indices": m["ror_indices"],
                "actions": m.get("ror_actions") or ["indices:data/read/*", "indices:admin/mappings/get", "cluster:monitor/*"],
            })

    def _ensure_team(self, name: str, email: str) -> dict:
        existing = self.g.request("GET", "/api/teams/search?perpage=1000&query=" + urllib.parse.quote(name), expected=(200,))
        teams = existing.get("teams") or existing if isinstance(existing, list) else existing.get("teams", [])
        for t in teams:
            if t.get("name") == name:
                LOG.info("Équipe déjà présente : %s (id=%s)", name, t.get("id"))
                return t
        LOG.info("%sCréation de l'équipe %s", "[dry-run] " if self.dry else "", name)
        self.changes += 1
        if self.dry and not self.g._is_mock:
            return {"id": -1, "name": name}
        return self.g.request("POST", "/api/teams", {"name": name, "email": email}, expected=(200, 201))

    def _team_members(self, team_id: int) -> list:
        if team_id < 0:
            return []
        return self.g.request("GET", f"/api/teams/{team_id}/members", expected=(200,)) or []

    def _add_member(self, team_id: int, user_id: int, login: str | None) -> None:
        LOG.info("%sAjout de %s (userId=%s) à l'équipe %s", "[dry-run] " if self.dry else "", login, user_id, team_id)
        self.changes += 1
        if self.dry and not self.g._is_mock:
            return
        if team_id < 0:
            return
        self.g.request("POST", f"/api/teams/{team_id}/members", {"userId": user_id}, expected=(200, 201))

    def _remove_member(self, team_id: int, user_id: int) -> None:
        LOG.info("%sRetrait du userId=%s de l'équipe %s", "[dry-run] " if self.dry else "", user_id, team_id)
        self.changes += 1
        if self.dry and not self.g._is_mock:
            return
        if team_id < 0:
            return
        self.g.request("DELETE", f"/api/teams/{team_id}/members/{user_id}", expected=(200, 201))

    def _ensure_folder_perm(self, folder: dict, team_id: int, team_name: str) -> None:
        uid = folder["uid"]
        title = folder.get("title") or uid
        perm_name = folder.get("permission", "Edit")
        if perm_name not in PERM_FOLDER:
            raise RuntimeError(f"permission de dossier inconnue : {perm_name} (View, Edit, Admin)")
        perm = PERM_FOLDER[perm_name]
        # créer le dossier s'il n'existe pas
        try:
            self.g.request("GET", f"/api/folders/{urllib.parse.quote(uid)}", expected=(200,))
            LOG.info("Dossier %s déjà présent", uid)
        except GrafanaError as exc:
            if exc.code != 404:
                raise
            LOG.info("%sCréation du dossier %s (%s)", "[dry-run] " if self.dry else "", uid, title)
            self.changes += 1
            if not (self.dry and not self.g._is_mock):
                self.g.request("POST", "/api/folders", {"uid": uid, "title": title}, expected=(200, 201))
        LOG.info("%sPermission dossier %s : équipe %s = %s", "[dry-run] " if self.dry else "", uid, team_name, perm_name)
        self.changes += 1
        if self.dry and not self.g._is_mock:
            return
        if team_id < 0:
            return
        # Remplace la liste des permissions du dossier (API documentée).
        # Les autres équipes déjà autorisées doivent figurer dans le même mapping
        # ou dans overwrite: false (non géré ici : on pose au moins l'item demandé
        # — pour un usage multi-équipes, regrouper les items dans la config).
        items = folder.get("permission_items") or [{"teamId": team_id, "permission": perm}]
        self.g.request("POST", f"/api/folders/{urllib.parse.quote(uid)}/permissions", {"items": items}, expected=(200, 201))

    def _provision_dashboard(self, dash: dict) -> None:
        path = dash["file"]
        p = Path(path)
        if not p.is_file():
            raise RuntimeError(f"tableau de bord introuvable : {path}")
        try:
            payload = json.loads(p.read_text(encoding="utf-8"))
        except json.JSONDecodeError as exc:
            raise RuntimeError(f"JSON invalide ({path}) : {exc}") from exc
        # Le fichier peut être un tableau de bord nu ou un enveloppe {dashboard: ...}
        if "dashboard" in payload and "meta" in payload:
            body_dash = payload["dashboard"]
        elif "panels" in payload or "uid" in payload:
            body_dash = payload
        else:
            raise RuntimeError(f"fichier {path} : structure de tableau de bord Grafana non reconnue")
        body_dash = dict(body_dash)
        body_dash["id"] = None  # laisser Grafana attribuer
        folder_uid = dash.get("folder_uid")
        LOG.info("%sProvisioning du tableau de bord %s dans le dossier %s",
                 "[dry-run] " if self.dry else "", body_dash.get("uid") or body_dash.get("title"), folder_uid)
        self.changes += 1
        if self.dry and not self.g._is_mock:
            return
        body = {"dashboard": body_dash, "overwrite": True, "message": "grafana_acl_sync"}
        if folder_uid:
            body["folderUid"] = folder_uid
        self.g.request("POST", "/api/dashboards/db", body, expected=(200, 201))

    def _emit_ror(self, path: str, blocks: list) -> None:
        # Génère un extrait YAML, il n'est PAS appliqué automatiquement à ES.
        lines = [
            "# Extrait généré par grafana_acl_sync — à intégrer manuellement dans readonlyrest.yml",
            "# Les blocs doivent être placés AVANT tout bloc plus large.",
            "# Le mot de passe de liaison LDAP n'est PAS écrit ici.",
            "# Vérifier la syntaxe dans https://docs.readonlyrest.com/elasticsearch",
            "",
            "# access_control_rules:",
        ]
        for b in blocks:
            indices = ", ".join(f'"{i}"' for i in b["indices"])
            actions = ", ".join(f'"{a}"' for a in b["actions"])
            grp = b["ad_group"]
            lines += [
                f"#  - name: \"{b['name']}\"",
                "#    type: allow",
                "#    ldap_auth:",
                "#      name: ldap-ad",
                f"#      groups_any_of: [\"{grp}\"]",
                f"#    indices: [{indices}]",
                f"#    actions: [{actions}]",
                "",
            ]
        text = "\n".join(lines)
        LOG.info("%sÉcriture de l'extrait ROR dans %s", "[dry-run] " if self.dry else "", path)
        if self.dry:
            LOG.info("Aperçu ROR :\n%s", text)
            return
        Path(path).write_text(text, encoding="utf-8")


# ---------------------------------------------------------------------------
# Point d'entrée
# ---------------------------------------------------------------------------

def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(
        prog="grafana_acl_sync",
        description="Synchronise les équipes, dossiers, permissions et tableaux de bord Grafana à partir des groupes AD.",
        epilog="Ne jamais passer de jeton ou de mot de passe en argument. Utiliser les fichiers 0600 indiqués dans la configuration.",
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    p.add_argument("--config", "-c", required=not ("--help" in sys.argv), help="Fichier YAML de configuration")
    p.add_argument("--dry-run", action="store_true", help="Simuler : aucune modification n'est écrite (sauf en --mock, où un magasin mémoire est utilisé)")
    p.add_argument("--mock", action="store_true", help="Mode de démonstration : LDAP et Grafana simulés (aucun réseau). Utile pour valider le script hors ligne.")
    p.add_argument("--verbose", "-v", action="store_true", help="Journaux DEBUG")
    p.add_argument("--log-format", choices=("text", "json"), default="text")
    return p


def setup_logging(verbose: bool, fmt: str) -> None:
    level = logging.DEBUG if verbose else logging.INFO
    if fmt == "json":
        class J(logging.Formatter):
            def format(self, record):
                return json.dumps({"level": record.levelname, "msg": record.getMessage(), "logger": record.name}, ensure_ascii=False)
        h = logging.StreamHandler(sys.stdout)
        h.setFormatter(J())
        logging.basicConfig(level=level, handlers=[h])
    else:
        logging.basicConfig(level=level, format="%(asctime)s %(levelname)s %(message)s", datefmt="%Y-%m-%dT%H:%M:%S", stream=sys.stdout)


def mock_stores() -> tuple[dict, dict]:
    grafana = {
        "users": [
            {"userId": 10, "login": "alice", "email": "alice@example.test"},
            {"userId": 11, "login": "bob", "email": "bob@example.test"},
        ],
        "teams": {},
        "members": {},
        "folders": {},
    }
    ldap = {
        "groups": {},
        "default_members": [
            {"login": "alice", "email": "alice@example.test", "dn": "CN=Alice,OU=Users,DC=example,DC=test"},
            {"login": "bob", "email": "bob@example.test", "dn": "CN=Bob,OU=Users,DC=example,DC=test"},
            {"login": "not-yet-logged-in", "email": "newbie@example.test", "dn": "CN=Newbie,OU=Users,DC=example,DC=test"},
        ],
    }
    return grafana, ldap


def main(argv: list[str] | None = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)
    setup_logging(args.verbose, args.log_format)
    cfg = load_config(args.config)

    gcfg = cfg["grafana"]
    if args.mock:
        token = "mock-token"
        g_store, l_store = mock_stores()
        grafana = GrafanaClient(gcfg.get("url", "https://grafana.mock"), token, mock=g_store)
        ldap = LdapClient(cfg["ldap"], mock=l_store)
        LOG.info("Mode --mock : aucun appel réseau.")
    else:
        token = read_secret_file(gcfg["token_file"], "jeton Grafana")
        grafana = GrafanaClient(
            gcfg["url"],
            token,
            verify_tls=gcfg.get("verify_tls", True),
            ca_file=gcfg.get("ca_file"),
            timeout=gcfg.get("timeout", 30),
        )
        token = ""  # libérer
        ldap = LdapClient(cfg["ldap"], mock=None)

    return Sync(cfg, grafana, ldap, dry_run=args.dry_run).run()


if __name__ == "__main__":
    try:
        sys.exit(main())
    except KeyboardInterrupt:
        LOG.error("Interrompu")
        sys.exit(1)
