# Runbook — Plateforme LGTM préproduction et production sur machines virtuelles RHEL 8

**Cible :** déployer une plateforme d'observabilité **LGTM** (Loki, Grafana, Tempo, Mimir) avec **Apache Kafka** (tampon) et **OpenTelemetry Collector**, en **haute disponibilité**, sur des machines virtuelles **RHEL 8**, **hors ligne**, **sans Docker**, services **systemd** natifs, **SELinux enforcing**.

Elasticsearch 8 existe déjà et est protégé par **ReadonlyREST (ROR)**. ElastAlert2 reste le moteur d'alertes sur ES pendant la transition. L'authentification des utilisateurs se fait via **Active Directory (LDAPS)**. Un composant dédié charge les **ACL Grafana**. SCOM et AppDynamics s'intègrent dans une **vue unique**, sans être remplacés d'emblée.

Ce document est **autonome**. L'architecture, les décisions et l'étude d'impact sont dans le dossier `architecture/` du même paquet (diagrammes Visio inclus). Le script d'ACL est dans `scripts/`. Le tableau de bord d'accueil est dans `dashboards/one_screen_home.json`.

---

> **Décisions déjà tranchées :** contrôleur AppDynamics **on-premises** ; **SCOM 2019** (support étendu jusqu'au 10 avril 2029, heure du Pacifique — [lifecycle Microsoft](https://learn.microsoft.com/en-us/lifecycle/products/system-center-2019-operations-manager)) ; FQDN et VIP d'exemple dans [`variables/environnements.env`](variables/environnements.env) (**modifier ici seulement**) ; dimensionnement : **estimations recommandées** au §1.1 (données sensibles, trois domaines de défaillance).
>
> **Hypothèses encore ouvertes** (reprises en annexe) :
> - Stockage objet : S3 déjà présent ou MinIO distribué (voir ADR-002).
> - Noms et DN des groupes Active Directory (les valeurs des modèles sont des exemples).
> - Recalage du dimensionnement après observation en préproduction.
> - Rétentions Kafka et par signal.
> - Version exacte d'Elasticsearch 8 et du greffon ROR (le build ROR doit correspondre à la version ES).
> - Présence ou non d'une licence Grafana Enterprise (non supposée).

> **Sécurité (règles permanentes) :**
> - Ne jamais saisir un mot de passe ou un jeton sur la ligne de commande, ni dans l'historique (`read -rsp`, éditeur, fichiers `0600` / `0640`).
> - Ne jamais afficher un secret dans une commande de vérification (`grep -c`, pas `grep` de la valeur).
> - Clés ou secrets de service avec échéance (90 jours lorsque le mécanisme le permet).
> - Pas de `ssl_skip_verify` en préprod ou prod.

---

### Valeurs d'exemple à remplacer

Les FQDN, VIP et adresses **ne se durcissent pas** dans ce runbook. Ils sont définis dans un fichier unique :

| Fichier | Rôle |
|---|---|
| [`variables/environnements.env`](variables/environnements.env) | Source des commandes — **modifier ici seulement** |
| [`variables/environnements.yaml`](variables/environnements.yaml) | Équivalent YAML, à garder aligné |

```bash
export LGTM_ENV=prod          # ou : preprod
set -a
. /chemin/vers/variables/environnements.env
set +a
# Les commandes ci-dessous utilisent ${GRAFANA_FQDN}, ${KAFKA_BOOTSTRAP}, ${ES_URL}, etc.
```

Les modèles de configuration (`variables/templates/*.tmpl`) se rendent par :

```bash
LGTM_ENV=prod ./scripts/rendre-config.sh          # → variables/rendu/prod/
LGTM_ENV=prod ./scripts/rendre-config.sh --liste  # contrôle des valeurs chargées
```

(`envsubst` si le paquet gettext est présent, sinon repli `scripts/_envsubst.py`.)

Domaines d'exemple, volontairement fictifs : **`obs.exemple.local`** (production), **`obs-pp.exemple.local`** (préproduction), AD `exemple.local`. Tableau de synthèse (le détail des hôtes est dans le fichier de variables et au §1.1) :

| Usage | Variable | Exemple prod | VIP / IP prod | Exemple préprod | VIP / IP préprod |
|---|---|---|---|---|---|
| Grafana | `${GRAFANA_FQDN}` / `${GRAFANA_VIP}` | grafana.obs.exemple.local | 10.80.8.10 | grafana.obs-pp.exemple.local | 10.81.8.10 |
| Passerelle OTel | `${OTEL_GW_FQDN}` / `${OTEL_GW_VIP}` | otel-gw.obs.exemple.local | 10.80.8.11 | otel-gw.obs-pp.exemple.local | 10.81.8.11 |
| Bootstrap Kafka | `${KAFKA_BOOTSTRAP}` | kafka-01..03.obs.exemple.local:9092 | (DNS multi-A, pas de VIP L4) | kafka-01..03.obs-pp.exemple.local:9092 | idem |
| Mimir | `${MIMIR_FQDN}` / `${MIMIR_VIP}` | mimir.obs.exemple.local | 10.80.8.12 | mimir.obs-pp.exemple.local | 10.81.8.12 |
| Loki | `${LOKI_FQDN}` / `${LOKI_VIP}` | loki.obs.exemple.local | 10.80.8.13 | loki.obs-pp.exemple.local | 10.81.8.13 |
| Tempo | `${TEMPO_FQDN}` / `${TEMPO_VIP}` | tempo.obs.exemple.local | 10.80.8.14 | tempo.obs-pp.exemple.local | 10.81.8.14 |
| S3 | `${S3_FQDN}` / `${S3_VIP}` | s3.obs.exemple.local | 10.80.8.15 | s3.obs-pp.exemple.local | 10.81.8.15 |
| PostgreSQL | `${PG_FQDN}` / `${PG_VIP}` | pg.obs.exemple.local | 10.80.8.16 | pg.obs-pp.exemple.local | 10.81.8.16 |
| Elasticsearch | `${ES_FQDN}` / `${ES_URL}` | es.exemple.local | 10.90.10.10 | es-pp.exemple.local | 10.91.10.10 |
| SCOM 2019 | `${SCOM_FQDN}` / `${SCOM_URL}` | scom.exemple.local | 10.90.20.10 | scom-pp.exemple.local | 10.91.20.10 |
| AppDynamics on-prem | `${APPD_FQDN}` / `${APPD_URL}` | appd.exemple.local:8181 | 10.90.30.10 | appd-pp.exemple.local:8181 | 10.91.30.10 |
| AD (LDAPS) | `${DC01_FQDN}`, `${DC02_FQDN}` | dc01 / dc02.exemple.local | 10.90.1.11 / .12 | (souvent partagé) | idem |

Le FQDN réellement utilisé par les clients **doit figurer dans le SAN** du certificat correspondant (ADR-007).

### Versions de référence (artefacts officiels, 28 octobre 2026)

À **revérifier** à chaque campagne (empreintes et signatures).

| Composant | Version | Artefact |
|---|---|---|
| Apache Kafka | **4.4.0** (Scala 2.13) | `kafka_2.13-4.4.0.tgz` + `.sha512` + `.asc` |
| Eclipse Temurin JRE | **25.0.5+8** (LTS) | archive Adoptium + `.sha256.txt` + `.sig` |
| Grafana OSS | **13.2.4** | RPM `dl.grafana.com` + `.sha256` |
| Grafana Mimir + mimirtool | **3.2.3** | RPM ou archive GitHub |
| Grafana Loki | **3.7.9** | RPM ou archive GitHub |
| Grafana Tempo | **3.1.1** | RPM ou archive GitHub |
| otelcol-contrib | **0.164.0** | RPM Linux + MSI Windows |
| Prometheus | **3.15.1** | archive GitHub `sha256sums.txt` |
| node_exporter | **1.12.1** | archive GitHub |
| windows_exporter | **0.32.0** | MSI |
| PostgreSQL | version du canal RHEL 8 AppStream (à noter à l'installation) | RPM hors ligne |
| HAProxy, keepalived | paquets RHEL 8 | RPM hors ligne |

Kafka 4.x fonctionne **uniquement en mode KRaft** ([documentation KRaft](https://kafka.apache.org/44/operations/kraft/)). Java 17, 21 et 25 sont pris en charge ; Java 25 LTS est recommandé ([version de Java](https://kafka.apache.org/44/operations/java-version/)).

---

## 0. Démarrage rapide

Avant toute commande de ce runbook :

```bash
export LGTM_ENV=prod    # ou preprod
set -a
. /chemin/vers/variables/environnements.env
set +a
```


Séquence condensée, détaillée dans les sections suivantes. **Instantané (snapshot) de chaque VM avant chaque changement irréversible.**

1. Trancher les hypothèses (objet, AD, FQDN, dimensionnement).
2. Télécharger et vérifier les artefacts sur un poste Windows, transférer par SFTP (§2).
3. Préparer chaque RHEL 8 : abonnements déjà présents hors ligne, utilisateurs système, SELinux, firewalld, ancrage du CA (§3).
4. Émettre et déployer les certificats, **contrôler les SAN** (§4).
5. Déployer le stockage objet (§5), puis Kafka à 3 courtiers (§6).
6. Déployer Mimir, Loki, Tempo (§7–9), les passerelles otel-gw (§10), Grafana HA + PostgreSQL + LDAP (§11–12).
7. Intégrer ROR (§13), installer `grafana_acl_sync` (§14), provisionner la vue unique (§16).
8. Vérifications de bout en bout (§17), exercices de panne (§18), liste de contrôle go-live (§18.5).

---

## 1. Architecture et haute disponibilité

Le détail (flux, matrice réseau, exigences, ADR) est dans `architecture/01_Document_architecture.md`. Les figures Visio sont dans `architecture/diagrammes/`.

![Architecture VM](architecture/diagrammes/01_architecture_vm.png)

```mermaid
flowchart LR
  SRC["Agents et applications OTLP"] --> VIP1["VIP ${OTEL_GW_FQDN}"]
  VIP1 --> GW["otel-gw × N"]
  GW --> KF["Kafka 3 courtiers RF=3"]
  KF --> MIM["Mimir + AM cluster"]
  KF --> LOK["Loki"]
  KF --> TEM["Tempo"]
  KF --> ES["ES 8 + ROR — groupe elk-es"]
  MIM --> S3["S3 ${S3_FQDN}"]
  LOK --> S3
  TEM --> S3
  VIP2["VIP ${GRAFANA_FQDN}"] --> GF["Grafana × 2"]
  GF --> PG["PostgreSQL HA"]
  GF --> MIM
  GF --> LOK
  GF --> TEM
  GF --> ES
  AD["AD LDAPS"] --> GF
```

**Principes HA** (ADR-009) :

- Kafka : RF=3, `min.insync.replicas=2`, producteurs `acks=all`. Un courrier perdu est toléré. Deux courriers perdus = perte de quorum.
- Mimir / Loki / Tempo : mode microservices ou simple-scalable, réplication d'ingestion, stockage objet.
- Grafana : 2 instances, base PostgreSQL partagée, VIP HAProxy + keepalived.
- otel-gw : ≥ 2 (3 en prod) derrière un VIP, configuration identique.

### 1.1 Dimensionnement — estimations recommandées

Tableaux identiques à ceux du [document d'architecture, §8](architecture/01_Document_architecture.md). Ce sont des **estimations recommandées** pour une organisation à **données sensibles** (préprod et prod séparées, trois domaines de défaillance A/B/C, séparation des rôles, bastion dédié, pas de point unique de défaillance sur le plan de données, chiffrement au repos, réseaux distincts). Justification détaillée dans le document d'architecture. À recalibrer après observation. OS : **RHEL 8**.

**Préproduction** (`obs-pp.exemple.local`) — 22 VM, ou 26 avec MinIO :

| Rôle | Noms d'exemple | Qté | vCPU | RAM | Disques (chiffrés) | OS | Zone |
|---|---|---|---|---|---|---|---|
| Bastion / administration | bastion-01, bastion-02 | 2 | 2 | 4 Go | OS 40 Go | RHEL 8 | A, C |
| Équilibreur HAProxy + keepalived | lb-01, lb-02 | 2 | 2 | 4 Go | OS 40 Go | RHEL 8 | A, B |
| Kafka (courtier + contrôleur KRaft) | kafka-01..03 | 3 | 4 | 16 Go | OS 50 Go + données 300 Go | RHEL 8 | A, B, C |
| Passerelle OTel + agent Prometheus | otel-gw-01, otel-gw-02 | 2 | 4 | 8 Go | OS 50 Go + WAL 50 Go | RHEL 8 | A, B |
| Mimir (compact HA, RF=3, objet) | mimir-01..03 | 3 | 4 | 16 Go | OS 50 Go + local 100 Go | RHEL 8 | A, B, C |
| Loki (compact HA, RF=3, objet) | loki-01..03 | 3 | 4 | 12 Go | OS 50 Go + local 100 Go | RHEL 8 | A, B, C |
| Tempo (compact HA, RF=3, objet) | tempo-01..03 | 3 | 4 | 12 Go | OS 50 Go + local 100 Go | RHEL 8 | A, B, C |
| Grafana | grafana-01, grafana-02 | 2 | 2 | 4 Go | OS 40 Go | RHEL 8 | A, B |
| PostgreSQL (primaire + réplique) | pg-01, pg-02 | 2 | 2 | 8 Go | OS 40 Go + données 80 Go | RHEL 8 | A, C |
| MinIO (si aucun S3 existant) | minio-01..04 | 4 | 4 | 8 Go | OS 50 Go + données 1 To | RHEL 8 | A, B, C, A |

**Production** (`obs.exemple.local`) — 41 VM, ou 45 avec MinIO :

| Rôle | Noms d'exemple | Qté | vCPU | RAM | Disques (chiffrés) | OS | Zone |
|---|---|---|---|---|---|---|---|
| Bastion / administration | bastion-01, bastion-02 | 2 | 2 | 4 Go | OS 40 Go | RHEL 8 | A, C |
| Équilibreur HAProxy + keepalived | lb-01, lb-02 | 2 | 4 | 8 Go | OS 40 Go | RHEL 8 | A, B |
| Kafka (courtier + contrôleur KRaft) | kafka-01..03 | 3 | 8 | 32 Go | OS 50 Go + données 800 Go | RHEL 8 | A, B, C |
| Passerelle OTel + agent Prometheus | otel-gw-01..03 | 3 | 6 | 16 Go | OS 50 Go + WAL 100 Go | RHEL 8 | A, B, C |
| Mimir écriture (distributor + ingester) | mimir-write-01..03 | 3 | 8 | 32 Go | OS 50 Go + local 200 Go | RHEL 8 | A, B, C |
| Mimir lecture | mimir-read-01, 02 | 2 | 8 | 24 Go | OS 50 Go + 50 Go | RHEL 8 | A, B |
| Mimir backend | mimir-backend-01..03 | 3 | 8 | 24 Go | OS 50 Go + 100 Go | RHEL 8 | A, B, C |
| Loki écriture | loki-write-01..03 | 3 | 6 | 24 Go | OS 50 Go + 200 Go | RHEL 8 | A, B, C |
| Loki lecture | loki-read-01, 02 | 2 | 6 | 16 Go | OS 50 Go + 50 Go | RHEL 8 | A, B |
| Loki backend | loki-backend-01..03 | 3 | 6 | 16 Go | OS 50 Go + 100 Go | RHEL 8 | A, B, C |
| Tempo distributor | tempo-dist-01, 02 | 2 | 4 | 8 Go | OS 50 Go | RHEL 8 | A, B |
| Tempo ingester | tempo-ing-01..03 | 3 | 6 | 16 Go | OS 50 Go + 200 Go | RHEL 8 | A, B, C |
| Tempo requête | tempo-query-01, 02 | 2 | 4 | 16 Go | OS 50 Go | RHEL 8 | A, C |
| Tempo compactor / metrics-generator | tempo-comp-01, 02 | 2 | 4 | 12 Go | OS 50 Go + 50 Go | RHEL 8 | A, B |
| Grafana | grafana-01, grafana-02 | 2 | 4 | 8 Go | OS 50 Go | RHEL 8 | A, B |
| PostgreSQL (primaire + réplique) | pg-01, pg-02 | 2 | 4 | 16 Go | OS 50 Go + données 150 Go | RHEL 8 | A, C |
| MinIO (si aucun S3 existant) | minio-01..04 | 4 | 8 | 16 Go | OS 50 Go + données 2 To | RHEL 8 | A, B, C, A |
- Alertmanager de Mimir en cluster (peering officiel, pour éviter les notifications doubles).

**Dimensionnement :** estimations dans le document d'architecture, §8. Ne pas les traiter comme des mesures.

Sujets Kafka et groupes (identiques dans les deux réalisations) :

| Sujet | Groupes lecteurs |
|---|---|
| `otlp_logs` | `lgtm-loki`, `elk-es` |
| `otlp_metrics` | `lgtm-mimir` |
| `otlp_spans` | `lgtm-tempo` |

---

## 2. Téléchargement hors ligne et transfert

Le réseau des VM n'a **pas** d'accès Internet. Un poste Windows (ou une machine de rebond connectée) télécharge les artefacts **officiels**, calcule les empreintes, produit un manifeste, archive, puis transfère par **SFTP**.

1. Télécharger chaque fichier et son fichier d'empreinte / de signature depuis le site officiel du projet (Grafana : `dl.grafana.com` et GitHub ; Kafka : `downloads.apache.org`, secours `archive.apache.org` ; Temurin : Adoptium ; Prometheus / node_exporter : GitHub Releases).
2. Sur le poste de téléchargement, calculer SHA-256 (PowerShell `Get-FileHash`) et comparer au fichier publié. Pour Kafka, vérifier aussi la signature GPG (`.asc` et fichier `KEYS`). Pour les RPM Grafana, l'index du dépôt est signé.
3. Produire un manifeste `SHA256SUMS` et une archive (`tar` est fourni avec Windows 10 1803+).
4. Transférer par SFTP vers une VM relais (par exemple `otel-gw-01`), hors du répertoire d'installation final.
5. Sur Linux, **revérifier** toutes les empreintes avant d'installer (`sha256sum -c`). Une non-concordance arrête la procédure.
6. Distribuer à chaque VM uniquement les fichiers qui la concernent, puis **revérifier sur la destination**.

Dépendances RPM RHEL 8 (HAProxy, keepalived, PostgreSQL, `python3`, bibliothèques) : les extraire du canal interne de paquets hors ligne déjà utilisé par l'organisation (Satellite, miroir, DVD). Contrôle : `rpm -qp --requires paquet.rpm`. **Ne pas** lancer `dnf` / `yum` vers Internet.

Les roues Python de `grafana_acl_sync` (`scripts/requirements.txt`) se téléchargent avec `pip download -r requirements.txt -d wheels/` sur le poste connecté, puis `pip install --no-index --find-links wheels -r requirements.txt` dans un `venv` sur la VM.

---

## 3. Préparation commune de chaque VM RHEL 8

### 3.1 Système

- RHEL 8 à jour selon le canal interne, **SELinux enforcing** : `getenforce` doit répondre `Enforcing`. Ne pas passer en permissive de façon durable.
- NTP / chrony aligné sur la même source que le reste de la production.
- Nom d'hôte = FQDN, résolution DNS (A et PTR) opérationnelle : `getent hosts $(hostname -f)`.
- Pare-feu : `firewalld` actif. N'ouvrir que les ports de la matrice (`architecture/01_Document_architecture.md`, §6), limités aux sources nécessaires (`--source=`).

Exemple (adapter ports et sources ; **à valider** avec `firewall-cmd --check-config`) :

```
firewall-cmd --permanent --add-rich-rule='rule family=ipv4 source address=${INGEST_NET} port protocol=tcp port=9092 accept'
firewall-cmd --reload
firewall-cmd --list-all
```

### 3.2 Utilisateurs et répertoires

Créer des utilisateurs système dédiés (`kafka`, `mimir`, `loki`, `tempo`, `otelcol-contrib`, `grafana`, `prometheus`, `grafana-acl-sync`), sans shell de connexion, et des répertoires de données en `0750`, propriétaire = utilisateur du service.

### 3.3 SELinux — ports et contextes

Les ports non standard doivent être déclarés, sinon SELinux refusera l'écoute (`avc: denied`). Exemples à adapter après `semanage port -l` (ne pas déclarer un port déjà étiqueté) :

```
# Exemples — vérifier d'abord si le port est déjà défini
semanage port -a -t http_port_t -p tcp 3000    # Grafana, si pas déjà http_port_t
semanage port -a -t http_port_t -p tcp 9009    # Mimir
semanage port -a -t http_port_t -p tcp 3100    # Loki
semanage port -a -t http_port_t -p tcp 3200    # Tempo
semanage port -a -t http_port_t -p tcp 4317
semanage port -a -t http_port_t -p tcp 4318
```

Après tout dépôt de fichier sous `/etc` ou `/var/lib` d'un service :

```
restorecon -Rv /etc/kafka /var/lib/kafka /etc/otelcol-contrib /etc/grafana /var/lib/grafana
```

En cas de refus : `ausearch -m avc -ts recent` (ou `audit2why`), puis module ou `semanage fcontext` — **pas** `setenforce 0` durable. Cette séquence est **à valider** sur l'image RHEL 8 réelle (politique exacte non testée dans ce dépôt).

### 3.4 Ancrage du CA interne

```
install -m 0644 /chemin/ca-entreprise.crt /etc/pki/ca-trust/source/anchors/ca-entreprise.crt
update-ca-trust extract
# Contrôle (le CN du CA doit apparaître) :
trust list | grep -A2 "exemple-cn-du-ca"
```

Chaque composant qui n'utilise pas le magasin système reçoit en plus un `ca_file` dédié (0644, certificat public, pas un secret).

### 3.5 Journal systemd et limites

Plafonner le journal (`SystemMaxUse`) pour éviter de remplir le disque. Pour chaque service gourmand, un drop-in systemd avec `MemoryHigh`, `MemoryMax` et, pour les binaires Go, `GOMEMLIMIT`. Les valeurs précises se calent sur le dimensionnement retenu (estimations du document d'architecture). Contrôle : `systemctl show <service> -p MemoryMax -p MemoryCurrent`.

---

## 4. Certificats — problèmes, émission, vérification, rotation

Cette section est **critique**. Une erreur de SAN casse TLS de façon opaque (journaux `x509`) et empêche la double écriture ou l'accès Grafana.

### 4.1 Règle du SAN

**Le nom d'hôte que le client met dans l'URL doit figurer dans le SAN (Subject Alternative Name) du certificat du serveur.** Le CN seul ne suffit pas aux clients modernes.

Cas réel déjà observé : un certificat de service HTTP ne contenait que le **nom court** (`es01`), alors que les clients appelaient le **FQDN** (`es.exemple.local`). Erreur résultante :

```
x509: certificate is valid for es01, not es.exemple.local
```

Correctif : régénérer le certificat en incluant **tous** les noms utilisés (`es.exemple.local`, `es01`, et `localhost` si des contrôles locaux s'en servent), signé par le même CA, redistribuer, redémarrer, revérifier.

Pour chaque service, dresser la liste des noms **réellement utilisés** : FQDN DNS, nom court résiduel, **nom du VIP**, éventuels alias. Cette liste va dans la CSR.

### 4.2 Émission (PKI interne / AD CS)

1. Créer une clé et une CSR (clé et mot de passe de keystore saisis de façon interactive, fichiers `0600`).
2. Déposer la CSR auprès de l'autorité interne (modèle Web Server ou équivalent, avec SAN DNS et, au besoin, IP).
3. Récupérer le certificat **et la chaîne** (intermédiaires).
4. Pour Kafka (Java) : keystore et truststore PKCS#12 ou JKS, mots de passe dans un fichier `0600` lu par l'unité systemd, pas sur la ligne `keytool` en historique — `read -rsp` puis `-storepass:env` / fichier, selon l'outil.
5. Pour ROR, suivre la documentation SSL : soit le SSL ROR (`http.type: ssl_netty4` lorsque `xpack.security.enabled` est `false`), soit le SSL X-Pack si `xpack.security.enabled` est `true`. Voir [encryption ROR](https://docs.readonlyrest.com/elasticsearch). Les fichiers de certificats se placent à côté de `elasticsearch.yml`.
6. `restorecon` sur les nouveaux fichiers.

### 4.3 Distribution de la chaîne

- `update-ca-trust` sur chaque RHEL 8 (§3.4).
- `tls.ca_file` dans otelcol (exportateur elasticsearch, récepteurs OTLP serveur, producteur Kafka SSL).
- Grafana : `tlsCACert: $__file{/etc/grafana/certs/ca.crt}` dans le provisioning.
- Kafka : truststore contenant le CA.
- ROR : truststore ou PEM selon l'option retenue.

### 4.4 Vérification (aucun secret affiché)

```
# Remplacer FQDN et port. Le FQDN demandé DOIT apparaître dans le SAN.
openssl s_client -connect ${ES_FQDN}:9200 -servername ${ES_FQDN} </dev/null 2>/dev/null \
  | openssl x509 -noout -subject -issuer -dates -ext subjectAltName
```

Contrôler les dates (`notAfter`) et la liste DNS. Répéter pour chaque VIP (Grafana :443, otel-gw :4318, Kafka :9092 en SSL, Mimir, Loki, Tempo, MinIO).

```mermaid
sequenceDiagram
  participant Client
  participant Serveur
  participant Cert as Certificat du serveur
  Client->>Serveur: ClientHello SNI=FQDN-utilisé
  Serveur->>Client: certificat
  Client->>Cert: le FQDN-utilisé est-il dans le SAN ?
  alt oui, chaîne ancrée, dates valides
    Cert-->>Client: handshake OK
  else SAN incomplet
    Cert-->>Client: x509: certificate is valid for X, not Y
  else CA inconnu
    Cert-->>Client: unknown authority / unable to verify
  else date dépassée
    Cert-->>Client: certificate has expired
  end
```

### 4.5 Tableau des erreurs fréquentes

| Symptôme (journal ou `openssl`) | Cause probable | Action |
|---|---|---|
| `x509: certificate is valid for X, not Y` | SAN sans le nom utilisé par le client | Régénérer avec le bon FQDN ; ou faire pointer le client vers un nom déjà présent (et l'enregistrer en DNS — pas dans `/etc/hosts` de production) |
| `certificate signed by unknown authority` / `x509: certificate is not valid for any names` | Chaîne CA absente ou incomplète | Déployer le CA (+ intermédiaires), `update-ca-trust`, `ca_file` |
| `certificate has expired` | Expiration | Rotation (§4.6) |
| `tls: handshake failure` / `no cipher overlap` | Protocoles ou suites trop anciens | TLS 1.2+ ; aligner les suites |
| `connection refused` | Service arrêté ou firewalld | `systemctl`, `ss -ltnp`, `firewall-cmd` |
| `hostname mismatch` côté Java | Truststore / `endpoint.identification.algorithm` | Vérifier le SAN et le nom dans `advertised.listeners` |

### 4.6 Rotation et surveillance

```mermaid
flowchart TD
  A["Alerte : expiration dans 30 jours"] --> B["Émettre un nouveau certificat<br/>MÊME liste de SAN, même CA"]
  B --> C["Déposer fichiers 0640/0600, restorecon"]
  C --> D["Recharger ou redémarrer le service<br/>dans une fenêtre, une instance à la fois"]
  D --> E["openssl s_client : nouvelles dates, même SAN"]
  E --> F["Révoquer l'ancien si la PKI l'exige"]
```

- Créer une alerte Mimir (ou sonde) sur la date d'expiration : par exemple un exportateur de certificats ou un script oneshot qui publie un score. **La sonde exacte n'est pas fournie testée ici.**
- Tester la rotation **en préprod** avant de la jouer en prod.
- mTLS Kafka (certificats client pour producteurs et consommateurs) est **optionnel en première étape**, recommandé ensuite ([ADR-007](architecture/adr/ADR-007_Strategie_PKI_certificats.md)).

---

## 5. Stockage objet

**Hypothèse à confirmer.** Deux options, même interface S3 :

1. **S3 déjà présent** (recommandé s'il est déjà exploité, répliqué, sauvegardé). Créer trois seaux : `lgtm-mimir`, `lgtm-loki`, `lgtm-tempo`. Identifiants dédiés, moindre privilège, TLS, fichiers `0600`.
2. **MinIO distribué** : au moins quatre nœuds pour un erasure coding standard — **suivre la documentation MinIO de la version réellement installée** (topologie et nombre de nœuds à confirmer, non testé ici). RPM ou binaire officiel, systemd, certificats, firewalld, SELinux.

Vérification (identifiants saisis interactivement, non affichés) :

```
# Exemple avec le client officiel, endpoint et seau à adapter
# Les clés sont lues depuis l'environnement déjà chargé, pas passées en argument.
mc alias set lgtm "$S3_ENDPOINT"   # le client demandera les clés, ou utiliser un fichier de config 0600
mc ls lgtm/lgtm-mimir
```

Mimir, Loki et Tempo reçoivent `endpoint`, `bucket`, `region` (souvent `us-east-1` pour MinIO), et les clés via variables d'environnement. `insecure: false` en préprod et prod.

---

## 6. Kafka — trois courtiers KRaft

Sources : [KRaft](https://kafka.apache.org/44/operations/kraft/), [configuration courtiers](https://kafka.apache.org/44/configuration/broker-configs/).

### 6.1 Installation

Sur chaque `kafka-0X`, après vérification d'empreinte : installer Temurin 25 dans `/usr/lib/jvm/temurin-25` (ou chemin retenu), archive Kafka dans `/opt/kafka` (lien symbolique de version), utilisateur `kafka`, données dans `/var/lib/kafka/data` (`0750`). Unité systemd `Type=simple` (ou selon la version), `Environment=JAVA_HOME=...`, `SuccessExitStatus=143`, `LimitNOFILE` élevé, `MemoryMax` calé sur la RAM de la VM, tas `-Xms` / `-Xmx` identiques (ex. 4g en préprod — **estimation**).

### 6.2 Configuration (exemple `kafka-01`)

Fichier `/etc/kafka/server.properties`. Adapter `node.id` (1, 2, 3) et `advertised.listeners` (FQDN de **cette** VM). Les noms dans `advertised.listeners` doivent être résolus par tous les clients **et** figurer dans le SAN si SSL est activé.

```
# Apache Kafka 4.4.0 — KRaft combiné (courtier + contrôleur). Référence :
# https://kafka.apache.org/44/configuration/broker-configs/
process.roles=broker,controller
node.id=1
controller.quorum.voters=1@${KAFKA01_FQDN}:9093,2@${KAFKA02_FQDN}:9093,3@${KAFKA03_FQDN}:9093
listeners=PLAINTEXT://0.0.0.0:9092,CONTROLLER://0.0.0.0:9093
advertised.listeners=PLAINTEXT://${KAFKA01_FQDN}:9092
listener.security.protocol.map=CONTROLLER:PLAINTEXT,PLAINTEXT:PLAINTEXT
controller.listener.names=CONTROLLER
inter.broker.listener.name=PLAINTEXT
log.dirs=/var/lib/kafka/data
num.network.threads=8
num.io.threads=8
socket.send.buffer.bytes=102400
socket.receive.buffer.bytes=102400
log.retention.hours=72
log.segment.bytes=1073741824
num.partitions=3
default.replication.factor=3
min.insync.replicas=2
offsets.topic.replication.factor=3
transaction.state.log.replication.factor=3
transaction.state.log.min.isr=2
auto.create.topics.enable=false
delete.topic.enable=false
```

> **TLS :** remplacer `PLAINTEXT` par `SSL` (ou `SASL_SSL`) une fois les keystores prêts : `listeners=SSL://0.0.0.0:9092`, `advertised.listeners=SSL://${KAFKA01_FQDN}:9092`, chemins de keystore / truststore, `ssl.endpoint.identification.algorithm=https`. Les mots de passe de keystore viennent de l'environnement de l'unité, pas du fichier en clair si l'organisation l'interdit — dans ce cas, fichier `0600` et script d'emballage. **La configuration SSL Kafka 4.4 n'est pas testée dans ce dépôt.**
>
> **Quorum dynamique (KIP-853) :** Kafka 4.x introduit `controller.quorum.bootstrap.servers` et un formatage `--initial-controllers`. Si la version installée exige ce formalisme, suivre la [documentation KRaft 4.4](https://kafka.apache.org/44/operations/kraft/) plutôt que `controller.quorum.voters`. À vérifier au moment de l'installation. Le formatage ci-dessous est le formalisme classique, encore largement documenté.

### 6.3 Formatage et démarrage

Le **même** identifiant de cluster sur les trois nœuds, un `node.id` distinct. Formater **une seule fois** par nœud (un second formatage est refusé ou destructeur).

```
# Sur une machine, générer l'identifiant, le transmettre hors bande aux autres (pas un secret critique, mais à figer)
/opt/kafka/bin/kafka-storage.sh random-uuid
# Sur CHAQUE courrier, une seule fois :
sudo -u kafka /opt/kafka/bin/kafka-storage.sh format \
  -t <CLUSTER_ID> \
  -c /etc/kafka/server.properties
systemctl enable --now kafka
# Vérifier le quorum :
/opt/kafka/bin/kafka-metadata-quorum.sh --bootstrap-server ${KAFKA01_FQDN}:9092 describe --status
```

Les trois voteurs doivent être visibles. **Non testé** sur un cluster à trois nœuds dans ce dépôt (le formatage multi-nœuds 4.4 est à confirmer sur un banc).

### 6.4 Création des sujets

```
# creer-sujets.sh — exécuter sur un courrier, une fois le cluster stable
set -euo pipefail
BOOT=${KAFKA_BOOTSTRAP}
create() {
  local t=$1 p=$2 ret=$3
  /opt/kafka/bin/kafka-topics.sh --bootstrap-server "$BOOT" --create --if-not-exists \
    --topic "$t" --partitions "$p" --replication-factor 3 \
    --config min.insync.replicas=2 \
    --config retention.ms=$ret \
    --config compression.type=zstd
}
# Rétention 3 jours = 259200000 ms — HYPOTHÈSE à confirmer
create otlp_logs 6 259200000
create otlp_metrics 6 259200000
create otlp_spans 6 259200000
/opt/kafka/bin/kafka-topics.sh --bootstrap-server "$BOOT" --describe
```

Le nombre de partitions (6 ici) est une **estimation** (parallélisme des consommateurs). Ne pas le réduire ensuite sans réaffectation.

Vérifications :

```
nc -vz ${KAFKA01_FQDN} 9092
/opt/kafka/bin/kafka-topics.sh --bootstrap-server ${KAFKA01_FQDN}:9092 --list
/opt/kafka/bin/kafka-consumer-groups.sh --bootstrap-server ${KAFKA01_FQDN}:9092 --list
```

Les groupes `lgtm-*` et `elk-es` n'apparaissent **qu'après** le premier démarrage des consommateurs.


---

## 7. Mimir (métriques) et Alertmanager en cluster

Sources : [Grafana Mimir](https://grafana.com/docs/mimir/latest/), [configuration](https://grafana.com/docs/mimir/latest/configure/).

Déployer Mimir en mode **microservices** ou **read-write / simple-scalable** (groupes `write`, `read`, `backend`). Le mode monolithique `target: all` n'est **pas** la cible de production (pas de tolérance d'un nœud). Chaque processus a un `target` explicite, un `memberlist` (ou le KV retenu) couvrant tous les nœuds, et un backend objet :

```
# Extrait — à compléter avec la configuration officielle de la version 3.2.3
# https://grafana.com/docs/mimir/latest/configure/configure-object-storage/
multitenancy_enabled: false          # ou true + X-Scope-OrgID, décision à trancher
# non testé en multi-tenant dans ce dépôt
common:
  storage:
    backend: s3
    s3:
      endpoint: ${S3_FQDN}
      bucket_name: lgtm-mimir
      access_key_id: ${S3_ACCESS_KEY}       # depuis fichier env 0600
      secret_access_key: ${S3_SECRET_KEY}
      insecure: false
blocks_storage:
  storage_prefix: blocks
ingester:
  ring:
    replication_factor: 3
    zone_awareness_enabled: true          # si les VM sont zonées
limits:
  ingestion_rate: 100000                  # à caler
  ingestion_burst_size: 200000
alertmanager:
  # cible cluster : au moins 3 réplicas, peering
  # https://grafana.com/docs/mimir/latest/configure/configure-the-alertmanager/
```

Les clés S3 et les éventuels secrets d'Alertmanager (webhooks) viennent d'un fichier d'environnement `0600` chargé par l'unité systemd (`EnvironmentFile=`), pas du YAML en clair si la politique l'interdit.

Valider la configuration :

```
mimir -config.file=/etc/mimir/config.yml -config.expand-env=true -modules
# ou selon le binaire : mimir -help  /  mimirtool config
```

Alertmanager en cluster : récepteurs vers l'ITSM déjà utilisé (webhook). Le fichier de repli (`alertmanager-fallback.yml`) est versionné. `mimirtool alertmanager verify` et `mimirtool rules lint` avant chargement.

Consommateur Kafka **local** (otelcol-contrib sur un nœud proche de Mimir, ou pool dédié) : groupe `lgtm-mimir`, sujet `otlp_metrics`, exportateur `otlp_http` vers l'endpoint d'ingestion Mimir (`https://${MIMIR_FQDN}:9009/otlp`). Même modèle que la section 10 (brokers, TLS, `memory_limiter`).

Vérification : `curl --cacert ... https://${MIMIR_FQDN}:9009/ready` doit répondre `ready`. Les métriques d'ingestion apparaissent après le premier lot.

**Non testé :** cette configuration distribuée avec S3 réel dans ce dépôt.

---

## 8. Loki (journaux)

Sources : [Grafana Loki](https://grafana.com/docs/loki/latest/), modes [Simple Scalable](https://grafana.com/docs/loki/latest/get-started/deployment-modes/).

Cible : `deploymentMode` simple-scalable (`write`, `read`, `backend`) ou microservices, backend S3 (`bucket_name: lgtm-loki`). Facteur de réplication des ingesters à 3. Schéma de stockage de la version 3.7.x (suivre le schéma documenté pour 3.7.9, ne pas inventer un `schema_config` hors documentation officielle — **à copier depuis la doc de la version installée**).

`auth_enabled: false` uniquement si l'accès est déjà restreint par le réseau et un proxy TLS ; en cible durcie, activer le multi-tenant ou un reverse proxy authentifié. Décision à trancher.

Consommateur : groupe `lgtm-loki`, sujet `otlp_logs`, exportateur vers Loki (OTLP HTTP ou endpoint Loki officiel de la version). Vérification : `wget -O- https://${LOKI_FQDN}:3100/ready`.

Règles Loki (optionnel) vers l'Alertmanager de Mimir : `ruler.alertmanager_url`. **Non testé** ici.

---

## 9. Tempo (traces)

Sources : [Grafana Tempo](https://grafana.com/docs/tempo/latest/), [déploiement](https://grafana.com/docs/tempo/latest/setup/deployment/).

Cible : microservices (`distributor`, `ingester`, `querier`, `query-frontend`, `compactor`, `metrics-generator`). Backend S3 `lgtm-tempo`. Réplication des ingesters ≥ 3. Le `metrics-generator` écrit des span-metrics et un service graph vers Mimir (remote_write), utilisés par la carte des services Grafana.

Consommateur : groupe `lgtm-tempo`, sujet `otlp_spans`, encodage `otlp_proto`. Vérification : `https://${TEMPO_FQDN}:3200/ready`.

Le compteur `otelcol_receiver_accepted` du consommateur **n'existe qu'après le premier span**. Un Tempo « ready » avec LAG 0 et LOG-END-OFFSET 0 est normal tant qu'aucune trace n'a été émise.

---

## 10. Passerelles OpenTelemetry (otel-gw)

Sources : [configuration du collecteur](https://opentelemetry.io/docs/collector/configuration/), [exportateur kafka v0.164.0](https://github.com/open-telemetry/opentelemetry-collector-contrib/blob/v0.164.0/exporter/kafkaexporter/README.md), [récepteur kafka](https://github.com/open-telemetry/opentelemetry-collector-contrib/blob/v0.164.0/receiver/kafkareceiver/README.md), [exportateur elasticsearch](https://github.com/open-telemetry/opentelemetry-collector-contrib/blob/v0.164.0/exporter/elasticsearchexporter/README.md), [Prometheus agent](https://prometheus.io/docs/prometheus/latest/prometheus_agent/).

Plusieurs VM identiques (`otel-gw-01` …) derrière le VIP HAProxy + keepalived (ports 4317 et 4318). HAProxy en TCP (gRPC) et HTTP, `check`, pas de persistance obligatoire.

### 10.1 Compte d'écriture Elasticsearch (ROR)

**Ne pas** appeler `POST /_security/api_key` : cette API n'existe pas lorsque ROR remplace X-Pack Security.

Créer le compte `otel-writer` dans `readonlyrest.yml` (voir §13). Sur chaque otel-gw, saisir le mot de passe sans écho :

```
# Fichier /etc/otelcol-contrib/otelcol-contrib.conf — 0600, root:otelcol-contrib
install -m 0600 /dev/null /etc/otelcol-contrib/otelcol-contrib.conf
chown root:otelcol-contrib /etc/otelcol-contrib/otelcol-contrib.conf
# Dans un éditeur, ou :
read -rsp "Mot de passe ES otel-writer : " P; echo
printf 'ES_USER=otel-writer\nES_PASSWORD=%s\n' "$P" >> /etc/otelcol-contrib/otelcol-contrib.conf
unset P
chmod 0600 /etc/otelcol-contrib/otelcol-contrib.conf
grep -c '^ES_PASSWORD=.\+' /etc/otelcol-contrib/otelcol-contrib.conf   # attendu : 1 — n'affiche JAMAIS la valeur
```

Copier le CA ES dans `/etc/otelcol-contrib/es-http-ca.crt` (`0644`). **L'endpoint HTTPS doit utiliser le FQDN présent dans le SAN** (§4).

L'unité systemd charge `EnvironmentFile=/etc/otelcol-contrib/otelcol-contrib.conf`.

### 10.2 Configuration de la passerelle (extrait)

```
# /etc/otelcol-contrib/config.yaml — otelcol-contrib 0.164.0 — 0640 root:otelcol-contrib
receivers:
  otlp:
    protocols:
      grpc:
        endpoint: "0.0.0.0:4317"
        tls:
          cert_file: /etc/otelcol-contrib/tls/server.crt
          key_file: /etc/otelcol-contrib/tls/server.key
          ca_file: /etc/otelcol-contrib/tls/ca.crt
      http:
        endpoint: "0.0.0.0:4318"
        tls:
          cert_file: /etc/otelcol-contrib/tls/server.crt
          key_file: /etc/otelcol-contrib/tls/server.key
          ca_file: /etc/otelcol-contrib/tls/ca.crt
  kafka/elk:
    brokers: ["${KAFKA01_FQDN}:9092", "${KAFKA02_FQDN}:9092", "${KAFKA03_FQDN}:9092"]
    group_id: elk-es
    client_id: otel-gw-elk
    initial_offset: earliest
    logs:
      topics: [otlp_logs]
      encoding: otlp_proto
    message_marking:
      after: true
      on_error: false
    error_backoff:
      enabled: true
      initial_interval: 1s
      max_interval: 30s
      max_elapsed_time: 0
  kafka_metrics:
    brokers: ["${KAFKA01_FQDN}:9092", "${KAFKA02_FQDN}:9092", "${KAFKA03_FQDN}:9092"]
    client_id: otel-gw-kafkametrics
    collection_interval: 30s
    scrapers: [brokers, topics, consumers]
    group_match: "^(lgtm-.*|elk-es)$"
processors:
  memory_limiter:
    check_interval: 1s
    limit_mib: 2400          # ≈ 80 % de MemoryMax — à caler
    spike_limit_mib: 480
  batch: {}
exporters:
  kafka:
    brokers: ["${KAFKA01_FQDN}:9092", "${KAFKA02_FQDN}:9092", "${KAFKA03_FQDN}:9092"]
    client_id: otel-gw
    logs:
      topic: otlp_logs
      encoding: otlp_proto
    metrics:
      topic: otlp_metrics
      encoding: otlp_proto
    traces:
      topic: otlp_spans
      encoding: otlp_proto
    partition_traces_by_id: true
    partition_logs_by_resource_attributes: true
    producer:
      required_acks: -1
      compression: zstd
      allow_auto_topic_creation: false
  elasticsearch:
    endpoints: ["https://${ES_FQDN}:9200"]    # FQDN = SAN du certificat
    user: ${env:ES_USER}
    password: ${env:ES_PASSWORD}
    tls:
      ca_file: /etc/otelcol-contrib/es-http-ca.crt
    sending_queue:
      enabled: false
  otlp_http/mimir:
    endpoint: "https://${MIMIR_FQDN}:9009/otlp"
    tls:
      ca_file: /etc/otelcol-contrib/tls/ca.crt
service:
  telemetry:
    metrics:
      readers:
        - pull:
            exporter:
              prometheus:
                host: 127.0.0.1
                port: 8888
  pipelines:
    logs:
      receivers: [otlp]
      processors: [memory_limiter, batch]
      exporters: [kafka]
    metrics:
      receivers: [otlp]
      processors: [memory_limiter, batch]
      exporters: [kafka]
    traces:
      receivers: [otlp]
      processors: [memory_limiter, batch]
      exporters: [kafka]
    logs/elk:
      receivers: [kafka/elk]
      processors: [memory_limiter]
      exporters: [elasticsearch]
    metrics/kafka:
      receivers: [kafka_metrics]
      processors: [memory_limiter, batch]
      exporters: [otlp_http/mimir]
```

Points d'attention, déjà constatés en pratique :

- Le sujet par défaut de certains récepteurs n'est **pas** forcément `otlp_logs` : le bloc `logs: topics: [otlp_logs]` doit être **présent et correctement indenté**, aligné sur `group_id`. Un oubli produit `UNKNOWN_TOPIC_OR_PARTITION` si le sujet attendu (parfois `otel_logs`) n'existe pas.
- Les noms d'exportateurs `otlp_http` / `otlp_grpc` remplacent les anciens `otlphttp` / `otlp` signalés obsolètes par otelcol-contrib 0.164.0.
- `validate` peut se plaindre que `ES_PASSWORD` est vide si le fichier d'environnement n'est pas chargé dans le shell : c'est attendu. Charger avec `set -a; . /etc/otelcol-contrib/otelcol-contrib.conf; set +a` puis `otelcol-contrib validate --config=...`, enfin `unset ES_PASSWORD`.

```
systemctl enable --now otelcol-contrib
systemctl is-active otelcol-contrib
journalctl -u otelcol-contrib --since "-5 min" --no-pager | grep -iE 'error|x509|401|403|refused|UNKNOWN_TOPIC' || true
```

### 10.3 Prometheus en mode agent

Collecte des `node_exporter`, des endpoints de service et `remote_write` vers Mimir. Unité avec `--agent`, WAL dans `/var/lib/prometheus`. `promtool check config --agent`. Ce flux **ne passe pas par Kafka**.

---

## 11. Grafana HA, PostgreSQL, HAProxy et keepalived

Sources : [haute disponibilité Grafana](https://grafana.com/docs/grafana/latest/setup-grafana/set-up-for-high-availability/), [provisioning](https://grafana.com/docs/grafana/latest/administration/provisioning/), [LDAP](https://grafana.com/docs/grafana/latest/setup-grafana/configure-access/configure-authentication/ldap/).

### 11.1 PostgreSQL

Deux instances (primaire + réplique streaming), TLS, utilisateur dédié `grafana`, base `grafana`. Mot de passe dans un fichier `0600` lu par Grafana (`$__file{}` n'existe pas dans `grafana.ini` pour tous les champs : utiliser un fichier d'environnement `GF_DATABASE_PASSWORD` chargé par un drop-in systemd, `0600`). Sauvegardes : `pg_basebackup` ou l'outil interne déjà en vigueur, test de restauration obligatoire avant la prod.

### 11.2 Grafana — deux instances identiques

RPM officiel, drop-in hors ligne :

```
# /etc/systemd/system/grafana-server.service.d/offline.conf
[Service]
Environment=GF_ANALYTICS_REPORTING_ENABLED=false
Environment=GF_ANALYTICS_CHECK_FOR_UPDATES=false
Environment=GF_ANALYTICS_CHECK_FOR_PLUGIN_UPDATES=false
Environment=GF_NEWS_NEWS_FEED_ENABLED=false
Environment=GF_PLUGINS_PREINSTALL_DISABLED=true
EnvironmentFile=-/etc/grafana/grafana.env
```

Dans `grafana.ini` (ou variables `GF_`) :

- `[database]` type `postgres`, hôte du primaire (ou VIP PG), SSL requis.
- `[session]` (ou sessions en base — selon la version, la base partagée suffit pour que les deux instances se voient).
- `[server]` `domain = ${GRAFANA_FQDN}`, `root_url = https://${GRAFANA_FQDN}`, `protocol` derrière le proxy.
- `[auth.ldap] enabled = true`, `config_file = /etc/grafana/ldap.toml`, `allow_sign_up = true`.
- Mot de passe administrateur local **d'urgence** : changé dès la première installation, conservé au coffre (pas `admin` / `admin` en service).

### 11.3 Sources de données (provisioning)

Fichier `/etc/grafana/provisioning/datasources/lgtm.yaml`, `0640 root:grafana`. Mot de passe ES et certificats via `$__file{}`.

```
apiVersion: 1
datasources:
  - name: Mimir
    uid: mimir
    type: prometheus
    access: proxy
    url: https://${MIMIR_FQDN}:9009/prometheus
    isDefault: true
    jsonData:
      prometheusType: Mimir
      timeInterval: 30s
      tlsAuthWithCACert: true
      exemplarTraceIdDestinations:
        - name: trace_id
          datasourceUid: tempo
    secureJsonData:
      tlsCACert: $__file{/etc/grafana/certs/ca.crt}
  - name: Mimir Alertmanager
    uid: mimir-am
    type: alertmanager
    access: proxy
    url: https://${MIMIR_FQDN}:9009
    jsonData:
      implementation: mimir
      tlsAuthWithCACert: true
    secureJsonData:
      tlsCACert: $__file{/etc/grafana/certs/ca.crt}
  - name: Loki
    uid: loki
    type: loki
    access: proxy
    url: https://${LOKI_FQDN}:3100
    jsonData:
      tlsAuthWithCACert: true
      derivedFields:
        - name: TraceID
          matcherType: label
          matcherRegex: trace_id
          datasourceUid: tempo
          url: '$${__value.raw}'
    secureJsonData:
      tlsCACert: $__file{/etc/grafana/certs/ca.crt}
  - name: Tempo
    uid: tempo
    type: tempo
    access: proxy
    url: https://${TEMPO_FQDN}:3200
    jsonData:
      tlsAuthWithCACert: true
      tracesToLogsV2:
        datasourceUid: loki
        filterByTraceID: true
      tracesToMetrics:
        datasourceUid: mimir
      serviceMap:
        datasourceUid: mimir
      nodeGraph:
        enabled: true
    secureJsonData:
      tlsCACert: $__file{/etc/grafana/certs/ca.crt}
  - name: Elasticsearch (ELK, transitoire)
    uid: elk
    type: elasticsearch
    access: proxy
    url: https://${ES_FQDN}:9200
    basicAuth: true
    basicAuthUser: grafana-reader
    jsonData:
      index: 'logs-*'
      timeField: '@timestamp'
      tlsAuthWithCACert: true
    secureJsonData:
      tlsCACert: $__file{/etc/grafana/certs/ca.crt}
      basicAuthPassword: $__file{/etc/grafana/es-grafana-password}
```

« Save & test » sur chaque source. L'URL ES **doit** être le FQDN du SAN.

### 11.4 HAProxy et keepalived

Deux équilibreurs, VIP flottant, keepalived en unicast si le multicast est interdit. HAProxy : frontend `443` TLS (certificat du VIP `${GRAFANA_FQDN}`, SAN = VIP), backend les deux Grafana en HTTP local ou HTTPS, `check` sur `/api/health`. Même schéma pour otel-gw (TCP 4317, HTTPS 4318).

Vérification : arrêter `grafana-server` sur `grafana-01`, l'URL `https://${GRAFANA_FQDN}/api/health` doit rester `ok` (voir scénario §18).

---

## 12. Authentification LDAP Grafana

Source : [Configure LDAP authentication](https://grafana.com/docs/grafana/latest/setup-grafana/configure-access/configure-authentication/ldap/).

`ldap.toml`, `0640 root:grafana`. Mot de passe de liaison saisi dans l'éditeur, jamais par `echo`. Après toute modification : redémarrer Grafana.

```
# /etc/grafana/ldap.toml — EXEMPLE à adapter aux DN réels (non testé contre un AD de production)
[[servers]]
host = "${DC01_FQDN} ${DC02_FQDN}"
port = 636
use_ssl = true
start_tls = false
ssl_skip_verify = false
root_ca_cert = "/etc/grafana/certs/ad-ca.crt"
bind_dn = "CN=svc-grafana-ldap,OU=Services,DC=prod,DC=example"
# Mot de passe : champ bind_password dans ce fichier 0640, ou mécanisme d'environnement documenté par la version.
bind_password = ""
search_filter = "(sAMAccountName=%s)"
search_base_dns = ["OU=Utilisateurs,DC=prod,DC=example"]

[servers.attributes]
name = "givenName"
surname = "sn"
username = "sAMAccountName"
member_of = "memberOf"
email = "mail"

# Le premier mapping qui correspond gagne. Ordre : plus spécifique en tête.
[[servers.group_mappings]]
group_dn = "CN=GRP-OBS-ADMIN,OU=Groupes,DC=prod,DC=example"
org_role = "Admin"
grafana_admin = true

[[servers.group_mappings]]
group_dn = "CN=GRP-OBS-PLATEFORME,OU=Groupes,DC=prod,DC=example"
org_role = "Editor"

[[servers.group_mappings]]
group_dn = "CN=GRP-OBS-APPLICATIF,OU=Groupes,DC=prod,DC=example"
org_role = "Editor"

[[servers.group_mappings]]
group_dn = "CN=GRP-OBS-LECTURE,OU=Groupes,DC=prod,DC=example"
org_role = "Viewer"
```

Si `memberOf` n'est pas renvoyé, utiliser `group_search_filter` / `group_search_base_dns` comme dans la documentation officielle.

**Team Sync** (inscription automatique dans les *équipes* Grafana) est une fonction **Enterprise / Cloud** ([documentation](https://grafana.com/docs/grafana/latest/setup-grafana/configure-access/configure-team-sync/)). Pour Grafana OSS, installer le composant §14.

Conserver un administrateur local d'urgence au coffre.

---


### 12.2 SSO Grafana en édition OSS

Décision et limites : [ADR-011](architecture/adr/ADR-011_SSO_Grafana_OSS.md). Toutes les procédures de cette sous-section sont **non testées** dans ce dépôt. Les noms viennent de `variables/environnements.env` (`source` après `export LGTM_ENV=…`).

**Ce que l'édition OSS ne fournit pas** (documentation Grafana Labs) : SAML, Team Sync, permissions fines de sources de données, auditing natif `[auditing]`, greffon AppDynamics. **Compensations :** `grafana_acl_sync` (équipes / dossiers, §14) ; **organisations** Grafana pour isoler les sources (ce n'est pas l'onglet Permissions Enterprise) ; journaux standard Grafana et Apache expédiés vers Loki (ce n'est pas l'auditing structuré Enterprise).

Deux voies OSS, cumulables avec LDAP (ADR-006, secours et `group_mappings`) :

1. **Kerberos (recommandée pour les postes joints au domaine)** : Apache HTTP Server + `mod_auth_gssapi` devant Grafana, `[auth.proxy]`.
2. **OIDC vers AD FS** (uniquement si le rôle AD FS est installé) : `[auth.generic_oauth]`, avec `role_attribute_path` et, en Grafana ≥ 11.2 (donc **13.2.4**), `org_attribute_path` / `org_mapping` — [Generic OAuth](https://grafana.com/docs/grafana/latest/setup-grafana/configure-access/configure-authentication/generic-oauth/), [nouveauté 11.2 (GA OSS)](https://grafana.com/whats-new/map-org-specific-user-roles-from-your-oauth-provider/). `org_attribute_path` doit renvoyer un **tableau**.

Modèles rendus : `LGTM_ENV=prod ./scripts/rendre-config.sh` → `variables/rendu/${LGTM_ENV}/` (`grafana-auth-proxy.ini`, `httpd-mod-auth-gssapi.conf`, `krb5.conf`, `grafana-generic-oauth.ini`).

#### 12.2.1 Kerberos — compte de service, SPN, keytab (sur un DC, administrateur)

Outil officiel : [ktpass](https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/ktpass). `-pass *` provoque une invite (le mot de passe n'est pas sur la ligne de commande). `ktpass` **réinitialise** le mot de passe du compte : le générer une fois, le saisir à l'invite, ne pas le réutiliser ailleurs. Cocher dans les propriétés du compte la prise en charge **AES 256 bits**. Le SPN et le keytab portent le **FQDN que l'utilisateur tape** (`${GRAFANA_FQDN}`), y compris en HA (même keytab sur chaque Apache).

```powershell
# PowerShell sur un contrôleur de domaine — NON TESTÉ
# Mot de passe : invite uniquement (Read-Host / ktpass -pass *)
$u = "${KRB_SERVICE_ACCOUNT}"   # après source du fichier de variables, ou coller la valeur
New-ADUser -Name $u -SamAccountName $u -AccountPassword (Read-Host -AsSecureString -Prompt 'Mot de passe du compte de service') -Enabled $true -PasswordNeverExpires $true -KerberosEncryptionType AES256
# SPN HTTP/<FQDN du VIP Grafana>
setspn -S "HTTP/${GRAFANA_FQDN}" $u
# Contrôle des doublons (officiel setspn)
setspn -Q "HTTP/${GRAFANA_FQDN}"
setspn -X
# Keytab AES-256 — le fichier produit est un secret (le transférer par SFTP, pas par courriel)
ktpass -princ "HTTP/${GRAFANA_FQDN}@${KRB_REALM}" -mapuser "$u@${KRB_REALM}" -crypto AES256-SHA1 -ptype KRB5_NT_PRINCIPAL -pass * -out C:\Temp\grafana.keytab
```

Sur chaque nœud Grafana / Apache (RHEL 8), après transfert SFTP :

```bash
# Paquets RHEL 8 (hors ligne, même chaîne que le §2) : httpd, mod_ssl, mod_auth_gssapi, krb5-workstation
# SELinux : autoriser httpd à joindre Grafana en local (boolean documenté Red Hat)
#   setsebool -P httpd_can_network_connect 1
install -o apache -g apache -m 0640 /chemin/recu/grafana.keytab "${KRB_KEYTAB}"
# krb5.conf : modèle variables/templates/krb5.conf.tmpl (royaume ${KRB_REALM}, KDC ${DC01_FQDN})
# VirtualHost : modèle httpd-mod-auth-gssapi.conf.tmpl (SAN = ${GRAFANA_FQDN})
# Relire, puis :
apachectl configtest && systemctl enable --now httpd
```

`mod_auth_openidc` existe dans AppStream RHEL 8 (module `mod_auth_openidc`) si l'on préfère qu'Apache soit le client OIDC, puis `[auth.proxy]`. La voie OIDC **recommandée** reste Grafana `[auth.generic_oauth]` (client officiel, §12.2.2), sans ce module.

#### 12.2.2 Grafana `[auth.proxy]` et durcissement

Documentation : [Configure auth proxy](https://grafana.com/docs/grafana/latest/setup-grafana/configure-access/configure-authentication/auth-proxy/). Extraire depuis le modèle rendu, relire, fusionner avec `grafana.ini` existant.

Points obligatoires :

- `http_addr = 127.0.0.1` — Grafana n'accepte plus les clients utilisateurs directement. Pare-feu : port 3000 limité à la boucle locale (et au dépannage depuis le bastion en SSH).
- `header_name = ${AUTH_PROXY_HEADER}` (`X-WEBAUTH-USER`).
- `whitelist = ${AUTH_PROXY_WHITELIST}` — **uniquement** l'IP source TCP d'Apache (colocalisé : `127.0.0.1`). Cette liste ne lit pas `X-Forwarded-For` (comportement documenté : éviter l'usurpation).
- `RequestHeader unset Authorization` côté Apache (exemple officiel Grafana).
- `GssapiLocalName On` pour retrancher `@${KRB_REALM}` et obtenir un identifiant aligné sur `sAMAccountName` (à vérifier sur la version du module, **non testé**).
- Certificat Apache : **SAN = `${GRAFANA_FQDN}`**, CA interne dans les postes.
- HAProxy devant Apache : soit terminaison TLS déjà sur Apache (VIP en TCP vers 443), soit cohérence du SAN ; le SPN reste `HTTP/${GRAFANA_FQDN}`.
- Compte d'administration local Grafana : conservé pour l'urgence (accès SSH + `localhost:3000`).

```bash
# Contrôles (aucun secret en argument)
openssl s_client -connect "${GRAFANA_FQDN}:${PORT_GRAFANA}" -servername "${GRAFANA_FQDN}" </dev/null 2>/dev/null \
  | openssl x509 -noout -ext subjectAltName
# Depuis le nœud : une requête qui usurpait l'en-tête SANS passer par Apache doit échouer
# (lancer depuis une autre machine vers le port 3000, qui doit être fermé).
```

#### 12.2.3 OIDC — Generic OAuth vers AD FS (optionnel)

Si et seulement si AD FS est installé. Découverte : `${ADFS_WELLKNOWN}`. Endpoints documentés : `${ADFS_AUTH_URL}`, `${ADFS_TOKEN_URL}` ([concepts AD FS OIDC](https://learn.microsoft.com/en-us/windows-server/identity/ad-fs/development/ad-fs-openid-connect-oauth-concepts)). Enregistrer une application AD FS, URL de rappel **exacte** `${OAUTH_REDIRECT_URL}` (`${GRAFANA_URL}/login/generic_oauth`). Secret client dans un `EnvironmentFile` `0600` (`GF_AUTH_GENERIC_OAUTH_CLIENT_SECRET`). Modèle : `grafana-generic-oauth.ini.tmpl`. Caler `role_attribute_path` et, si besoin, `org_attribute_path` / `org_mapping` sur les **revendications réellement émises** (à lire dans le jeton, **non testé**). `use_pkce = true` est recommandé (option documentée). Team Sync reste Enterprise.

#### 12.2.4 Diagrammes de séquence

```mermaid
sequenceDiagram
  autonumber
  participant P as Poste Windows (domaine)
  participant VIP as VIP HTTPS ${GRAFANA_FQDN}
  participant AP as Apache mod_auth_gssapi
  participant DC as DC Kerberos :88
  participant GF as Grafana 127.0.0.1:3000
  P->>VIP: HTTPS (Negotiate)
  VIP->>AP: TLS SAN=${GRAFANA_FQDN}
  AP->>DC: Kerberos (SPN HTTP/${GRAFANA_FQDN})
  DC-->>AP: ticket accepté
  AP->>GF: HTTP + ${AUTH_PROXY_HEADER} (sAMAccountName)
  Note over AP,GF: whitelist = IP TCP d'Apache uniquement
  GF-->>P: session Grafana
  Note over GF: Équipes / dossiers : grafana_acl_sync (Team Sync = Enterprise)
```

```mermaid
sequenceDiagram
  autonumber
  participant P as Navigateur
  participant GF as Grafana OSS (${GRAFANA_FQDN})
  participant ADFS as AD FS (${ADFS_FQDN})
  P->>GF: /login (bouton AD FS)
  GF->>ADFS: redirection authorize (OIDC, PKCE)
  ADFS->>P: authentification (session AD FS / Kerberos AD FS)
  P->>ADFS: consentement le cas échéant
  ADFS-->>GF: code → ${ADFS_TOKEN_URL}
  GF->>ADFS: échange, UserInfo
  GF->>GF: role_attribute_path / org_mapping (OSS ≥ 11.2)
  GF-->>P: session
```

#### 12.2.5 Journaux vers Loki (compensation d'audit)

Configurer l'agent déjà prévu (journald) pour collecter `grafana-server` et `httpd` (`/var/log/httpd/*` ou journald `httpd`) vers la passerelle OTLP, sujet `otlp_logs`, Loki. Requête d'exemple, à adapter : `{service_name=~"grafana|httpd"}`. Cela **ne remplace pas** [l'auditing Enterprise](https://grafana.com/docs/grafana/latest/setup-grafana/configure-security/audit-grafana/).

---
## 13. Intégration ReadonlyREST

Sources : [documentation ROR Elasticsearch](https://docs.readonlyrest.com/elasticsearch) (blocs, `auth_key_pbkdf2`, connecteur `ldaps`, `ldap_auth`, ordre des blocs, `force_load_from_file`).

### 13.1 Hachage du mot de passe (aucun écho)

```
python3 -c 'import getpass,hashlib,base64; p=getpass.getpass("Mot de passe otel-writer: ").encode(); print("otel-writer:"+base64.b64encode(hashlib.pbkdf2_hmac("sha512",p,p,10000,64)).decode())'
```

Paramètres imposés par ROR : HmacSHA512, 10 000 itérations, clé 512 bits, sel = la valeur elle-même ([docs](https://docs.readonlyrest.com/elasticsearch)). Répéter pour `grafana-reader`.

### 13.2 Blocs à placer **en tête** de `access_control_rules`

Un extrait aligné sur les groupes AD est fourni dans `scripts/ror-acl-groups.example.yml`. Principe :

```
readonlyrest:
  access_control_rules:
    - name: "otel-writer - ecriture logs"
      type: allow
      auth_key_pbkdf2: "otel-writer:<HASH>"
      indices: ["logs-*"]
      actions: ["indices:data/write/*", "indices:admin/auto_create", "indices:admin/mapping/auto_put", "indices:admin/create", "cluster:monitor/*"]

    - name: "grafana-reader - lecture logs"
      type: allow
      auth_key_pbkdf2: "grafana-reader:<HASH>"
      indices: ["logs-*"]
      actions: ["indices:data/read/*", "indices:admin/mappings/get", "indices:admin/get", "indices:admin/resolve/*", "cluster:monitor/*"]

    # Blocs ldap_auth : voir scripts/ror-acl-groups.example.yml
    # Connecteur :
  ldaps:
    - name: "ldap-ad"
      host: "${DC01_FQDN}"
      port: 636
      ssl_enabled: true
      ssl_trust_all_certs: false
      bind_dn: "CN=svc-ror-ldap,OU=Services,DC=prod,DC=example"
      bind_password: "${env:ROR_LDAP_BIND_PASSWORD}"
      users:
        search_user_base_DN: "OU=Utilisateurs,DC=prod,DC=example"
        user_id_attribute: "sAMAccountName"
      groups:
        search_groups_base_DN: "OU=Groupes,DC=prod,DC=example"
```

> **Non testé :** la liste exacte des `actions` utilisées par l'exportateur otelcol-contrib 0.164.0 et par la source Grafana 13.2 contre ROR. En cas de 403, le journal ES indique l'action refusée : l'ajouter au bloc, redémarrer.
>
> Attributs de groupes AD (`unique_member_attribute`, etc.) : adapter d'après la documentation du connecteur et valider en préprod. Ne pas activer `ssl_trust_all_certs` en production.

En édition gratuite : `systemctl restart elasticsearch`. Si les changements sont ignorés : `readonlyrest.force_load_from_file: true` dans `elasticsearch.yml`, puis redémarrage.

### 13.3 Vérifications (le mot de passe est demandé, non affiché)

```
ES=https://${ES_FQDN}:9200
CA=/etc/otelcol-contrib/es-http-ca.crt
curl --cacert "$CA" -u otel-writer "$ES/_cluster/health?pretty"          # 200
# Une écriture de test, puis suppression — uniquement sur un index de test dédié, jamais un index métier
curl --cacert "$CA" -u grafana-reader "$ES/_cat/indices/logs-*?v"
curl --cacert "$CA" -u grafana-reader -o /dev/null -w '%{http_code}\n' -XDELETE "$ES/logs-un-index-interdit"   # 403 attendu
```

---

## 14. Composant de chargement des ACL

Fichiers : `scripts/grafana_acl_sync.py`, `scripts/acl-config.example.yaml`, `scripts/requirements.txt`, `scripts/grafana-acl-sync.service`, `scripts/grafana-acl-sync.timer`, `scripts/README.md`.

Installation (VM relais ou `grafana-01`) :

1. Créer l'utilisateur `grafana-acl-sync`, répertoire `/opt/grafana-acl-sync`, `venv`, installer les roues hors ligne.
2. Copier le script, la configuration (DN **réels**), le tableau de bord.
3. Créer un **compte de service Grafana** (rôle suffisant pour équipes, dossiers, tableaux de bord) et un jeton, saisi dans `/etc/grafana-acl-sync/token` (`0600`). Mot de passe de liaison LDAP dans `/etc/grafana-acl-sync/ldap-bind-password` (`0600`).
4. Contrôles :

```
/opt/grafana-acl-sync/venv/bin/python3 -m py_compile /opt/grafana-acl-sync/grafana_acl_sync.py
/opt/grafana-acl-sync/venv/bin/python3 /opt/grafana-acl-sync/grafana_acl_sync.py --help
/opt/grafana-acl-sync/venv/bin/python3 /opt/grafana-acl-sync/grafana_acl_sync.py \
  --config /opt/grafana-acl-sync/acl-config.yaml --dry-run
# Puis sans --dry-run, une première fois en observation, puis activer le timer
install -m 0644 scripts/grafana-acl-sync.service scripts/grafana-acl-sync.timer /etc/systemd/system/
systemctl daemon-reload
systemctl enable --now grafana-acl-sync.timer
systemctl list-timers grafana-acl-sync.timer
```

Codes de sortie : 0 succès, 1 configuration, 2 LDAP, 3 Grafana, 4 succès partiel, 5 dépendance.

Les utilisateurs AD absents de Grafana (jamais connectés) sont **signalés** et inscrits au tour suivant. **Le script a été validé en `--mock --dry-run` et par `py_compile` ; il n'a pas été exécuté contre un AD ni un Grafana réels dans ce dépôt.**

```mermaid
flowchart TD
  A["Timer 15 min"] --> B["Lecture groupes AD en LDAPS"]
  B --> C["API Grafana : équipes, membres, dossiers, permissions, tableaux de bord"]
  C --> D{"Écarts ?"}
  D -->|oui| E["Créations / mises à jour idempotentes"]
  D -->|non| F["Aucun changement"]
  E --> G["Extrait ROR optionnel — intégration manuelle"]
```

---

## 15. Intégration SCOM 2019 et AppDynamics on-premises

Voir [ADR-008](architecture/adr/ADR-008_Integration_SCOM_AppDynamics.md) et la figure [06_integration_scom_appd](architecture/diagrammes/06_integration_scom_appd.png). Les FQDN sont ceux de `variables/environnements.env`.

### 15.1 SCOM 2019

Version retenue : **System Center 2019 Operations Manager**. Cycle de vie officiel ([Product Lifecycle](https://learn.microsoft.com/en-us/lifecycle/products/system-center-2019-operations-manager), politique Fixed) : support standard terminé le 10 avril 2024 (heure du Pacifique) ; **support étendu jusqu'au 10 avril 2029**, 06:59:59 PT. Au 12 novembre 2026, le produit est en support étendu. Planifier la migration vers une version en support standard (2022 ou ultérieure) avant cette date. Certaines pages Microsoft 2019 affichent une bannière « end of support » invitant à passer à 2022 ; les dates contraignantes sont celles de la page Lifecycle.

**Voie A (recommandée en premier) :** sur les serveurs Windows concernés, ou sur un collecteur WEF, installer otelcol-contrib (MSI 0.164.0, empreinte vérifiée) avec le récepteur [`windowseventlog`](https://github.com/open-telemetry/opentelemetry-collector-contrib/blob/v0.164.0/receiver/windowseventlogreceiver/README.md). Exporter en OTLP TLS vers `https://${OTEL_GW_FQDN}:${PORT_OTEL_HTTP}`. Choisir les canaux (Application, System, ForwardedEvents) ; le canal Security demande une étude de volume et d'autorisation. **Non testé** ici.

**Voie B :** [SCOM-Prometheus-Exporter](https://github.com/opslogix/SCOM-Prometheus-Exporter) (communautaire, **non officiel Microsoft**, prérequis du projet « Microsoft SCOM 2019 or later », licence AGPL-3.0) — à qualifier avant tout déploiement prod (charge sur le SDK / le serveur de gestion), puis scrape par l'agent Prometheus. **Non testé**.

**Voie C — API REST et SDK :** SCOM 2019 expose une API REST (depuis 1801). À partir de UR1, les appels mutateurs exigent le jeton CSRF `SCOM-CSRF-TOKEN`. Le SDK et le Connector Framework (OMCF) sont documentés par Microsoft ([third-party integration, vue sc-om-2019](https://learn.microsoft.com/en-us/system-center/scom/plan-thirdparty-integration?view=sc-om-2019)). Un greffon Grafana tierce ([SCOM Data Source for Grafana, OpsLogix](https://github.com/opslogix/SCOM-Data-Source-Grafana)) s'appuie sur l'API REST et la console `${SCOM_URL}` (exemple : `https://scom.exemple.local/OperationsManager`, port 443) : ni Grafana Labs, ni Microsoft ; à qualifier (authentification, CSRF, HTTPS). **Non testé**. La consultation SQL des bases Operations Manager et Data Warehouse n'est pas retenue comme voie principale (données sensibles).

Ports utiles : [firewall SCOM 2019](https://learn.microsoft.com/en-us/system-center/scom/plan-security-config-firewall?view=sc-om-2019) — console 443, agents / MS 5723-5724.

### 15.2 AppDynamics — contrôleur on-premises

Le contrôleur est **sur site**. Il reste en place. URL d'exemple : `${APPD_URL}` (`https://appd.exemple.local:8181`).

- **Ports** ([Port Settings on-premises](https://docs.appdynamics.com/appd/onprem/24.x/latest/en/planning-your-deployment/port-settings)) : HTTPS **8181** (à utiliser) ; HTTP **8090** à désactiver et bloquer ; Enterprise Console 9191 ; Events Service 9080/9081 si présent.
- **Certificats :** remplacer un éventuel certificat auto-signé par un certificat de l'autorité interne. Le **SAN doit contenir le FQDN réellement utilisé** (`${APPD_FQDN}`). Le CA interne est ajouté au truststore de Grafana et des agents (les agents .NET l'exigent). Contrôle : `openssl s_client -connect ${APPD_FQDN}:${PORT_APPD_HTTPS} -servername ${APPD_FQDN}`. **Non testé**.
- **LDAP :** *Controller Settings > Administration > Authentication Provider > LDAP*. LDAPS **636**, Bind DN, Base DN, attribut `sAMAccountName` pour AD, mapping des groupes vers les rôles AppDynamics. Compte d'administration local en secours si l'annuaire est indisponible. Recommandation : même AD que Grafana (configurations indépendantes). **Non testé**.
- Le greffon Grafana [`dlopes7-appdynamics-datasource`](https://grafana.com/docs/plugins/dlopes7-appdynamics-datasource/latest/) est **Enterprise** (Grafana ≥ 11.6.7, licence requise). L'URL pointe vers `${APPD_URL}`, avec confiance au CA du contrôleur. Fonctionnement contre un contrôleur on-premises : **à vérifier sur la version installée (non testé)**. Sans licence, placer un lien vers `${APPD_URL}` dans la vue unique et corréler par `service.name`.
- *Splunk AppDynamics for OpenTelemetry* (documentation **On-Premises**) envoie des traces **vers** le contrôleur (`otlphttp`, en-tête `x-api-key`). Endpoint documenté : `${APPD_OTEL_INGEST}` (`https://<dns-contrôleur>:8181/otis/ingest`) — **à vérifier sur la version du contrôleur, non testé**. Ce n'est **pas** un flux AppDynamics → Tempo. La cible de migration des traces est l'instrumentation OTel native vers `${OTEL_GW_FQDN}`. Un extrait commenté figure dans `variables/templates/otelcol-contrib.yaml.tmpl`.

---

## 16. Vue unique (« one screen »)

Fichier `dashboards/one_screen_home.json` (JSON validé, uid `lgtm-one-screen`). Le provisionner via `grafana_acl_sync` (dossier « Plateforme observabilité ») ou via `/etc/grafana/provisioning/dashboards/`.

Le tableau de bord résume : LAG Kafka par groupe, membres des groupes, cibles `up`, débits d'ingestion et d'échec otelcol, emplacement santé ES (si exportateur ou sonde), alertes, emplacements SCOM et AppDynamics, raccourcis de drill-down.

Adapter les libellés `job` une fois la collecte définie. **Non exercé contre une plateforme de production.**

En Explore, après un test (§17) : `lab_test_kafka` dans Mimir, `{service_name="test-kafka"}` dans Loki, service `test-kafka` dans Tempo, `logs-*` dans Elasticsearch.

---

## 17. Vérifications de bout en bout

À exécuter **soi-même** (aucun besoin d'en partager la sortie, aucun secret affiché).

### 17.1 Santé des services

```
systemctl is-active kafka mimir loki tempo otelcol-contrib grafana-server prometheus
# Sur chaque VM de stockage, /ready (le port n'existe que sur SA VM) :
curl -fsS --cacert /etc/pki/... https://127.0.0.1:9009/ready ; echo   # Mimir
curl -fsS https://127.0.0.1:3100/ready ; echo                          # Loki
curl -fsS https://127.0.0.1:3200/ready ; echo                          # Tempo
wget -O- http://127.0.0.1:8888/metrics | grep -c otelcol_              # collecteur local
```

Ne pas enchaîner les trois ports sur la même machine : 9009, 3100 et 3200 n'écoutent chacun que sur leur rôle.

### 17.2 Kafka

```
/opt/kafka/bin/kafka-consumer-groups.sh --bootstrap-server ${KAFKA01_FQDN}:9092 --describe --group lgtm-loki
/opt/kafka/bin/kafka-consumer-groups.sh --bootstrap-server ${KAFKA01_FQDN}:9092 --describe --group lgtm-mimir
/opt/kafka/bin/kafka-consumer-groups.sh --bootstrap-server ${KAFKA01_FQDN}:9092 --describe --group lgtm-tempo
/opt/kafka/bin/kafka-consumer-groups.sh --bootstrap-server ${KAFKA01_FQDN}:9092 --describe --group elk-es
```

Après un test d'émission, le LAG doit tendre vers 0. Un `LOG-END-OFFSET` à 0 avec des tirets dans CURRENT-OFFSET est **normal** tant qu'aucun message n'a été produit.

### 17.3 Émission de test (sur une passerelle)

Utiliser un client OTLP officiel ou `telemetrygen` s'il figure dans le lot hors ligne. Envoyer une métrique `lab_test_kafka=42`, un journal et une trace `service.name=test-kafka`, vers `https://${OTEL_GW_FQDN}:4318` (CA du VIP). Puis retrouver les trois signaux dans Grafana et, pour le journal, dans ES (`curl -u grafana-reader --cacert ...`).

### 17.4 LDAP et ACL

Se connecter avec un compte AD de chaque groupe d'exemple (ou réel), vérifier le rôle. Lancer `grafana_acl_sync --dry-run` puis observer les équipes et dossiers.

### 17.5 Certificats

Contrôle §4.4 sur **tous** les VIP, avant d'ouvrir le trafic applicatif.

---

## 18. Exploitation

### 18.1 Sauvegardes

| Donnée | Méthode | Test de restauration |
|---|---|---|
| PostgreSQL Grafana | `pg_basebackup` / outil interne, rétention à définir | **obligatoire** en préprod |
| Configurations | Git interne (sans secrets) + copies `0600` hors bande | réinstallation sur VM de test |
| Seaux S3 | Politique du service objet (versioning, réplication) | restauration d'un préfixe |
| Métadonnées Kafka | Procédure officielle de la version 4.4 + snapshots VM | banc de test |
| `readonlyrest.yml` | Git + copie | redémarrage ES sur banc |

Les blocs objet **sont** l'historique Mimir / Loki / Tempo : une sauvegarde des seuls disques locaux des ingesters est insuffisante.

### 18.2 Mises à jour

Préprod d'abord. Lire les notes de version officielles. ROR : désinstaller / dé-patcher / installer le build **aligné sur la nouvelle version ES**, re-patcher ([docs ROR](https://docs.readonlyrest.com/elasticsearch)). Kafka : suivre le guide d'upgrade 4.x (rolling, un courrier à la fois, ISR complet). Grafana / Mimir / Loki / Tempo : rolling derrière le VIP. Toujours vérifier les empreintes du nouveau lot hors ligne.

### 18.3 Scénarios de panne

#### Perte d'un courrier Kafka

```mermaid
sequenceDiagram
  participant P as Producteur otel-gw
  participant K1 as kafka-01 leader
  participant K2 as kafka-02 ISR
  participant K3 as kafka-03
  Note over K3: panne
  P->>K1: produce acks=all
  K1->>K2: réplication
  K2-->>K1: ack ISR=2
  K1-->>P: OK
  Note over K1,K2: partitions de K3 élisent un nouveau leader
```

Contrôle : `kafka-metadata-quorum.sh describe --status`, `kafka-topics.sh --describe` (ISR ≥ 2), LAG des groupes. **Ne pas** éteindre un second courrier. Au retour de K3, attendre qu'il réintègre l'ISR avant toute autre maintenance.

#### Perte d'un ingester (Mimir / Loki / Tempo)

Les réplicas d'ingestion (RF=3) conservent les blocs non flushed. Kafka tamponne le surplus. Contrôle : `/ready` des autres, LAG du groupe concerné qui peut monter puis redescendre au retour. Si le LAG ne redescend pas : journaux de l'ingester, objet S3 joignable, disque.

#### Perte d'une instance Grafana

```mermaid
sequenceDiagram
  participant U as Utilisateur
  participant VIP as HAProxy / keepalived
  participant G1 as grafana-01
  participant G2 as grafana-02
  participant PG as PostgreSQL
  Note over G1: arrêt
  U->>VIP: HTTPS
  VIP->>G2: bascule (check /api/health)
  G2->>PG: sessions et tableaux de bord partagés
  G2-->>U: même URL
```

Contrôle : `https://${GRAFANA_FQDN}/api/health`. L'utilisateur peut devoir rafraîchir.

#### Perte d'une passerelle otel-gw

Le VIP dirige vers les instances restantes. Les agents ne changent rien. Contrôle : `ss` sur le VIP, journaux HAProxy, débit `otelcol_receiver_accepted` sur les survivants.

#### Certificat expiré

```mermaid
flowchart TD
  A["Symptôme : x509 certificate has expired<br/>ou handshake failure"] --> B["Identifier le service : journal otelcol / Grafana / Kafka"]
  B --> C["Émettre un nouveau certificat, MÊME SAN complet"]
  C --> D["Déposer, restorecon, redémarrer une instance à la fois"]
  D --> E["openssl s_client : notAfter à jour, SAN inchangé"]
  E --> F["LAG elk-es ou files d'export redescendent"]
```

Prévention : alerte J-30, exercice de rotation en préprod.

### 18.4 Supervision de la supervision

Alertes minimales (Mimir, routées vers l'ITSM) :

- `sum by (group)(kafka_consumer_group_lag{group=~"lgtm-.*|elk-es"})` au-dessus d'un seuil pendant plusieurs minutes.
- `up` à 0 pour une cible critique.
- Taux `otelcol_exporter_send_failed_*` non nul.
- Expiration de certificat < 30 jours.
- Prometheus agent : WAL qui grossit (Mimir injoignable).
- Espace disque Kafka et inode.

Ces règles se formalisent avec `mimirtool rules` (`mimirtool rules lint` puis `load`). Le seuil exact se cale en préprod.

### 18.5 Liste de contrôle go-live préprod → prod

1. Hypothèses H1–H11 tranchées par écrit (objet, AD, FQDN, rétentions, licences).
2. Empreintes du lot prod vérifiées, identiques à celles validées en préprod (ou écart documenté).
3. SAN de **tous** les certificats prod contrôlés au FQDN réel, **avant** le trafic.
4. Règles pare-feu ouvertes et testées (`nc -vz`).
5. Exercices de panne §18.3 réalisés en préprod, durées mesurées.
6. Rotation d'un certificat testée. Restauration PostgreSQL testée.
7. `grafana_acl_sync` exécuté contre l'AD de préprod (pas seulement `--mock`).
8. Double écriture : LAG `elk-es` à 0, échantillon comparé, pas de 403.
9. Vue unique provisionnée, « Save & test » des sources OK.
10. Alertes de supervision de la supervision routées, astreinte informée.
11. Plan de retour arrière lu et applicable (retrait ou rétablissement du pipeline `logs/elk`).
12. Compte d'urgence Grafana au coffre, administrateur initial changé.

---

## 19. Sources

- Apache Kafka 4.4 : [KRaft](https://kafka.apache.org/44/operations/kraft/), [courtiers](https://kafka.apache.org/44/configuration/broker-configs/), [Java](https://kafka.apache.org/44/operations/java-version/)
- SSO OSS : [ADR-011](architecture/adr/ADR-011_SSO_Grafana_OSS.md), [Auth proxy](https://grafana.com/docs/grafana/latest/setup-grafana/configure-access/configure-authentication/auth-proxy/), [Generic OAuth](https://grafana.com/docs/grafana/latest/setup-grafana/configure-access/configure-authentication/generic-oauth/) (`org_mapping` OSS depuis [11.2](https://grafana.com/whats-new/map-org-specific-user-roles-from-your-oauth-provider/)), [ktpass](https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/ktpass), [AD FS OIDC](https://learn.microsoft.com/en-us/windows-server/identity/ad-fs/development/ad-fs-openid-connect-oauth-concepts), [Auditing Enterprise](https://grafana.com/docs/grafana/latest/setup-grafana/configure-security/audit-grafana/)
- Grafana : [HA](https://grafana.com/docs/grafana/latest/setup-grafana/set-up-for-high-availability/), [LDAP](https://grafana.com/docs/grafana/latest/setup-grafana/configure-access/configure-authentication/ldap/), [Team Sync (Enterprise)](https://grafana.com/docs/grafana/latest/setup-grafana/configure-access/configure-team-sync/), [provisioning](https://grafana.com/docs/grafana/latest/administration/provisioning/), [API dossiers](https://grafana.com/docs/grafana/latest/developer-resources/api-reference/http-api/folder/), [comptes de service](https://grafana.com/docs/grafana/latest/administration/service-accounts/)
- Mimir, Loki, Tempo : documentation Grafana Labs des versions de référence
- OpenTelemetry Collector : [configuration](https://opentelemetry.io/docs/collector/configuration/), exportateurs et récepteurs contrib v0.164.0
- ReadonlyREST : [For Elasticsearch](https://docs.readonlyrest.com/elasticsearch)
- AppDynamics greffon : [dlopes7-appdynamics-datasource](https://grafana.com/docs/plugins/dlopes7-appdynamics-datasource/latest/) (Enterprise)
- AppDynamics on-premises : [Port Settings](https://docs.appdynamics.com/appd/onprem/24.x/latest/en/planning-your-deployment/port-settings), [OpenTelemetry Configure Exporters (On-Premises)](https://help.splunk.com/en/appdynamics-on-premises/application-performance-monitoring/26.7.0/splunk-appdynamics-for-opentelemetry/configure-the-opentelemetry-collector/configure-exporters)
- SCOM 2019 : [cycle de vie](https://learn.microsoft.com/en-us/lifecycle/products/system-center-2019-operations-manager), [intégration tierce](https://learn.microsoft.com/en-us/system-center/scom/plan-thirdparty-integration?view=sc-om-2019), [pare-feu](https://learn.microsoft.com/en-us/system-center/scom/plan-security-config-firewall?view=sc-om-2019)
- SCOM exportateur communautaire : [OpsLogix SCOM-Prometheus-Exporter](https://github.com/opslogix/SCOM-Prometheus-Exporter) (SCOM 2019+)
- systemd : [systemd.resource-control](https://www.freedesktop.org/software/systemd/man/latest/systemd.resource-control.html)
- SELinux / firewalld : documentation RHEL 8 Red Hat

---

## Annexe A — Points non testés et limites

| # | Point | État |
|---|---|---|
| 1 | Installation réelle sur RHEL 8 (RPM, SELinux, firewalld) | Procédures rédigées, **non exécutées** dans ce dépôt |
| 2 | Cluster Kafka 4.4 à 3 courtiers, formatage KRaft, quorum, SSL | Formalisme classique documenté ; KIP-853 à vérifier ; **non testé** ici |
| 3 | Mimir / Loki / Tempo en mode distribué + S3 réel | Extraits alignés sur la doc ; **non testés** |
| 4 | Exportateur otelcol elasticsearch contre ROR (actions exactes, user/password) | Fondé sur la doc ROR et la doc de l'exportateur ; **non testé** bout en bout |
| 5 | LDAP Grafana et `ldap_auth` ROR contre un AD réel | Exemples de DN ; **non testés** |
| 6 | `grafana_acl_sync` contre un vrai Grafana et un vrai AD | Validé `--help`, `py_compile`, `--mock --dry-run` uniquement |
| 7 | Tableau de bord d'accueil contre des métriques réelles | JSON valide ; **non exercé** |
| 8 | HAProxy / keepalived, bascule VIP | Procédure écrite, **non exécutée** |
| 9 | MinIO distribué, nombre de nœuds, erasure coding | Dépend de la version ; **à confirmer** |
| 10 | Voies SCOM 2019 B/C, greffon AppDynamics Enterprise contre le contrôleur on-prem, LDAP et certificats AppD | Qualification et licence à confirmer ; **non testé** |
| 11 | mTLS Kafka | Optionnel, **non configuré testé** |
| 12 | Charges et cardinalités de production | Estimations uniquement |
| 13 | Compatibilité mapping OTel / mapping Logstash existant sur ES | À vérifier en préprod |
| 14 | SSO Kerberos (httpd + mod_auth_gssapi + keytab) et OIDC AD FS | Procédures rédigées, **non testées** |

Les points ouverts (hypothèses H1–H11) figurent dans `architecture/01_Document_architecture.md`, §9. H4 (DNS/VIP), H8 (AppDynamics on-premises) et H9 (SCOM 2019) ont été tranchés ; la licence Enterprise et la qualification des voies B/C restent ouvertes.
