# ADR-008 — Intégration SCOM 2019 et AppDynamics on-premises

- **Statut :** accepté (décisions d'environnement tranchées : SCOM **2019**, contrôleur AppDynamics **sur site**)
- **Date :** 2026-11-12
- **Décideurs :** architecture / exploitation / sécurité

## Contexte

SCOM est le superviseur d'infrastructure Microsoft déjà en place ; la version retenue est **System Center 2019 Operations Manager**. AppDynamics est l'APM déjà en place, avec un **contrôleur on-premises** (sur site). La plateforme LGTM ne les remplace pas d'emblée : elle doit les **faire apparaître dans la vue unique** Grafana, puis, progressivement, accueillir les charges que l'on choisira de migrer (surtout les traces, via OpenTelemetry).

Les FQDN et VIP d'exemple (`scom.exemple.local`, `appd.exemple.local`, et leurs équivalents préprod) sont définis dans [variables/environnements.env](../../variables/environnements.env) — **modifier ici seulement**.

## Décision

### SCOM 2019

**Cycle de vie (source officielle Microsoft, politique « Fixed Lifecycle ») :**

| Jalon | Date officielle (heure du Pacifique) |
| --- | --- |
| Début | 14 mars 2019 |
| Fin du support standard (Mainstream) | 10 avril 2024, 06:59:59 PT |
| Fin du support étendu (Extended) | **10 avril 2029**, 06:59:59 PT |

Source : [System Center 2019 Operations Manager — Product Lifecycle](https://learn.microsoft.com/en-us/lifecycle/products/system-center-2019-operations-manager).

Au 12 novembre 2026, SCOM 2019 est donc en **support étendu** (mises à jour de sécurité ; pas de nouvelles fonctionnalités au titre de cette phase). Certaines pages de documentation Microsoft 2019 affichent une bannière invitant à passer à Operations Manager 2022 ; **les dates contraignantes sont celles de la page Lifecycle**. Il est recommandé de **planifier la migration** vers une version encore en support standard (2022 ou ultérieure) avant la fin du support étendu. Cette planification est hors du déploiement LGTM, mais elle conditionne l'effort d'intégration (ne pas investir lourdement dans une voie qui disparaîtrait avec la version).

**Voies d'intégration, honnêtes sur leur statut :**

- **Voie A — journaux (recommandée en premier) :** récepteur OpenTelemetry officiel [`windowseventlog`](https://github.com/open-telemetry/opentelemetry-collector-contrib/blob/v0.164.0/receiver/windowseventlogreceiver/README.md) sur les agents Windows concernés, ou collecteur WEF. Export OTLP TLS vers le VIP `otel-gw` (`${OTEL_GW_FQDN}:${PORT_OTEL_HTTP}`). Composant documenté par le projet OpenTelemetry. **Non testé** sur cet environnement.
- **Voie B — métriques / alertes :** exportateur Prometheus communautaire [SCOM-Prometheus-Exporter (OpsLogix)](https://github.com/opslogix/SCOM-Prometheus-Exporter). Les prérequis du projet indiquent **« Microsoft SCOM 2019 or later »**. **Ce n'est pas un produit officiel Microsoft.** Licence AGPL-3.0, support et charge sur le SDK / le serveur de gestion sont **à qualifier**. **Non testé**.
- **Voie C — API REST et SDK :** SCOM 2019 expose une **API REST** (présente depuis Operations Manager 1801). À partir de la mise à jour UR1, les appels mutateurs exigent un jeton CSRF (`SCOM-CSRF-TOKEN`). Le **SDK** et le **Operations Manager Connector Framework (OMCF)** sont les voies d'intégration tierce documentées par Microsoft : [Plan for third-party integration (vue sc-om-2019)](https://learn.microsoft.com/en-us/system-center/scom/plan-thirdparty-integration?view=sc-om-2019). Un greffon Grafana tierce ([SCOM Data Source for Grafana, OpsLogix](https://github.com/opslogix/SCOM-Data-Source-Grafana)) s'appuie sur cette API REST et la console web ; **ce n'est ni un greffon Grafana Labs, ni un produit Microsoft**. À qualifier (authentification, UR1/CSRF, HTTPS). **Non testé**.
- **Consultation des bases SQL (Operations Manager et Data Warehouse) :** Microsoft la mentionne parmi les méthodes d'intégration / de rapports. Pour une organisation à **données sensibles**, elle n'est **pas retenue comme voie principale** : le schéma n'est pas un contrat d'API public stable, et elle implique un compte à privilèges sur SQL Server. Les ports SQL (1433) restent ceux des serveurs SCOM existants, hors plateforme LGTM.

**Ports utiles (documentation Microsoft, vue sc-om-2019) :** console web **443** (éviter HTTP 80) ; communication agents / serveur de gestion **5723** (et 5724 selon le rôle) ; voir [Configure firewall rules](https://learn.microsoft.com/en-us/system-center/scom/plan-security-config-firewall?view=sc-om-2019). Grafana ou un exportateur qui parlerait à la console vise `${SCOM_URL}` (exemple : `https://scom.exemple.local/OperationsManager`).

### AppDynamics — contrôleur on-premises

Le contrôleur est **sur site**. Les flux, certificats et l'annuaire se configurent contre ce contrôleur, pas contre un tenant SaaS.

**Ports (documentation officielle on-premises) :**

- **HTTPS 8181** — accès principal au contrôleur (à utiliser).
- **HTTP 8090** — à **désactiver et bloquer** au pare-feu.
- Enterprise Console : 9191.
- Events Service (si déployé) : 9080 / 9081.
- EUM (si déployé) : 7001 / 7002.

Sources : [Port Settings (on-premises)](https://docs.appdynamics.com/appd/onprem/24.x/latest/en/planning-your-deployment/port-settings), documentation Splunk AppDynamics On-Premises (ports, SSL, LDAP).

**Certificats du contrôleur :** l'installation par défaut peut fournir un certificat auto-signé. En production (données sensibles), le **remplacer par un certificat émis par l'autorité interne**, avec un **SAN qui contient exactement le FQDN utilisé par les clients** (navigateur, greffon Grafana, agents, collecteur OTLP) — exemple `${APPD_FQDN}` (`appd.exemple.local`). Le CA interne doit être présent dans le magasin de confiance de Grafana et des agents. Les agents .NET, en particulier, exigent un certificat signé par une CA de confiance (documentation AppDynamics on-premises, configuration SSL). **Non testé** dans ce dépôt.

**LDAP sur le contrôleur :** le contrôleur on-premises peut s'authentifier contre un annuaire LDAP/LDAPS (Active Directory). Configuration : *Controller Settings > Administration > Authentication Provider > LDAP*. Port **636** lorsque SSL est activé ; Bind DN, Base DN, attribut de connexion `sAMAccountName` pour AD ; correspondance des groupes AD vers les rôles AppDynamics. Un compte d'administration **local** reste un secours si l'annuaire est indisponible. Il est recommandé d'utiliser le **même AD** que Grafana (configurations **indépendantes**, groupes éventuellement communs). **Non testé** dans ce dépôt.

**Intégration avec LGTM :**

- Le greffon Grafana [`dlopes7-appdynamics-datasource`](https://grafana.com/docs/plugins/dlopes7-appdynamics-datasource/latest/) est **Enterprise** (Grafana ≥ 11.6.7, licence requise). L'URL pointe vers le contrôleur on-premises `${APPD_URL}` (exemple : `https://appd.exemple.local:8181`), avec confiance au CA du contrôleur. Le fonctionnement contre un contrôleur on-premises est **à vérifier sur la version installée (non testé)**. Sans licence Enterprise, placer un lien vers la console AppDynamics dans la vue unique et corréler par `service.name`.
- *Splunk AppDynamics for OpenTelemetry* (documentation **On-Premises**) documente l'envoi de traces **vers** le contrôleur via l'exportateur `otlphttp` et l'en-tête `x-api-key`. L'endpoint documenté est de la forme `https://<dns-du-contrôleur>:8181/otis/ingest` (variable `${APPD_OTEL_INGEST}`). **À vérifier sur la version du contrôleur installé. Non testé.** Ce n'est **pas** un flux officiel AppDynamics → Tempo. La cible de migration des traces vers Tempo reste l'instrumentation OpenTelemetry native vers la passerelle `${OTEL_GW_FQDN}`.

## Conséquences

- **Positives :** SCOM 2019 et le contrôleur AppDynamics sur site restent les références ; la vue unique Grafana les expose sans les éteindre ; les voies A (journaux) et les liens / la corrélation sont réalisables sans licence supplémentaire.
- **Négatives :** support étendu SCOM 2019 (migration à planifier) ; greffon AppDynamics et Team Sync = Grafana Enterprise ; voies B et C SCOM communautaires ou à qualifier ; endpoint OTLP AppDynamics on-premises à confirmer sur la version réelle.
- **Réseau :** nouveaux flux (documentés dans la matrice) : agents Windows → VIP otel-gw 4317/4318 ; éventuellement exportateur ou Grafana → console SCOM 443 ; Grafana → contrôleur AppDynamics **8181** ; éventuellement otel-gw → `${APPD_OTEL_INGEST}`. LDAP du contrôleur AppDynamics : contrôleur → DC **636** (déjà dans le périmètre identité si ce n'est pas déjà ouvert).

## Alternatives écartées

| Alternative | Motif |
| --- | --- |
| Éteindre SCOM / AppDynamics dès la mise en service LGTM | Perte de couverture, pas de période de comparaison. |
| Traiter AppDynamics comme un contrôleur SaaS | Contredit le fait établi (contrôleur sur site) : ports, certificats et LDAP sont ceux de l'on-premises. |
| Requête SQL directe des bases SCOM comme voie principale | Inadapté à des données sensibles (contrat d'API, privilèges). |
| Recoder un greffon Grafana SCOM | Hors périmètre ; à n'envisager qu'après échec des voies A/B/C. |
