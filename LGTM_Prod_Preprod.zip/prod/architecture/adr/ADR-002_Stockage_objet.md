# ADR-002 — Stockage objet pour Mimir, Loki et Tempo

- **Statut :** proposé (hypothèse à confirmer)
- **Date :** 2026-11-11
- **Décideurs :** à confirmer

## Contexte

En mode monolithique avec disque local, Mimir, Loki et Tempo ne tolèrent pas la perte d'un nœud sans perte de données historiques. Les modes de production documentés par Grafana Labs (microservices ou simple-scalable / distributed) s'appuient sur un **stockage objet** compatible S3 pour les blocs et index de long terme.

## Décision

Les trois stockages LGTM utilisent un **backend objet S3 compatible**, partagé logiquement (préfixes / seaux distincts) :

- soit un **service S3 déjà présent** sur le site (à privilégier s'il existe, avec réplication et cycle de vie) ;
- soit un cluster **MinIO en mode distribué** (au moins quatre nœuds pour l'erasure coding — à confirmer selon la version et la documentation MinIO retenue au moment de l'installation).

Les seaux (buckets) sont séparés : `lgtm-mimir`, `lgtm-loki`, `lgtm-tempo`, éventuellement `lgtm-admin` pour les sauvegardes. Chiffrement en transit (TLS) et, si le service le permet, au repos. Identifiants dans des fichiers 0600, jamais en ligne de commande.

Cette décision est une **hypothèse** : le choix final (S3 existant ou MinIO, nom des seaux, classe de stockage) doit être confirmé avant le dimensionnement disque.

## Alternatives

| Alternative | Pourquoi elle n'est pas retenue comme cible prod |
|---|---|
| Disque local uniquement (mode laboratoire) | Pas de réplication des blocs historiques ; une VM perdue = données perdues. Acceptable uniquement en démonstration. |
| NFS partagé | Grafana Labs déconseille NFS pour ces composants (verrous, cohérence). Non retenu sans preuve contraire officielle. |
| Ceph RGW / autre S3 interne | Acceptable s'il est déjà en production et qualifié : c'est une variante de « S3 existant », pas une alternative contradictoire. |

## Conséquences

- **Positives :** les nœuds Mimir / Loki / Tempo deviennent des travailleurs interchangeables ; la capacité de rétention se scale sur l'objet ; restauration d'un nœud sans recopier l'historique.
- **Négatives :** dépendance à la disponibilité du service objet ; coût de stockage ; compétence supplémentaire si MinIO est nouveau.
- **Ouvert :** rétention (durée par signal), cycle de vie des objets, chiffrement au repos, sauvegarde des seaux. Marqué **non chiffré** tant que le service n'est pas choisi.
