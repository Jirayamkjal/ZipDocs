# ADR-005 — Grafana OSS et composant de synchronisation des ACL, plutôt que Grafana Enterprise Team Sync

- **Statut :** accepté (sous réserve d'une licence Enterprise non prévue)
- **Date :** 2026-11-11
- **Décideurs :** à confirmer

## Contexte

Les tableaux de bord doivent être liés aux équipes, elles-mêmes liées aux groupes Active Directory : un nouvel arrivant dans un groupe AD doit, après sa première connexion, retrouver les bons dossiers. Grafana documente une fonction **Team Sync** (synchronisation des équipes avec les groupes de l'identité) comme disponible dans **Grafana Enterprise et Grafana Cloud** ([Configure Team Sync](https://grafana.com/docs/grafana/latest/setup-grafana/configure-access/configure-team-sync/)). La synchronisation LDAP « active » en arrière-plan est également une fonctionnalité renforcée Enterprise ([enhanced LDAP](https://grafana.com/docs/grafana/latest/setup-grafana/configure-access/configure-authentication/enhanced-ldap/)).

Grafana OSS permet déjà, via `ldap.toml`, le mapping des groupes vers les **rôles d'organisation** (Admin, Editor, Viewer) au moment de la connexion ([LDAP authentication](https://grafana.com/docs/grafana/latest/setup-grafana/configure-access/configure-authentication/ldap/)).

## Décision

1. Déployer **Grafana OSS**.
2. Utiliser `ldap.toml` pour les rôles d'organisation.
3. Déployer le composant **`grafana_acl_sync.py`** (ce dépôt, `scripts/`) : lecture des groupes AD, création idempotente des équipes, inscription des utilisateurs déjà connus de Grafana, permissions de dossiers, provisioning des tableaux de bord, extrait ROR aligné. Mode `--dry-run`, jeton lu dans un fichier 0600, exécution par timer systemd (VM) ou CronJob (Kubernetes).

Si une licence Grafana Enterprise est acquise plus tard, Team Sync pourra remplacer la partie « membres d'équipe » du script ; les dossiers et le provisioning restent utiles.

## Alternatives

| Alternative | Pourquoi elle n'est pas retenue maintenant |
|---|---|
| Acheter Grafana Enterprise pour Team Sync | Possible, mais non supposé. Coût et processus d'achat hors de la décision technique par défaut. |
| Gestion manuelle des équipes dans l'UI | Non reproductible, erreur humaine, inacceptable en prod. |
| Provisioning YAML uniquement (fichiers) | Ne résout pas l'appartenance dynamique aux groupes AD. |

## Conséquences

- **Positives :** pas de licence obligatoire ; GitOps possible (config YAML versionnée) ; mêmes groupes réutilisés pour ROR.
- **Négatives :** les utilisateurs n'apparaissent dans Grafana qu'après leur **première connexion LDAP** (`allow_sign_up = true`) ; le script le signale et les ajoutera au tour suivant. Composant à exploiter (timer, journaux, compte de service). **Le script a été validé en `--mock --dry-run` et par `py_compile`, pas contre un AD ni un Grafana réels** (non testé en conditions réelles).
