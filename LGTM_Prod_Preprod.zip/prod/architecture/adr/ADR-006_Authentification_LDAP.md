# ADR-006 — Authentification LDAP (Active Directory) pour Grafana et ROR

- **Statut :** accepté
- **Date :** 2026-11-11
- **Décideurs :** à confirmer

## Contexte

L'organisation dispose d'Active Directory. Les utilisateurs ne doivent pas avoir de mot de passe local Grafana (hors compte d'urgence). Les droits doivent suivre les groupes métier. Elasticsearch (via ROR) doit pouvoir s'appuyer sur les mêmes groupes pour restreindre les motifs d'index.

## Décision

- **Grafana :** `[auth.ldap]` activé, fichier `/etc/grafana/ldap.toml`, **LDAPS** (port 636), vérification du certificat, compte de liaison en lecture seule, `search_filter = "(sAMAccountName=%s)"`, attributs AD (`sAMAccountName`, `mail`, `memberOf`), `group_mappings` vers Admin / Editor / Viewer. Mot de passe de liaison saisi dans un fichier 0640, jamais en ligne de commande. Documentation : [Configure LDAP authentication](https://grafana.com/docs/grafana/latest/setup-grafana/configure-access/configure-authentication/ldap/).
- **ROR :** section `ldaps` et règles `ldap_auth` / `ldap_authentication` + `ldap_authorization`, mêmes groupes (`groups_any_of`). Documentation : [For Elasticsearch — LDAP](https://docs.readonlyrest.com/elasticsearch). Le connecteur LDAP figure dans la documentation du greffon Elasticsearch (Free) ; il n'est pas marqué « Enterprise » contrairement à `ror_kbn_auth`. À confirmer sur la version ROR déployée.
- **Compte d'urgence Grafana** : un administrateur local conservé, mot de passe dans le coffre, usage exceptionnel (indisponibilité AD).
- **Noms des groupes AD :** exemples dans les fichiers (`GRP-OBS-PLATEFORME`, etc.) — **à remplacer** par les vrais DN.

## Alternatives

| Alternative | Pourquoi elle n'est pas retenue |
|---|---|
| OAuth / SAML / OIDC | Le SSO OSS (Kerberos via auth.proxy, OIDC Generic OAuth vers AD FS) est traité dans [ADR-011](ADR-011_SSO_Grafana_OSS.md). SAML Grafana et SAML ROR Kibana (`ror_kbn_auth`) restent Enterprise. LDAP demeure le socle et le secours. |
| Utilisateurs locaux uniquement | Inexploitable à l'échelle, pas de révocation centralisée. |

## Conséquences

- **Positives :** identité unique ; révocation au départ d'un collaborateur ; alignment Grafana / ES.
- **Négatives :** dépendance à AD (mitigée par le compte d'urgence et par le cache éventuel ROR `cache_ttl`) ; configuration AD (base DN, attributs) **non testée** contre un annuaire réel dans ce dépôt.
