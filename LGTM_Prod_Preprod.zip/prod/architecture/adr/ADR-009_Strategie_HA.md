# ADR-009 — Stratégie de haute disponibilité

- **Statut :** accepté (cible)
- **Date :** 2026-11-11
- **Décideurs :** à confirmer

## Contexte

La plateforme est prévue pour la préproduction et la production : la perte d'un nœud (courtier Kafka, ingester, instance Grafana, passerelle OTel, nœud objet) ne doit ni arrêter l'ingestion ni rendre la consultation impossible. L'objectif de disponibilité chiffré (ex. 99,9 %) est une **hypothèse à confirmer** avec l'exploitation.

## Décision

- **Kafka :** 3 courtiers KRaft (rôles combinés broker+contrôleur en première étape ; contrôleurs dédiés possibles plus tard), RF=3, `min.insync.replicas=2`, `acks=all`. Tolérance : 1 courrier (et 1 contrôleur) perdu. Deux pertes simultanées = perte de quorum — accepté et documenté.
- **Mimir, Loki, Tempo :** mode microservices ou simple-scalable / distributed, réplication d'ingestion, stockage objet, au moins deux réplicas des composants de requête, Alertmanager Mimir **en cluster**.
- **Grafana :** au moins deux instances, **base PostgreSQL partagée** (elle-même en primaire + réplique), sessions dans cette base, VIP HAProxy + keepalived (VM) ou Ingress (K8s).
- **Passerelle OTel :** N réplicas (≥ 2, recommandé 3 en prod) derrière un VIP / Service, configurations identiques.
- **Kubernetes :** PodDisruptionBudget, anti-affinité, `topologySpreadConstraints`, StorageClass adaptées.
- **RPO / RTO indicatifs (hypothèses, non contractuels) :** RPO ingestion ≈ 0 tant que Kafka et `acks=all` tiennent ; RPO historique = celui du stockage objet et de ses sauvegardes ; RTO consultation Grafana ≈ bascule VIP (dizaines de secondes, à mesurer).

## Alternatives

| Alternative | Pourquoi elle n'est pas retenue en prod |
|---|---|
| Un nœud par composant (mode laboratoire) | Aucune tolérance de panne. |
| Réplication 2 avec `min.insync=1` | Une écriture peut n'être que sur un courtier : perte possible. |

## Conséquences

- **Positives :** incident simple absorbé ; procédures de panne écrites (runbook, section exploitation).
- **Négatives :** coût en machines (tableau de dimensionnement : **estimations**) ; complexité d'exploitation. Les délais réels de rattrapage (LAG, flush d'ingester) sont **à mesurer en préprod** (non testés à l'échelle production dans ce dépôt).
