# ADR-003 — Deux déploiements cibles : machines virtuelles et Kubernetes

- **Statut :** accepté
- **Date :** 2026-11-11
- **Décideurs :** à confirmer

## Contexte

L'organisation dispose d'environnements RHEL 8 hors ligne, d'un savoir-faire systemd, et, par ailleurs, d'une trajectoire Kubernetes (registre privé de type Artifactory). La même plateforme logique (LGTM + Kafka + OpenTelemetry + Grafana) doit pouvoir être installée sur l'une ou l'autre infrastructure, avec les mêmes exigences de haute disponibilité, de sécurité (ROR, PKI, LDAP) et de vue unique.

## Décision

Il existe **deux runbooks distincts**, un par mode de déploiement, et un seul jeu de documents d'architecture (même logique, deux réalisations) :

1. **Machines virtuelles RHEL 8** — services systemd natifs, **sans Docker**, paquets RPM / archives officielles transférés par SFTP, SELinux enforcing, firewalld, HAProxy + keepalived.
2. **Kubernetes** — charts Helm officiels ou communautaires maintenus, opérateurs (Strimzi, OpenTelemetry, cert-manager), images et charts issus d'un **registre privé**, PodDisruptionBudgets, anti-affinité, Ingress TLS.

Le choix de l'environnement (préprod VM, prod Kubernetes, ou l'inverse, ou les deux) est une **décision d'exploitation à confirmer**. Les deux versions restent alignées sur les mêmes versions de composants, les mêmes sujets Kafka et les mêmes règles ROR / LDAP / ACL.

## Alternatives

| Alternative | Pourquoi elle n'est pas retenue |
|---|---|
| Un seul mode (VM seulement) | Ignore une trajectoire Kubernetes déjà possible et complique une future industrialisation. |
| Un seul mode (Kubernetes seulement) | Ignore les contraintes actuelles (hors ligne, RHEL 8, pas de Docker sur les VM, équipe habituée à systemd). |
| Docker Compose / Podman sur les VM | Le déploiement VM est volontairement natif systemd, cohérent avec l'exploitation existante et avec SELinux. |

## Conséquences

- **Positives :** même architecture logique ; liberté de calendrier ; compétences des deux côtés capitalisées.
- **Négatives :** deux procédures à maintenir ; risque de divergence de versions — mitigé par un tableau de versions commun et une vérification des artefacts à chaque campagne.
