# ADR-001 — Kafka comme tampon d'ingestion

- **Statut :** accepté (cible préprod et prod)
- **Date :** 2026-11-11
- **Décideurs :** à confirmer

## Contexte

La plateforme doit absorber des à-coups d'ingestion (redémarrages d'applications, pics, pannes d'un stockage) sans perdre de journaux, de métriques ou de traces. Elle doit aussi permettre une **double consommation** des mêmes journaux par Loki et par Elasticsearch, pour une transition progressive (double écriture puis retrait d'ELK).

## Décision

Toute l'ingestion OTLP passe par un **cluster Apache Kafka en mode KRaft** (sans ZooKeeper — Kafka 4.x n'offre plus que ce mode, voir [KRaft](https://kafka.apache.org/44/operations/kraft/)).

- Trois courtiers, facteur de réplication **3**, `min.insync.replicas=2`, producteurs `acks=all` (`required_acks: -1`).
- Trois sujets explicites : `otlp_logs`, `otlp_metrics`, `otlp_spans` (création manuelle, `auto.create.topics.enable=false`).
- Groupes de consommateurs distincts : `lgtm-loki`, `lgtm-mimir`, `lgtm-tempo`, `elk-es`. Chaque groupe a son propre offset : un consommateur arrêté ne bloque pas les autres.
- La collecte Prometheus en mode agent (`remote_write` vers Mimir) reste **hors Kafka** : le WAL de l'agent sert de tampon pour les métriques « pull ».

## Alternatives

| Alternative | Pourquoi elle n'est pas retenue |
|---|---|
| Écriture directe OTLP vers Mimir / Loki / Tempo | Une panne d'un stockage fait perdre les données ou impose une file dans chaque collecteur, sans consommation indépendante pour ELK. |
| File d'attente d'un seul collecteur (`sending_queue`) | Tampon local, non partagé, perdu si le nœud tombe, pas de relecture par un second système. |
| Redis / NATS / Pulsar | Moins d'écosystème opérationnel déjà connu, rétention et groupes de consommateurs moins adaptés au cas « plusieurs lecteurs du même flux ». |
| Kafka avec ZooKeeper | ZooKeeper est retiré de Kafka 4.x. |

## Conséquences

- **Positives :** découplage ingestion / stockage ; rattrapage automatique après panne d'un consommateur ; double écriture Loki et Elasticsearch sans dupliquer les agents ; point de supervision unique (LAG par groupe).
- **Négatives :** composant critique supplémentaire (le quorum de contrôleurs doit rester disponible) ; dimensionnement disque et rétention à caler ; compétence Kafka à maintenir.
- **Risque :** perte de deux courtiers simultanément = perte du quorum. Mitigé par RF=3, placement anti-affinité (VM distinctes / zones), sauvegarde des métadonnées et procédure de reconstruction documentée.
