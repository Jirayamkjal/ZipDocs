# ADR-010 — Vue unique (« one screen ») dans Grafana

- **Statut :** accepté
- **Date :** 2026-11-11
- **Décideurs :** à confirmer

## Contexte

L'exploitation et l'architecture veulent **un écran d'accueil unique** : santé de la plateforme, débits, erreurs, retards Kafka, état des stockages, et fenêtres SCOM / AppDynamics, avec des percées (drill-down) vers les signaux détaillés.

## Décision

- Un tableau de bord Grafana d'accueil, uid `lgtm-one-screen`, titre « Observabilité — vue unique », provisionné (fichier `dashboards/one_screen_home.json`), placé dans le dossier « Plateforme observabilité » et lié à l'équipe correspondante par `grafana_acl_sync`.
- Sources de données provisionnées avec corrélations officielles Grafana : exemplars Mimir → Tempo, champ dérivé TraceID Loki → Tempo, Tempo → Loki / Mimir (service map).
- Panneaux fondés sur des métriques documentées (`kafka_consumer_group_lag`, télémétrie otelcol, `up`, `ALERTS`). Panneaux SCOM et AppDynamics en **emplacements honnêtes** tant que les voies d'intégration ne sont pas qualifiées.
- Ce tableau de bord est le `home` de l'organisation (préférence Grafana ou provisioning).

## Alternatives

| Alternative | Pourquoi elle n'est pas retenue |
|---|---|
| Plusieurs écrans disjoints sans accueil | Ne répond pas à l'exigence « one screen ». |
| Kibana comme écran unique | Kibana ne couvre pas Mimir / Tempo ; la cible de consultation est Grafana. Kibana reste disponible pendant la double écriture. |

## Conséquences

- **Positives :** un point d'entrée ; onboarding facilité (le dossier suit le groupe AD).
- **Négatives :** le tableau de bord doit être adapté aux vrais libellés `job` une fois la collecte définie. **Il n'a pas été exercé contre une plateforme de production** (JSON validé syntaxiquement seulement).
