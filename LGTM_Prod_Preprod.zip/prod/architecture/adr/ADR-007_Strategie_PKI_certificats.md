# ADR-007 — Stratégie PKI et certificats

- **Statut :** accepté
- **Date :** 2026-11-11
- **Décideurs :** à confirmer

## Contexte

Une erreur déjà observée en environnement de démonstration illustre un piège classique de TLS : le certificat HTTP d'un service contenait uniquement un **nom court** (`es01`) dans le SAN, alors que les clients se connectaient avec le **FQDN** (`es.exemple.local`). Le résultat est une erreur du type `x509: certificate is valid for es01, not es.exemple.local`. Le nom utilisé par le client **doit** figurer dans le SAN.

## Décision

1. **Autorité :** PKI interne d'entreprise (typiquement **AD CS**). Pas d'autorités publiques pour les services internes, pas de `ssl_skip_verify` / `InsecureSkipVerify` en préprod ou prod.
2. **SAN obligatoire :** pour chaque certificat de service, inclure **tous** les noms réellement utilisés : FQDN DNS, nom court si encore utilisé, nom du VIP, `localhost` / `127.0.0.1` seulement si des contrôles locaux s'en servent. En Kubernetes : noms de Service, d'Ingress et, au besoin, `*.namespace.svc`.
3. **Chaîne de confiance :** le CA (et les intermédiaires) sont distribués :
   - magasin d'ancrage RHEL : `/etc/pki/ca-trust/source/anchors/` puis `update-ca-trust` ;
   - fichiers dédiés des composants : `tls.ca_file` (otelcol), `tlsCACert` / `$__file{}` (Grafana), truststore Java (Kafka), ROR (`truststore` ou PEM selon la configuration SSL retenue) ;
   - Kubernetes : `cert-manager` avec un `Issuer` / `ClusterIssuer` de type CA, secret du CA interne importé.
4. **mTLS Kafka :** optionnel en première étape, recommandé ensuite (SASL_SSL ou SSL avec authentification client). Marqué à planifier.
5. **Rotation :** durée de vie limitée, **alerte d'expiration à 30 jours**, procédure de renouvellement testée en préprod (même SAN), `restorecon` après dépôt des fichiers sur RHEL 8.
6. **Vérification :** `openssl s_client -connect FQDN:port </dev/null 2>/dev/null | openssl x509 -noout -ext subjectAltName` — le FQDN du client doit apparaître. Aucun secret n'est affiché.

## Alternatives

| Alternative | Pourquoi elle n'est pas retenue |
|---|---|
| Certificats auto-signés par service, sans CA commun | Explosion de la distribution, rotation impossible à industrialiser. |
| Désactiver la vérification TLS | Interdit en préprod et prod. |
| Let's Encrypt public | Inadapté à un réseau isolé et à des noms internes. |

## Conséquences

- **Positives :** un seul ancrage de confiance ; diagnostic clair (tableau des erreurs x509) ; rotation anticipée.
- **Négatives :** discipline de demande de certificat (SAN complet dès la CSR) ; coordination avec l'équipe PKI. La procédure de régénération d'un certificat Elasticsearch déjà émis **doit être répétée en préprod** (non testée dans ce dépôt sur un cluster ES 8 ROR).
