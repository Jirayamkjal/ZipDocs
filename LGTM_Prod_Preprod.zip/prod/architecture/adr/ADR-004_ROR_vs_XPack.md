# ADR-004 — ReadonlyREST plutôt que X-Pack Security devant Elasticsearch

- **Statut :** accepté (contrainte d'environnement existante)
- **Date :** 2026-11-11
- **Décideurs :** déjà en vigueur sur les environnements Elasticsearch 8 RHEL

## Contexte

Les environnements préprod et prod Elasticsearch 8 sont déjà protégés par **ReadonlyREST (ROR)**, qui assure TLS et le contrôle d'accès. L'API `_security/*` d'Elasticsearch n'est donc pas le mécanisme d'authentification en vigueur : une tentative de création de clé d'API via `POST /_security/api_key` se solde par une erreur du type « no handler ».

## Décision

Conserver **ROR comme unique moteur d'authentification et d'autorisation** devant Elasticsearch. La pile LGTM s'y intègre ainsi :

- **Compte de service d'écriture** (`otel-writer`) pour l'exportateur elasticsearch d'otelcol : HTTP Basic, mot de passe stocké via `auth_key_pbkdf2` (voir [documentation ROR](https://docs.readonlyrest.com/elasticsearch)), droits limités à `logs-*` (écriture) et `cluster:monitor/*`.
- **Compte de service de lecture** (`grafana-reader`) pour la source de données Elasticsearch de Grafana : lecture seule sur `logs-*`.
- **Connecteur `ldaps`** et règle `ldap_auth` pour mapper les mêmes groupes AD que Grafana vers des motifs d'index (voir [connecteur LDAP ROR](https://docs.readonlyrest.com/elasticsearch)).
- Les blocs spécialisés sont **placés avant** tout bloc plus large. L'ordre est déterminant.
- En édition gratuite, le rechargement à chaud n'est pas disponible : un **redémarrage d'Elasticsearch** est nécessaire. Si l'index `.readonlyrest` existe, ajouter `readonlyrest.force_load_from_file: true` pour que le fichier soit pris en compte.

## Alternatives

| Alternative | Pourquoi elle n'est pas retenue |
|---|---|
| Réactiver X-Pack Security (clés d'API `_security/api_key`) | Changerait le modèle de sécurité déjà déployé ; conflit de responsabilité avec ROR. La documentation ROR décrit d'ailleurs la coexistence SSL : si `xpack.security.enabled` est vrai, c'est le SSL X-Pack qui s'applique, tandis que l'ACL ROR reste le moteur d'auth. Ce n'est pas une raison pour migrer l'auth vers X-Pack. |
| Laisser ES ouvert sur le réseau interne | Inacceptable en préprod et prod. |

## Conséquences

- **Positives :** pas de double système d'identité sur ES ; même annuaire AD que Grafana ; Moindre privilège par bloc.
- **Négatives :** pas de clés d'API Elasticsearch natives ; les procédures d'otelcol et de Grafana doivent utiliser utilisateur / mot de passe (fichiers 0600 / `$__file{}`) ; liste exacte des `actions` ROR à ajuster en préprod si un 403 apparaît dans le journal ES (marqué **non testé** pour l'exportateur otelcol-contrib contre ROR dans ce dépôt).
- **Attention :** `auth_key` en clair est documenté par ROR pour les tests seulement ; en production, utiliser `auth_key_pbkdf2`.
