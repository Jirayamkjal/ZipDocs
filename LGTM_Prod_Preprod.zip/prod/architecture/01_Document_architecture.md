# Document d'architecture — Plateforme LGTM préproduction et production

**Objet :** décrire l'architecture cible d'une plateforme d'observabilité LGTM
(Loki, Grafana, Tempo, Mimir) avec Apache Kafka, OpenTelemetry Collector,
double écriture vers Elasticsearch 8 protégé par ReadonlyREST, authentification
LDAP, vue unique Grafana, et intégration logique de SCOM et d'AppDynamics.

**Audience :** architecte logiciel, exploitation, sécurité, équipes applicatives.

**Date :** 2026-11-11. Les versions de composants citées sont des **versions de
référence vérifiées le 28 octobre 2026** sur les artefacts officiels ; elles
doivent être **revérifiées à chaque campagne d'installation**.

**Décisions détaillées :** dossier [`adr/`](adr/). **Impacts :**
[`02_Etude_impact.md`](02_Etude_impact.md). **Déploiement :** runbooks VM et
Kubernetes à la racine de ce paquet.

---

## 1. Périmètre

Inclus :

- Ingestion OTLP (traces, métriques, journaux) via une passerelle OpenTelemetry
  hautement disponible, tampon Kafka, stockages Mimir / Loki / Tempo.
- Consultation Grafana HA, vue unique, corrélation des trois signaux.
- Double écriture des journaux vers Elasticsearch 8 (ROR) pendant la transition.
- Identité AD (LDAPS), ACL Grafana, mapping ROR des mêmes groupes.
- PKI interne, exigences SAN, rotation.
- Intégration logique SCOM et AppDynamics (voies honnêtes, voir ADR-008).
- Deux réalisations : machines virtuelles RHEL 8 (systemd, sans Docker) et Kubernetes.

Exclus (hors conception détaillée ici) :

- Le dimensionnement exact du cluster Elasticsearch existant.
- Les FQDN et VIP **réels** (les valeurs du paquet sont des exemples fictifs, fichier `variables/`).
- Le remplacement fonctionnel complet de SCOM ou d'AppDynamics.
- Les règles métier d'alerting applicatif (seule la mécanique est décrite).

---

## 2. Contexte et objectifs

L'existant comprend un cluster Elasticsearch 8 sur RHEL 8, sécurisé par
ReadonlyREST, ElastAlert2 pour les alertes sur ES, SCOM pour l'infrastructure
Microsoft, et AppDynamics comme APM. Le réseau est **hors ligne** : les
artefacts arrivent par un poste Windows puis SFTP.

Objectifs de la plateforme cible :

1. Offrir une observabilité unifiée (métriques, journaux, traces) avec une
   **vue unique**.
2. Rester **robuste** : perte d'un nœud sans arrêt d'ingestion ni de consultation.
3. Permettre une **transition** depuis ELK (double écriture, puis retrait
   contrôlé) sans casser ElastAlert2 ni ROR.
4. S'intégrer à **l'identité AD** et appliquer le moindre privilège.
5. Être déployable sur **VM RHEL 8** et sur **Kubernetes**.

---

## 3. Vue d'ensemble

Les deux réalisations partagent le même graphe logique.

![Architecture cible sur machines virtuelles RHEL 8](diagrammes/01_architecture_vm.png)

*Figure 1 — Déploiement VM. Source Visio : [diagrammes/01_architecture_vm.vsdx](diagrammes/01_architecture_vm.vsdx).*

![Architecture cible Kubernetes](diagrammes/02_architecture_k8s.png)

*Figure 2 — Déploiement Kubernetes. Source Visio : [diagrammes/02_architecture_k8s.vsdx](diagrammes/02_architecture_k8s.vsdx).*

```mermaid
flowchart LR
  subgraph SRC["Sources"]
    APP["Applications SDK OTel"]
    AG["Agents hôtes et Windows"]
    SCOM["SCOM 2019
scom.exemple.local"]
    APPD["AppDynamics on-prem
appd.exemple.local:8181"]
  end
  subgraph GW["Ingestion HA"]
    LB1["VIP otel-gw.obs.exemple.local"]
    OTEL["otel-gw × N"]
    PROM["Prometheus agent"]
    ELKCONS["consommateur elk-es"]
  end
  subgraph K["Kafka KRaft RF=3"]
    TL["otlp_logs"]
    TM["otlp_metrics"]
    TS["otlp_spans"]
  end
  subgraph ST["Stockages"]
    MIM["Mimir + Alertmanager"]
    LOK["Loki"]
    TEM["Tempo"]
    S3["S3 s3.obs.exemple.local"]
    ES["ES 8 + ROR"]
  end
  subgraph UI["Consultation"]
    LB2["VIP grafana.obs.exemple.local"]
    GF["Grafana OSS × 2+"]
    PG["PostgreSQL HA"]
    AD["Active Directory"]
    ACL["grafana_acl_sync"]
    ONE["Vue unique"]
  end
  APP --> LB1
  AG --> LB1
  SCOM -.-> LB1
  LB1 --> OTEL
  OTEL --> TL
  OTEL --> TM
  OTEL --> TS
  TL --> LOK
  TL --> ELKCONS
  TM --> MIM
  TS --> TEM
  ELKCONS -.-> ES
  PROM --> MIM
  MIM --> S3
  LOK --> S3
  TEM --> S3
  TEM --> MIM
  GF --> MIM
  GF --> LOK
  GF --> TEM
  GF -.-> ES
  GF -.-> APPD
  LB2 --> GF
  GF --> PG
  AD --> GF
  ACL --> GF
  GF --> ONE
```

Les FQDN ci-dessus sont des **exemples fictifs** de production (`obs.exemple.local`).
La préproduction utilise `obs-pp.exemple.local`. Tous les noms, IP et VIP se
modifient **uniquement** dans [`variables/environnements.env`](../variables/environnements.env)
(équivalent YAML : [`environnements.yaml`](../variables/environnements.yaml)).

### 3.1 Composants et responsabilités

| Composant | Responsabilité | HA minimale |
|---|---|---|
| Passerelle otelcol-contrib | Réception OTLP, production Kafka, consommateur `elk-es`, métriques Kafka | ≥ 2 (prod : 3) derrière VIP |
| Prometheus agent | Collecte pull, `remote_write` vers Mimir (WAL local) | 2 (ou agent sur chaque passerelle) |
| Kafka KRaft | Tampon durable, 3 sujets OTLP | 3 courtiers, RF=3, min.ISR=2 |
| Mimir | Métriques longue durée, règles, Alertmanager en cluster | mode microservices ou simple-scalable, objet S3 |
| Loki | Journaux | simple-scalable ou distributed, objet S3 |
| Tempo | Traces, metrics-generator vers Mimir | microservices, objet S3 |
| Elasticsearch 8 + ROR | Journaux en double écriture, ElastAlert2 | cluster existant, inchangé dans son rôle |
| Grafana OSS | Consultation, vue unique, Explore | 2+ instances, PostgreSQL partagé, VIP |
| grafana_acl_sync | AD → équipes / dossiers / permissions | timer ou CronJob, idempotent |
| PKI / AD CS | Certificats de service, CA | procédures de rotation |
| MinIO ou S3 existant | Blocs et index de long terme | distribué / répliqué (hypothèse) |

### 3.2 Versions de référence

Vérifiées sur les artefacts officiels le **28 octobre 2026**. À revérifier à l'installation.

| Composant | Version de référence | Notes |
|---|---|---|
| Apache Kafka | 4.4.0 (Scala 2.13) | KRaft uniquement, Java 17/21/25 — [Java](https://kafka.apache.org/44/operations/java-version/) |
| Eclipse Temurin JRE | 25.0.5+8 (LTS) | Recommandé par la documentation Kafka 4.4 |
| Grafana OSS | 13.2.4 | |
| Grafana Mimir | 3.2.3 | |
| Grafana Loki | 3.7.9 | |
| Grafana Tempo | 3.1.1 | |
| otelcol-contrib | 0.164.0 | |
| Prometheus | 3.15.1 (mode agent) | |
| node_exporter | 1.12.1 | |
| Elasticsearch | 8.x (existant) | ROR, version du greffon **alignée** sur celle d'ES |
| RHEL | 8 | SELinux enforcing, firewalld |

Les noms de charts Helm (dépôts `grafana` et `grafana-community`) sont précisés dans le runbook Kubernetes. Le chart `lgtm-distributed` du dépôt historique est **déprécié** et n'est pas utilisé. Les versions de charts doivent être lues sur Artifact Hub au moment de l'installation.

---

## 4. Flux de données

![Flux de données](diagrammes/03_flux_donnees.png)

*Figure 3 — OTLP → Kafka → stockages et double écriture. Source : [03_flux_donnees.vsdx](diagrammes/03_flux_donnees.vsdx).*

### 4.1 Scénario nominal : un journal, une métrique, une trace

```mermaid
sequenceDiagram
  autonumber
  participant App as Application / agent
  participant VIP as VIP otel-gw
  participant GW as otel-gw
  participant KF as Kafka RF=3
  participant LK as consommateur lgtm-loki
  participant MM as consommateur lgtm-mimir
  participant TP as consommateur lgtm-tempo
  participant ES as consommateur elk-es
  participant GR as Grafana
  App->>VIP: OTLP (4317 gRPC ou 4318 HTTP) TLS
  VIP->>GW: répartition
  GW->>KF: Produce otlp_logs / otlp_metrics / otlp_spans<br/>acks=all, zstd, otlp_proto
  KF-->>GW: ISR ≥ 2, offset confirmé
  KF->>LK: groupe lgtm-loki → Loki
  KF->>MM: groupe lgtm-mimir → Mimir
  KF->>TP: groupe lgtm-tempo → Tempo
  KF->>ES: groupe elk-es → ES 8 (ROR, compte otel-writer)
  Note over LK,ES: Groupes indépendants, offsets distincts
  GR->>MM: PromQL
  GR->>LK: LogQL
  GR->>TP: TraceQL / Search
  GR-->>ES: lecture logs-* (compte grafana-reader)
  GR-->>GR: liens TraceID, exemplars, service map
```

### 4.2 Double écriture et retrait

Pendant la transition, le pipeline `logs/elk` de la passerelle lit `otlp_logs`
avec le groupe `elk-es` et écrit dans Elasticsearch. Loki lit le **même sujet**
avec `lgtm-loki`. ElastAlert2 continue de travailler sur ES.

Lorsque les critères de retrait sont atteints (comparaison des alertes, plus
aucune consultation exclusive de Kibana sur la période d'observation), le
pipeline `logs/elk` est retiré, le groupe peut être supprimé, les comptes de
service ROR révoqués. Le retour arrière consiste à rétablir le pipeline (nouveau
groupe, `initial_offset` selon la rétention Kafka encore disponible).

### 4.3 Métriques pull

Les exportateurs (`node_exporter`, `windows_exporter`, endpoints `/metrics` des
services, éventuellement exportateur SCOM communautaire) sont collectés par
Prometheus en **mode agent**, qui pousse vers Mimir par `remote_write`. Ce flux
ne traverse pas Kafka. Le WAL de l'agent tamponne une indisponibilité temporaire
de Mimir.

### 4.4 Supervision de Kafka

Le récepteur `kafka_metrics` de la passerelle publie périodiquement
`kafka_consumer_group_lag`, `kafka_consumer_group_members`, etc., directement
vers Mimir. Ces séries alimentent la vue unique.

---

## 5. Flux d'authentification et de sécurité

![Flux de sécurité](diagrammes/04_flux_securite_auth.png)

*Figure 4 — LDAP, ROR, PKI. Source : [04_flux_securite_auth.vsdx](diagrammes/04_flux_securite_auth.vsdx).*

### 5.1 Connexion d'un utilisateur à Grafana

```mermaid
sequenceDiagram
  autonumber
  participant U as Utilisateur
  participant VIP as VIP Grafana
  participant GF as grafana-01 ou 02
  participant AD as AD LDAPS :636
  participant PG as PostgreSQL
  U->>VIP: HTTPS /login
  VIP->>GF: session
  GF->>AD: liaison (compte de service) puis recherche sAMAccountName
  AD-->>GF: attributs, memberOf
  GF->>GF: premier group_mappings correspondant<br/>→ rôle Org Admin / Editor / Viewer
  GF->>PG: utilisateur créé ou mis à jour (allow_sign_up)
  GF-->>U: session
  Note over GF: Les équipes et dossiers sont posés par grafana_acl_sync<br/>(Team Sync est une fonction Enterprise)
```

### 5.1 bis — SSO Kerberos (Auth Proxy) et OIDC (AD FS)

Voir [ADR-011](adr/ADR-011_SSO_Grafana_OSS.md). Noms d'exemple : `variables/environnements.env`. Procédures **non testées**.

```mermaid
sequenceDiagram
  autonumber
  participant P as Poste Windows (domaine)
  participant VIP as VIP grafana.obs.exemple.local
  participant AP as Apache mod_auth_gssapi
  participant DC as DC Kerberos :88
  participant GF as Grafana 127.0.0.1:3000
  P->>VIP: HTTPS Negotiate
  VIP->>AP: TLS SAN=grafana.obs.exemple.local
  AP->>DC: SPN HTTP/grafana.obs.exemple.local
  DC-->>AP: ticket
  AP->>GF: X-WEBAUTH-USER (whitelist = IP d'Apache)
  GF-->>P: session
```

```mermaid
sequenceDiagram
  autonumber
  participant P as Navigateur
  participant GF as Grafana OSS
  participant ADFS as AD FS (si déployé)
  P->>GF: /login bouton AD FS
  GF->>ADFS: OIDC authorize
  ADFS-->>GF: code / jeton
  GF->>GF: role_attribute_path et org_mapping (OSS depuis 11.2)
  GF-->>P: session
```

### 5.2 Onboarding d'une équipe

```mermaid
flowchart TD
  A["Demande : nouvelle équipe métier"] --> B["Créer le groupe AD et y inscrire les personnes"]
  B --> C["Ajouter un mapping dans acl-config.yaml<br/>équipe, dossiers, permissions, motifs d'index ROR"]
  C --> D["grafana_acl_sync --dry-run puis exécution réelle"]
  D --> E["Intégrer l'extrait ROR généré<br/>redémarrer ES si édition gratuite"]
  E --> F["Les utilisateurs se connectent une première fois à Grafana"]
  F --> G["Tour suivant du sync : inscription dans l'équipe<br/>dossiers et tableaux de bord visibles"]
```

### 5.3 Écriture otel-gw vers Elasticsearch (ROR)

```mermaid
sequenceDiagram
  participant GW as otel-gw (elk-es)
  participant ES as Elasticsearch + ROR
  GW->>ES: HTTPS POST data stream logs-*<br/>Authorization Basic (utilisateur otel-writer)
  Note over GW,ES: Mot de passe via variable d'environnement<br/>chargée depuis un fichier 0600, jamais en clair dans la config
  ES->>ES: Premier bloc ROR correspondant<br/>auth_key_pbkdf2 + indices logs-* + actions d'écriture
  alt autorisé
    ES-->>GW: 2xx, offset Kafka avancé
  else 401 / 403 / x509
    ES-->>GW: erreur, offset non avancé (message_marking after/on_error)
    GW-->>GW: journal, LAG elk-es augmente
  end
```

L'API `_security/api_key` n'est **pas** utilisée (ROR remplace ce mécanisme).

---

## 6. Matrice des flux réseau

Les noms d'hôtes et les plages sont des **exemples**. Le tableau sert de
demande de règles pare-feu (firewalld sur les VM, NetworkPolicy en Kubernetes,
pare-feu d'infrastructure). Tous les flux applicatifs sont en **TLS** dès que
le certificat est en place. Les ports d'administration restent limités aux
bastions / réseaux d'exploitation.

| Source | Destination | Port | Protocole | Usage | TLS |
|---|---|---|---|---|---|
| Agents, applications | VIP otel-gw | 4317 | gRPC | OTLP | oui (cible) |
| Agents, applications | VIP otel-gw | 4318 | HTTP | OTLP | oui (cible) |
| otel-gw (tous) | kafka-01..03 | 9092 | Kafka | produce / consume / métriques | SSL ou SASL_SSL (cible) |
| Consommateurs stockages | kafka-01..03 | 9092 | Kafka | consume groupes lgtm-* | idem |
| otel-gw | VIP ES / nœuds coord. | 9200 | HTTPS | exportateur elasticsearch | oui (ROR) |
| Grafana | Mimir (query / nginx) | 9009 | HTTPS | PromQL, Alertmanager | oui (cible) |
| Grafana | Loki gateway | 3100 | HTTPS | LogQL | oui (cible) |
| Grafana | Tempo query | 3200 | HTTPS | traces | oui (cible) |
| Grafana | VIP ES | 9200 | HTTPS | source transitoire logs-* | oui (ROR) |
| Prometheus agent | cibles scrape | 9100, 9182, 8888, ports services | HTTP(S) | collecte | selon cible |
| Prometheus agent | Mimir | 9009 | HTTPS | remote_write /otlp ou /api/v1/push | oui (cible) |
| Mimir / Loki / Tempo | S3 / MinIO | 443 ou 9000 | HTTPS | blocs objet | oui |
| Grafana × 2 | PostgreSQL | 5432 | TLS | base partagée | oui |
| Grafana | DC AD | 636 | LDAPS | authentification | oui |
| grafana_acl_sync | DC AD | 636 | LDAPS | lecture groupes | oui |
| grafana_acl_sync | VIP Grafana | 443 | HTTPS | API (jeton de compte de service) | oui |
| ROR (nœuds ES) | DC AD | 636 | LDAPS | ldap_auth | oui |
| Utilisateurs | VIP Grafana | 443 | HTTPS | consultation | oui |
| Exploitation | chaque nœud | 22 | SSH | administration | oui |
| keepalived | pairs | VRRP | VRRP | VIP | — |
| Alertmanager cluster | pairs | port gossip Mimir AM | TCP | peering | selon config |
| Ingress / cert-manager (K8s) | Issuer CA | 443 | HTTPS | émission | oui |
| Grafana (si greffon Enterprise) | Contrôleur AppDynamics on-prem `${APPD_FQDN}` | 8181 | HTTPS | greffon datasource ; CA du contrôleur dans le truststore Grafana | oui |
| otel-gw (optionnel) | Contrôleur AppDynamics `${APPD_OTEL_INGEST}` | 8181 | HTTPS | traces **vers** AppD (`/otis/ingest`, à vérifier sur la version) | oui |
| Contrôleur AppDynamics | DC AD | 636 | LDAPS | authentification LDAP du contrôleur on-prem | oui |
| Grafana ou exportateur qualifié | Console SCOM 2019 `${SCOM_FQDN}` | 443 | HTTPS | API REST / greffon tierce (voies B/C, à qualifier) | oui |
| Agents Windows (voie A) | VIP otel-gw `${OTEL_GW_FQDN}` | 4317, 4318 | gRPC / HTTPS | `windowseventlog` → OTLP | oui |
| Postes utilisateurs (SSO Kerberos) | VIP Grafana Apache `${GRAFANA_FQDN}` | 443 | HTTPS + Negotiate | SSO intégré Windows | oui |
| Apache (colocalisé) | Grafana `127.0.0.1` | 3000 | HTTP | Auth Proxy, pas d'exposition utilisateurs | local |
| Apache / Grafana | DC AD | 88 | Kerberos | Validation du ticket (SPN HTTP/${GRAFANA_FQDN}) | oui (Kerberos) |
| Grafana (si OIDC) | AD FS `${ADFS_FQDN}` | 443 | HTTPS | Generic OAuth (authorize, token, userinfo) | oui |
| Navigateurs (si OIDC) | AD FS `${ADFS_FQDN}` | 443 | HTTPS | Authentification fédérée | oui |

Les FQDN et IP d'exemple (production `10.80.0.0/16`, préproduction `10.81.0.0/16`,
existants `10.90.0.0/16` / `10.91.0.0/16`) figurent dans
[`variables/environnements.env`](../variables/environnements.env) — **modifier ici seulement**.

Ports d'écoute **locaux uniquement** (127.0.0.1) : télémétrie otelcol `:8888`
si on ne la scrape que localement ; à ouvrir au réseau de collecte si le
Prometheus agent est distant.

En première étape de laboratoire certains flux (Mimir, Loki, Tempo, Kafka)
peuvent encore être en clair **à l'intérieur** d'un segment filtré. En préprod
et prod, la cible est TLS partout. Cette bascule doit être planifiée
explicitement (certificats, SAN, truststores).

---

## 7. Exigences non fonctionnelles

| Id | Exigence | Cible (hypothèse à confirmer) | Mesure |
|---|---|---|---|
| DISPO-1 | Perte d'un nœud Kafka, Grafana, otel-gw, ingester : service maintenu | oui | exercices de panne en préprod |
| DISPO-2 | Disponibilité consultation | à chiffrer (ex. 99,9 %) | sondes + journaux VIP |
| RPO-1 | Ingestion OTLP | ≈ 0 si `acks=all` et ISR respecté | LAG, offsets |
| RPO-2 | Historique long terme | celui du S3 et de ses sauvegardes | tests de restauration |
| RTO-1 | Bascule Grafana | VIP, dizaines de secondes (à mesurer) | exercice |
| PERF-1 | Débit et cardinalité | à mesurer en préprod sur un échantillon réel | tests de charge |
| RET-1 | Rétention Kafka | hypothèse 3 jours (à confirmer) | config sujets |
| RET-2 | Rétention Mimir / Loki / Tempo | à définir par signal (ex. 15 / 30 / 7 jours — **hypothèse**) | compactor / retention |
| SEC-1 | Pas de secret en ligne de commande ni dans l'historique | oui | revue des procédures |
| SEC-2 | TLS vérifié, SAN = FQDN client | oui | `openssl s_client` |
| SEC-3 | Moindre privilège ROR et Grafana | oui | revue des blocs et mappings |
| SEC-4 | SELinux enforcing (VM) | oui | `getenforce`, `restorecon` |
| SEC-5 | Échéance des secrets de service | 90 jours lorsque le mécanisme existe | calendrier |
| EXP-1 | Installation hors ligne | oui | runbooks |
| EXP-2 | Supervision de la supervision | vue unique + alertes lag / up / certificats | Mimir + Alertmanager |
| EXP-3 | Sauvegarde / restauration documentée | oui | section exploitation des runbooks |

---

## 8. Dimensionnement — estimations recommandées

Les tableaux ci-dessous sont des **estimations recommandées** pour une organisation
traitant des **données sensibles**, avec préproduction et production **séparées**
(domaines, plages IP, plan de données et identités de service distincts ; pas de
partage Kafka / Mimir / Loki / Tempo / objet). Ils ne sont **pas** des mesures
issues d'un essai de charge. Ils devront être recalés après observation en
préproduction (débit, cardinalité, rétention objet).

**Justification (abrégée) :**

- **Trois domaines de défaillance** (zones A, B, C) : au minimum trois
  hyperviseurs, trois baies ou trois salles. Tout composant à quorum (Kafka,
  moteurs LGTM avec facteur de réplication 3) a un membre dans chaque zone.
  Préproduction et production ne partagent pas les mêmes hyperviseurs.
- **Séparation des rôles** : bastion, équilibreurs, Kafka, ingestion, stockage
  métriques / journaux / traces, interface Grafana, PostgreSQL, objet — pas de
  colocation de rôles critiques sur une même VM.
- **Bastion d'administration dédié** (deux VM, zones A et C) : seul point
  d'entrée SSH ; pas d'administration depuis le réseau utilisateur.
- **Pas de point unique de défaillance** sur le plan de données : Kafka à trois
  courtiers (RF=3, `min.insync.replicas=2`) ; Grafana en paire derrière VIP ;
  PostgreSQL primaire + réplique (bascule documentée ; un gestionnaire de
  bascule automatique du type Patroni reste optionnel et **non testé** ici) ;
  passerelles et moteurs répliqués. Les VIP keepalived sont un couple
  maître / secours (zones A et B) : la perte simultanée de A et B emporte le
  VIP — limite assumée du VRRP à deux nœuds, documentée.
- **Chiffrement au repos** : disques de données chiffrés (LUKS ou chiffrement
  équivalent au niveau de l'hyperviseur), chiffrement côté serveur du stockage
  objet (SSE), TLS en transit dès la préproduction. Les volumes Kubernetes
  suivent une StorageClass chiffrée lorsqu'elle existe.
- **Réseaux et zones séparés** : sous-réseaux distincts VIP, administration,
  ingestion, Kafka, stockage LGTM, interface, objet ; pas de route par défaut
  vers Internet ; règles pare-feu limitées aux sources nécessaires.
- **Préprod compacte, prod simple-scalable :** la préproduction valide les
  procédures HA avec trois nœuds par moteur (`target` compact, RF=3, objet).
  La production sépare écriture, lecture et backend pour limiter le rayon
  d'explosion et absorber la cardinalité.

Système d'exploitation des VM LGTM : **RHEL 8**. Les serveurs existants
(AD, ES, SCOM 2019, contrôleur AppDynamics) ne sont pas redimensionnés ici.

### 8.1 Préproduction — machines virtuelles

| Rôle | Noms d'exemple | Qté | vCPU | RAM | Disques (chiffrés) | OS | Zone |
|---|---|---|---|---|---|---|---|
| Bastion / administration | bastion-01, bastion-02 | 2 | 2 | 4 Go | OS 40 Go | RHEL 8 | A, C |
| Équilibreur HAProxy + keepalived | lb-01, lb-02 | 2 | 2 | 4 Go | OS 40 Go | RHEL 8 | A, B |
| Kafka (courtier + contrôleur KRaft) | kafka-01..03 | 3 | 4 | 16 Go | OS 50 Go + données 300 Go | RHEL 8 | A, B, C |
| Passerelle OTel + agent Prometheus | otel-gw-01, otel-gw-02 | 2 | 4 | 8 Go | OS 50 Go + WAL 50 Go | RHEL 8 | A, B |
| Mimir (compact HA, RF=3, objet) | mimir-01..03 | 3 | 4 | 16 Go | OS 50 Go + local 100 Go | RHEL 8 | A, B, C |
| Loki (compact HA, RF=3, objet) | loki-01..03 | 3 | 4 | 12 Go | OS 50 Go + local 100 Go | RHEL 8 | A, B, C |
| Tempo (compact HA, RF=3, objet) | tempo-01..03 | 3 | 4 | 12 Go | OS 50 Go + local 100 Go | RHEL 8 | A, B, C |
| Grafana | grafana-01, grafana-02 | 2 | 2 | 4 Go | OS 40 Go | RHEL 8 | A, B |
| PostgreSQL (primaire + réplique) | pg-01, pg-02 | 2 | 2 | 8 Go | OS 40 Go + données 80 Go | RHEL 8 | A, C |
| MinIO (si aucun S3 existant) | minio-01..04 | 4 | 4 | 8 Go | OS 50 Go + données 1 To | RHEL 8 | A, B, C, A |

**Total préproduction :** 22 VM, ou **26** avec MinIO. Domaine d'exemple :
`obs-pp.exemple.local`, préfixe `10.81`.

### 8.2 Production — machines virtuelles

| Rôle | Noms d'exemple | Qté | vCPU | RAM | Disques (chiffrés) | OS | Zone |
|---|---|---|---|---|---|---|---|
| Bastion / administration | bastion-01, bastion-02 | 2 | 2 | 4 Go | OS 40 Go | RHEL 8 | A, C |
| Équilibreur HAProxy + keepalived | lb-01, lb-02 | 2 | 4 | 8 Go | OS 40 Go | RHEL 8 | A, B |
| Kafka (courtier + contrôleur KRaft) | kafka-01..03 | 3 | 8 | 32 Go | OS 50 Go + données 800 Go | RHEL 8 | A, B, C |
| Passerelle OTel + agent Prometheus | otel-gw-01..03 | 3 | 6 | 16 Go | OS 50 Go + WAL 100 Go | RHEL 8 | A, B, C |
| Mimir écriture (distributor + ingester) | mimir-write-01..03 | 3 | 8 | 32 Go | OS 50 Go + local 200 Go | RHEL 8 | A, B, C |
| Mimir lecture (query-frontend + querier) | mimir-read-01, 02 | 2 | 8 | 24 Go | OS 50 Go + 50 Go | RHEL 8 | A, B |
| Mimir backend (store-gateway, compactor, AM) | mimir-backend-01..03 | 3 | 8 | 24 Go | OS 50 Go + 100 Go | RHEL 8 | A, B, C |
| Loki écriture | loki-write-01..03 | 3 | 6 | 24 Go | OS 50 Go + 200 Go | RHEL 8 | A, B, C |
| Loki lecture | loki-read-01, 02 | 2 | 6 | 16 Go | OS 50 Go + 50 Go | RHEL 8 | A, B |
| Loki backend | loki-backend-01..03 | 3 | 6 | 16 Go | OS 50 Go + 100 Go | RHEL 8 | A, B, C |
| Tempo distributor | tempo-dist-01, 02 | 2 | 4 | 8 Go | OS 50 Go | RHEL 8 | A, B |
| Tempo ingester | tempo-ing-01..03 | 3 | 6 | 16 Go | OS 50 Go + 200 Go | RHEL 8 | A, B, C |
| Tempo requête (frontend + querier) | tempo-query-01, 02 | 2 | 4 | 16 Go | OS 50 Go | RHEL 8 | A, C |
| Tempo compactor / metrics-generator | tempo-comp-01, 02 | 2 | 4 | 12 Go | OS 50 Go + 50 Go | RHEL 8 | A, B |
| Grafana | grafana-01, grafana-02 | 2 | 4 | 8 Go | OS 50 Go | RHEL 8 | A, B |
| PostgreSQL (primaire + réplique) | pg-01, pg-02 | 2 | 4 | 16 Go | OS 50 Go + données 150 Go | RHEL 8 | A, C |
| MinIO (si aucun S3 existant) | minio-01..04 | 4 | 8 | 16 Go | OS 50 Go + données 2 To | RHEL 8 | A, B, C, A |

**Total production :** 41 VM, ou **45** avec MinIO. Domaine d'exemple :
`obs.exemple.local`, préfixe `10.80`.

Les FQDN et adresses complets sont dans
[`variables/environnements.env`](../variables/environnements.env). Quatre nœuds
MinIO sur trois zones impliquent deux nœuds dans la zone A : un compromis
d'erasure coding, à revoir si un quatrième domaine de défaillance existe.

### 8.3 Kubernetes — pools de nœuds équivalents

Même isolation, mêmes zones, mêmes exigences de chiffrement. Les `requests`
suivent les budgets ci-dessous (par nœud). Anti-affinité de zone et PDB
obligatoires sur les charges critiques.

**Préproduction :**

| Pool | Nœuds | vCPU / RAM / disque par nœud | Usage | Zones |
|---|---|---|---|---|
| ingest | 2 | 4 / 8 Go / 100 Go | passerelle OTel, agent Prometheus | A, B |
| kafka | 3 | 4 / 16 Go / 350 Go local | StatefulSet Kafka (Strimzi) | A, B, C |
| lgtm | 6 | 4 / 16 Go / 150 Go | Mimir, Loki, Tempo (anti-affinité) | A, B, C (2 chacun) |
| ui | 2 | 2 / 8 Go / 120 Go | Grafana, PostgreSQL | A, C |
| objet | 0 ou 4 | 4 / 8 Go / 1 To | MinIO, si pas de S3 existant | A, B, C, A |
| system | 2 (ou existant) | 4 / 8 Go | Ingress, cert-manager, opérateurs | A, B |

**Production :**

| Pool | Nœuds | vCPU / RAM / disque par nœud | Usage | Zones |
|---|---|---|---|---|
| ingest | 3 | 6 / 16 Go / 150 Go | passerelle OTel, agent Prometheus | A, B, C |
| kafka | 3 | 8 / 32 Go / 850 Go local | StatefulSet Kafka | A, B, C |
| lgtm-write | 3 | 16 / 64 Go / 250 Go | ingesters / write Mimir, Loki, Tempo | A, B, C |
| lgtm-read | 3 | 8 / 32 Go / 100 Go | couches de requête | A, B, C |
| lgtm-backend | 3 | 8 / 32 Go / 150 Go | store-gateway, compacteurs, Alertmanager | A, B, C |
| ui | 2 | 4 / 16 Go / 200 Go | Grafana, PostgreSQL | A, C |
| objet | 0 ou 4 | 8 / 16 Go / 2 To | MinIO, si pas de S3 existant | A, B, C, A |
| system | 3 | 4 / 16 Go | Ingress, opérateurs | A, B, C |

L'objet S3 de long terme reste hors des PVC. StorageClass chiffrée pour Kafka,
PostgreSQL et WAL.

### 8.4 DNS, VIP et plan d'adressage — modifier ici seulement

Tous les noms d'exemple, toutes les adresses et tous les VIP (Grafana, passerelle
OTel, bootstrap Kafka, Mimir, Loki, Tempo, S3, ainsi que ES, SCOM 2019 et le
contrôleur AppDynamics on-premises) sont définis dans **un seul** fichier :

| Fichier | Rôle |
|---|---|
| [`variables/environnements.env`](../variables/environnements.env) | Source pour les commandes (`source` / `.`) et pour `scripts/rendre-config.sh` |
| [`variables/environnements.yaml`](../variables/environnements.yaml) | Équivalent YAML, à garder aligné |

**Modifier ici seulement.** Extraire le jeu d'un environnement :

```bash
export LGTM_ENV=prod          # ou : preprod
set -a
. /chemin/vers/variables/environnements.env
set +a
```

| Usage | FQDN d'exemple (prod) | VIP / IP (prod) | FQDN d'exemple (préprod) | VIP / IP (préprod) |
|---|---|---|---|---|
| Grafana | grafana.obs.exemple.local | 10.80.8.10 | grafana.obs-pp.exemple.local | 10.81.8.10 |
| Passerelle OTel / Ingress OTLP | otel-gw.obs.exemple.local | 10.80.8.11 | otel-gw.obs-pp.exemple.local | 10.81.8.11 |
| Kafka (DNS multi-A, **pas** de VIP L4) | kafka.obs.exemple.local | 10.80.30.11–13 | kafka.obs-pp.exemple.local | 10.81.30.11–13 |
| Bootstrap Kafka | kafka-01..03.obs.exemple.local:9092 | — | kafka-01..03.obs-pp.exemple.local:9092 | — |
| Mimir | mimir.obs.exemple.local | 10.80.8.12 | mimir.obs-pp.exemple.local | 10.81.8.12 |
| Loki | loki.obs.exemple.local | 10.80.8.13 | loki.obs-pp.exemple.local | 10.81.8.13 |
| Tempo | tempo.obs.exemple.local | 10.80.8.14 | tempo.obs-pp.exemple.local | 10.81.8.14 |
| S3 / MinIO | s3.obs.exemple.local | 10.80.8.15 | s3.obs-pp.exemple.local | 10.81.8.15 |
| PostgreSQL | pg.obs.exemple.local | 10.80.8.16 | pg.obs-pp.exemple.local | 10.81.8.16 |
| Elasticsearch (existant) | es.exemple.local | 10.90.10.10 | es-pp.exemple.local | 10.91.10.10 |
| SCOM 2019 (console) | scom.exemple.local | 10.90.20.10 | scom-pp.exemple.local | 10.91.20.10 |
| AppDynamics on-prem (8181) | appd.exemple.local | 10.90.30.10 | appd-pp.exemple.local | 10.91.30.10 |
| AD | dc01 / dc02.exemple.local | 10.90.1.11 / .12 | (annuaire souvent partagé) | idem |

Kafka n'utilise pas de VIP de niveau 4 : les clients reçoivent la liste
`${KAFKA_BOOTSTRAP}`. Un nom DNS à plusieurs enregistrements A est fourni pour
la lisibilité. Les modèles de configuration se rendent avec
`scripts/rendre-config.sh` (`envsubst`, ou repli Python).

---

## 9. Hypothèses et points ouverts

Certains points ont été **tranchés** (12 novembre 2026) ; d'autres restent
ouverts avant le gel définitif des règles réseau et des achats.

| # | Point | État |
|---|---|---|
| H1 | Choix du stockage objet : S3 existant ou MinIO, noms des seaux | **à confirmer** (MinIO optionnel dans les tableaux §8) |
| H2 | Noms et DN des groupes AD, base DN, UO | **exemples uniquement** |
| H3 | Nombre exact de VM / de réplicas, ressources réelles | **estimations recommandées** §8, à recalibrer après observation |
| H4 | FQDN, domaine DNS, VIP | **exemples fictifs** dans `variables/environnements.env` (`obs.exemple.local` / `obs-pp.exemple.local`) — **modifier ici seulement** |
| H5 | Rétention Kafka et rétention par signal | hypothèses |
| H6 | Objectif de disponibilité chiffré, RPO/RTO contractuels | hypothèses §7 |
| H7 | Version exacte d'Elasticsearch 8 et du greffon ROR | aligner les builds |
| H8 | AppDynamics | **tranché : contrôleur on-premises** (ADR-008) ; licence Grafana Enterprise **toujours à confirmer** |
| H9 | SCOM | **tranché : SCOM 2019**, support étendu jusqu'au 10 avril 2029 (heure du Pacifique), voir [lifecycle](https://learn.microsoft.com/en-us/lifecycle/products/system-center-2019-operations-manager) ; qualification des voies B/C **toujours ouverte** |
| H10 | mTLS Kafka dès la mise en service ou en phase 2 | recommandé, phase à fixer |
| H11 | Contrôleurs Kafka dédiés ou rôles combinés | combinés en première étape (ADR-009) |
| H12 | SSO Grafana OSS | **tranché (ADR-011)** : Kerberos/auth.proxy recommandé pour les postes du domaine ; OIDC Generic OAuth si AD FS est déployé ; SAML / Team Sync / auditing natif / permissions fines de sources = Enterprise, compensations OSS documentées. Procédures **non testées**. Présence réelle d'AD FS **à confirmer**. |

---

## 10. Cartographie des documents de déploiement

| Besoin | Document |
|---|---|
| Installer sur RHEL 8 | `../Runbook_LGTM_Prod_VM_RHEL8.md` |
| Installer sur Kubernetes | `../Runbook_LGTM_Prod_Kubernetes.md` |
| ACL et LDAP | `../scripts/` |
| Tableau de bord d'accueil | `../dashboards/one_screen_home.json` |
| Impacts et transition | [02_Etude_impact.md](02_Etude_impact.md) |
| DNS, VIP, plan d'adressage | `../variables/environnements.env` et `.yaml` — **modifier ici seulement** |
| Rendu des modèles | `../scripts/rendre-config.sh` |
