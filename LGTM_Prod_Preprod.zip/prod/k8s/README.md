# Extraits de values Helm

Fichiers indicatifs, à relire contre le `values.yaml` du **chart figé** le jour de
l'installation (clés parfois renommées entre versions). Images et registres sont
des exemples (`registre.exemple.local`). Aucun secret en clair.

Voir le runbook Kubernetes pour le contexte et les versions.


Les FQDN d'exemple (`grafana.obs.exemple.local`, `s3.obs.exemple.local`,
`registre.exemple.local`) viennent de `variables/environnements.env` —
**modifier ici seulement**. Préproduction : `obs-pp.exemple.local`.
