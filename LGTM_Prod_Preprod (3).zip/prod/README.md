# Plateforme LGTM — préproduction et production

Paquet autonome pour déployer Grafana LGTM (Loki, Grafana, Tempo, Mimir) avec
Kafka, OpenTelemetry Collector, ReadonlyREST **Enterprise 1.72.0** (Elasticsearch **8.19.0**), authentification **LDAP** (mécanisme principal, Grafana OSS), vue unique, et intégration
logique de SCOM **2019** et d'AppDynamics **on-premises**.

## Démarrer par

| Fichier | Contenu |
|---|---|
| [architecture/00_README.md](architecture/00_README.md) | Architecture, ADR, étude d'impact, diagrammes Visio |
| [Runbook_LGTM_Prod_VM_RHEL8.md](Runbook_LGTM_Prod_VM_RHEL8.md) | Déploiement sur machines virtuelles RHEL 8 (systemd, hors ligne, SELinux) |
| [Runbook_LGTM_Prod_Kubernetes.md](Runbook_LGTM_Prod_Kubernetes.md) | Déploiement Kubernetes (Helm, opérateurs, registre privé) |
| [scripts/README.md](scripts/README.md) | Composant `grafana_acl_sync` (ACL / LDAP) |
| [dashboards/one_screen_home.json](dashboards/one_screen_home.json) | Tableau de bord d'accueil « vue unique » |
| [k8s/](k8s/) | Extraits de values Helm et exemple de namespace |
| [variables/](variables/) | **Modifier ici seulement** : DNS, plan d'adressage, VIP (`environnements.env`) |
| [scripts/Actualiser-Variables.ps1](scripts/Actualiser-Variables.ps1) | Copie actualisée du dossier : remplace les `{{NOM_VARIABLE}}` (textes, `.vsdx`, `.docx`) dans une copie `sortie_...`, sans modifier l'original — [mode d'emploi](scripts/Actualiser-Variables.md) |
| [scripts/rendre-config.sh](scripts/rendre-config.sh) | Linux, bash seul : rendu des modèles `variables/templates/` avec le même fichier de valeurs |
| [architecture/annexes/Checklist_decision_stockage_objet.md](architecture/annexes/Checklist_decision_stockage_objet.md) | Décision stockage objet prise : **MinIO distribué** (ADR-002) ; contrôles avant installation ; questions pour l'archivage à froid optionnel |
| [architecture/annexes/Annexe_Stockage_objet_Hitachi_HCP_S3.md](architecture/annexes/Annexe_Stockage_objet_Hitachi_HCP_S3.md) | Archivage à froid (optionnel) — plateforme S3 interne d'objet et d'archivage : procédure Inf-360, copies d'exports |
| [architecture/annexes/Annexe_Stockage_objet_S3_MinIO.md](architecture/annexes/Annexe_Stockage_objet_S3_MinIO.md) | Stockage objet cible — MinIO distribué (licence AGPLv3 à examiner avant installation) |
| Annexes B des runbooks VM et Kubernetes | SSO Kerberos / OIDC — complément optionnel, LDAP reste le socle |

Les noms d'hôtes, VIP et adresses sont des **exemples fictifs** (`{{PROD_DOMAIN}}` /
`{{PREPROD_DOMAIN}}`) à modifier **uniquement** dans `variables/environnements.env`
(vue YAML de synthèse générée dans la copie actualisée). Le dimensionnement des VM et des pools Kubernetes est
un ensemble d'**estimations recommandées** (données sensibles, trois domaines de
défaillance). Les points non testés figurent en annexe de chaque runbook.
