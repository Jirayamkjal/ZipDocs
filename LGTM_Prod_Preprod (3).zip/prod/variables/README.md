# Variables d'environnements — DNS, plan d'adressage et VIP

**Modifier ici seulement :** [`environnements.env`](environnements.env), fichier de valeurs unique pour la préproduction et la production (exemples fictifs : domaines `{{PROD_DOMAIN}}` et `{{PREPROD_DOMAIN}}`). [`environnements.yaml`](environnements.yaml) est une vue de synthèse en `{{NOM_VARIABLE}}`, remplie dans la copie actualisée : ne pas y saisir de valeurs.

## Actualiser le dossier (PowerShell)

```powershell
.\scripts\Actualiser-Variables.ps1 -DryRun                    # analyse
.\scripts\Actualiser-Variables.ps1 -Environnement prod        # copie sortie_prod_<horodatage>
```

La copie reçoit les valeurs (Markdown, configurations, `.vsdx`, `.docx`) ; l'original reste en `{{NOM_VARIABLE}}`. Voir [`scripts/Actualiser-Variables.md`](../scripts/Actualiser-Variables.md).

## Chargement

```bash
export LGTM_ENV=prod          # ou : preprod
set -a
. /chemin/vers/variables/environnements.env
set +a
# Ensuite : echo "$GRAFANA_FQDN"  "$KAFKA_BOOTSTRAP"  "$APPD_URL"
```

## Rendu des modèles (Linux, bash)

```bash
# Tous les modèles de templates/ → variables/rendu/prod/ (ou preprod/)
LGTM_ENV=prod    ../scripts/rendre-config.sh
LGTM_ENV=preprod ../scripts/rendre-config.sh

# Un modèle isolé, ou liste des variables chargées
LGTM_ENV=prod ../scripts/rendre-config.sh --liste
LGTM_ENV=prod ../scripts/rendre-config.sh grafana.ini.tmpl /tmp/grafana.ini
```

Le script n'utilise que bash (aucune dépendance) ; une variable inconnue est laissée telle quelle et signalée. Le répertoire `variables/rendu/` est un produit généré : il peut être recréé à tout moment et n'est pas une source.

Aucun secret (mot de passe, jeton, clé S3) n'appartient à ces fichiers.

## SSO (Kerberos et AD FS)

Les variables `KRB_*`, `AUTH_PROXY_*`, `ADFS_*` et `OAUTH_REDIRECT_URL` sont dans le même fichier
(bloc « SSO Grafana OSS »). Aucun secret (keytab, client_secret) n'y figure. Voir
[ADR-011](../architecture/adr/ADR-011_SSO_Grafana_OSS.md) et les modèles
`grafana-auth-proxy.ini.tmpl`, `httpd-mod-auth-gssapi.conf.tmpl`,
`grafana-generic-oauth.ini.tmpl`, `krb5.conf.tmpl`.

## Versions Elasticsearch et ReadonlyREST

`ES_VERSION=8.19.0`, `ROR_VERSION=1.72.0`, `KIBANA_VERSION=8.19.0` (cette dernière à aligner sur la Kibana réellement déployée), ainsi que les noms de paquets `ROR_ES_PLUGIN_ZIP` (`readonlyrest-1.72.0_es8.19.0.zip`) et `ROR_KBN_PLUGIN_ZIP`. Le build ROR doit correspondre exactement à la version Elasticsearch. Voir [ADR-004](../architecture/adr/ADR-004_ROR_vs_XPack.md).

## Stockage objet

`STOCKAGE_OBJET_SCENARIO` : `minio` — stockage objet du chemin chaud = MinIO distribué ([ADR-002](../architecture/adr/ADR-002_Stockage_objet.md)). Examen de la licence AGPLv3 avant installation. Un HNAS seul n'est pas une cible S3.

`ARCHIVE_S3_FQDN` / `ARCHIVE_S3_ENDPOINT` / `ARCHIVE_S3_CA_FILE` / `ARCHIVE_S3_BUCKET` : archivage à froid optionnel sur la plateforme S3 interne d'objet et d'archivage (copies d'exports). FQDN d'exemple fictifs, à remplacer par le FQDN fourni par l'équipe stockage après Inf-360 et demande de compartiment.

`S3_ENDPOINT` / `S3_FQDN` : VIP MinIO (HAProxy + keepalived), `https://`.

`S3_CA_FILE` : chemin du PEM de la CA du service objet. `S3_FORCE_PATH_STYLE` : `true` (path-style) ou `false` (virtual-hosted). `S3_REGION` : exigé par les clients Grafana, à confirmer.

## Seaux objet et MinIO

Les noms de seaux (`S3_BUCKET_MIMIR`, `S3_BUCKET_LOKI`, `S3_BUCKET_TEMPO`, `S3_BUCKET_ADMIN`) et les ports MinIO d'exemple (`MINIO_API_PORT`, `MINIO_CONSOLE_PORT`) se définissent dans le même fichier `.env`. Les FQDN `s3.` et `minio-01` … `minio-04` sont déjà dérivés du domaine. Procédure si aucun S3 n'existe : [Annexe stockage objet](../architecture/annexes/Annexe_Stockage_objet_S3_MinIO.md).

Les variables SSO (Kerberos, AD FS) restent disponibles pour l'**annexe** SSO des runbooks ; elles ne sont pas requises pour l'authentification LDAP principale.
