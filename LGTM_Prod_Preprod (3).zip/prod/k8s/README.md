# Extraits de values Helm

Fichiers indicatifs, à relire contre le `values.yaml` du **chart figé** le jour de
l'installation (clés parfois renommées entre versions). Images et registres sont
des exemples (`{{PROD_REGISTRY_FQDN}}`). Aucun secret en clair.

Voir le runbook Kubernetes pour le contexte et les versions.


Les FQDN d'exemple (`{{PROD_GRAFANA_FQDN}}`, `{{PROD_S3_FQDN}}`,
`{{PROD_REGISTRY_FQDN}}`) viennent de `variables/environnements.env` —
**modifier ici seulement**. Préproduction : `{{PREPROD_DOMAIN}}`.
