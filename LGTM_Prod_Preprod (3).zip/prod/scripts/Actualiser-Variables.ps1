﻿<#
.SYNOPSIS
    Produit une copie actualisée du dossier LGTM : chaque {{NOM_VARIABLE}} est
    remplacé par sa valeur, l'original n'est jamais modifié.

.DESCRIPTION
    Fichier de valeurs unique : variables/environnements.env (format NOM=valeur,
    références ${AUTRE_NOM} autorisées, lu aussi par bash et rendre-config.sh).

    Étapes :
      1. lecture et résolution des valeurs pour l'environnement choisi
         (PROD_<NOM> ou PREPROD_<NOM> devient <NOM>, comme dans bash) ;
      2. inventaire des {{NOM_VARIABLE}} dans les fichiers texte et dans les XML
         des fichiers Office (.vsdx, .docx, .xlsx, .pptx) ;
      3. rapport : variables utilisées mais absentes du fichier de valeurs,
         valeurs définies mais jamais utilisées ;
      4. copie du dossier source vers le dossier de sortie, puis remplacement
         dans la COPIE uniquement (encodage, BOM et fins de ligne préservés ;
         .vsdx / .docx rouverts et réécrits avec System.IO.Compression) ;
      5. rendu des modèles variables/templates/*.tmpl vers
         variables/rendu/prod et variables/rendu/preprod de la copie.

    Aucun secret ne doit figurer dans le fichier de valeurs : une variable dont
    le nom évoque un secret (PASSWORD, SECRET, TOKEN, API_KEY...) doit être vide
    ou contenir un chemin de fichier ; sa valeur n'est jamais affichée.

    Compatible Windows PowerShell 5.1 et PowerShell 7 (Windows, Linux).

.PARAMETER Source
    Dossier racine du dossier LGTM (par défaut : le parent du dossier scripts).

.PARAMETER Sortie
    Dossier de sortie à créer (par défaut : sortie_<env>_AAAAMMJJ-HHmmss à côté
    du dossier source). Ne doit pas exister, ni se trouver dans la source.

.PARAMETER FichierVariables
    Fichier de valeurs (par défaut : <Source>\variables\environnements.env).

.PARAMETER Environnement
    prod (défaut) ou preprod : choisit les variables courtes (DOMAIN,
    GRAFANA_FQDN...). Les variables PROD_* et PREPROD_* restent disponibles.

.PARAMETER DryRun
    Analyse seule : rien n'est copié ni écrit. Équivaut à -WhatIf.

.PARAMETER ListerValeurs
    Affiche les valeurs résolues (secrets masqués) puis s'arrête.

.PARAMETER Strict
    Code de sortie 1 si des variables utilisées sont absentes du fichier.

.PARAMETER Ignorer
    Noms à ne pas signaler (par défaut NOM_VARIABLE, utilisé dans la
    documentation pour décrire le format).

.PARAMETER RegenererPng
    Après le remplacement, régénère dans la copie les aperçus PNG des
    diagrammes avec les valeurs de l'environnement (python3 + LibreOffice
    requis ; sinon un avertissement est affiché et les PNG gardent les
    valeurs d'exemple).

.EXAMPLE
    .\scripts\Actualiser-Variables.ps1 -DryRun

.EXAMPLE
    .\scripts\Actualiser-Variables.ps1 -Environnement preprod -Sortie D:\livraison\lgtm-preprod
#>
[CmdletBinding(SupportsShouldProcess = $true)]
param(
    [string]$Source,
    [string]$Sortie,
    [string]$FichierVariables,
    [ValidateSet('prod', 'preprod')]
    [string]$Environnement = 'prod',
    [switch]$DryRun,
    [switch]$ListerValeurs,
    [switch]$Strict,
    [string[]]$Ignorer = @('NOM_VARIABLE'),
    [switch]$RegenererPng
)

Set-StrictMode -Version 2.0
$ErrorActionPreference = 'Stop'

# ----------------------------------------------------------------------------
# Constantes
# ----------------------------------------------------------------------------
$MotifVariable   = '\{\{([A-Z][A-Z0-9_]*)\}\}'
$MotifSensible   = 'PASSWORD|PASSWD|SECRET|TOKEN|API_KEY|PRIVATE_KEY|MDP|MOT_DE_PASSE'
$ExtensionsTexte = @('.md', '.markdown', '.txt', '.yaml', '.yml', '.ini', '.toml', '.conf',
                     '.cfg', '.sh', '.bash', '.ps1', '.psm1', '.psd1', '.json', '.env',
                     '.example', '.tmpl', '.properties', '.service', '.timer', '.py',
                     '.xml', '.csv', '.j2', '.tf', '.sql', '.html', '.htm')
$ExtensionsOffice = @('.vsdx', '.vssx', '.vstx', '.docx', '.dotx', '.xlsx', '.pptx')
$DossiersExclus   = @('.git', '.svn', '__pycache__')
# Outils dont les {{NOM_VARIABLE}} sont des modèles : ni analysés ni remplacés
$OutilsExclus     = @('architecture/diagrammes/_gen_visio.py')

$Utf8SansBom = New-Object System.Text.UTF8Encoding($false, $true)   # strict
$Utf8AvecBom = New-Object System.Text.UTF8Encoding($true)

function Write-Info([string]$Texte)  { Write-Host $Texte }
function Write-Titre([string]$Texte) { Write-Host ''; Write-Host "== $Texte ==" -ForegroundColor Cyan }

function Test-NomSensible([string]$Nom) {
    # URL, chemin ou en-tête : pas un secret (ex. ADFS_TOKEN_URL, *_FILE)
    if ($Nom -match '_(URL|FILE|FICHIER|PATH|CHEMIN|HEADER|ENDPOINT)$') { return $false }
    return ($Nom -match $MotifSensible)
}

# ----------------------------------------------------------------------------
# Chemins
# ----------------------------------------------------------------------------
if (-not $Source) { $Source = Split-Path -Parent (Split-Path -Parent $MyInvocation.MyCommand.Path) }
if (-not (Test-Path -LiteralPath $Source -PathType Container)) { throw "Dossier source introuvable : $Source" }
$Source = (Resolve-Path -LiteralPath $Source).ProviderPath.TrimEnd('\', '/')

if (-not $FichierVariables) { $FichierVariables = Join-Path (Join-Path $Source 'variables') 'environnements.env' }
if (-not (Test-Path -LiteralPath $FichierVariables -PathType Leaf)) { throw "Fichier de valeurs introuvable : $FichierVariables" }
$FichierVariables = (Resolve-Path -LiteralPath $FichierVariables).ProviderPath

$Horodatage = Get-Date -Format 'yyyyMMdd-HHmmss'
if (-not $Sortie) {
    $Sortie = Join-Path (Split-Path -Parent $Source) ("sortie_{0}_{1}" -f $Environnement, $Horodatage)
}
$Sortie = [System.IO.Path]::GetFullPath($Sortie).TrimEnd('\', '/')

$sep = [System.IO.Path]::DirectorySeparatorChar
$comparaison = [System.StringComparison]::OrdinalIgnoreCase
if ($Sortie.Equals($Source, $comparaison) -or $Sortie.StartsWith($Source + $sep, $comparaison)) {
    throw "Le dossier de sortie ne doit pas être la source ni se trouver dedans : $Sortie"
}

# ----------------------------------------------------------------------------
# Lecture du fichier de valeurs (sous-ensemble sûr de la syntaxe bash)
# ----------------------------------------------------------------------------
function Read-FichierValeurs([string]$Chemin) {
    $defs = New-Object 'System.Collections.Generic.Dictionary[string,object]'
    $numero = 0
    foreach ($ligne in [System.IO.File]::ReadAllLines($Chemin, $Utf8SansBom)) {
        $numero++
        if ($ligne -notmatch '^([A-Z][A-Z0-9_]*)=(.*)$') { continue }   # commentaires, blocs bash indentés
        $nom = $Matches[1]; $reste = $Matches[2]
        $mode = 'nq'; $brut = ''; $apres = ''
        if ($reste.StartsWith('"')) {
            $fin = $reste.IndexOf('"', 1)
            if ($fin -lt 0) { throw "Ligne $numero : guillemet fermant manquant pour $nom" }
            $brut = $reste.Substring(1, $fin - 1); $apres = $reste.Substring($fin + 1); $mode = 'dq'
        } elseif ($reste.StartsWith("'")) {
            $fin = $reste.IndexOf("'", 1)
            if ($fin -lt 0) { throw "Ligne $numero : apostrophe fermante manquante pour $nom" }
            $brut = $reste.Substring(1, $fin - 1); $apres = $reste.Substring($fin + 1); $mode = 'sq'
        } else {
            $brut = ($reste -split '\s+#', 2)[0].Trim()
            if ($brut -match '\s') { throw "Ligne $numero : valeur avec espace sans guillemets pour $nom" }
        }
        $apres = $apres.Trim()
        if ($apres -and -not $apres.StartsWith('#')) { throw "Ligne $numero : syntaxe non prise en charge après la valeur de $nom" }
        if ($mode -ne 'sq') {
            if ($brut -match '\$\(|`') { throw "Ligne $numero : substitution de commande interdite dans $nom" }
            $sansRef = [regex]::Replace($brut, '\$\{[A-Za-z_][A-Za-z0-9_]*\}', '')
            if ($sansRef.Contains('$')) { throw "Ligne $numero : seule la forme `${NOM} est prise en charge dans $nom" }
        }
        $defs[$nom] = [pscustomobject]@{ Brut = $brut; Mode = $mode; Ligne = $numero }
    }
    return ,$defs
}

$Defs = Read-FichierValeurs $FichierVariables

function Get-Tag([string]$Env) { if ($Env -eq 'prod') { return 'PROD' } else { return 'PREPROD' } }

# Résolution paresseuse : <NOM> = ${TAG}_<NOM> s'il existe (règle du jeu court bash), sinon <NOM>.
$Caches = @{}
$Avertissements = New-Object 'System.Collections.Generic.List[string]'
function Resolve-Valeur([string]$Nom, [string]$Env, [string[]]$Pile) {
    if ($Nom -eq 'LGTM_ENV') { return $Env }
    $tag = Get-Tag $Env
    if (-not $Caches.ContainsKey($Env)) { $Caches[$Env] = @{} }
    $cache = $Caches[$Env]
    if ($cache.ContainsKey($Nom)) { return $cache[$Nom] }
    $src = $null
    if ($Defs.ContainsKey("${tag}_$Nom")) { $src = "${tag}_$Nom" } elseif ($Defs.ContainsKey($Nom)) { $src = $Nom }
    if ($null -eq $src) { return $null }
    if ($Pile -contains $src) { throw "Référence circulaire : $(($Pile + $src) -join ' -> ')" }
    $d = $Defs[$src]
    $valeur = $d.Brut
    if ($d.Mode -ne 'sq') {
        $refs = [regex]::Matches($valeur, '\$\{([A-Za-z_][A-Za-z0-9_]*)\}')
        foreach ($r in @($refs)) {
            $v = Resolve-Valeur $r.Groups[1].Value $Env ($Pile + $src)
            if ($null -eq $v) {
                $Avertissements.Add("Ligne $($d.Ligne) : `${$($r.Groups[1].Value)} inconnue dans $src (remplacée par une chaîne vide, comme bash)")
                $v = ''
            }
            $valeur = $valeur.Replace($r.Value, $v)
        }
    }
    $cache[$Nom] = $valeur
    return $valeur
}

function Get-Valeurs([string]$Env) {
    $tag = Get-Tag $Env
    $noms = New-Object 'System.Collections.Generic.SortedSet[string]' ([System.StringComparer]::Ordinal)
    foreach ($k in $Defs.Keys) {
        [void]$noms.Add($k)
        if ($k.StartsWith("${tag}_")) { [void]$noms.Add($k.Substring($tag.Length + 1)) }
    }
    [void]$noms.Add('LGTM_ENV')
    $table = New-Object 'System.Collections.Generic.Dictionary[string,string]' ([System.StringComparer]::Ordinal)
    foreach ($n in $noms) { $table[$n] = [string](Resolve-Valeur $n $Env @()) }
    return ,$table
}

$Valeurs = Get-Valeurs $Environnement

# Garde-fou secrets : nom sensible => vide ou chemin de fichier uniquement
foreach ($n in @($Valeurs.Keys)) {
    if (Test-NomSensible $n) {
        $v = $Valeurs[$n]
        if ($v -and -not ($v -match '^(/|[A-Za-z]:\\|\\\\|\.{1,2}[\\/]|~[\\/])')) {
            throw "La variable $n semble contenir un secret (valeur non affichée). Mettre un chemin de fichier 0600 à la place."
        }
    }
}

if ($ListerValeurs) {
    Write-Titre "Valeurs résolues ($Environnement) — $FichierVariables"
    foreach ($n in $Valeurs.Keys) {
        if (Test-NomSensible $n) { Write-Info ("{0}=(masqué)" -f $n) } else { Write-Info ("{0}={1}" -f $n, $Valeurs[$n]) }
    }
    foreach ($a in $Avertissements) { Write-Warning $a }
    return
}

# ----------------------------------------------------------------------------
# Inventaire des fichiers
# ----------------------------------------------------------------------------
function Get-Fichiers([string]$Racine) {
    $res = New-Object 'System.Collections.Generic.List[object]'
    foreach ($f in Get-ChildItem -LiteralPath $Racine -Recurse -Force -File) {
        $rel = $f.FullName.Substring($Racine.Length + 1)
        $parties = $rel -split '[\\/]'
        $exclu = $false
        foreach ($p in $parties[0..($parties.Count - 2)]) { if ($DossiersExclus -contains $p) { $exclu = $true } }
        if ($exclu -and $parties.Count -gt 1) { continue }
        $ext = $f.Extension.ToLowerInvariant()
        $type = 'binaire'
        if ($ExtensionsOffice -contains $ext) { $type = 'office' }
        elseif ($ExtensionsTexte -contains $ext -or $f.Name -like '*.env.example') { $type = 'texte' }
        $res.Add([pscustomobject]@{ Rel = ($rel -replace '\\', '/'); Plein = $f.FullName; Type = $type })
    }
    return ,$res
}

# Décodage avec détection du BOM ; $null si le fichier n'est pas du texte UTF-8/UTF-16
function Read-Texte([byte[]]$Octets) {
    if ($Octets.Length -ge 3 -and $Octets[0] -eq 0xEF -and $Octets[1] -eq 0xBB -and $Octets[2] -eq 0xBF) {
        return [pscustomobject]@{ Texte = $Utf8SansBom.GetString($Octets, 3, $Octets.Length - 3); Enc = 'utf8bom' }
    }
    if ($Octets.Length -ge 2 -and $Octets[0] -eq 0xFF -and $Octets[1] -eq 0xFE) {
        return [pscustomobject]@{ Texte = [System.Text.Encoding]::Unicode.GetString($Octets, 2, $Octets.Length - 2); Enc = 'utf16le' }
    }
    if ($Octets.Length -ge 2 -and $Octets[0] -eq 0xFE -and $Octets[1] -eq 0xFF) {
        return [pscustomobject]@{ Texte = [System.Text.Encoding]::BigEndianUnicode.GetString($Octets, 2, $Octets.Length - 2); Enc = 'utf16be' }
    }
    try { return [pscustomobject]@{ Texte = $Utf8SansBom.GetString($Octets); Enc = 'utf8' } }
    catch { return $null }
}

function ConvertTo-Octets([string]$Texte, [string]$Enc) {
    switch ($Enc) {
        'utf8bom' { return [byte[]](@(0xEF, 0xBB, 0xBF) + $Utf8SansBom.GetBytes($Texte)) }
        'utf16le' { return [byte[]](@(0xFF, 0xFE) + [System.Text.Encoding]::Unicode.GetBytes($Texte)) }
        'utf16be' { return [byte[]](@(0xFE, 0xFF) + [System.Text.Encoding]::BigEndianUnicode.GetBytes($Texte)) }
        default   { return $Utf8SansBom.GetBytes($Texte) }
    }
}

function Get-Jetons([string]$Texte) {
    $set = New-Object 'System.Collections.Generic.HashSet[string]'
    foreach ($m in [regex]::Matches($Texte, $MotifVariable)) { [void]$set.Add($m.Groups[1].Value) }
    return ,$set
}

Add-Type -AssemblyName System.IO.Compression
Add-Type -AssemblyName System.IO.Compression.FileSystem

function Test-PartieXml([string]$Nom) { return ($Nom -match '\.(xml|rels)$') }

$Fichiers = Get-Fichiers $Source
$RelVariables = $FichierVariables.Substring([Math]::Min($FichierVariables.Length, $Source.Length + 1)) -replace '\\', '/'
$Usages = @{}           # nom -> liste de fichiers
$ParFichier = @{}       # rel -> nombre de jetons
$NonLus = New-Object 'System.Collections.Generic.List[string]'
$Coupures = New-Object 'System.Collections.Generic.List[string]'

foreach ($f in $Fichiers) {
    if ($f.Rel -eq $RelVariables) { continue }
    if ($OutilsExclus -contains $f.Rel) { continue }
    $jetons = $null
    if ($f.Type -eq 'texte') {
        $t = Read-Texte ([System.IO.File]::ReadAllBytes($f.Plein))
        if ($null -eq $t) { $NonLus.Add($f.Rel); continue }
        $jetons = Get-Jetons $t.Texte
    } elseif ($f.Type -eq 'office') {
        $jetons = New-Object 'System.Collections.Generic.HashSet[string]'
        $zip = [System.IO.Compression.ZipFile]::OpenRead($f.Plein)
        try {
            foreach ($e in $zip.Entries) {
                if (-not (Test-PartieXml $e.FullName)) { continue }
                $flux = $e.Open(); $ms = New-Object System.IO.MemoryStream
                try { $flux.CopyTo($ms) } finally { $flux.Dispose() }
                $t = Read-Texte $ms.ToArray()
                if ($null -eq $t) { continue }
                foreach ($j in (Get-Jetons $t.Texte)) { [void]$jetons.Add($j) }
                # Accolades isolées : variable probablement coupée par la mise en forme (Word)
                $reste = [regex]::Replace($t.Texte, $MotifVariable, '')
                if ($reste -match '\{\{[A-Z_]*<|>[A-Z0-9_]*\}\}') { $Coupures.Add("$($f.Rel) : $($e.FullName)") }
            }
        } finally { $zip.Dispose() }
    } else { continue }
    if ($jetons.Count -gt 0) {
        $ParFichier[$f.Rel] = $jetons.Count
        foreach ($j in $jetons) {
            if (-not $Usages.ContainsKey($j)) { $Usages[$j] = New-Object 'System.Collections.Generic.List[string]' }
            $Usages[$j].Add($f.Rel)
        }
    }
}

$Absentes = @($Usages.Keys | Where-Object { -not $Valeurs.ContainsKey($_) -and ($Ignorer -notcontains $_) } | Sort-Object)
# Inutilisées : noms du fichier de valeurs (et jeu court) jamais référencés
# Une définition est utilisée si son nom apparaît comme variable, si son jeu
# court apparaît (PROD_X / PREPROD_X pour la variable X), ou si une définition
# utilisée la référence avec la forme bash dollar-accolade.
$DefsUtilisees = New-Object 'System.Collections.Generic.HashSet[string]' ([System.StringComparer]::Ordinal)
$aTraiter = New-Object 'System.Collections.Generic.Queue[string]'
foreach ($u in @($Usages.Keys)) {
    foreach ($c in @($u, "PROD_$u", "PREPROD_$u")) { if ($Defs.ContainsKey($c) -and $DefsUtilisees.Add($c)) { $aTraiter.Enqueue($c) } }
}
while ($aTraiter.Count -gt 0) {
    $d = $Defs[$aTraiter.Dequeue()]
    if ($d.Mode -eq 'sq') { continue }
    foreach ($r in @([regex]::Matches($d.Brut, '\$\{([A-Za-z_][A-Za-z0-9_]*)\}'))) {
        $u = $r.Groups[1].Value
        foreach ($c in @($u, "PROD_$u", "PREPROD_$u")) { if ($Defs.ContainsKey($c) -and $DefsUtilisees.Add($c)) { $aTraiter.Enqueue($c) } }
    }
}
$Inutilisees = @($Defs.Keys | Where-Object { -not $DefsUtilisees.Contains($_) } | Sort-Object)
$Utilisees = @($Usages.Keys | Where-Object { $Valeurs.ContainsKey($_) } | Sort-Object)

Write-Titre 'Analyse'
Write-Info ("Source            : {0}" -f $Source)
Write-Info ("Fichier de valeurs: {0}" -f $FichierVariables)
Write-Info ("Environnement     : {0}" -f $Environnement)
Write-Info ("Fichiers analysés : {0} (dont {1} avec variables)" -f $Fichiers.Count, $ParFichier.Count)
Write-Info ("Variables utilisées et définies : {0}" -f $Utilisees.Count)
foreach ($a in $Avertissements) { Write-Warning $a }
if ($NonLus.Count) { Write-Warning ("Fichiers texte non UTF-8 ignorés : {0}" -f ($NonLus -join ', ')) }
if ($Coupures.Count) { Write-Warning ("Variable(s) possiblement coupée(s) par la mise en forme : {0}" -f ($Coupures -join '; ')) }
if ($Absentes.Count) {
    Write-Warning ("{0} variable(s) utilisée(s) mais absente(s) du fichier de valeurs (laissées telles quelles) :" -f $Absentes.Count)
    foreach ($n in $Absentes) { Write-Host ("   {{{{{0}}}}}  <- {1}" -f $n, (($Usages[$n] | Select-Object -Unique) -join ', ')) -ForegroundColor Yellow }
} else {
    Write-Info 'Aucune variable utilisée absente du fichier de valeurs.'
}
Write-Info ("Valeurs définies jamais utilisées : {0} (liste complète dans le rapport)" -f $Inutilisees.Count)

$simulation = $DryRun -or -not $PSCmdlet.ShouldProcess($Sortie, 'Créer la copie actualisée')
if ($simulation) {
    Write-Titre 'Simulation (DryRun / WhatIf) : aucune copie, aucun fichier écrit'
    Write-Info ("Sortie prévue : {0}" -f $Sortie)
    foreach ($k in ($ParFichier.Keys | Sort-Object)) { Write-Info ("  {0}  ({1} variable(s))" -f $k, $ParFichier[$k]) }
    if ($Inutilisees.Count) { Write-Info ("Jamais utilisées : {0}" -f ($Inutilisees -join ', ')) }
    if ($Strict -and $Absentes.Count) { exit 1 }
    return
}

# ----------------------------------------------------------------------------
# Copie puis remplacement dans la copie
# ----------------------------------------------------------------------------
if (Test-Path -LiteralPath $Sortie) { throw "Le dossier de sortie existe déjà : $Sortie" }
Write-Titre 'Copie'
[void](New-Item -ItemType Directory -Path $Sortie)
foreach ($f in $Fichiers) {
    $dest = Join-Path $Sortie ($f.Rel -replace '/', $sep)
    $dir = Split-Path -Parent $dest
    if (-not (Test-Path -LiteralPath $dir)) { [void](New-Item -ItemType Directory -Path $dir -Force) }
    Copy-Item -LiteralPath $f.Plein -Destination $dest
}
Write-Info ("{0} fichier(s) copiés vers {1}" -f $Fichiers.Count, $Sortie)

function Format-Valeur([string]$Valeur, [string]$Contexte) {
    switch ($Contexte) {
        'xml'  { return [System.Security.SecurityElement]::Escape($Valeur) }
        'json' { return ($Valeur.Replace('\', '\\').Replace('"', '\"')) }
        default { return $Valeur }
    }
}

function Set-Variables([string]$Texte, $Table, [string]$Contexte) {
    $evaluateur = [System.Text.RegularExpressions.MatchEvaluator] {
        param($m)
        $n = $m.Groups[1].Value
        if ($Table.ContainsKey($n)) { return (Format-Valeur $Table[$n] $Contexte) }
        return $m.Value
    }
    return [regex]::Replace($Texte, $MotifVariable, $evaluateur)
}

function Update-FichierTexte([string]$Chemin, $Table) {
    $t = Read-Texte ([System.IO.File]::ReadAllBytes($Chemin))
    if ($null -eq $t) { return $false }
    $ext = [System.IO.Path]::GetExtension($Chemin).ToLowerInvariant()
    $ctx = 'texte'; if ($ext -eq '.json') { $ctx = 'json' } elseif ($ext -eq '.xml') { $ctx = 'xml' }
    $nouveau = Set-Variables $t.Texte $Table $ctx
    if ($nouveau -ceq $t.Texte) { return $false }
    [System.IO.File]::WriteAllBytes($Chemin, (ConvertTo-Octets $nouveau $t.Enc))
    return $true
}

function Update-FichierOffice([string]$Chemin, $Table) {
    $modifie = $false
    $zip = [System.IO.Compression.ZipFile]::Open($Chemin, [System.IO.Compression.ZipArchiveMode]::Update)
    try {
        foreach ($e in @($zip.Entries)) {
            if (-not (Test-PartieXml $e.FullName)) { continue }
            $flux = $e.Open()
            try {
                $ms = New-Object System.IO.MemoryStream
                $flux.CopyTo($ms)
                $t = Read-Texte $ms.ToArray()
                if ($null -eq $t) { continue }
                $nouveau = Set-Variables $t.Texte $Table 'xml'
                if ($nouveau -ceq $t.Texte) { continue }
                $octets = ConvertTo-Octets $nouveau $t.Enc
                $flux.Seek(0, [System.IO.SeekOrigin]::Begin) | Out-Null
                $flux.SetLength(0)
                $flux.Write($octets, 0, $octets.Length)
                $modifie = $true
            } finally { $flux.Dispose() }
        }
    } finally { $zip.Dispose() }
    return $modifie
}

Write-Titre 'Remplacement dans la copie'
$Modifies = New-Object 'System.Collections.Generic.List[string]'
foreach ($f in $Fichiers) {
    if (-not $ParFichier.ContainsKey($f.Rel)) { continue }
    if ($f.Rel -like 'variables/templates/*') { continue }        # les modèles restent des modèles
    $dest = Join-Path $Sortie ($f.Rel -replace '/', $sep)
    $ok = $false
    if ($f.Type -eq 'texte') { $ok = Update-FichierTexte $dest $Valeurs }
    elseif ($f.Type -eq 'office') { $ok = Update-FichierOffice $dest $Valeurs }
    if ($ok) { $Modifies.Add($f.Rel); Write-Info ("  actualisé : {0}" -f $f.Rel) }
}

# Rendu des modèles pour les deux environnements (comme rendre-config.sh)
$DossierModeles = Join-Path (Join-Path $Sortie 'variables') 'templates'
$Rendus = New-Object 'System.Collections.Generic.List[string]'
if (Test-Path -LiteralPath $DossierModeles) {
    Write-Titre 'Rendu des modèles (variables/rendu/prod et preprod)'
    foreach ($envRendu in @('prod', 'preprod')) {
        $table = Get-Valeurs $envRendu
        $dossierRendu = Join-Path (Join-Path (Join-Path $Sortie 'variables') 'rendu') $envRendu
        if (-not (Test-Path -LiteralPath $dossierRendu)) { [void](New-Item -ItemType Directory -Path $dossierRendu -Force) }
        foreach ($m in Get-ChildItem -LiteralPath $DossierModeles -Filter '*.tmpl' -File) {
            $t = Read-Texte ([System.IO.File]::ReadAllBytes($m.FullName))
            if ($null -eq $t) { continue }
            $ext = [System.IO.Path]::GetExtension($m.BaseName).ToLowerInvariant()
            $ctx = 'texte'; if ($ext -eq '.json') { $ctx = 'json' }
            $cible = Join-Path $dossierRendu $m.BaseName
            [System.IO.File]::WriteAllBytes($cible, (ConvertTo-Octets (Set-Variables $t.Texte $table $ctx) $t.Enc))
            $Rendus.Add("variables/rendu/$envRendu/$($m.BaseName)")
        }
        Write-Info ("  {0} : {1} modèle(s)" -f $envRendu, @(Get-ChildItem -LiteralPath $DossierModeles -Filter '*.tmpl' -File).Count)
    }
}

# ----------------------------------------------------------------------------
# Rapport (aucun secret : valeurs sensibles masquées)
# ----------------------------------------------------------------------------
$rapport = New-Object 'System.Collections.Generic.List[string]'
$rapport.Add('# Rapport d''actualisation des variables')
$rapport.Add('')
$rapport.Add("- Date : $(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')")
$rapport.Add("- Source (non modifiée) : $Source")
$rapport.Add("- Fichier de valeurs : $FichierVariables")
$rapport.Add("- Environnement : $Environnement")
$rapport.Add("- Fichiers actualisés : $($Modifies.Count) ; modèles rendus : $($Rendus.Count)")
$rapport.Add('')
$rapport.Add('## Variables utilisées et leur valeur')
$rapport.Add('')
foreach ($n in $Utilisees) {
    $v = $Valeurs[$n]; if (Test-NomSensible $n) { $v = '(masqué)' }
    $rapport.Add(('- `{0}` = `{1}`' -f $n, $v))
}
$rapport.Add('')
$rapport.Add('## Utilisées mais absentes du fichier de valeurs (laissées telles quelles)')
$rapport.Add('')
if ($Absentes.Count) { foreach ($n in $Absentes) { $rapport.Add(('- `{0}` : {1}' -f $n, (($Usages[$n] | Select-Object -Unique) -join ', '))) } } else { $rapport.Add('- aucune') }
$rapport.Add('')
$rapport.Add('## Définies mais jamais utilisées')
$rapport.Add('')
$rapport.Add(($Inutilisees -join ', '))
$rapport.Add('')
$rapport.Add('## Fichiers actualisés')
$rapport.Add('')
foreach ($m in $Modifies) { $rapport.Add("- $m") }
foreach ($m in $Rendus) { $rapport.Add("- $m (rendu)") }
$cheminRapport = Join-Path $Sortie 'RAPPORT_ACTUALISATION.md'
[System.IO.File]::WriteAllLines($cheminRapport, $rapport.ToArray(), $Utf8SansBom)

# ----------------------------------------------------------------------------
# Aperçus PNG des diagrammes (optionnel)
# ----------------------------------------------------------------------------
$Generateur = Join-Path $Sortie ((('architecture', 'diagrammes', '_gen_visio.py') -join $sep))
$PngRegeneres = $false
if ($RegenererPng) {
    Write-Titre 'Aperçus PNG des diagrammes'
    $python = $null
    foreach ($c in @('python3', 'python', 'py')) { if (Get-Command $c -ErrorAction SilentlyContinue) { $python = $c; break } }
    $soffice = $null
    foreach ($c in @('soffice', 'libreoffice', 'soffice.exe')) { if (Get-Command $c -ErrorAction SilentlyContinue) { $soffice = $c; break } }
    if (-not (Test-Path -LiteralPath $Generateur)) {
        Write-Warning 'Générateur des diagrammes absent de la copie : PNG non régénérés.'
    } elseif (-not $python -or -not $soffice) {
        Write-Warning 'python3 et LibreOffice (soffice) sont requis : PNG non régénérés (valeurs d''exemple conservées).'
    } else {
        # Valeurs transmises en JSON (sans les noms sensibles) : pas besoin de bash
        $json = Join-Path ([System.IO.Path]::GetTempPath()) ("lgtm_valeurs_{0}.json" -f [guid]::NewGuid().ToString('N'))
        $publiques = @{}
        foreach ($k in $Valeurs.Keys) { if (-not (Test-NomSensible $k)) { $publiques[$k] = [string]$Valeurs[$k] } }
        [System.IO.File]::WriteAllText($json, ($publiques | ConvertTo-Json -Compress), $Utf8SansBom)
        try {
            & $python $Generateur --env $Environnement --png-seulement --valeurs $json
            if ($LASTEXITCODE -eq 0) { $PngRegeneres = $true } else { Write-Warning 'Échec de la régénération des PNG.' }
        } finally { Remove-Item -LiteralPath $json -Force -ErrorAction SilentlyContinue }
    }
}

Write-Titre 'Terminé'
Write-Info ("Copie actualisée : {0}" -f $Sortie)
Write-Info ("Rapport          : {0}" -f $cheminRapport)
if (-not $PngRegeneres) {
    Write-Info 'Les .png des diagrammes gardent les valeurs d''exemple (option -RegenererPng pour les refaire).'
}
if ($Strict -and $Absentes.Count) { exit 1 }
