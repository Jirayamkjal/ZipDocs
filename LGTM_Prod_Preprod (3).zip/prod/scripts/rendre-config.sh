#!/usr/bin/env bash
# =============================================================================
# Rendu des modèles de configuration LGTM (Linux, bash seul).
# =============================================================================
#
# Remplace les variables {{NOM_VARIABLE}} des modèles variables/templates/*.tmpl
# par les valeurs de variables/environnements.env (même fichier et même format
# que scripts/Actualiser-Variables.ps1, qui actualise tout le dossier depuis
# Windows ou PowerShell 7).
#
# Usage :
#   LGTM_ENV=prod    ./scripts/rendre-config.sh
#   LGTM_ENV=preprod ./scripts/rendre-config.sh
#   LGTM_ENV=prod    ./scripts/rendre-config.sh chemin/modele.tmpl [fichier-sortie]
#   LGTM_ENV=prod    ./scripts/rendre-config.sh --liste
#
# Par défaut, tous les modèles sont rendus dans :
#   variables/rendu/${LGTM_ENV}/
#
# Seules les variables définies par environnements.env (et LGTM_ENV) sont
# remplacées ; un {{NOM_VARIABLE}} inconnu est laissé tel quel et signalé.
# Ce script ne dépose rien dans /etc : l'opérateur recopie après relecture.
# Aucun secret n'est attendu dans le fichier de variables (mots de passe,
# jetons : fichiers 0600 à part, jamais en argument).
# =============================================================================
set -euo pipefail
# bash >= 5.2 : « & » dans un remplacement ${x//a/b} ne doit pas être interprété
shopt -u patsub_replacement 2>/dev/null || true

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROD_ROOT="$(cd "${SCRIPT_DIR}/.." && pwd)"
ENV_FILE="${LGTM_ENV_FILE:-${PROD_ROOT}/variables/environnements.env}"
TMPL_DIR="${PROD_ROOT}/variables/templates"
LGTM_ENV="${LGTM_ENV:-prod}"
OUT_DIR="${PROD_ROOT}/variables/rendu/${LGTM_ENV}"

usage() {
  sed -n '2,25p' "$0"
}

if [[ "${1:-}" == "-h" || "${1:-}" == "--help" ]]; then
  usage
  exit 0
fi

if [[ ! -f "${ENV_FILE}" ]]; then
  printf 'Fichier de variables introuvable : %s\n' "${ENV_FILE}" >&2
  exit 2
fi

# Charger les variables et retenir uniquement celles que le fichier définit
_avant="$(compgen -v | sort)"
set -a
# shellcheck disable=SC1090
. "${ENV_FILE}"
set +a
_apres="$(compgen -v | sort)"
declare -A DEFINIES=()
while IFS= read -r _n; do
  [[ "${_n}" =~ ^[A-Z][A-Z0-9_]*$ ]] && DEFINIES["${_n}"]=1
done < <(comm -13 <(printf '%s\n' "${_avant}") <(printf '%s\n' "${_apres}"))
DEFINIES[LGTM_ENV]=1

# Noms jamais affichés (garde-fou : aucun secret attendu dans le fichier)
_est_sensible() {
  [[ "$1" =~ _(URL|FILE|FICHIER|PATH|CHEMIN|HEADER|ENDPOINT)$ ]] && return 1
  [[ "$1" =~ (PASSWORD|PASSWD|SECRET|TOKEN|API_KEY|PRIVATE_KEY|MDP) ]]
}

if [[ "${1:-}" == "--liste" ]]; then
  printf 'LGTM_ENV=%s  DOMAIN=%s\n' "${LGTM_ENV}" "${DOMAIN}"
  printf 'Fichier : %s\n' "${ENV_FILE}"
  printf '\nVariables courtes (extrait) :\n'
  for v in DOMAIN GRAFANA_FQDN GRAFANA_VIP GRAFANA_URL \
           OTEL_GW_FQDN OTEL_GW_VIP KAFKA_BOOTSTRAP KAFKA_DNS \
           MIMIR_FQDN MIMIR_VIP LOKI_FQDN LOKI_VIP TEMPO_FQDN TEMPO_VIP \
           S3_FQDN S3_VIP S3_ENDPOINT S3_BUCKET_MIMIR S3_BUCKET_LOKI S3_BUCKET_TEMPO S3_BUCKET_ADMIN MINIO_API_PORT MINIO_CONSOLE_PORT PG_FQDN PG_VIP \
           ES_FQDN ES_URL APPD_FQDN APPD_URL APPD_OTEL_INGEST \
           SCOM_FQDN SCOM_URL DC01_FQDN DC02_FQDN LDAP_HOSTS \
           REGISTRY_FQDN BASTION01_FQDN LB01_FQDN \
           PORT_GRAFANA PORT_OTEL_GRPC PORT_OTEL_HTTP PORT_KAFKA \
           PORT_MIMIR PORT_LOKI PORT_TEMPO PORT_ES PORT_APPD_HTTPS PORT_SCOM_WEB PORT_LDAPS PORT_KERBEROS \
           KRB_REALM KRB_SERVICE_ACCOUNT KRB_PRINCIPAL KRB_KEYTAB AUTH_PROXY_HEADER AUTH_PROXY_WHITELIST \
           ADFS_FQDN ADFS_URL ADFS_WELLKNOWN ADFS_AUTH_URL ADFS_TOKEN_URL ADFS_USERINFO_URL OAUTH_REDIRECT_URL \
           ES_VERSION ROR_VERSION KIBANA_VERSION ROR_ES_PLUGIN_ZIP ROR_KBN_PLUGIN_ZIP \
           STOCKAGE_OBJET_SCENARIO S3_CA_FILE S3_FORCE_PATH_STYLE S3_REGION \
           ARCHIVE_S3_FQDN ARCHIVE_S3_ENDPOINT ARCHIVE_S3_CA_FILE ARCHIVE_S3_BUCKET
  do
    if _est_sensible "$v"; then
      printf '  %-22s = %s\n' "$v" '(masqué)'
    else
      printf '  %-22s = %s\n' "$v" "${!v-}"
    fi
  done
  printf '\n%d variables définies au total.\n' "${#DEFINIES[@]}"
  exit 0
fi

rendre_un() {
  local tmpl="$1" dest="$2" contenu="" nom
  local -a inconnues=()
  mkdir -p "$(dirname "${dest}")"
  # Lecture intégrale (fins de ligne et dernière ligne conservées)
  IFS= read -r -d '' contenu < "${tmpl}" || true
  while IFS= read -r nom; do
    [[ -z "${nom}" ]] && continue
    if [[ -n "${DEFINIES[${nom}]+x}" ]]; then
      contenu="${contenu//"{{${nom}}}"/"${!nom}"}"
    else
      inconnues+=("${nom}")
    fi
  done < <(grep -oE '\{\{[A-Z][A-Z0-9_]*\}\}' "${tmpl}" | sed 's/^{{//; s/}}$//' | sort -u || true)
  printf '%s' "${contenu}" > "${dest}"
  printf 'rendu : %s → %s\n' "${tmpl}" "${dest}"
  if [[ ${#inconnues[@]} -gt 0 ]]; then
    printf '  attention : variable(s) absente(s) de %s, laissée(s) telle(s) quelle(s) : %s\n' \
      "$(basename "${ENV_FILE}")" "${inconnues[*]}" >&2
  fi
}

if [[ $# -ge 1 ]]; then
  tmpl="$1"
  if [[ ! -f "${tmpl}" ]]; then
    # essayer relatif au répertoire de modèles
    if [[ -f "${TMPL_DIR}/${tmpl}" ]]; then
      tmpl="${TMPL_DIR}/${tmpl}"
    else
      printf 'Modèle introuvable : %s\n' "$1" >&2
      exit 2
    fi
  fi
  dest="${2:-${OUT_DIR}/$(basename "${tmpl}" .tmpl)}"
  rendre_un "${tmpl}" "${dest}"
  exit 0
fi

# Tous les modèles
shopt -s nullglob
tmpls=("${TMPL_DIR}"/*.tmpl)
if [[ ${#tmpls[@]} -eq 0 ]]; then
  printf 'Aucun modèle dans %s\n' "${TMPL_DIR}" >&2
  exit 2
fi
mkdir -p "${OUT_DIR}"
for tmpl in "${tmpls[@]}"; do
  rendre_un "${tmpl}" "${OUT_DIR}/$(basename "${tmpl}" .tmpl)"
done
printf 'Terminé (%s) dans %s\n' "${LGTM_ENV}" "${OUT_DIR}"
