# Composant de chargement des ACL Grafana

`grafana_acl_sync.py` lit les appartenances aux groupes Active Directory et
applique, de façon idempotente, les équipes, dossiers, permissions et tableaux
de bord Grafana correspondants.

## Pourquoi ce composant

La synchronisation d'équipes (Team Sync) est documentée comme une fonction de
Grafana Enterprise et Grafana Cloud
(https://grafana.com/docs/grafana/latest/setup-grafana/configure-access/configure-team-sync/).
Grafana OSS mappe déjà les groupes LDAP vers les rôles d'organisation au moment
de la connexion. Ce script complète OSS pour les équipes, dossiers et tableaux
de bord.

## Fichiers

| Fichier | Rôle |
|---|---|
| `grafana_acl_sync.py` | Script principal (Python 3, bibliothèque standard + PyYAML + ldap3) |
| `acl-config.example.yaml` | Configuration d'exemple (groupes AD fictifs) |
| `requirements.txt` | Dépendances, avec procédure d'installation hors ligne |
| `grafana-acl-sync.service` / `.timer` | Unités systemd (déploiement machines virtuelles) |
| `grafana-acl-sync-cronjob.yaml` | CronJob Kubernetes |
| `ror-acl-groups.example.yml` | Extrait ReadonlyREST aligné sur les mêmes groupes |
| `../dashboards/one_screen_home.json` | Tableau de bord d'accueil « vue unique » |

## Utilisation

```
# Aide
python3 grafana_acl_sync.py --help

# Simulation complète hors réseau (aucun AD, aucun Grafana)
python3 grafana_acl_sync.py --config acl-config.example.yaml --mock --dry-run

# Exécution réelle (jeton et mot de passe LDAP dans des fichiers 0600)
python3 grafana_acl_sync.py --config /etc/grafana-acl-sync/acl-config.yaml
```

Codes de sortie : 0 succès, 1 configuration, 2 LDAP, 3 Grafana, 4 succès partiel, 5 dépendance manquante.

Les utilisateurs AD qui ne se sont jamais connectés à Grafana n'y ont pas encore
de compte : le script les signale et les ajoutera à l'équipe dès qu'ils
existeront (après leur première connexion LDAP, `allow_sign_up = true`).

Le script n'affiche jamais la valeur d'un jeton ou d'un mot de passe.


## Rendu des modèles de configuration

Deux outils lisent le même fichier de valeurs
[`variables/environnements.env`](../variables/environnements.env) et le même
format `{{NOM_VARIABLE}}` :

- [`Actualiser-Variables.ps1`](Actualiser-Variables.ps1) (PowerShell 5.1 / 7) :
  copie tout le dossier vers `sortie_...` et remplace les variables dans la
  copie (textes, `.vsdx`, `.docx`), avec rapport des variables non définies ou
  inutilisées. Mode d'emploi : [`Actualiser-Variables.md`](Actualiser-Variables.md).
- [`rendre-config.sh`](rendre-config.sh) (Linux, bash seul) : rend les modèles
  `variables/templates/*.tmpl` dans `variables/rendu/<environnement>/`.

```bash
LGTM_ENV=prod ./scripts/rendre-config.sh
LGTM_ENV=prod ./scripts/rendre-config.sh --liste
```

Aucun secret n'appartient au fichier de variables. Voir [`variables/README.md`](../variables/README.md).
