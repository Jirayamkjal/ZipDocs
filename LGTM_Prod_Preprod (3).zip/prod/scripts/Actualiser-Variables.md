# Actualiser-Variables.ps1 — mode d'emploi

Le script copie tout le dossier `prod/` vers un dossier `sortie_...` et remplace,
**dans la copie seulement**, chaque variable `{{NOM_VARIABLE}}` par sa valeur.
L'original n'est jamais modifié.

## Format

- Variable : `{{NOM_VARIABLE}}` (majuscules, chiffres, `_` ; commence par une lettre).
- Valeurs : un seul fichier modifiable, [`variables/environnements.env`](../variables/environnements.env),
  lu aussi par `bash` et par [`rendre-config.sh`](rendre-config.sh).
- Jeu court : selon `-Environnement`, `PROD_NOM_VARIABLE` (ou `PREPROD_NOM_VARIABLE`)
  fournit la valeur de `NOM_VARIABLE`, comme `LGTM_ENV` côté bash. Les formes
  préfixées restent aussi utilisables.
- Références : dans le fichier de valeurs, seule la forme bash `${NOM_VARIABLE}`
  est acceptée ; une substitution de commande est refusée.

## Fichiers traités

- Textes : `.md`, `.txt`, `.yaml`/`.yml`, `.json`, `.ini`, `.conf`, `.cfg`, `.toml`,
  `.properties`, `.tmpl`, `.env`, `.sh`, `.ps1`, `.py`, `.xml`, etc. L'encodage
  (UTF-8 avec ou sans BOM, UTF-16) et les fins de ligne (LF/CRLF) sont conservés.
- Office : `.vsdx`, `.docx` (et `.xlsx`, `.pptx`) — les parties XML internes sont
  actualisées, le paquet reste valide.
- Non remplacés (modèles conservés) : `variables/templates/*` et le générateur
  `architecture/diagrammes/_gen_visio.py`.
- Les modèles `variables/templates/*.tmpl` sont rendus dans
  `variables/rendu/prod/` et `variables/rendu/preprod/` de la copie (même résultat
  que `rendre-config.sh`).

## Utilisation

```powershell
# Analyse seule : rien n'est copié ni écrit
.\scripts\Actualiser-Variables.ps1 -DryRun          # ou -WhatIf

# Copie actualisée pour la production (dossier ..\sortie_prod_<horodatage>)
.\scripts\Actualiser-Variables.ps1 -Environnement prod

# Préproduction, dossier de sortie choisi, aperçus PNG refaits
.\scripts\Actualiser-Variables.ps1 -Environnement preprod -Sortie D:\livraison\lgtm-preprod -RegenererPng

# Autre source ou autre fichier de valeurs
.\scripts\Actualiser-Variables.ps1 -Source D:\lgtm\prod -FichierVariables D:\lgtm\valeurs.env
```

| Option | Rôle |
|---|---|
| `-Environnement prod\|preprod` | Jeu de valeurs utilisé (défaut : `prod`) |
| `-Source` | Dossier à copier (défaut : le dossier parent de `scripts/`) |
| `-Sortie` | Dossier de la copie ; ne doit pas exister ni se trouver dans la source |
| `-FichierVariables` | Fichier de valeurs (défaut : `variables/environnements.env` de la source) |
| `-DryRun` / `-WhatIf` | Analyse et liste des remplacements, sans rien écrire |
| `-RegenererPng` | Refait les PNG des diagrammes dans la copie (python3 + LibreOffice requis) |
| `-ListerValeurs` | Affiche les valeurs résolues (noms sensibles masqués) |

## Contrôles et rapport

- Variables **utilisées mais absentes** du fichier de valeurs : signalées et laissées telles quelles.
- Valeurs **définies mais jamais utilisées** : listées.
- Variable coupée par la mise en forme Word (plusieurs « runs ») : signalée ; la
  retaper d'un seul tenant dans le `.docx` source.
- Le rapport complet est écrit dans `RAPPORT_ACTUALISATION.md` à la racine de la copie.

## Secrets

Aucun secret dans le fichier de valeurs. Un nom sensible (`PASSWORD`, `SECRET`,
`TOKEN`, `API_KEY`, `MDP`…) ne peut contenir qu'un chemin de fichier (0600/0640) ;
sinon le script s'arrête sans afficher la valeur. Les valeurs sensibles ne sont
jamais affichées ni écrites dans le rapport.

## Diagrammes

Les `.vsdx` de la copie reçoivent les valeurs. Les `.png` sont des images : sans
`-RegenererPng`, ils gardent les valeurs d'exemple. Pour les refaire à la main
dans la copie :

```bash
python3 architecture/diagrammes/_gen_visio.py --env prod --png-seulement
```

## Compatibilité

Conçu pour Windows PowerShell 5.1 et PowerShell 7 (Windows, Linux) ; le fichier est en UTF-8 avec BOM.
