# Logos des diagrammes — provenance

Logos officiels publics, convertis en PNG carrés (256 px, fond blanc) pour être
intégrés comme images dans les fichiers `.vsdx` par `../_gen_visio.py`.
Les marques appartiennent à leurs propriétaires ; usage limité à l'identification
des produits dans la documentation d'architecture.

| Fichier | Produit | Source publique |
|---|---|---|
| grafana.png | Grafana | dépôt GitHub grafana/grafana (icône SVG) |
| loki.png | Loki | dépôt GitHub grafana/loki (logo) |
| tempo.png | Tempo | dépôt GitHub grafana/tempo (logo, icône recadrée) |
| mimir.png | Mimir | dépôt GitHub grafana/mimir (logo) |
| kafka.png | Apache Kafka | Wikimedia Commons, « Apache_Kafka_logo.svg » |
| otel.png | OpenTelemetry | dépôt GitHub cncf/artwork |
| prometheus.png | Prometheus | dépôt GitHub cncf/artwork |
| kubernetes.png | Kubernetes | dépôt GitHub cncf/artwork |
| helm.png | Helm | dépôt GitHub cncf/artwork |
| strimzi.png | Strimzi | dépôt GitHub cncf/artwork |
| certmanager.png | cert-manager | dépôt GitHub cncf/artwork |
| minio.png | MinIO | simple-icons (icône « minio », couleur de marque #C72E49) |
| haproxy.png | HAProxy | Wikimedia Commons, « Haproxy-logo.png » (CC BY-SA 4.0) |
| elasticsearch.png, kibana.png, elastic.png | Elastic | dépôt GitHub elastic/eui (logos produits) |
| redhat.png | Red Hat (badge RHEL 8) | simple-icons (icône « redhat », couleur #EE0000) |
| windows.png | Windows Server (AD, AD FS, AD CS) | Wikimedia Commons, « Windows_logo_-_2021.svg » |
| microsoft.png | Microsoft (SCOM 2019) | Wikimedia Commons, « Microsoft_logo.svg » |
| appd.png | AppDynamics | Wikimedia Commons, « Appd-logo-340x0_q100.png » (logotype) |
| postgresql.png | PostgreSQL | Wikimedia Commons, « Postgresql_elephant.svg » |
| apache.png | Apache HTTP Server (annexe SSO) | simple-icons (icône « apache », couleur #D22128) |

Logos sans fichier officiel dédié, remplacés :

- keepalived : pas de logo officiel — étiquette texte « keepalived ».
- Active Directory, AD FS, AD CS : pas de logo dédié retenu — logo Windows.
- SCOM 2019 : pas de logo dédié retenu — logo Microsoft.
- Registre privé, plateforme S3 interne d'archivage, postes utilisateurs, mc mirror :
  produit non nommé ou générique — icône générique avec le nom.
