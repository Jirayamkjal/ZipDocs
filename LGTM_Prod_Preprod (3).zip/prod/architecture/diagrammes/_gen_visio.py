#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Génère les diagrammes Visio (.vsdx) et leurs aperçus PNG de la plateforme LGTM préprod/prod.

Vue réseau : chaque VM ou serveur est une icône de machine qui porte le logo officiel
du produit (images PNG intégrées au paquet .vsdx, dossier _logos/), avec sous-réseaux,
pare-feu, VIP et ports des flux.

Les textes des .vsdx gardent les jetons {{NOM_VARIABLE}} (noms d'hôtes, IP, ports) :
scripts/Actualiser-Variables.ps1 les remplace dans une copie à partir de
variables/environnements.env. Les PNG sont rendus avec les valeurs de l'environnement
choisi (prod par défaut) via LibreOffice, à partir du même fichier de valeurs.

Usage :
    python3 _gen_visio.py                 # .vsdx + PNG (valeurs prod)
    python3 _gen_visio.py --env preprod   # PNG avec les valeurs préprod
    python3 _gen_visio.py --sans-png      # .vsdx seulement
    python3 _gen_visio.py --png-seulement # PNG seulement (ex. dans une copie actualisée)

Prérequis : Python 3.9+ ; LibreOffice (soffice) pour les PNG ; bash pour lire le fichier de valeurs.
"""
from __future__ import annotations

import io
import re
import zipfile
from pathlib import Path
from xml.etree import ElementTree as ET
from xml.sax.saxutils import escape

NS = "http://schemas.microsoft.com/office/visio/2012/main"
RNS = "http://schemas.openxmlformats.org/officeDocument/2006/relationships"
PAGE_W = 18.0
PAGE_H = 10.125
FONT = "Calibri"

HERE = Path(__file__).resolve().parent
TPL = HERE / "_template"
LOGOS = HERE / "_logos"

# ----------------------------------------------------------------- palette
NAVY = "#1F3864"
INK = "#1E293B"
MUTED = "#475569"
WHITE = "#FFFFFF"
LED = "#22C55E"
RED = "#B91C1C"
RED_BG = "#FEE2E2"
OK = "#15803D"
OK_BG = "#DCFCE7"
WARN = "#B45309"
WARN_BG = "#FEF3C7"

_HEX6 = re.compile(r"^#[0-9A-Fa-f]{6}$")


def _c(color: str) -> str:
    """Couleur Visio : toujours #RRGGBB (libvisio refuse les formes courtes)."""
    if not _HEX6.match(color):
        raise ValueError(f"couleur invalide (6 chiffres hex attendus) : {color}")
    return color.upper()


def _f(v) -> str:
    if isinstance(v, float):
        return f"{v:.4f}".rstrip("0").rstrip(".") or "0"
    return str(v)


def _cell(parent, n, v, f=None, u=None):
    a = {"N": n, "V": _f(v)}
    if u:
        a["U"] = u
    if f is not None:
        a["F"] = f
    ET.SubElement(parent, "Cell", a)


# ----------------------------------------------------------------- primitives
class Prim:
    """Forme élémentaire en coordonnées « haut-gauche » du parent (page ou groupe)."""

    def __init__(self, kind, x, y, w, h, **kw):
        self.kind, self.x, self.y, self.w, self.h = kind, x, y, w, h
        self.kw = kw
        self.sid = 0

    def anchor(self, side):
        x, y, w, h = self.x, self.y, self.w, self.h
        return {"l": (x, y + h / 2), "r": (x + w, y + h / 2), "t": (x + w / 2, y), "b": (x + w / 2, y + h),
                "bb": (x + w / 2, y + h), "c": (x + w / 2, y + h / 2)}[side]


class Group:
    def __init__(self, x, y, w, h, name, props=None):
        self.x, self.y, self.w, self.h = x, y, w, h
        self.name = name
        self.children: list[Prim] = []
        self.props = props or []
        self.sid = 0

    def add(self, kind, x, y, w, h, **kw):
        p = Prim(kind, x, y, w, h, **kw)
        self.children.append(p)
        if kind == "image":
            bg = kw.get("bg", WHITE)
            self.children.append(Prim("rect", x, y, w, h, fill=bg, line=bg, weight=0.022, nofill=True))
        return p

    # centre et bords en coordonnées page (haut-gauche)
    def anchor(self, side):
        cx, cy = self.x + self.w / 2, self.y + self.h / 2
        bh = getattr(self, "body_h", self.h)
        bx0 = self.x + getattr(self, "body_x", 0.0)
        bw = getattr(self, "body_w", self.w)
        by_mid = self.y + bh / 2
        return {
            "l": (bx0, by_mid), "r": (bx0 + bw, by_mid),
            "t": (bx0 + bw / 2, self.y), "b": (bx0 + bw / 2, self.y + self.h),
            "bb": (bx0 + bw / 2, self.y + bh), "c": (cx, cy),
        }[side]


class Connector:
    def __init__(self, pts, src, dst, color, dashed, both, weight, arrow=True):
        self.pts, self.src, self.dst = pts, src, dst
        self.color, self.dashed, self.both, self.weight, self.arrow = color, dashed, both, weight, arrow
        self.sid = 0


class Page:
    def __init__(self, name: str):
        self.name = name
        self.items: list = []
        self.images: dict[str, str] = {}  # logo -> rId

    # ------------------------------------------------------------ éléments simples
    def rect(self, x, y, w, h, fill=WHITE, line=NAVY, weight=0.012, rounding=0.0,
             dashed=False, text="", size=0.10, bold=False, color=INK, align=1, valign=1,
             italic=False, nofill=False, noline=False):
        p = Prim("rect", x, y, w, h, fill=fill, line=line, weight=weight, rounding=rounding,
                 dashed=dashed, text=text, size=size, bold=bold, color=color, align=align,
                 valign=valign, italic=italic, nofill=nofill, noline=noline)
        self.items.append(p)
        return p

    def text(self, text, x, y, w, h, size=0.10, bold=False, color=INK, align=0, valign=1, italic=False):
        p = Prim("text", x, y, w, h, text=text, size=size, bold=bold, color=color,
                 align=align, valign=valign, italic=italic)
        self.items.append(p)
        return p

    def image(self, logo, x, y, w, h):
        self._use(logo)
        p = Prim("image", x, y, w, h, logo=logo)
        self.items.append(p)
        self.items.append(Prim("rect", x, y, w, h, fill=WHITE, line=WHITE, weight=0.022, nofill=True))
        return p

    def _use(self, logo):
        if not (LOGOS / f"{logo}.png").exists():
            raise FileNotFoundError(f"logo absent : {logo}")
        if logo not in self.images:
            self.images[logo] = f"rId{len(self.images) + 2}"

    # ------------------------------------------------------------ zone = sous-réseau
    def zone(self, title, x, y, w, h, accent, bg, net="", tag="", dashed=False):
        self.rect(x, y, w, h, fill=bg, line=accent, weight=0.016, rounding=0.08, dashed=dashed)
        self.rect(x, y, w, 0.30, fill=accent, line=accent, weight=0.012, rounding=0.06)
        self.text(title, x + 0.10, y, w - 0.2, 0.30, size=0.105, bold=True, color=WHITE, align=0)
        right = "   ".join(t for t in (net, tag) if t)
        if right:
            self.text(right, x + 0.1, y, w - 0.2, 0.30, size=0.09, bold=True, color=WHITE, align=2)

    # ------------------------------------------------------------ machine (groupe)
    def machine(self, x, y, logo=None, title="", lines=(), accent=MUTED, kind="server",
                badge=None, count=None, status=None, w=1.0, bh=0.70, lw=None, generic="",
                props=None, size=0.085):
        """Icône de serveur avec logo du produit, badge OS et étiquette (nom d'hôte, IP)."""
        lw = max(lw or 1.55, w)
        nlines = 1 + len(lines)
        lh = 0.06 + 0.135 * nlines
        G = Group(x - (lw - w) / 2, y, lw, bh + lh, title or (generic or logo or "machine"),
                  props=props)
        G.body_x, G.body_w, G.body_h = (lw - w) / 2, w, bh
        bx = (lw - w) / 2
        fillbody = WHITE
        if kind == "pc":
            sh = bh * 0.78
            G.add("rect", bx, 0, w, sh, fill=WHITE, line=accent, weight=0.018, rounding=0.05)
            G.add("rect", bx + w * 0.42, sh, w * 0.16, bh * 0.12, fill=accent, line=accent, weight=0.01)
            G.add("rect", bx + w * 0.25, sh + bh * 0.12, w * 0.5, bh * 0.08, fill=accent, line=accent,
                  weight=0.01, rounding=0.02)
            area = (bx + 0.08, 0.06, w - 0.16, sh - 0.12)
            imgbg = WHITE
        else:
            if count and count > 1:
                for k in (2, 1):
                    G.add("rect", bx + 0.05 * k, -0.05 * k + 0.0, w, bh, fill="#E2E8F0", line=accent,
                          weight=0.012, rounding=0.06)
            G.add("rect", bx, 0, w, bh, fill=fillbody, line=accent, weight=0.02, rounding=0.06)
            G.add("rect", bx, 0, w, 0.15, fill=accent, line=accent, weight=0.012, rounding=0.05)
            G.add("lines", bx + 0.10, 0.045, 0.34, 0.06, segs=[(0, 0, 0.34, 0), (0, 0.06, 0.34, 0.06)],
                  line=WHITE, weight=0.012)
            for k in range(2):
                G.add("rect", bx + w - 0.20 + k * 0.08, 0.05, 0.05, 0.05, fill=LED if status != "ko" else "#EF4444",
                      line=LED if status != "ko" else "#EF4444", weight=0.005, rounding=0.0)
            rm = 0.22 if badge else 0.0
            area = (bx + 0.08, 0.20, w - 0.16 - rm, bh - 0.25)
            imgbg = fillbody
        ax, ay, aw, ah = area
        if isinstance(logo, (list, tuple)):
            n = len(logo)
            gap = 0.04
            s = min(ah, (aw - gap * (n - 1)) / n)
            x0 = ax + (aw - (s * n + gap * (n - 1))) / 2
            for i, lg in enumerate(logo):
                self._use(lg)
                G.add("image", x0 + i * (s + gap), ay + (ah - s) / 2, s, s, logo=lg, bg=imgbg)
            logo = None
        if logo:
            self._use(logo)
            s = min(aw, ah)
            iw, ih = s, s
            if logo == "appd":
                iw = aw * 0.92
                ih = iw / 4.0
                G.add("image", ax + (aw - iw) / 2, ay + 0.06, iw, ih, logo=logo, bg=imgbg)
            else:
                G.add("image", ax + (aw - iw) / 2, ay + (ah - ih) / 2, iw, ih, logo=logo, bg=imgbg)
        elif generic:
            G.add("text", ax, ay, aw, ah, text=generic, size=0.085, bold=True, color=accent, align=1, valign=1)
        if badge:
            self._use(badge)
            G.add("image", bx + w - 0.25, bh - 0.25, 0.21, 0.21, logo=badge, bg=fillbody)
        if status == "ko":
            G.add("lines", bx + 0.1, 0.2, w - 0.2, bh - 0.3, segs=[(0, 0, w - 0.2, bh - 0.3), (0, bh - 0.3, w - 0.2, 0)],
                  line="#DC2626", weight=0.03)
        # deux zones de texte (titre en gras, détails) : une mise en forme par forme, rendu identique partout
        G.add("text", 0, bh + 0.03, lw, 0.16, text=title, size=size, bold=True, color=RED if status == "ko" else INK,
              align=1, valign=0)
        if lines:
            G.add("text", 0, bh + 0.03 + 0.135, lw, lh - 0.135, text="\n".join(lines), size=size * 0.92, bold=False,
                  color=RED if status == "ko" else MUTED, align=1, valign=0)
        self.items.append(G)
        return G

    def vip(self, text, x, y, w, h=0.30, accent="#1D4ED8", bg="#DBEAFE", size=0.085):
        G = Group(x, y, w, h, "VIP")
        G.add("rect", 0, 0, w, h, fill=bg, line=accent, weight=0.016, rounding=h / 2)
        G.add("rect", 0.04, 0.04, 0.42, h - 0.08, fill=accent, line=accent, weight=0.005, rounding=(h - 0.08) / 2,
              text="VIP", size=0.075, bold=True, color=WHITE, align=1, valign=1)
        G.add("text", 0.5, 0, w - 0.55, h, text=text, size=size, bold=True, color=INK, align=0, valign=1)
        self.items.append(G)
        return G

    def firewall(self, x, y, w, h, label="Pare-feu", lsize=0.08, label_below=True):
        lh = 0.34 if label_below else 0
        G = Group(x, y, w, h + lh, "Pare-feu")
        G.body_h = h
        G.add("rect", 0, 0, w, h, fill="#DC2626", line="#7F1D1D", weight=0.014, rounding=0.03)
        rows = max(2, int(round(h / 0.12)))
        rh = h / rows
        segs = []
        for r in range(1, rows):
            segs.append((0, r * rh, w, r * rh))
        bw = 0.16
        for r in range(rows):
            off = 0 if r % 2 == 0 else bw / 2
            xx = off + bw
            while xx < w - 0.01:
                segs.append((xx, r * rh, xx, (r + 1) * rh))
                xx += bw
        G.add("lines", 0, 0, w, h, segs=segs, line="#FECACA", weight=0.01)
        if label_below:
            G.add("text", -0.4, h + 0.02, w + 0.8, lh, text=label, size=lsize, bold=True, color="#7F1D1D",
                  align=1, valign=0)
        self.items.append(G)
        return G

    # ------------------------------------------------------------ flux
    def flow(self, src, dst, label="", color=NAVY, dashed=False, both=False, via=None,
             s_side="r", d_side="l", weight=0.018, lpos=None, lsize=0.08, lw=None, arrow=True, lfloat=False):
        a = src.anchor(s_side) if hasattr(src, "anchor") else src
        b = dst.anchor(d_side) if hasattr(dst, "anchor") else dst
        pts = [a]
        if via is None:
            s0, d0 = s_side[0], d_side[0]
            if s0 in "lr" and d0 in "lr" and abs(a[1] - b[1]) > 1e-6:
                mx = (a[0] + b[0]) / 2
                pts += [(mx, a[1]), (mx, b[1])]
            elif s0 in "tb" and d0 in "tb" and abs(a[0] - b[0]) > 1e-6:
                my = (a[1] + b[1]) / 2
                pts += [(a[0], my), (b[0], my)]
            elif s0 in "lr" and d0 in "tb":
                pts += [(b[0], a[1])]
            elif s0 in "tb" and d0 in "lr":
                pts += [(a[0], b[1])]
        else:
            for v in via:
                if v[0] == "x":
                    pts.append((v[1], pts[-1][1]))
                elif v[0] == "y":
                    pts.append((pts[-1][0], v[1]))
                else:
                    pts.append(v)
            last = pts[-1]
            if abs(last[0] - b[0]) > 1e-6 and abs(last[1] - b[1]) > 1e-6:
                pts.append((b[0], last[1]) if d_side[0] in "tb" else (last[0], b[1]))
        pts.append(b)
        # suppression des points dupliqués
        clean = [pts[0]]
        for p in pts[1:]:
            if abs(p[0] - clean[-1][0]) > 1e-6 or abs(p[1] - clean[-1][1]) > 1e-6:
                clean.append(p)
        c = Connector(clean, src if isinstance(src, (Group, Prim)) else None, dst if isinstance(dst, (Group, Prim)) else None,
                      color, dashed, both, weight, arrow)
        self.items.append(c)
        if label:
            if lpos is None:
                best = max(range(len(clean) - 1), key=lambda i: abs(clean[i + 1][0] - clean[i][0]) + abs(clean[i + 1][1] - clean[i][1]))
                p0, p1 = clean[best], clean[best + 1]
                lpos = ((p0[0] + p1[0]) / 2, (p0[1] + p1[1]) / 2)
            nl = label.count("\n") + 1
            width = lw or min(2.6, max(0.5, 0.052 * max(len(s) for s in label.split("\n")) + 0.12))
            hh = 0.06 + 0.125 * nl
            if lfloat:
                self.text(label, lpos[0] - width / 2, lpos[1] - hh - 0.01, width, hh, size=lsize, bold=True,
                          color=color, align=1, valign=2)
            else:
                self.rect(lpos[0] - width / 2, lpos[1] - hh / 2, width, hh, fill=WHITE, line=color, weight=0.01,
                          rounding=0.05, text=label, size=lsize, bold=True, color=color, align=1, valign=1)
        return c


# ----------------------------------------------------------------- XML
def _text_sections(el, text, size, bold, color, align, italic=False, first_bold=False, valign=1):
    lines = text.split("\n") if text else [""]
    _cell(el, "VerticalAlign", valign)
    for n in ("LeftMargin", "RightMargin", "TopMargin", "BottomMargin"):
        _cell(el, n, 0.02)
    sec = ET.SubElement(el, "Section", {"N": "Character"})
    for i, _ in enumerate(lines if first_bold else lines[:1]):
        row = ET.SubElement(sec, "Row", {"IX": str(i)})
        b = bold or (first_bold and i == 0)
        style = (1 if b else 0) | (2 if italic else 0)
        _cell(row, "Color", _c(color) if (i == 0 or not first_bold) else _c(MUTED) if color == INK else _c(color))
        sz = size if (i == 0 or not first_bold) else size * 0.92
        _cell(row, "Size", sz, u="IN")
        _cell(row, "Font", FONT)
        _cell(row, "Style", style)
    par = ET.SubElement(el, "Section", {"N": "Paragraph"})
    row = ET.SubElement(par, "Row", {"IX": "0"})
    _cell(row, "HorzAlign", align)
    _cell(row, "SpLine", -1.0)
    tx = ET.SubElement(el, "Text")
    if not first_bold:
        ET.SubElement(tx, "cp", {"IX": "0"}).tail = "\n".join(lines)
        return
    for i, ln in enumerate(lines):
        cp = ET.SubElement(tx, "cp", {"IX": str(i)})
        cp.tail = ln + ("\n" if i < len(lines) - 1 else "")


def _xform(el, x, y, w, h, ph):
    """x, y : coin haut-gauche dans le repère haut-gauche du parent de hauteur ph."""
    _cell(el, "PinX", x + w / 2)
    _cell(el, "PinY", ph - (y + h / 2))
    _cell(el, "Width", w)
    _cell(el, "Height", h)
    _cell(el, "LocPinX", w / 2)
    _cell(el, "LocPinY", h / 2)


def _rect_geo(el, w, h, nofill=False, noline=False):
    geo = ET.SubElement(el, "Section", {"N": "Geometry", "IX": "0"})
    _cell(geo, "NoFill", 1 if nofill else 0)
    _cell(geo, "NoLine", 1 if noline else 0)
    _cell(geo, "NoShow", 0)
    _cell(geo, "NoSnap", 0)
    pts = [(0, 0), (w, 0), (w, h), (0, h), (0, 0)]
    for i, (px, py) in enumerate(pts, start=1):
        r = ET.SubElement(geo, "Row", {"T": "MoveTo" if i == 1 else "LineTo", "IX": str(i)})
        _cell(r, "X", px)
        _cell(r, "Y", py)


def _prim_xml(p: Prim, ph: float, sid: int, page: Page) -> ET.Element:
    k = p.kw
    if p.kind == "image":
        el = ET.Element("Shape", {"ID": str(sid), "NameU": f"Logo {k['logo']}", "Name": f"Logo {k['logo']}",
                                  "Type": "Foreign", "LineStyle": "0", "FillStyle": "0", "TextStyle": "0"})
        _xform(el, p.x, p.y, p.w, p.h, ph)
        _cell(el, "ImgOffsetX", 0)
        _cell(el, "ImgOffsetY", 0)
        _cell(el, "ImgWidth", p.w)
        _cell(el, "ImgHeight", p.h)
        _cell(el, "LinePattern", 0)
        _cell(el, "LineColor", _c(k.get("bg", WHITE)))
        _cell(el, "LineWeight", 0, u="IN")
        _cell(el, "FillForegnd", _c(k.get("bg", WHITE)))
        _cell(el, "FillPattern", 1)
        _rect_geo(el, p.w, p.h, nofill=False, noline=True)
        fd = ET.SubElement(el, "ForeignData", {"ForeignType": "Bitmap", "CompressionType": "PNG"})
        ET.SubElement(fd, "Rel", {f"{{{RNS}}}id": page.images[k["logo"]]})
        return el
    el = ET.Element("Shape", {"ID": str(sid), "NameU": f"Forme.{sid}", "Name": f"Forme.{sid}", "Type": "Shape",
                              "LineStyle": "0", "FillStyle": "0", "TextStyle": "0"})
    _xform(el, p.x, p.y, p.w, p.h, ph)
    if p.kind == "rect":
        if k.get("nofill"):
            _cell(el, "FillPattern", 0)
        else:
            _cell(el, "FillForegnd", _c(k["fill"]))
            _cell(el, "FillPattern", 1)
        if k.get("noline"):
            _cell(el, "LinePattern", 0)
        else:
            _cell(el, "LineColor", _c(k["line"]))
            _cell(el, "LineWeight", k["weight"], u="IN")
            _cell(el, "LinePattern", 2 if k.get("dashed") else 1)
        _cell(el, "Rounding", min(k.get("rounding", 0.0), p.w / 2, p.h / 2), u="IN")
        _text_sections(el, k.get("text", ""), k.get("size", 0.1), k.get("bold", False), k.get("color", INK),
                       k.get("align", 1), k.get("italic", False), valign=k.get("valign", 1))
        _rect_geo(el, p.w, p.h, k.get("nofill", False), k.get("noline", False))
    elif p.kind == "text":
        _cell(el, "FillPattern", 0)
        _cell(el, "LinePattern", 0)
        _text_sections(el, k["text"], k["size"], k.get("bold", False), k.get("color", INK), k.get("align", 0),
                       k.get("italic", False), k.get("first_bold", False), valign=k.get("valign", 1))
    elif p.kind == "lines":
        _cell(el, "FillPattern", 0)
        _cell(el, "LineColor", _c(k["line"]))
        _cell(el, "LineWeight", k["weight"], u="IN")
        _cell(el, "LinePattern", 1)
        for gi, (x0, y0, x1, y1) in enumerate(k["segs"]):
            geo = ET.SubElement(el, "Section", {"N": "Geometry", "IX": str(gi)})
            _cell(geo, "NoFill", 1)
            _cell(geo, "NoLine", 0)
            r = ET.SubElement(geo, "Row", {"T": "MoveTo", "IX": "1"})
            _cell(r, "X", x0)
            _cell(r, "Y", p.h - y0)
            r = ET.SubElement(geo, "Row", {"T": "LineTo", "IX": "2"})
            _cell(r, "X", x1)
            _cell(r, "Y", p.h - y1)
    return el


def _props(el, props):
    if not props:
        return
    sec = ET.SubElement(el, "Section", {"N": "Property"})
    for i, (label, value) in enumerate(props):
        row = ET.SubElement(sec, "Row", {"N": f"Donnee{i + 1}"})
        _cell(row, "Value", value, u="STR")
        _cell(row, "Prompt", "")
        _cell(row, "Label", label)
        _cell(row, "Format", "")
        _cell(row, "SortKey", "")
        _cell(row, "Type", 0)
        _cell(row, "Invisible", 0)


def page_xml(page: Page) -> bytes:
    root = ET.Element(f"{{{NS}}}PageContents")
    shapes = ET.SubElement(root, "Shapes")
    sid = 0
    connects = []

    def nid():
        nonlocal sid
        sid += 1
        return sid

    for it in page.items:
        if isinstance(it, Group):
            it.sid = nid()
            g = ET.SubElement(shapes, "Shape", {"ID": str(it.sid), "NameU": it.name, "Name": it.name, "Type": "Group",
                                                "LineStyle": "0", "FillStyle": "0", "TextStyle": "0"})
            _xform(g, it.x, it.y, it.w, it.h, PAGE_H)
            _props(g, it.props)
            sub = ET.SubElement(g, "Shapes")
            for ch in it.children:
                sub.append(_prim_xml(ch, it.h, nid(), page))
        elif isinstance(it, Prim):
            it.sid = nid()
            shapes.append(_prim_xml(it, PAGE_H, it.sid, page))
        elif isinstance(it, Connector):
            it.sid = nid()
            shapes.append(_connector_xml(it))
            if it.src is not None and it.dst is not None:
                connects.append(it)
    # ID des groupes connus seulement après numérotation : triggers ajoutés ensuite
    for c in connects:
        el = shapes.find(f"Shape[@ID='{c.sid}']")
        for cell in el.findall("Cell"):
            if cell.get("N") == "BegTrigger":
                cell.set("F", f"_XFTRIGGER(Sheet.{c.src.sid}!EventXFMod)")
            if cell.get("N") == "EndTrigger":
                cell.set("F", f"_XFTRIGGER(Sheet.{c.dst.sid}!EventXFMod)")
    if connects:
        cr = ET.SubElement(root, "Connects")
        for c in connects:
            ET.SubElement(cr, "Connect", {"FromSheet": str(c.sid), "FromCell": "BeginX", "FromPart": "9",
                                          "ToSheet": str(c.src.sid), "ToCell": "PinX", "ToPart": "3"})
            ET.SubElement(cr, "Connect", {"FromSheet": str(c.sid), "FromCell": "EndX", "FromPart": "12",
                                          "ToSheet": str(c.dst.sid), "ToCell": "PinX", "ToPart": "3"})
    ET.register_namespace("", NS)
    ET.register_namespace("r", RNS)
    return ET.tostring(root, encoding="utf-8", xml_declaration=True)


def _connector_xml(c: Connector) -> ET.Element:
    (bx, by), (ex, ey) = c.pts[0], c.pts[-1]
    BX, BY, EX, EY = bx, PAGE_H - by, ex, PAGE_H - ey
    w, h = EX - BX, EY - BY
    el = ET.Element("Shape", {"ID": str(c.sid), "NameU": f"Dynamic connector.{c.sid}",
                              "Name": f"Connecteur.{c.sid}", "Type": "Shape", "Master": "4"})
    _cell(el, "PinX", BX + w / 2)
    _cell(el, "PinY", BY + h / 2)
    _cell(el, "Width", w)
    _cell(el, "Height", h)
    _cell(el, "LocPinX", w / 2)
    _cell(el, "LocPinY", h / 2)
    _cell(el, "BeginX", BX)
    _cell(el, "BeginY", BY)
    _cell(el, "EndX", EX)
    _cell(el, "EndY", EY)
    if c.src is not None and c.dst is not None:
        _cell(el, "BegTrigger", 2)
        _cell(el, "EndTrigger", 2)
    _cell(el, "ShapeRouteStyle", 16)
    _cell(el, "ConLineRouteExt", 1)
    _cell(el, "LineColor", _c(c.color))
    _cell(el, "LineWeight", c.weight, u="IN")
    _cell(el, "LinePattern", 2 if c.dashed else 1)
    _cell(el, "Rounding", 0.04, u="IN")
    _cell(el, "BeginArrow", 4 if c.both else 0)
    _cell(el, "EndArrow", 4 if c.arrow else 0)
    _cell(el, "BeginArrowSize", 1)
    _cell(el, "EndArrowSize", 1)
    geo = ET.SubElement(el, "Section", {"N": "Geometry", "IX": "0"})
    _cell(geo, "NoFill", 1)
    _cell(geo, "NoLine", 0)
    for i, (px, py) in enumerate(c.pts, start=1):
        r = ET.SubElement(geo, "Row", {"T": "MoveTo" if i == 1 else "LineTo", "IX": str(i)})
        _cell(r, "X", px - bx)
        _cell(r, "Y", (PAGE_H - py) - BY)
    return el


def pages_xml(pages) -> bytes:
    out = ['<?xml version="1.0" encoding="UTF-8" standalone="yes"?>',
           f'<Pages xmlns="{NS}" xmlns:r="{RNS}">']
    for i, p in enumerate(pages):
        n = escape(p.name, {'"': "&quot;"})
        out.append(
            f'<Page ID="{i}" NameU="{n}" Name="{n}"><PageSheet>'
            f'<Cell N="PageWidth" V="{PAGE_W}" U="IN"/><Cell N="PageHeight" V="{PAGE_H}" U="IN"/>'
            '<Cell N="PageScale" V="1" U="IN"/><Cell N="DrawingScale" V="1" U="IN"/>'
            '<Cell N="DrawingSizeType" V="0"/><Cell N="PrintPageOrientation" V="2"/>'
            f'</PageSheet><Rel r:id="rId{i + 1}"/></Page>')
    out.append("</Pages>")
    return "".join(out).encode("utf-8")


CT_HEAD = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">
<Default Extension="png" ContentType="image/png"/>
<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>
<Default Extension="xml" ContentType="application/xml"/>
<Override PartName="/docProps/app.xml" ContentType="application/vnd.openxmlformats-officedocument.extended-properties+xml"/>
<Override PartName="/docProps/core.xml" ContentType="application/vnd.openxmlformats-package.core-properties+xml"/>
<Override PartName="/docProps/custom.xml" ContentType="application/vnd.openxmlformats-officedocument.custom-properties+xml"/>
<Override PartName="/visio/document.xml" ContentType="application/vnd.ms-visio.drawing.main+xml"/>
<Override PartName="/visio/masters/masters.xml" ContentType="application/vnd.ms-visio.masters+xml"/>
<Override PartName="/visio/masters/master1.xml" ContentType="application/vnd.ms-visio.master+xml"/>
<Override PartName="/visio/pages/pages.xml" ContentType="application/vnd.ms-visio.pages+xml"/>
<Override PartName="/visio/windows.xml" ContentType="application/vnd.ms-visio.windows+xml"/>
"""

RELS = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/package/2006/relationships/metadata/core-properties" Target="docProps/core.xml"/>
<Relationship Id="rId2" Type="http://schemas.microsoft.com/visio/2010/relationships/document" Target="visio/document.xml"/>
<Relationship Id="rId3" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/custom-properties" Target="docProps/custom.xml"/>
<Relationship Id="rId4" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/extended-properties" Target="docProps/app.xml"/>
</Relationships>"""

DOC_RELS = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
<Relationship Id="rId1" Type="http://schemas.microsoft.com/visio/2010/relationships/masters" Target="masters/masters.xml"/>
<Relationship Id="rId2" Type="http://schemas.microsoft.com/visio/2010/relationships/pages" Target="pages/pages.xml"/>
<Relationship Id="rId3" Type="http://schemas.microsoft.com/visio/2010/relationships/windows" Target="windows.xml"/>
</Relationships>"""

APP = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Properties xmlns="http://schemas.openxmlformats.org/officeDocument/2006/extended-properties" xmlns:vt="http://schemas.openxmlformats.org/officeDocument/2006/docPropsVTypes">
<Application>Microsoft Visio</Application><AppVersion>15.0000</AppVersion>
</Properties>"""

CORE = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<cp:coreProperties xmlns:cp="http://schemas.openxmlformats.org/package/2006/metadata/core-properties" xmlns:dc="http://purl.org/dc/elements/1.1/" xmlns:dcterms="http://purl.org/dc/terms/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">
<dc:title>{title}</dc:title>
<dc:creator>Architecture observabilité</dc:creator>
<dc:language>fr-CA</dc:language>
</cp:coreProperties>"""

CUSTOM = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Properties xmlns="http://schemas.openxmlformats.org/officeDocument/2006/custom-properties" xmlns:vt="http://schemas.openxmlformats.org/officeDocument/2006/docPropsVTypes"/>"""

WINDOWS = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Windows ClientWidth="1920" ClientHeight="1080" xmlns="http://schemas.microsoft.com/office/visio/2012/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships" xml:space="preserve"/>"""


def write_vsdx(path: Path, pages, title: str, transform=None):
    """Écrit le paquet OPC. transform(bytes)->bytes est appliqué aux pages (rendu des valeurs)."""
    buf = io.BytesIO()
    media = sorted({lg for p in pages for lg in p.images})
    with zipfile.ZipFile(buf, "w", compression=zipfile.ZIP_DEFLATED) as z:
        ct = CT_HEAD + "".join(
            f'<Override PartName="/visio/pages/page{i}.xml" ContentType="application/vnd.ms-visio.page+xml"/>'
            for i in range(1, len(pages) + 1)) + "</Types>"
        z.writestr("[Content_Types].xml", ct)
        z.writestr("_rels/.rels", RELS)
        z.writestr("docProps/app.xml", APP)
        z.writestr("docProps/core.xml", CORE.format(title=escape(title)))
        z.writestr("docProps/custom.xml", CUSTOM)
        z.writestr("visio/document.xml", (TPL / "document.xml").read_bytes())
        z.writestr("visio/windows.xml", WINDOWS)
        z.writestr("visio/_rels/document.xml.rels", DOC_RELS)
        z.writestr("visio/masters/masters.xml", (TPL / "masters.xml").read_bytes())
        z.writestr("visio/masters/master1.xml", (TPL / "master1.xml").read_bytes())
        z.writestr("visio/masters/_rels/masters.xml.rels", (TPL / "masters.xml.rels").read_bytes())
        z.writestr("visio/pages/pages.xml", pages_xml(pages))
        z.writestr("visio/pages/_rels/pages.xml.rels",
                   '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
                   '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
                   + "".join(f'<Relationship Id="rId{i}" Type="http://schemas.microsoft.com/visio/2010/relationships/page" Target="page{i}.xml"/>'
                             for i in range(1, len(pages) + 1)) + "</Relationships>")
        for lg in media:
            z.writestr(f"visio/media/{lg}.png", (LOGOS / f"{lg}.png").read_bytes())
        for i, p in enumerate(pages, start=1):
            data = page_xml(p)
            if transform:
                data = transform(data)
            z.writestr(f"visio/pages/page{i}.xml", data)
            rels = ['<?xml version="1.0" encoding="UTF-8" standalone="yes"?>',
                    '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">',
                    '<Relationship Id="rId1" Type="http://schemas.microsoft.com/visio/2010/relationships/master" Target="../masters/master1.xml"/>']
            for lg, rid in p.images.items():
                rels.append(f'<Relationship Id="{rid}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/image" Target="../media/{lg}.png"/>')
            rels.append("</Relationships>")
            z.writestr(f"visio/pages/_rels/page{i}.xml.rels", "".join(rels))
    path.write_bytes(buf.getvalue())
    return path


# couleurs par sous-réseau / produit
C_SRC, B_SRC = "#64748B", "#F8FAFC"
C_LB, B_LB = "#1D4ED8", "#EFF6FF"
C_ADM, B_ADM = "#475569", "#F1F5F9"
C_ING, B_ING = "#4F46E5", "#EEF2FF"
C_KAF, B_KAF = "#231F20", "#F5F5F4"
C_STO, B_STO = "#7C3AED", "#F5F3FF"
C_UI, B_UI = "#EA580C", "#FFF7ED"
C_OBJ, B_OBJ = "#C72E49", "#FFF1F2"
C_EX, B_EX = "#0F766E", "#F0FDFA"
C_ES = "#0077CC"
C_SEC = "#B45309"
C_APPD = "#AE1F23"
C_SCOM = "#0078D4"
C_PG = "#336791"
C_SSH = "#64748B"


def header(p, title, subtitle):
    p.rect(0, 0, PAGE_W, 0.72, fill=NAVY, line=NAVY, weight=0.01)
    p.text(title, 0.25, 0.04, 12.5, 0.38, size=0.21, bold=True, color=WHITE)
    p.text(subtitle, 0.25, 0.40, 13.0, 0.28, size=0.105, color="#D6E0F0")
    p.text("Environnement : {{LGTM_ENV}}\ndomaine {{DOMAIN}}", 13.3, 0.08, 4.45, 0.56, size=0.11, bold=True,
           color=WHITE, align=2)


def footer(p, note):
    p.rect(0, PAGE_H - 0.36, PAGE_W, 0.36, fill="#EEF2F7", line="#EEF2F7", weight=0.005)
    p.text(note, 0.25, PAGE_H - 0.36, PAGE_W - 0.5, 0.36, size=0.085, color=MUTED, italic=True)


def H(v):
    return "{{%s_FQDN}}" % v


def IP(v, zone):
    return "{{%s_IP}} · zone %s" % (v, zone)


def rhel_props(role, var, zone, net, extra=()):
    return [("Rôle", role), ("Nom d'hôte", H(var)), ("Adresse IP", "{{%s_IP}}" % var),
            ("Zone", zone), ("Sous-réseau", net), ("Système", "RHEL 8"), *extra]


def legend(p, x, y, w, h):
    p.zone("Légende", x, y, w, h, C_SRC, WHITE)
    yy = y + 0.42
    p.machine(x + 0.12, yy, logo="grafana", title="", lines=(), accent=C_UI, badge="redhat", w=0.62, bh=0.46, lw=0.62)
    p.text("Machine : logo du produit,\nbadge Red Hat = VM RHEL 8,\npile = plusieurs VM du rôle", x + 0.85, yy - 0.04, w - 0.9, 0.5, size=0.08)
    yy += 0.66
    p.firewall(x + 0.25, yy, 0.34, 0.36, label_below=False)
    p.text("Pare-feu d'infrastructure\n(firewalld actif sur chaque VM)", x + 0.85, yy - 0.04, w - 0.9, 0.42, size=0.08)
    yy += 0.52
    p.vip("", x + 0.12, yy, 0.62, 0.26)
    p.text("Adresse virtuelle (keepalived)", x + 0.85, yy - 0.04, w - 0.9, 0.34, size=0.08)
    yy += 0.40
    for col, lab, dash in ((C_ING, "flux de données (port)", False), (C_SSH, "administration / optionnel", True)):
        p.flow((x + 0.12, yy + 0.08), (x + 0.74, yy + 0.08), "", color=col, dashed=dash, s_side="r", d_side="l")
        p.text(lab, x + 0.85, yy - 0.04, w - 0.9, 0.24, size=0.08)
        yy += 0.26


# =====================================================================================
def d_archi_vm():
    p = Page("1 - Architecture VM RHEL 8")
    header(p, "Architecture cible — machines virtuelles RHEL 8 (vue réseau)",
           "Pile LGTM (Loki, Grafana, Tempo, Mimir) + Kafka + OpenTelemetry — sous-réseaux, pare-feu, VIP et ports des flux")
    T, TH = 0.86, 5.30          # rangée haute
    Bt, BH = 6.36, 3.30          # rangée basse

    # --- clients et sources
    p.zone("Clients et sources", 0.2, T, 2.05, TH, C_SRC, B_SRC, tag="réseaux métiers")
    app = p.machine(0.72, T + 0.48, logo="otel", title="Applications", lines=["SDK OpenTelemetry"], accent=C_ING, bh=0.66)
    agt = p.machine(0.72, T + 1.75, logo="otel", title="Agents hôtes", lines=["otelcol · exporters"], accent=C_ING, bh=0.66)
    usr = p.machine(0.72, T + 3.02, title="Utilisateurs", lines=["navigateur HTTPS"], accent=C_SRC, kind="pc",
                    generic="Poste", bh=0.66)
    ops = p.machine(0.72, T + 4.29, title="Exploitation", lines=["poste d'administration"], accent=C_ADM, kind="pc",
                    generic="Poste", bh=0.66)
    fw1 = p.firewall(2.37, T + 0.5, 0.26, 4.3, label="Pare-feu\nd'infrastructure")

    # --- équilibrage / VIP
    p.zone("Équilibrage et VIP", 2.78, T, 2.52, TH, C_LB, B_LB, net="{{VIP_NET}}")
    lb1 = p.machine(2.93, T + 0.48, logo="haproxy", title=H("LB01"), lines=[IP("LB01", "A")], accent=C_LB, badge="redhat",
                    w=0.92, bh=0.62, lw=1.2, size=0.075, props=rhel_props("HAProxy + keepalived", "LB01", "A", "{{VIP_NET}}"))
    lb2 = p.machine(4.23, T + 0.48, logo="haproxy", title=H("LB02"), lines=[IP("LB02", "B")], accent=C_LB, badge="redhat",
                    w=0.92, bh=0.62, lw=1.2, size=0.075, props=rhel_props("HAProxy + keepalived", "LB02", "B", "{{VIP_NET}}"))
    p.flow(lb1, lb2, "VRRP", color=C_LB, dashed=True, both=True, lsize=0.065, lfloat=True)
    p.rect(2.9, T + 1.68, 2.28, 0.26, fill=WHITE, line=C_LB, weight=0.01, rounding=0.04,
           text="keepalived : VIP maître / secours", size=0.075, bold=True, color=C_LB)
    v_gra = p.vip("Grafana {{GRAFANA_VIP}} :{{PORT_GRAFANA}}", 2.9, T + 2.12, 2.28, size=0.078)
    v_otl = p.vip("otel-gw {{OTEL_GW_VIP}} :{{PORT_OTEL_GRPC}}/{{PORT_OTEL_HTTP}}", 2.9, T + 2.52, 2.28, size=0.078)
    v_s3 = p.vip("S3 {{S3_VIP}} :{{PORT_S3}}", 2.9, T + 2.92, 2.28, size=0.078)
    p.text("Autres VIP du plan :\nMimir {{MIMIR_VIP}} :{{PORT_MIMIR}}\nLoki {{LOKI_VIP}} :{{PORT_LOKI}}\n"
           "Tempo {{TEMPO_VIP}} :{{PORT_TEMPO}}\nPostgreSQL {{PG_VIP}} :{{PORT_POSTGRES}}",
           2.92, T + 3.38, 2.3, 1.0, size=0.078, color=INK, valign=0)
    p.text("Kafka : pas de VIP, DNS multi-A\n{{KAFKA_DNS}}", 2.92, T + 4.62, 2.3, 0.45, size=0.075, color=MUTED, italic=True, valign=0)

    # --- ingestion
    p.zone("Ingestion", 5.42, T, 1.95, TH, C_ING, B_ING, net="{{INGEST_NET}}")
    gws = []
    for i, z in enumerate("ABC"):
        v = f"OTELGW0{i + 1}"
        g = p.machine(5.9, T + 0.45 + i * 1.40, logo="otel", title=H(v), lines=[IP(v, z)], accent=C_ING, badge="redhat",
                      w=1.0, bh=0.74, lw=1.85, size=0.075,
                      props=rhel_props("Passerelle OpenTelemetry + agent Prometheus", v, z, "{{INGEST_NET}}"))
        gws.append(g)
    p.image("prometheus", 5.52, T + 4.68, 0.3, 0.3)
    p.text("+ agent Prometheus sur chaque passerelle\npréprod : otel-gw-01, 02", 5.86, T + 4.62, 1.5, 0.45, size=0.072, color=MUTED, valign=0)

    # --- Kafka
    p.zone("Kafka KRaft", 7.49, T, 1.95, TH, C_KAF, B_KAF, net="{{KAFKA_NET}}")
    ks = []
    for i, z in enumerate("ABC"):
        v = f"KAFKA0{i + 1}"
        k = p.machine(7.97, T + 0.45 + i * 1.40, logo="kafka", title=H(v), lines=[IP(v, z)], accent=C_KAF, badge="redhat",
                      w=1.0, bh=0.74, lw=1.85, size=0.075,
                      props=rhel_props("Kafka courtier + contrôleur KRaft", v, z, "{{KAFKA_NET}}"))
        ks.append(k)
    p.text("RF=3 · min.insync.replicas=2\ncontrôleur :{{PORT_KAFKA_CONTROLLER}}", 7.6, T + 4.62, 1.75, 0.45, size=0.075, color=MUTED, valign=0)

    # --- stockage LGTM
    sx = 9.56
    p.zone("Stockage LGTM", sx, TH and T, 4.86, TH, C_STO, B_STO, net="{{STORE_NET}}", tag="prod : simple-scalable")
    rows = [
        ("mimir", [("mimir-write", 3, "distributor + ingester"), ("mimir-read", 2, "query-frontend + querier"),
                   ("mimir-backend", 3, "store-gateway · compactor · AM")]),
        ("loki", [("loki-write", 3, "écriture"), ("loki-read", 2, "lecture"), ("loki-backend", 3, "backend")]),
        ("tempo", [("tempo-dist", 2, "distributor"), ("tempo-ing", 3, "ingester"), ("tempo-query", 2, "frontend + querier"),
                   ("tempo-comp", 2, "compactor · metrics-gen.")]),
    ]
    sto = {}
    for r, (logo, items) in enumerate(rows):
        for c, (nm, n, role) in enumerate(items):
            rng = f"{nm}-01..0{n}" if n > 2 else f"{nm}-01, 02"
            m = p.machine(sx + 0.30 + c * 1.18, T + 0.50 + r * 1.40, logo=logo, title=rng, lines=[role], accent=C_STO,
                          badge="redhat", count=n, w=0.84, bh=0.70, lw=1.16, size=0.072,
                          props=[("Rôle", role), ("Hôtes", rng + ".{{DOMAIN}}"), ("Nombre de VM (prod)", str(n)),
                                 ("Sous-réseau", "{{STORE_NET}}"), ("Système", "RHEL 8")])
            sto[(logo, c)] = m
    p.text("préprod : mimir-01..03 · loki-01..03 · tempo-01..03 (compact HA, RF=3)", sx + 0.1, T + 4.75, 4.6, 0.4,
           size=0.078, color=MUTED, italic=True, valign=0)

    # --- objet
    ox = 14.56
    p.zone("Stockage objet MinIO", ox, T, 3.24, TH, C_OBJ, B_OBJ, net="{{OBJ_NET}}")
    mins = []
    for i, z in enumerate("ABCA"):
        v = f"MINIO0{i + 1}"
        m = p.machine(ox + 0.32 + (i % 2) * 1.55, T + 0.48 + (i // 2) * 1.40, logo="minio", title=H(v), lines=[IP(v, z)],
                      accent=C_OBJ, badge="redhat", w=1.0, bh=0.74, lw=1.52, size=0.072,
                      props=rhel_props("MinIO distribué", v, z, "{{OBJ_NET}}"))
        mins.append(m)
    p.text("Erasure coding · TLS · IAM\nAPI :{{MINIO_API_PORT}} · console :{{MINIO_CONSOLE_PORT}}\n"
           "Seaux : {{S3_BUCKET_MIMIR}} · {{S3_BUCKET_LOKI}}\n{{S3_BUCKET_TEMPO}} · {{S3_BUCKET_ADMIN}}",
           ox + 0.15, T + 3.4, 3.0, 0.9, size=0.078, color=INK, valign=0)
    p.text("VIP : {{S3_FQDN}}", ox + 0.15, T + 4.45, 3.0, 0.3, size=0.078, bold=True, color=C_OBJ, valign=0)

    # --- rangée basse : administration
    p.zone("Administration", 0.2, Bt, 3.0, BH, C_ADM, B_ADM, net="{{ADMIN_NET}}")
    bas = []
    for i, z in enumerate("AC"):
        v = f"BASTION0{i + 1}"
        b = p.machine(0.42 + i * 1.42, Bt + 0.48, logo="redhat", title=H(v), lines=[IP(v, z)], accent=C_ADM,
                      w=0.9, bh=0.62, lw=1.38, size=0.072, props=rhel_props("Bastion d'administration (SSH)", v, z, "{{ADMIN_NET}}"))
        bas.append(b)
    p.text("Seul point d'entrée SSH ;\npas d'administration depuis le réseau utilisateur.", 0.32, Bt + 1.6, 2.8, 0.5,
           size=0.078, color=MUTED, valign=0)

    # --- existants
    ex = 3.36
    p.zone("Systèmes existants (non redimensionnés)", ex, Bt, 5.56, BH, C_EX, B_EX, tag="10.90 / 10.91")
    dc1 = p.machine(ex + 0.25, Bt + 0.48, logo="windows", title=H("DC01"), lines=["{{DC01_IP}}"], accent=C_EX, w=0.82, bh=0.62,
                    lw=1.1, size=0.072, props=[("Rôle", "Active Directory (DC)"), ("Nom d'hôte", H("DC01")), ("Adresse IP", "{{DC01_IP}}")])
    dc2 = p.machine(ex + 1.33, Bt + 0.48, logo="windows", title=H("DC02"), lines=["{{DC02_IP}}"], accent=C_EX, w=0.82, bh=0.62,
                    lw=1.1, size=0.072, props=[("Rôle", "Active Directory (DC)"), ("Nom d'hôte", H("DC02")), ("Adresse IP", "{{DC02_IP}}")])
    es = p.machine(5.99, Bt + 0.48, logo="elasticsearch", title=H("ES"), lines=["{{ES_VIP}} · ROR"], accent=C_ES, w=0.82,
                   bh=0.62, lw=1.0, size=0.072, props=[("Rôle", "Elasticsearch 8 + ReadonlyREST"), ("Nom", H("ES")), ("VIP", "{{ES_VIP}}")])
    scom = p.machine(7.05, Bt + 0.48, logo="microsoft", title=H("SCOM"), lines=["{{SCOM_VIP}}"], accent=C_SCOM, w=0.82,
                     bh=0.62, lw=1.0, size=0.072, props=[("Rôle", "System Center Operations Manager 2019"), ("Nom", H("SCOM")), ("VIP", "{{SCOM_VIP}}")])
    appd = p.machine(8.08, Bt + 0.48, logo="appd", title=H("APPD"), lines=["{{APPD_VIP}}"], accent=C_APPD, w=0.82,
                     bh=0.62, lw=1.0, size=0.072, props=[("Rôle", "Contrôleur AppDynamics on-prem"), ("Nom", H("APPD")), ("VIP", "{{APPD_VIP}}")])
    p.text("AD : {{AD_DOMAIN}} · SCOM 2019 · AppDynamics on-prem :{{PORT_APPD_HTTPS}}", ex + 0.15, Bt + 2.95, 5.3, 0.3,
           size=0.075, color=MUTED, italic=True)
    fw2 = p.firewall(9.0, Bt + 0.45, 0.24, 2.2, label="Pare-feu")

    # --- interface
    ux = 9.38
    p.zone("Interface « one screen »", ux, Bt, 5.04, BH, C_UI, B_UI, net="{{UI_NET}}")
    gf = []
    for i, z in enumerate("AB"):
        v = f"GRAFANA0{i + 1}"
        g = p.machine(ux + 0.22 + i * 1.22, Bt + 0.48, logo="grafana", title=H(v), lines=[IP(v, z)], accent=C_UI,
                      badge="redhat", w=0.86, bh=0.62, lw=1.2, size=0.07, props=rhel_props("Grafana", v, z, "{{UI_NET}}"))
        gf.append(g)
    pgs = []
    for i, (z, r) in enumerate((("A", "primaire"), ("C", "réplique"))):
        v = f"PG0{i + 1}"
        g = p.machine(ux + 2.66 + i * 1.22, Bt + 0.48, logo="postgresql", title=H(v), lines=[IP(v, z)], accent=C_PG,
                      badge="redhat", w=0.86, bh=0.62, lw=1.2, size=0.07,
                      props=rhel_props(f"PostgreSQL ({r})", v, z, "{{UI_NET}}"))
        pgs.append(g)
    p.flow(pgs[0], pgs[1], "réplication", color=C_PG, dashed=True, lsize=0.062, lfloat=True)
    p.text("Base partagée Grafana (PostgreSQL primaire + réplique) · grafana_acl_sync : AD → équipes → dossiers",
           ux + 0.15, Bt + 2.9, 4.8, 0.36, size=0.075, color=MUTED, italic=True)

    legend(p, 14.56, Bt, 3.24, BH)

    # ---------------- flux
    gwx = 5.36
    p.flow(app, v_otl, "OTLP\n{{PORT_OTEL_GRPC}}/{{PORT_OTEL_HTTP}}", color=C_ING, via=[("x", 2.72)], lpos=(2.02, T + 0.48 + 0.33), lw=0.6)
    p.flow(agt, v_otl, "", color=C_ING, via=[("x", 2.72)])
    p.flow(usr, v_gra, "HTTPS\n{{PORT_GRAFANA}}", color=C_UI, via=[("x", 2.75)], lpos=(2.02, T + 3.02 + 0.29), lw=0.55)
    for g in gws:
        p.flow(v_otl, g, "", color=C_ING, via=[("x", gwx)])
    for i, (g, k) in enumerate(zip(gws, ks)):
        p.flow(g, k, "{{PORT_KAFKA}}" if i == 0 else "", color=C_KAF, lpos=None, lsize=0.07)
    # consommateurs stockage -> Kafka
    for r, k in zip(("mimir", "loki", "tempo"), ks):
        p.flow(sto[(r, 0)], k, "consume\n{{PORT_KAFKA}}" if r == "loki" else "", color=C_KAF, s_side="l", d_side="r",
               via=[("x", 9.5)], lsize=0.065, lpos=(9.2, k.y + 0.37), lw=0.5)
    # stockage -> objet
    p.flow(sto[("mimir", 2)], mins[0], "S3 {{PORT_S3}} via VIP", color=C_OBJ, lsize=0.068, via=[("x", 14.5)])
    p.flow(sto[("loki", 2)], mins[2], "", color=C_OBJ, via=[("x", 14.5)])
    p.flow(sto[("tempo", 3)], mins[2], "", color=C_OBJ, s_side="r", d_side="l", via=[("x", 14.5)])
    # Grafana -> stockage / PG / AD / ES / AppD
    p.flow(gf[0], (gf[0].anchor("t")[0], T + TH), "{{PORT_MIMIR}} · {{PORT_LOKI}} · {{PORT_TEMPO}}", color=C_UI,
           s_side="t", d_side="b", lpos=(gf[0].anchor("t")[0] + 0.35, T + TH - 0.2), lw=1.3)
    p.flow(gf[1], pgs[0], "{{PORT_POSTGRES}}", color=C_PG, lsize=0.065, lfloat=True)
    p.flow(gf[0], dc1, "LDAPS {{PORT_LDAPS}}", color=C_SEC, s_side="b", d_side="b", via=[("y", Bt + 2.62)],
           lpos=(6.2, Bt + 2.62))
    p.flow(es, dc2, "ROR {{PORT_LDAPS}}", color=C_SEC, s_side="b", d_side="b", via=[("y", Bt + 2.3)], lsize=0.065)
    p.flow(gws[2], es, "HTTPS {{PORT_ES}} (double écriture)", color=C_ES, s_side="b", d_side="t",
           lpos=(6.4, T + TH - 0.14), lw=1.6)
    p.flow(gf[1], appd, "{{PORT_APPD_HTTPS}}\ngreffon (option)", color=C_APPD, dashed=True, s_side="b", d_side="b",
           via=[("y", Bt + 1.98)], lpos=(10.5, Bt + 1.98), lw=0.85)
    # administration
    p.flow(ops, bas[0], "", color=C_SSH, dashed=True, s_side="b", d_side="t")
    p.flow(bas[1], (14.5, Bt - 0.1), "SSH 22 → toutes les VM", color=C_SSH, dashed=True, s_side="t", d_side="l",
           via=[("y", Bt - 0.1)], lpos=(12.9, Bt - 0.1), lw=1.4)

    footer(p, "Plan d'adressage, FQDN et ports : variables/environnements.env (format {{NOM_VARIABLE}}, scripts/Actualiser-Variables.ps1). "
              "Trois zones de défaillance A/B/C. Préprod : 26 VM, prod : 45 VM. Stockage objet : MinIO distribué (ADR-002). Systemd, sans Docker.")
    return p


# =====================================================================================
def d_archi_k8s():
    p = Page("2 - Architecture Kubernetes")
    header(p, "Architecture cible — déploiement Kubernetes (vue réseau)",
           "Mêmes blocs logiques : Helm + opérateurs, registre privé, cert-manager, NetworkPolicy entre espaces de noms")
    T = 0.86
    # clients
    p.zone("Clients", 0.2, T, 1.9, 5.2, C_SRC, B_SRC)
    usr = p.machine(0.65, T + 0.5, title="Utilisateurs", lines=["navigateur HTTPS"], accent=C_SRC, kind="pc", generic="Poste", bh=0.66)
    agt = p.machine(0.65, T + 1.85, logo="otel", title="Applications", lines=["et agents OTLP"], accent=C_ING, bh=0.66)
    ops = p.machine(0.65, T + 3.2, title="Exploitation", lines=["kubectl / helm"], accent=C_ADM, kind="pc", generic="Poste", bh=0.66)
    fw = p.firewall(2.2, T + 0.5, 0.24, 4.2, label="Pare-feu\nd'infrastructure")

    # cluster
    cx, cw = 2.6, 11.95
    p.rect(cx, T, cw, 7.75, fill="#FBFDFF", line="#326CE5", weight=0.022, rounding=0.1)
    p.rect(cx, T, cw, 0.34, fill="#326CE5", line="#326CE5", weight=0.01, rounding=0.08)
    p.image("kubernetes", cx + 0.08, T + 0.03, 0.28, 0.28)
    p.text("Cluster Kubernetes ({{LGTM_ENV}}) — trois zones A/B/C, NetworkPolicy par espace de noms", cx + 0.42, T, 8.5, 0.34,
           size=0.11, bold=True, color=WHITE)
    p.text("pools de nœuds : prod / préprod", cx + 8.6, T, cw - 8.7, 0.34, size=0.09, bold=True, color=WHITE, align=2)

    def pool(x, y, w, h, title, accent, bg, logos, cnt, usage, zones, extra=None):
        p.zone(title, x, y, w, h, accent, bg, tag=zones)
        m = p.machine(x + (w - 1.1) / 2, y + 0.45, logo=logos, title=cnt, lines=[usage], accent=accent, badge="kubernetes",
                      count=3, w=1.1, bh=0.74, lw=w - 0.1, size=0.075,
                      props=[("Pool", title), ("Nœuds", cnt), ("Usage", usage), ("Zones", zones)])
        if extra:
            p.text(extra, x + 0.1, y + 1.62, w - 0.2, h - 1.68, size=0.075, color=MUTED, valign=0)
        return m

    r1 = T + 0.5
    W = 2.85
    xs = [cx + 0.15 + i * (W + 0.1) for i in range(4)]
    sysm = pool(xs[0], r1, W, 2.55, "system", C_LB, B_LB, ["kubernetes", "certmanager"], "prod 3 · préprod 2",
                "Ingress, cert-manager, opérateurs", "A/B/C",
                "Ingress HTTPS :\n{{GRAFANA_FQDN}}\n{{OTEL_GW_FQDN}}\ncert-manager : Issuer CA interne")
    ing = pool(xs[1], r1, W, 2.55, "ingest", C_ING, B_ING, ["otel", "prometheus"], "prod 3 · préprod 2",
               "passerelle OTel, agent Prometheus", "A/B/C",
               "OpenTelemetry Operator\nCollector gateway × N\nPDB + anti-affinité")
    kaf = pool(xs[2], r1, W, 2.55, "kafka", C_KAF, B_KAF, ["strimzi", "kafka"], "prod 3 · préprod 3",
               "StatefulSet Kafka (Strimzi)", "A/B/C",
               "KRaft · RF=3 · min.ISR=2\notlp_logs · otlp_metrics · otlp_spans\n:{{PORT_KAFKA}}")
    obj = pool(xs[3], r1, W, 2.55, "objet", C_OBJ, B_OBJ, ["minio"], "prod 4 · préprod 4",
               "MinIO distribué", "A/B/C/A",
               "opérateur ou chart officiel\n4 pods, anti-affinité\nSecret, cert-manager")
    r2 = T + 3.2
    wr = pool(xs[0], r2, W, 2.55, "lgtm-write", C_STO, B_STO, ["mimir", "loki", "tempo"], "prod 3 nœuds",
              "ingesters / write", "A/B/C", "préprod : pool lgtm unique,\n6 nœuds (2 par zone)")
    rd = pool(xs[1], r2, W, 2.55, "lgtm-read", C_STO, B_STO, ["mimir", "loki", "tempo"], "prod 3 nœuds",
              "couches de requête", "A/B/C", "Mimir :{{PORT_MIMIR}} · Loki :{{PORT_LOKI}}\nTempo :{{PORT_TEMPO}}")
    bk = pool(xs[2], r2, W, 2.55, "lgtm-backend", C_STO, B_STO, ["mimir", "loki", "tempo"], "prod 3 nœuds",
              "store-gateway, compacteurs, AM", "A/B/C", "Alertmanager en cluster")
    ui = pool(xs[3], r2, W, 2.55, "ui", C_UI, B_UI, ["grafana", "postgresql"], "prod 2 · préprod 2",
              "Grafana, PostgreSQL", "A/C", "Grafana × 2+ · PDB · LDAP\nCronJob grafana-acl-sync")

    # charts et résilience
    r3 = T + 5.9
    p.zone("Charts Helm et opérateurs", cx + 0.15, r3, 5.8, 1.6, "#0F1689", "#EEF0FF")
    p.image("helm", cx + 0.3, r3 + 0.42, 0.62, 0.62)
    p.text("grafana/mimir-distributed (microservices + S3)\ngrafana-community/loki (Distributed ou SimpleScalable)\n"
           "grafana-community/tempo-distributed (metrics-generator)\ngrafana-community/grafana (× 2+, PostgreSQL)\n"
           "Strimzi (Kafka KRaft) · OpenTelemetry Operator\nCharts à vérifier à l'installation",
           cx + 1.05, r3 + 0.36, 4.8, 1.2, size=0.08, valign=0)
    p.zone("Résilience et sécurité réseau", cx + 6.05, r3, 5.75, 1.6, OK, OK_BG)
    p.text("PodDisruptionBudget sur tous les composants critiques\nanti-affinité de zone + topologySpread\n"
           "StorageClass chiffrée (Kafka, PostgreSQL, WAL)\nobjet S3 long terme hors des PVC\n"
           "NetworkPolicy : seuls les flux de la matrice sont ouverts",
           cx + 6.2, r3 + 0.36, 5.5, 1.2, size=0.08, valign=0)

    # hors cluster
    ox = 14.7
    p.zone("Hors cluster", ox, T, 3.1, 7.75, C_EX, B_EX)
    reg = p.machine(ox + 0.3, T + 0.5, title=H("REGISTRY"), lines=["images + charts (hors ligne)"], accent=C_EX,
                    generic="Registre\nprivé", w=0.95, bh=0.7, lw=2.5, size=0.075)
    dc = p.machine(ox + 0.3, T + 1.95, logo="windows", title=H("DC01"), lines=["AD · LDAPS {{PORT_LDAPS}}"], accent=C_EX,
                   w=0.95, bh=0.7, lw=2.5, size=0.075)
    es = p.machine(ox + 0.3, T + 3.4, logo="elasticsearch", title=H("ES"), lines=["ES 8 + ROR · {{PORT_ES}}"], accent=C_ES,
                   w=0.95, bh=0.7, lw=2.5, size=0.075)
    scom = p.machine(ox + 0.3, T + 4.85, logo="microsoft", title=H("SCOM"), lines=["SCOM 2019 · voies A / B / C"],
                     accent=C_SCOM, w=0.95, bh=0.7, lw=2.5, size=0.075)
    appd = p.machine(ox + 0.3, T + 6.3, logo="appd", title=H("APPD"), lines=["AppDynamics · HTTPS {{PORT_APPD_HTTPS}}"],
                     accent=C_APPD, w=0.95, bh=0.7, lw=2.5, size=0.075)

    # flux
    p.flow(usr, sysm, "HTTPS\n{{PORT_GRAFANA}}", color=C_UI, d_side="l", via=[("x", 2.52)], lpos=(1.88, usr.y + 0.33), lw=0.5, lsize=0.065)
    p.flow(agt, sysm, "OTLP\n{{PORT_OTEL_GRPC}}/{{PORT_OTEL_HTTP}}", color=C_ING, d_side="l", via=[("x", 2.52)],
           lpos=(1.88, agt.y + 0.33), lw=0.55, lsize=0.065)
    p.flow(ops, (cx, ops.y + 0.33), "", color=C_SSH, dashed=True)
    p.flow(sysm, ing, "", color=C_ING)
    p.flow(ing, kaf, "{{PORT_KAFKA}}", color=C_KAF, lsize=0.07)
    p.flow(wr, kaf, "consume {{PORT_KAFKA}}", color=C_KAF, s_side="t", d_side="b", via=[("y", r2 - 0.1)],
           lpos=(xs[1] + W + 0.05, r2 - 0.1), lw=1.1, lsize=0.07)
    p.flow((xs[2] + W - 0.3, r2), obj, "S3 {{PORT_S3}}", color=C_OBJ, s_side="t", d_side="b", via=[("y", r2 - 0.075)], lsize=0.07, lpos=(xs[3] + 0.5, r2 - 0.075), lw=0.75)
    p.flow(ui, rd, "requêtes", color=C_UI, s_side="b", d_side="b", via=[("y", r2 + 2.38)], lsize=0.07,
           lpos=(xs[2] + 1.42, r2 + 2.38))
    p.flow(ui, dc, "LDAPS\n{{PORT_LDAPS}}", color=C_SEC, s_side="r", d_side="l", via=[("x", ox - 0.1)], lsize=0.065,
           lpos=(ox - 0.1, dc.y + 1.3), lw=0.5)
    p.flow(reg, (cx + cw, reg.y + 0.37), "pull images", color=C_SSH, dashed=True, s_side="l", d_side="r", lsize=0.07,
           lpos=(ox - 0.08, reg.y + 0.37 - 0.0), lw=0.8)
    footer(p, "FQDN : {{GRAFANA_FQDN}}, {{OTEL_GW_FQDN}}, {{REGISTRY_FQDN}} — variables/environnements.env. Pools de nœuds : estimations recommandées "
              "(architecture §8.3). Charts à vérifier à l'installation.")
    return p


# =====================================================================================
def d_flux():
    p = Page("3 - Flux de données")
    header(p, "Flux de données — OTLP → Kafka → Mimir / Loki / Tempo et double écriture ELK",
           "Chaque signal a son sujet et son groupe de consommateurs ; les journaux sont lus deux fois (Loki et Elasticsearch)")
    T, Hh = 0.86, 7.75
    # 1. émission
    p.zone("1. Émission", 0.2, T, 2.4, Hh, C_SRC, B_SRC)
    s1 = p.machine(0.7, T + 0.5, logo="otel", title="Application", lines=["SDK OTel"], accent=C_ING, bh=0.7, w=1.0, lw=2.2)
    s2 = p.machine(0.7, T + 1.85, logo="otel", title="Agent Linux", lines=["journald → OTLP"], accent=C_ING, badge="redhat",
                   bh=0.7, w=1.0, lw=2.2)
    s3 = p.machine(0.7, T + 3.2, logo="otel", title="Agent Windows", lines=["windowseventlog"], accent=C_ING, badge="windows",
                   bh=0.7, w=1.0, lw=2.2)
    s4 = p.machine(0.7, T + 4.55, logo="prometheus", title="Agent Prometheus", lines=["scrape + remote_write (hors Kafka)"],
                   accent=C_STO, bh=0.7, w=1.0, lw=2.2)
    p.rect(0.35, T + 6.2, 2.1, 0.62, fill=WHITE, line=C_ING, weight=0.012, rounding=0.05,
           text="OTLP gRPC :{{PORT_OTEL_GRPC}}\nOTLP HTTP :{{PORT_OTEL_HTTP}}", size=0.085, bold=True, color=C_ING)
    fw = p.firewall(2.72, T + 0.6, 0.24, 4.6, label="Pare-feu")

    # 2. passerelle
    p.zone("2. Passerelle", 3.1, T, 2.9, Hh, C_ING, B_ING, net="{{INGEST_NET}}")
    vip = p.vip("{{OTEL_GW_FQDN}} · {{OTEL_GW_VIP}}", 3.22, T + 0.5, 2.66, size=0.075)
    gw = p.machine(3.95, T + 1.1, logo="otel", title="otel-gw-01..03", lines=["récepteur OTLP", "memory_limiter + batch",
                   "exportateur kafka · acks=-1 · zstd"], accent=C_ING, badge="redhat", count=3, w=1.1, bh=0.8, lw=2.7)
    km = p.rect(3.25, T + 3.25, 2.6, 0.8, fill=WHITE, line=C_STO, weight=0.014, rounding=0.05,
                text="récepteur kafka_metrics\nlag des groupes → Mimir", size=0.085, bold=True, color=INK)
    elk = p.rect(3.25, T + 4.3, 2.6, 1.0, fill=WHITE, line=C_ES, weight=0.014, rounding=0.05,
                 text="récepteur kafka/elk · groupe elk-es\nexportateur elasticsearch\n(pipeline logs/elk)", size=0.085,
                 bold=True, color=INK)
    elkg = Group(3.25, T + 4.3, 2.6, 1.0, "elk")

    # 3. Kafka
    p.zone("3. Tampon Kafka", 6.15, T, 3.2, Hh, C_KAF, B_KAF, net="{{KAFKA_NET}}")
    kk = p.machine(7.2, T + 0.5, logo="kafka", title="kafka-01..03", lines=["{{KAFKA_DNS}} · :{{PORT_KAFKA}}"], accent=C_KAF,
                   badge="redhat", count=3, w=1.1, bh=0.8, lw=3.0, size=0.07)
    tl = p.rect(6.35, T + 2.05, 2.8, 0.75, fill="#FEF3C7", line=C_SEC, weight=0.016, rounding=0.06,
                text="sujet otlp_logs\n3+ partitions · RF=3", size=0.095, bold=True)
    tm = p.rect(6.35, T + 3.05, 2.8, 0.75, fill="#EDE9FE", line=C_STO, weight=0.016, rounding=0.06,
                text="sujet otlp_metrics\n3+ partitions · RF=3", size=0.095, bold=True)
    ts = p.rect(6.35, T + 4.05, 2.8, 0.75, fill="#DBEAFE", line="#1D4ED8", weight=0.016, rounding=0.06,
                text="sujet otlp_spans\n3+ partitions · RF=3", size=0.095, bold=True)
    p.rect(6.35, T + 5.15, 2.8, 0.95, fill=WHITE, line=C_KAF, weight=0.012, rounding=0.05,
           text="Rétention à définir\n(ex. 3 jours — hypothèse)\nauto.create.topics=false", size=0.085)

    # 4. consommation
    p.zone("4. Groupes de consommateurs", 9.5, T, 2.75, Hh, C_STO, B_STO, net="{{STORE_NET}}")
    def grp(y, txt, col, bg):
        return p.rect(9.65, y, 2.45, 0.75, fill=bg, line=col, weight=0.016, rounding=0.06, text=txt, size=0.09, bold=True)
    cl = grp(T + 2.05, "groupe lgtm-loki\n→ Loki :{{PORT_LOKI}}", "#C2410C", "#FFEDD5")
    cm = grp(T + 3.05, "groupe lgtm-mimir\n→ Mimir :{{PORT_MIMIR}}/otlp", C_STO, "#EDE9FE")
    ct = grp(T + 4.05, "groupe lgtm-tempo\n→ Tempo :{{PORT_TEMPO}}", "#1D4ED8", "#DBEAFE")
    ce = grp(T + 5.25, "groupe elk-es\n→ ES :{{PORT_ES}} · logs-*\nauth ROR (compte service)", C_ES, "#E6F3FB")

    # 5. stockage
    p.zone("5. Stockage et consultation", 12.4, T, 5.4, Hh, C_UI, B_UI)
    lo = p.machine(12.75, T + 1.85, logo="loki", title=H("LOKI"), lines=["journaux"], accent="#C2410C", badge="redhat", w=0.95,
                   bh=0.7, lw=1.7, size=0.072)
    mi = p.machine(12.75, T + 3.05, logo="mimir", title=H("MIMIR"), lines=["métriques + Alertmanager"], accent=C_STO,
                   badge="redhat", w=0.95, bh=0.7, lw=1.7, size=0.072)
    te = p.machine(12.75, T + 4.25, logo="tempo", title=H("TEMPO"), lines=["traces"], accent="#1D4ED8", badge="redhat",
                   w=0.95, bh=0.7, lw=1.7, size=0.072)
    es = p.machine(12.75, T + 5.55, logo="elasticsearch", title=H("ES"), lines=["ES 8 + ROR · ElastAlert2"], accent=C_ES,
                   w=0.95, bh=0.7, lw=1.7, size=0.072)
    s3m = p.machine(15.3, T + 3.05, logo="minio", title=H("S3"), lines=["MinIO · S3 {{PORT_S3}}"], accent=C_OBJ, badge="redhat",
                   count=4, w=1.0, bh=0.74, lw=2.0, size=0.072)
    gr = p.machine(15.3, T + 0.5, logo="grafana", title=H("GRAFANA"), lines=["vue unique"], accent=C_UI, badge="redhat",
                   count=2, w=1.0, bh=0.74, lw=2.0, size=0.072)

    # flux
    for s in (s1, s2, s3):
        p.flow(s, vip, "", color=C_ING, via=[("x", 3.05)])
    p.flow(vip, gw, "", color=C_ING, s_side="b", d_side="t")
    p.flow(gw, kk, "produce {{PORT_KAFKA}}", color=C_KAF, s_side="r", d_side="l", lsize=0.07, lw=1.1)
    for t_, c_, col in ((tl, cl, "#C2410C"), (tm, cm, C_STO), (ts, ct, "#1D4ED8")):
        p.flow((6.35 + 2.8, t_.y + 0.375), (9.65, c_.y + 0.375), "", color=col)
    p.flow((6.35, tl.y + 0.6), (5.85, elk.y + 0.3), "même sujet", color=C_ES, dashed=True, lsize=0.065, s_side="l", d_side="r",
           lpos=(6.1, tl.y + 1.55), lw=0.6)
    p.flow((5.85, elk.y + 0.75), (9.65, ce.y + 0.375), "", color=C_ES, via=[("x", 6.25)])
    p.flow((9.65 + 2.45, cl.y + 0.375), lo, "", color="#C2410C", d_side="l")
    p.flow((9.65 + 2.45, cm.y + 0.375), mi, "", color=C_STO, d_side="l")
    p.flow((9.65 + 2.45, ct.y + 0.375), te, "", color="#1D4ED8", d_side="l")
    p.flow((9.65 + 2.45, ce.y + 0.5), es, "", color=C_ES, d_side="l")
    for m in (lo, mi, te):
        p.flow(m, s3m, "", color=C_OBJ, via=[("x", 14.9)])
    p.text("S3 {{PORT_S3}}\nvia VIP", 14.5, T + 2.45, 0.8, 0.4, size=0.07, bold=True, color=C_OBJ, align=1)
    p.flow(gr, (13.22, T + 1.7), "requêtes", color=C_UI, s_side="l", d_side="t", lsize=0.07, lpos=(14.3, gr.y + 0.37), lw=0.7)
    p.flow(s4, mi, "remote_write :{{PORT_MIMIR}}", color=C_STO, dashed=True, s_side="b", d_side="b",
           via=[("y", T + 7.5)], lpos=(7.5, T + 7.5), lw=1.7, lsize=0.075)
    p.flow(km, (13.22, mi.y + mi.h), "", color=C_STO, dashed=True, s_side="b", d_side="b", via=[("y", T + 7.25)])
    footer(p, "Le groupe elk-es est indépendant de lgtm-loki : chaque groupe a son offset. En phase de retrait ELK, le pipeline logs/elk est "
              "retiré. LAG = 0 en régime établi. Noms et ports : variables/environnements.env.")
    return p


# =====================================================================================
def d_securite():
    p = Page("4 - Flux de sécurité et d'authentification")
    header(p, "Sécurité — LDAP principal, ROR Enterprise, certificats (vue réseau)",
           "LDAPS {{PORT_LDAPS}} = authentification principale (ADR-006) · SSO Kerberos/OIDC = annexe optionnelle (ADR-011) · ROR Enterprise : LDAP, audit, tenancy")
    T = 0.86
    # identité AD
    p.zone("Annuaire — Active Directory {{AD_DOMAIN}}", 0.2, T, 4.3, 4.3, C_SEC, "#FFFBEB", tag="LDAPS {{PORT_LDAPS}} · Kerberos {{PORT_KERBEROS}}")
    dc1 = p.machine(0.45, T + 0.5, logo="windows", title=H("DC01"), lines=["{{DC01_IP}}"], accent=C_SEC, w=0.9, bh=0.66, lw=1.6, size=0.072)
    dc2 = p.machine(2.3, T + 0.5, logo="windows", title=H("DC02"), lines=["{{DC02_IP}}"], accent=C_SEC, w=0.9, bh=0.66, lw=1.6, size=0.072)
    pki = p.machine(0.45, T + 1.9, logo="windows", title="PKI interne (AD CS)", lines=["certificats de service"], accent=C_SEC,
                    w=0.9, bh=0.66, lw=1.6, size=0.072)
    adfs = p.machine(2.3, T + 1.9, logo="windows", title=H("ADFS"), lines=["AD FS (si OIDC)"], accent=C_SEC, w=0.9, bh=0.66,
                     lw=1.6, size=0.072)
    p.text("Compte de liaison en lecture · groupes métier\nAD CS : logo dédié non disponible, logo Windows utilisé",
           0.35, T + 3.35, 4.0, 0.8, size=0.078, color=MUTED, valign=0)

    p.firewall(4.65, T + 0.5, 0.24, 3.4, label="Pare-feu")

    # Grafana
    p.zone("Interface Grafana", 5.05, T, 5.9, 4.3, C_UI, B_UI, net="{{UI_NET}}")
    vg = p.vip("{{GRAFANA_FQDN}} · {{GRAFANA_VIP}}:{{PORT_GRAFANA}}", 5.25, T + 0.48, 3.4, size=0.075)
    gf1 = p.machine(5.35, T + 1.05, logo=["grafana", "apache"], title=H("GRAFANA01"), lines=["LDAP principal · group_mappings"],
                    accent=C_UI, badge="redhat", w=1.15, bh=0.72, lw=2.1, size=0.07)
    gf2 = p.machine(7.45, T + 1.05, logo=["grafana", "apache"], title=H("GRAFANA02"), lines=["Admin / Editor / Viewer"],
                    accent=C_UI, badge="redhat", w=1.15, bh=0.72, lw=2.1, size=0.07)
    p.rect(9.3, T + 0.48, 1.5, 1.3, fill=WHITE, line=C_UI, weight=0.012, rounding=0.05,
           text="Apache (option SSO)\nmod_auth_gssapi\n→ Grafana [auth.proxy]\n127.0.0.1:3000", size=0.072)
    sync = p.rect(5.25, T + 2.55, 5.55, 0.7, fill=WHITE, line=C_SEC, weight=0.014, rounding=0.05,
                  text="grafana_acl_sync — AD → équipes → dossiers → tableaux de bord\n(Team Sync = fonction Grafana Enterprise)",
                  size=0.08, bold=True)
    p.rect(5.25, T + 3.4, 5.55, 0.7, fill=WHITE, line=NAVY, weight=0.012, rounding=0.05,
           text="Jeton de compte de service Grafana : fichier 0600, jamais en ligne de commande\n"
                "Logo Apache = annexe SSO optionnelle (colocalisé)", size=0.075)

    # ES + ROR
    p.zone("Elasticsearch 8 + ReadonlyREST Enterprise", 11.1, T, 6.7, 4.3, C_ES, "#E6F3FB", tag="{{ES_VIP}}:{{PORT_ES}}")
    es = p.machine(11.35, T + 0.5, logo=["elasticsearch", "kibana"], title=H("ES"), lines=["ROR : ldap_auth (ldaps), audit"],
                   accent=C_ES, w=1.2, bh=0.72, lw=2.3, size=0.07)
    p.rect(13.85, T + 0.48, 3.8, 1.2, fill=WHITE, line=C_ES, weight=0.012, rounding=0.05,
           text="readonlyrest.yml · access_control_rules\n(premier bloc qui correspond gagne)\nmulti-tenancy Kibana · rechargement à chaud\npas d'api_key",
           size=0.075)
    ow = p.rect(11.3, T + 2.1, 3.05, 1.0, fill=WHITE, line=C_ES, weight=0.012, rounding=0.05,
                text="otel-writer\nauth_key_pbkdf2 · indices logs-*\nactions d'écriture limitées", size=0.075)
    grd = p.rect(14.55, T + 2.1, 3.1, 1.0, fill=WHITE, line=C_ES, weight=0.012, rounding=0.05,
                 text="grafana-reader\nauth_key_pbkdf2 · indices logs-*\nlecture seule", size=0.075)
    gw = p.machine(11.6, T + 3.25, logo="otel", title="otel-gw-01..03", lines=[], accent=C_ING, badge="redhat", count=3,
                   w=0.8, bh=0.5, lw=1.5, size=0.07)

    # PKI leçon SAN
    p.zone("PKI interne — leçon du SAN", 0.2, T + 4.5, 5.6, 3.95, RED, "#FEF2F2")
    p.rect(0.35, T + 4.95, 5.3, 1.05, fill=RED_BG, line=RED, weight=0.016, rounding=0.05,
           text="INCORRECT\ncertificat ES avec SAN = hôte court\n(ex. es01 seulement)", size=0.09, bold=True, color=RED)
    p.rect(0.35, T + 6.15, 5.3, 1.25, fill=OK_BG, line=OK, weight=0.016, rounding=0.05,
           text="CORRECT\nSAN = FQDN réellement utilisé + hôte court + localhost au besoin\nex. {{ES_FQDN}}, es01", size=0.09,
           bold=True, color=OK)
    p.text("Vérification : openssl s_client, SAN = FQDN client. Rotation 30 j.", 0.35, T + 7.5, 5.3, 0.4, size=0.08, color=MUTED)

    # SSO Kerberos
    p.zone("Annexe optionnelle — SSO Kerberos (postes du domaine)", 5.95, T + 4.5, 5.85, 3.95, C_UI, B_UI)
    pc = p.machine(6.2, T + 5.0, logo="windows", title="Poste Windows", lines=["Negotiate / Kerberos"], accent=C_SRC, kind="pc",
                   w=0.95, bh=0.7, lw=1.5, size=0.072)
    ap = p.machine(8.35, T + 5.0, logo="apache", title="Apache + mod_auth_gssapi", lines=["HTTPS {{PORT_GRAFANA}} · SAN = FQDN VIP"],
                   accent=C_UI, badge="redhat", w=0.95, bh=0.7, lw=2.0, size=0.07)
    gp = p.machine(10.55, T + 5.0, logo="grafana", title="Grafana [auth.proxy]", lines=["127.0.0.1:3000"], accent=C_UI,
                   badge="redhat", w=0.95, bh=0.7, lw=1.4, size=0.07)
    p.text("SPN HTTP/{{GRAFANA_FQDN}} · keytab AES-256 · krb5 {{KRB_REALM}}\nCompte {{KRB_SERVICE_ACCOUNT}} · ktpass -pass * (invite)\n"
           "X-WEBAUTH-USER · whitelist = 127.0.0.1",
           6.1, T + 6.65, 5.6, 0.9, size=0.078, color=INK, valign=0)

    # OIDC
    p.zone("Annexe optionnelle — SSO OIDC / Generic OAuth (si AD FS)", 11.95, T + 4.5, 5.85, 3.95, C_SEC, "#FFFBEB")
    br = p.machine(12.2, T + 5.0, title="Navigateur", lines=["/login/generic_oauth"], accent=C_SRC, kind="pc", generic="Poste",
                   w=0.95, bh=0.7, lw=1.5, size=0.072)
    af = p.machine(14.5, T + 5.0, logo="windows", title=H("ADFS"), lines=["/adfs/oauth2/authorize · /token"], accent=C_SEC,
                   w=0.95, bh=0.7, lw=2.1, size=0.07)
    p.text("role_attribute_path · org_mapping (OSS ≥ 11.2) · Team Sync = Enterprise\nCompensation : grafana_acl_sync (équipes), organisations\n"
           "Journaux Grafana/Apache → Loki (pas l'auditing Enterprise). Non testé.",
           12.1, T + 6.65, 5.6, 0.9, size=0.078, color=INK, valign=0)

    # flux
    p.flow(gf1, dc1, "LDAPS {{PORT_LDAPS}}", color=C_SEC, s_side="l", d_side="r", via=[("x", 4.55)], lsize=0.07,
           lpos=(4.25, gf1.y + 0.36), lw=0.9)
    p.flow(sync, dc2, "LDAPS {{PORT_LDAPS}}", color=C_SEC, s_side="l", d_side="r", via=[("x", 4.4)], lsize=0.07,
           lpos=(4.25, sync.y + 0.35), lw=0.9)
    p.flow(es, (11.1, T + 0.4), "", color=C_SEC, s_side="t", d_side="r", via=[("y", T + 0.4)])
    p.flow((11.1, T + 0.4), dc2, "ROR ldap_auth {{PORT_LDAPS}}", color=C_SEC, s_side="l", d_side="t", via=[("x", 2.92)],
           lpos=(8.0, T + 0.4), lw=1.6, lsize=0.07)
    p.flow(vg, gf1, "", color=C_UI, s_side="b", d_side="t")
    p.flow(gf2, grd, "HTTPS {{PORT_ES}}", color=C_ES, s_side="b", d_side="t", via=[("y", T + 1.95)], lsize=0.07,
           lpos=(12.9, T + 1.95), lw=1.0)
    p.flow(gw, ow, "HTTPS {{PORT_ES}}", color=C_ES, s_side="r", d_side="b", lsize=0.07, lpos=(13.2, gw.y + 0.25), lw=1.0)
    p.flow(pc, ap, "HTTPS {{PORT_GRAFANA}}", color=C_UI, lsize=0.065, lfloat=True)
    p.flow(ap, gp, "3000", color=C_UI, lsize=0.065, lfloat=True)
    p.flow(ap, (3.6, T + 4.3), "Kerberos {{PORT_KERBEROS}} → DC", color=C_SEC, dashed=True, s_side="t", d_side="b",
           via=[("y", T + 4.4)], lpos=(5.9, T + 4.4), lw=1.4, lsize=0.07)
    p.flow(br, af, "HTTPS 443", color=C_SEC, lsize=0.065, lfloat=True)
    footer(p, "LDAP principal : ADR-006. SSO annexe : ADR-011. ROR Enterprise : ADR-004 (audit, tenancy, rechargement à chaud ; pas de "
              "_security/api_key). Secrets : read -rsp / Read-Host -AsSecureString, fichiers 0600/0640, jamais en ligne de commande. Non testé.")
    return p


# =====================================================================================
def d_ha():
    p = Page("5 - Topologie HA et bascule")
    header(p, "Haute disponibilité et bascule — tolérance à la perte d'un nœud",
           "Objectif : un incident simple (1 courtier Kafka, 1 ingester, 1 Grafana, 1 passerelle) ne coupe ni l'ingestion ni la consultation")
    T = 0.86
    # Kafka
    p.zone("Kafka — perte d'un courtier", 0.2, T, 5.75, 4.15, C_KAF, B_KAF, net="{{KAFKA_NET}}")
    k = []
    for i, (z, st, l2) in enumerate((("A", None, "leader part. 0"), ("B", None, "leader part. 1"), ("C", "ko", "HORS SERVICE"))):
        v = f"KAFKA0{i + 1}"
        k.append(p.machine(0.5 + i * 1.85, T + 0.5, logo="kafka", title=H(v), lines=[f"zone {z} · {l2}"], accent=RED if st else OK,
                           badge="redhat", status=st, w=0.95, bh=0.7, lw=1.75, size=0.07))
    p.flow(k[0], k[1], "réplication", color=C_KAF, both=True, lsize=0.065, lfloat=True)
    p.rect(0.35, T + 1.95, 5.45, 1.15, fill=WHITE, line=C_KAF, weight=0.012, rounding=0.05,
           text="RF=3, ISR ≥ 2 → les partitions restent disponibles\nProducteurs acks=all · pas de perte si ISR respecté\n"
                "Contrôleurs KRaft : quorum 2/3, un échec toléré", size=0.085)
    p.rect(0.35, T + 3.25, 5.45, 0.55, fill=WARN_BG, line=WARN, weight=0.012, rounding=0.05,
           text="À 2 courtiers perdus : quorum perdu, écriture arrêtée.", size=0.085, bold=True, color=WARN)

    # Grafana
    p.zone("Grafana — perte d'une instance", 6.1, T, 5.85, 4.15, C_UI, B_UI, net="{{UI_NET}}")
    lb1 = p.machine(6.35, T + 0.5, logo="haproxy", title=H("LB01"), lines=["zone A · VIP maître"], accent=C_LB, badge="redhat",
                    w=0.9, bh=0.62, lw=1.5, size=0.068)
    lb2 = p.machine(6.35, T + 1.65, logo="haproxy", title=H("LB02"), lines=["zone B · secours"], accent=C_LB, badge="redhat",
                    w=0.9, bh=0.62, lw=1.5, size=0.068)
    p.flow(lb1, lb2, "VRRP", color=C_LB, dashed=True, both=True, s_side="bb", d_side="t", lsize=0.06, lfloat=False, lw=0.45)
    g1 = p.machine(8.3, T + 0.5, logo="grafana", title=H("GRAFANA01"), lines=["HORS SERVICE"], accent=RED, badge="redhat",
                   status="ko", w=0.9, bh=0.62, lw=1.6, size=0.068)
    g2 = p.machine(10.1, T + 0.5, logo="grafana", title=H("GRAFANA02"), lines=["actif"], accent=OK, badge="redhat",
                   w=0.9, bh=0.62, lw=1.6, size=0.068)
    pg1 = p.machine(8.3, T + 1.65, logo="postgresql", title=H("PG01"), lines=["primaire"], accent=C_PG, badge="redhat",
                    w=0.9, bh=0.62, lw=1.6, size=0.068)
    pg2 = p.machine(10.1, T + 1.65, logo="postgresql", title=H("PG02"), lines=["réplique"], accent=C_PG, badge="redhat",
                    w=0.9, bh=0.62, lw=1.6, size=0.068)
    p.vip("{{GRAFANA_VIP}}:{{PORT_GRAFANA}}", 6.25, T + 2.82, 1.95, size=0.072)
    p.flow(lb1, g2, "", color=C_UI, s_side="r", d_side="t", via=[("x", 7.8), ("y", T + 0.42), ("x", 10.55)])
    p.flow(lb1, g1, "", color=RED, dashed=True)
    p.flow(g2, pg1, "{{PORT_POSTGRES}}", color=C_PG, s_side="bb", d_side="r", lsize=0.06, lfloat=True)
    p.flow(pg1, pg2, "réplication", color=C_PG, dashed=True, lsize=0.06, lfloat=True)
    p.rect(8.25, T + 2.8, 3.55, 1.0, fill=WHITE, line=C_UI, weight=0.012, rounding=0.05,
           text="Sessions et tableaux de bord dans PostgreSQL partagé\nL'utilisateur se reconnecte sur le VIP, même URL\n"
                "Pas d'état local indispensable", size=0.078)

    # Ingesters
    p.zone("Mimir / Loki / Tempo — perte d'un ingester", 12.1, T, 5.7, 4.15, C_STO, B_STO, net="{{STORE_NET}}")
    i1 = p.machine(12.5, T + 0.5, logo=["mimir", "loki", "tempo"], title="Ingester A", lines=["zone A · OK"], accent=OK,
                   badge="redhat", w=1.2, bh=0.7, lw=1.9, size=0.07)
    i2 = p.machine(14.55, T + 0.5, logo=["mimir", "loki", "tempo"], title="Ingester B", lines=["zone B · PANNE"], accent=RED,
                   badge="redhat", status="ko", w=1.2, bh=0.7, lw=1.9, size=0.07)
    i3 = p.machine(16.4, T + 0.5, logo=["mimir", "loki", "tempo"], title="Ingester C", lines=["zone C · OK"], accent=OK,
                   badge="redhat", w=1.2, bh=0.7, lw=1.4, size=0.07)
    p.rect(12.25, T + 1.95, 5.4, 1.15, fill=WHITE, line=C_STO, weight=0.012, rounding=0.05,
           text="Réplication d'ingestion (ex. RF=3, zone-aware)\nLes blocs non flushed sont sur d'autres ingesters\n"
                "Requêtes via query-frontend", size=0.085)
    p.rect(12.25, T + 3.25, 5.4, 0.55, fill=B_KAF, line=C_KAF, weight=0.012, rounding=0.05,
           text="Le tampon Kafka absorbe le surcroît le temps du rattrapage.", size=0.085)

    # passerelle
    p.zone("Passerelle OTel et Alertmanager", 0.2, T + 4.3, 8.65, 4.15, C_ING, B_ING, net="{{INGEST_NET}}")
    ag = p.machine(0.45, T + 4.85, logo="otel", title="Agents", lines=["ne voient que le VIP"], accent=C_ING, w=0.9, bh=0.62,
                   lw=1.5, size=0.068)
    vo = p.vip("{{OTEL_GW_FQDN}} · {{OTEL_GW_VIP}}", 2.1, T + 5.0, 2.6, size=0.07)
    o = []
    for i, (z, st, l2) in enumerate((("A", "ko", "PANNE"), ("B", None, "reçoit le trafic"), ("C", None, "actif"))):
        v = f"OTELGW0{i + 1}"
        o.append(p.machine(5.05 + i * 1.25, T + 4.75 + (0 if i != 1 else 0), logo="otel", title=f"otel-gw-0{i + 1}",
                           lines=[f"zone {z} · {l2}"], accent=RED if st else OK, badge="redhat", status=st, w=0.85, bh=0.6,
                           lw=1.22, size=0.068))
    p.flow(ag, vo, "", color=C_ING)
    p.flow(vo, o[1], "OTLP", color=C_ING, s_side="b", d_side="bb", via=[("y", T + 6.0)], lsize=0.065, lpos=(4.3, T + 6.0), lw=0.5)
    p.rect(0.35, T + 6.25, 8.35, 1.05, fill=WHITE, line=NAVY, weight=0.012, rounding=0.05,
           text="Les agents ne voient que le VIP : aucune reconfiguration.\nAlertmanager Mimir en cluster (gossip) : une instance perdue, "
                "les notifications continuent\n(éviter les doublons par le peering officiel).", size=0.08)
    p.rect(0.35, T + 7.45, 8.35, 0.75, fill=WARN_BG, line=WARN, weight=0.012, rounding=0.05,
           text="Surveillance de la supervision : lag Kafka, up des cibles, certificats, files d'export.", size=0.085, bold=True, color=WARN)

    # certificat expiré
    p.zone("Certificat expiré (scénario d'échec)", 9.0, T + 4.3, 8.8, 4.15, RED, "#FEF2F2")
    p.rect(9.15, T + 4.75, 8.5, 1.4, fill=WHITE, line=RED, weight=0.014, rounding=0.05,
           text="Symptôme : x509 certificate has expired ou handshake failure.\nImpact : otel-gw n'écrit plus vers ES, Grafana ne teste plus "
                "la source ES,\nles clients OTLP TLS refusent la passerelle.", size=0.085)
    p.rect(9.15, T + 6.3, 8.5, 1.9, fill=WHITE, line=NAVY, weight=0.014, rounding=0.05,
           text="Remède : renouveler le certificat (même SAN complet), déployer la chaîne,\nrestaurer le contexte SELinux, redémarrer le "
                "service, vérifier openssl s_client.\nPrévention : alerte à 30 jours, procédure de rotation testée en préprod.", size=0.085)
    footer(p, "Les bascules décrites sont des conceptions cibles. Les délais réels de rattrapage (LAG, flush d'ingester) doivent être mesurés "
              "en préprod — non testés à l'échelle de production dans ce document.")
    return p


# =====================================================================================
def d_scom_appd():
    p = Page("6 - Intégration SCOM 2019 et AppDynamics on-prem")
    header(p, "Intégration SCOM 2019 et AppDynamics on-premises dans la vue unique",
           "Contrôleur AppDynamics sur site ({{PORT_APPD_HTTPS}}) · SCOM 2019 (support étendu jusqu'au 10 avril 2029 PT) · Grafana corrèle, ne remplace pas")
    T = 0.86
    # SCOM
    p.zone("SCOM 2019 — console HTTPS {{PORT_SCOM_WEB}}", 0.2, T, 8.65, 4.7, C_SCOM, "#E0F2FE", tag="{{SCOM_VIP}}")
    scom = p.machine(0.45, T + 0.5, logo="microsoft", title=H("SCOM"), lines=["Operations Manager 2019"], accent=C_SCOM,
                     w=1.0, bh=0.72, lw=1.9, size=0.072)
    wag = p.machine(0.45, T + 1.95, logo="windows", title="Serveurs Windows", lines=["agents SCOM / journaux"], accent=C_SCOM,
                    count=3, w=1.0, bh=0.72, lw=1.9, size=0.072)
    p.text("Logo SCOM dédié non disponible :\nlogo Microsoft utilisé.", 0.35, T + 3.25, 2.1, 0.5, size=0.072, color=MUTED, italic=True)
    va = p.rect(2.5, T + 0.5, 1.95, 2.35, fill=WHITE, line=C_SCOM, weight=0.014, rounding=0.05,
                text="Voie A — journaux\n(recommandée)\nRécepteur OpenTelemetry\nofficiel windowseventlog\nou collecteur WEF\n→ VIP otel-gw\n→ otlp_logs → Loki / ES",
                size=0.078)
    vb = p.rect(4.55, T + 0.5, 1.95, 2.35, fill=WHITE, line=C_SCOM, weight=0.014, rounding=0.05,
                text="Voie B — métriques\nExportateur Prometheus\ncommunautaire OpsLogix\n(SCOM 2019+, AGPL-3.0)\nnon officiel Microsoft\nà qualifier → Mimir",
                size=0.078)
    vc = p.rect(6.6, T + 0.5, 2.1, 2.35, fill=WHITE, line=C_SCOM, weight=0.014, rounding=0.05,
                text="Voie C — API REST / SDK\nREST depuis 1801 ; UR1 : CSRF\nSDK / OMCF (docs Microsoft)\nGreffon Grafana tierce :\nà qualifier\nSQL des bases : pas de\nvoie principale",
                size=0.078)
    p.rect(2.5, T + 3.0, 6.2, 0.75, fill=WARN_BG, line=WARN, weight=0.012, rounding=0.05,
           text="Voie A : composants OpenTelemetry documentés (non testé ici).\nVoies B et C : communautaires ou à qualifier (licence, CSRF, charge SDK).",
           size=0.078)
    p.text("Support étendu jusqu'au 10 avril 2029 (heure du Pacifique) — planifier la migration vers une version en support standard.",
           0.35, T + 3.95, 8.3, 0.5, size=0.078, color=MUTED, italic=True)

    # AppD
    p.zone("AppDynamics on-premises — {{APPD_FQDN}}", 9.0, T, 8.8, 4.7, C_APPD, "#FEF2F2", tag="{{APPD_VIP}}")
    appd = p.machine(9.3, T + 0.5, logo="appd", title=H("APPD"), lines=["contrôleur sur site · HTTPS {{PORT_APPD_HTTPS}}"],
                     accent=C_APPD, w=1.2, bh=0.72, lw=2.3, size=0.072)
    fw = p.firewall(9.55, T + 2.05, 0.7, 0.42, label="HTTP {{PORT_APPD_HTTP}} : à bloquer")
    p.rect(11.75, T + 0.5, 5.9, 1.0, fill=WHITE, line=C_APPD, weight=0.014, rounding=0.05,
           text="Certificat de l'autorité interne, SAN = {{APPD_FQDN}}\nLDAP du contrôleur : AD LDAPS {{PORT_LDAPS}}, sAMAccountName,\ncompte local de secours",
           size=0.078, bold=True)
    v1 = p.rect(11.75, T + 1.65, 2.9, 1.65, fill=WHITE, line=C_APPD, weight=0.014, rounding=0.05,
                text="Voie 1 — greffon Grafana\ndlopes7-appdynamics-datasource\nEnterprise (licence requise)\nURL {{APPD_URL}}\nCA du contrôleur dans Grafana\nà vérifier on-prem (non testé)",
                size=0.075)
    v2 = p.rect(14.75, T + 1.65, 2.9, 1.65, fill=WHITE, line=C_APPD, weight=0.014, rounding=0.05,
                text="Voie 2 — OpenTelemetry\nTraces VERS le contrôleur\notlphttp + x-api-key\n{{APPD_OTEL_INGEST}}\n(à vérifier sur la version)\nPas un flux AppD → Tempo",
                size=0.075)
    p.rect(9.15, T + 3.45, 8.5, 0.75, fill=WARN_BG, line=WARN, weight=0.012, rounding=0.05,
           text="Sans licence Enterprise : lien vers {{APPD_URL}} et corrélation par service.name.", size=0.08)

    # vue unique
    p.zone("Vue unique Grafana — {{GRAFANA_FQDN}} (VIP {{GRAFANA_VIP}})", 0.2, T + 4.85, 17.6, 3.6, C_UI, B_UI)
    gw = p.machine(0.5, T + 5.35, logo="otel", title="otel-gw-01..03", lines=["VIP {{OTEL_GW_FQDN}}"], accent=C_ING, badge="redhat",
                   count=3, w=0.95, bh=0.68, lw=1.9, size=0.07)
    gr = p.machine(0.5, T + 6.75, logo="grafana", title="grafana-01, 02", lines=["vue unique"], accent=C_UI, badge="redhat", count=2,
                   w=0.95, bh=0.68, lw=1.9, size=0.07)
    def panel(x, logo, title, sub, col):
        p.rect(x, T + 5.3, 2.75, 2.0, fill=WHITE, line=col, weight=0.016, rounding=0.06)
        if logo == "appd":
            p.image(logo, x + 0.08, T + 5.6, 0.64, 0.64 / 4.0)
        else:
            p.image(logo, x + 0.1, T + 5.42, 0.55, 0.55)
        p.text(title, x + 0.75, T + 5.4, 1.95, 0.6, size=0.095, bold=True)
        p.text(sub, x + 0.12, T + 6.05, 2.55, 1.2, size=0.078, valign=0)
    panel(2.75, "grafana", "Santé LGTM", "lag, ingest, up", C_UI)
    panel(5.65, "mimir", "Métriques Mimir", "{{MIMIR_FQDN}}\n(+ SCOM si voie B)", C_STO)
    panel(8.55, "loki", "Journaux Loki / ES", "{{LOKI_FQDN}}\n(+ événements Windows)", "#C2410C")
    panel(11.45, "tempo", "Traces Tempo", "{{TEMPO_FQDN}}\n(apps instrumentées OTel)", "#1D4ED8")
    panel(14.35, "appd", "Panneau AppD", "{{APPD_FQDN}}:{{PORT_APPD_HTTPS}}\nou lien contrôleur", C_APPD)
    p.text("Préprod : même logique (noms préprod). Valeurs : variables/environnements.env.", 2.75, T + 7.5, 14.3, 0.4, size=0.08,
           color=MUTED, italic=True)

    # flux
    p.flow(wag, va, "OTLP {{PORT_OTEL_GRPC}}/{{PORT_OTEL_HTTP}}", color=C_ING, lsize=0.065, lpos=(2.5, wag.y + 1.25), lw=1.2)
    p.flow(va, gw, "", color=C_ING, s_side="b", d_side="r", via=[("y", T + 4.6), ("x", 2.6)])
    p.flow(gr, vc, "API REST (voie C)", color=C_SCOM, dashed=True, s_side="r", d_side="b", via=[("x", 2.55), ("y", T + 4.72), ("x", 7.65)],
           lsize=0.065, lpos=(5.2, T + 4.72), lw=1.1)
    p.flow(gr, v1, "HTTPS {{PORT_APPD_HTTPS}} (voie 1)", color=C_APPD, s_side="b", d_side="b",
           via=[("y", T + 8.25), ("x", 17.72), ("y", T + 3.38), ("x", 13.2)], lsize=0.065, lpos=(9.0, T + 8.25), lw=1.5)
    p.flow(gw, appd, "{{PORT_APPD_HTTPS}} /otis/ingest (voie 2)", color=C_APPD, dashed=True, s_side="t", d_side="l",
           via=[("y", T + 4.78), ("x", 8.93)], lsize=0.065, lpos=(9.9, T + 4.78), lw=1.7)
    p.flow(scom, (scom.anchor("r")[0] + 0.6, scom.y + 0.36), "", color=C_SCOM, arrow=False)
    footer(p, "Greffon AppDynamics = Enterprise (docs Grafana Labs). Exportateur SCOM = projet communautaire OpsLogix, non officiel Microsoft, "
              "SCOM 2019+. Cycle de vie SCOM 2019 : support étendu jusqu'au 10 avril 2029 PT. Non testé sur l'environnement réel.")
    return p


# =====================================================================================
def d_minio():
    p = Page("7 - Stockage objet — MinIO distribué (cible)")
    header(p, "Stockage objet du chemin chaud : MinIO distribué (cible retenue)",
           "ADR-002 accepté. STOCKAGE_OBJET_SCENARIO={{STOCKAGE_OBJET_SCENARIO}}. Quatre nœuds, erasure coding, TLS, IAM. Examen AGPLv3 : prérequis bloquant. Non testé.")
    T = 0.86
    p.rect(0.2, T, 17.6, 0.62, fill=OK_BG, line=OK, weight=0.014, rounding=0.06,
           text="Aucune installation avant conclusion écrite de l'examen de la licence AGPLv3 (ou offre commerciale). Contrôles : checklist §2.\n"
                "Plateforme S3 interne d'objet et d'archivage : rejetée pour le chemin chaud ; archivage à froid optionnel — page 8. HNAS seul et NFS : rejetés.",
           size=0.088, bold=True, color=OK)
    # clients S3
    p.zone("Clients S3 (stockage LGTM)", 0.2, T + 0.8, 3.3, 7.6, C_STO, B_STO, net="{{STORE_NET}}")
    cm = p.machine(0.85, T + 1.3, logo="mimir", title="Mimir", lines=["mimir-svc → {{S3_BUCKET_MIMIR}}"], accent=C_STO,
                   badge="redhat", count=3, w=1.0, bh=0.72, lw=2.9, size=0.075)
    cl = p.machine(0.85, T + 2.75, logo="loki", title="Loki", lines=["loki-svc → {{S3_BUCKET_LOKI}}"], accent=C_STO,
                   badge="redhat", count=3, w=1.0, bh=0.72, lw=2.9, size=0.075)
    ct = p.machine(0.85, T + 4.2, logo="tempo", title="Tempo", lines=["tempo-svc → {{S3_BUCKET_TEMPO}}"], accent=C_STO,
                   badge="redhat", count=3, w=1.0, bh=0.72, lw=2.9, size=0.075)
    bk = p.machine(0.85, T + 5.65, title="mc mirror", lines=["sauvegarde vers une cible distincte"], accent=WARN,
                   generic="mc\nmirror", w=1.0, bh=0.72, lw=2.9, size=0.075)
    p.firewall(3.62, T + 1.3, 0.24, 5.0, label="Pare-feu")

    # équilibrage
    p.zone("VIP S3", 4.0, T + 0.8, 3.4, 7.6, C_LB, B_LB, net="{{VIP_NET}}")
    vip = p.vip("{{S3_FQDN}} · {{S3_VIP}}", 4.12, T + 1.3, 3.16, size=0.075)
    lb1 = p.machine(4.4, T + 2.0, logo="haproxy", title=H("LB01"), lines=["zone A · maître"], accent=C_LB, badge="redhat", w=0.95,
                    bh=0.68, lw=1.45, size=0.07)
    lb2 = p.machine(5.95, T + 2.0, logo="haproxy", title=H("LB02"), lines=["zone B · secours"], accent=C_LB, badge="redhat",
                    w=0.95, bh=0.68, lw=1.45, size=0.07)
    p.flow(lb1, lb2, "VRRP", color=C_LB, dashed=True, both=True, lsize=0.06, lfloat=True)
    p.rect(4.15, T + 3.4, 3.1, 1.1, fill=WHITE, line=C_LB, weight=0.012, rounding=0.05,
           text="HAProxy + keepalived\nTLS · SAN = VIP + nœuds\nVIP :{{PORT_S3}} · API MinIO :{{MINIO_API_PORT}}", size=0.08, bold=True)
    p.rect(4.15, T + 4.65, 3.1, 1.1, fill=WHITE, line=C_SEC, weight=0.012, rounding=0.05,
           text="IAM / politiques\nmimir-svc · loki-svc · tempo-svc\npas le compte root", size=0.08, bold=True)

    # MinIO
    p.zone("MinIO distribué — erasure coding", 7.55, T + 0.8, 10.25, 7.6, C_OBJ, B_OBJ, net="{{OBJ_NET}}")
    ms = []
    for i, z in enumerate("ABCA"):
        v = f"MINIO0{i + 1}"
        ms.append(p.machine(7.95 + i * 2.45, T + 1.35, logo="minio", title=H(v), lines=[IP(v, z), "/data/minio"], accent=C_OBJ,
                            badge="redhat", w=1.1, bh=0.8, lw=2.3, size=0.075, props=rhel_props("MinIO distribué", v, z, "{{OBJ_NET}}")))
    for a_, b_ in ((0, 1), (1, 2), (2, 3)):
        p.flow(ms[a_], ms[b_], "", color=C_OBJ, both=True, dashed=True)
    p.text("Trafic inter-nœuds MinIO (même commande sur les 4 nœuds, {1...4})", 7.8, T + 2.75, 9.8, 0.3, size=0.08, color=C_OBJ,
           bold=True, align=1)
    p.rect(7.75, T + 3.25, 9.85, 1.0, fill=WHITE, line=C_SEC, weight=0.012, rounding=0.05,
           text="Erasure coding : jeux formés à l'initialisation, non modifiables ensuite · commande identique · {1...4} (trois points)\n"
                "Répertoires vides au premier démarrage · MINIO_ROOT_* dans EnvironmentFile 0600 · certificats /opt/minio/certs", size=0.08)
    p.rect(7.75, T + 4.4, 9.85, 1.0, fill=WHITE, line=NAVY, weight=0.012, rounding=0.05,
           text="Seaux : {{S3_BUCKET_MIMIR}} · {{S3_BUCKET_LOKI}} · {{S3_BUCKET_TEMPO}} · {{S3_BUCKET_ADMIN}}\n"
                "Supervision : métriques Prometheus (doc MinIO de la version) + journaux vers Loki", size=0.08)
    p.rect(7.75, T + 5.55, 9.85, 1.0, fill=WHITE, line="#326CE5", weight=0.012, rounding=0.05,
           text="Kubernetes : opérateur ou chart officiel, 4 pods, anti-affinité, cert-manager, Secret, NetworkPolicy.\n"
                "Quatre nœuds sur trois zones : deux nœuds en zone A (compromis d'erasure coding).", size=0.08)
    p.text("Console MinIO :{{MINIO_CONSOLE_PORT}} réservée à l'administration.", 7.8, T + 6.75, 9.8, 0.3, size=0.08, color=MUTED, italic=True)

    for c in (cm, cl, ct, bk):
        p.flow(c, vip, "", color=C_OBJ, via=[("x", 3.95)])
    p.text("HTTPS\n{{PORT_S3}}", 2.95, T + 1.3, 0.6, 0.35, size=0.07, bold=True, color=C_OBJ, align=1)
    p.flow(vip, lb1, "", color=C_LB, s_side="b", d_side="t")
    for m in ms:
        p.flow(lb2, m, "", color=C_OBJ, s_side="r", d_side="b", via=[("x", 7.45), ("y", T + 3.1)])
    p.text(":{{MINIO_API_PORT}}", 7.1, T + 3.12, 0.6, 0.22, size=0.07, bold=True, color=C_OBJ, align=1)
    footer(p, "Cible retenue (ADR-002). Procédures : Annexe_Stockage_objet_S3_MinIO.md et annexes C des runbooks. Licence AGPLv3 : prérequis "
              "bloquant. Non testé. Valeurs : variables/environnements.env.")
    return p


# =====================================================================================
def d_hitachi():
    p = Page("8 - Archivage à froid (optionnel) — plateforme S3 interne")
    header(p, "Archivage à froid (optionnel) : plateforme S3 interne d'objet et d'archivage",
           "ADR-002. Copies d'exports uniquement. Le chemin chaud LGTM reste sur MinIO (page 7). Produit non nommé : à confirmer. Non testé.")
    T = 0.86
    p.rect(0.2, T, 17.6, 0.85, fill=OK_BG, line=OK, weight=0.014, rounding=0.06,
           text="Rejetée pour le chemin chaud : l'offre exclut traitement intensif, modification fréquente et données personnelles ; "
                "ses options WORM / legal hold / rétention\nsont incompatibles avec le compactage Mimir / Loki / Tempo. "
                "Conservée pour déposer des copies d'exports sans données personnelles (usage conforme à l'offre).",
           size=0.088, bold=True, color=OK, align=0)
    # source
    p.zone("Source — plateforme LGTM", 0.2, T + 1.05, 5.6, 4.6, C_OBJ, B_OBJ, net="{{OBJ_NET}}")
    src = p.machine(0.5, T + 1.55, logo="minio", title="MinIO distribué", lines=["seau {{S3_BUCKET_ADMIN}} / exports"],
                    accent=C_OBJ, badge="redhat", count=4, w=1.0, bh=0.72, lw=2.3, size=0.072)
    exp = p.machine(3.1, T + 1.55, logo="redhat", title="Hôte d'export", lines=["systemd timer · aws s3 cp", "mc mirror sans --remove"],
                    accent=C_ADM, w=1.0, bh=0.72, lw=2.5, size=0.072)
    cj = p.machine(3.1, T + 3.0, logo="kubernetes", title="ou CronJob Kubernetes", lines=["même commande"], accent="#326CE5",
                   w=1.0, bh=0.72, lw=2.5, size=0.072)
    p.rect(0.35, T + 4.35, 5.3, 1.1, fill=WHITE, line=WARN, weight=0.012, rounding=0.05,
           text="Pas de journaux avec noms d'utilisateur / IP,\nni de sauvegarde PostgreSQL Grafana,\nsauf filtrage amont ou accord écrit",
           size=0.08)
    fw = p.firewall(5.95, T + 1.55, 0.26, 3.5, label="Pare-feu")

    # demande
    p.zone("Demande à l'équipe stockage", 6.4, T + 1.05, 5.0, 4.6, C_EX, B_EX)
    for i, (t_, h_) in enumerate((("1. Demande d'accès Inf-360", 0.55), ("2. Demande de compartiment\nmode standard, justification", 0.75),
                                  ("5 jours ouvrables\nlun–ven 8 h 30–16 h 30", 0.75), ("Produit à confirmer (ne pas affirmer HCP)", 0.6))):
        p.rect(6.6, T + 1.55 + [0, 0.7, 1.6, 2.5][i], 4.6, h_, fill=WHITE, line=C_EX, weight=0.012, rounding=0.05, text=t_,
               size=0.085, bold=i < 3)

    # cible
    p.zone("Compartiment d'archives", 11.55, T + 1.05, 6.25, 4.6, C_STO, B_STO)
    dst = p.machine(11.9, T + 1.55, title=H("ARCHIVE_S3"), lines=["bucket {{ARCHIVE_S3_BUCKET}}", "HTTPS 443 + CA ({{ARCHIVE_S3_CA_FILE}})"],
                    accent=C_STO, generic="S3\ninterne", count=3, w=1.1, bh=0.8, lw=5.6, size=0.075)
    p.rect(11.75, T + 3.25, 5.85, 1.0, fill=WHITE, line=C_STO, weight=0.012, rounding=0.05,
           text="Options selon la politique de conservation :\nrétention automatisée · legal hold · WORM (à définir)", size=0.08)
    p.rect(11.75, T + 4.4, 5.85, 0.9, fill=WHITE, line=NAVY, weight=0.012, rounding=0.05,
           text="Endpoint : {{ARCHIVE_S3_ENDPOINT}}\nclés en fichier 0600 · logo : produit non nommé (icône générique)", size=0.08)

    p.flow(src, exp, "", color=C_OBJ)
    p.flow(exp, dst, "HTTPS 443 · copies d'exports", color=C_STO, via=[("x", 6.3), ("y", T + 0.95), ("x", 11.7)],
           lpos=(9.0, T + 0.95), lw=1.9, lsize=0.075)
    p.flow(cj, (6.3, T + 0.95), "", color=C_STO, dashed=True, s_side="r", d_side="b", arrow=False)

    p.zone("Vigilance (si le produit s'avère être un HCP — à confirmer)", 0.2, T + 5.85, 17.6, 2.55, WARN, WARN_BG)
    p.text("Endpoint = FQDN du tenant ; authentification AWS : sans /hs3 (note officielle Hitachi) ; seau = espace de noms.\n"
           "DeleteObjects : pas de suppression d'objets sous rétention ou hold (attendu pour des archives).\n"
           "Cycle de vie S3 et politique de seau : non pris en charge sur HCP (matrice Hitachi). Multipart documenté.\n"
           "Qualifier le dépôt et une restauration en préprod.",
           0.4, T + 6.3, 17.2, 1.9, size=0.095, valign=0)
    footer(p, "Optionnel. Procédure : Annexe_Stockage_objet_Hitachi_HCP_S3.md (archivage à froid) et annexes D des runbooks. Non testé. "
              "Exemples fictifs. Valeurs : variables/environnements.env.")
    return p


def all_pages():
    return [d_archi_vm(), d_archi_k8s(), d_flux(), d_securite(), d_ha(), d_scom_appd(), d_minio(), d_hitachi()]


# =====================================================================================
FILENAMES = [
    "01_architecture_vm", "02_architecture_k8s", "03_flux_donnees", "04_flux_securite_auth",
    "05_topologie_ha", "06_integration_scom_appd", "07_stockage_objet_minio", "08_stockage_objet_hitachi",
]
VARS_FILE = HERE.parent.parent / "variables" / "environnements.env"
JETON = re.compile(r"\{\{([A-Z][A-Z0-9_]*)\}\}")


def lire_valeurs(env: str) -> dict:
    """Charge variables/environnements.env avec bash (même résolution que rendre-config.sh)."""
    import subprocess
    script = 'set -a; . "$1" >/dev/null; set +a; env -0'
    out = subprocess.run(["env", "-i", f"LGTM_ENV={env}", "PATH=/usr/bin:/bin", "bash", "--noprofile", "--norc", "-c",
                          script, "_", str(VARS_FILE)], capture_output=True, check=True).stdout
    vals = {}
    for item in out.split(b"\0"):
        if b"=" in item:
            k, _, v = item.partition(b"=")
            vals[k.decode()] = v.decode("utf-8", "replace")
    return vals


def remplaceur(vals: dict):
    from xml.sax.saxutils import escape as xesc
    manquants = set()

    def tr(data: bytes) -> bytes:
        def rep(m):
            n = m.group(1)
            if n == "NOM_VARIABLE":
                return m.group(0)
            if n not in vals:
                manquants.add(n)
                return m.group(0)
            return xesc(vals[n], {'"': "&quot;"})
        return JETON.sub(rep, data.decode("utf-8")).encode("utf-8")
    return tr, manquants


def rendre_png(page, png: Path, tr):
    import shutil
    import subprocess
    import tempfile
    soffice = shutil.which("soffice") or shutil.which("libreoffice")
    if not soffice:
        raise SystemExit("LibreOffice (soffice) introuvable : relancer avec --sans-png")
    with tempfile.TemporaryDirectory() as tmp:
        tmp = Path(tmp)
        v = tmp / f"{png.stem}.vsdx"
        write_vsdx(v, [page], page.name, transform=tr)
        filtre = 'png:draw_png_Export:{"PixelWidth":{"type":"long","value":"3600"},"PixelHeight":{"type":"long","value":"2025"}}'
        r = subprocess.run([soffice, "--headless", f"-env:UserInstallation=file://{tmp}/profil", "--convert-to", filtre,
                            "--outdir", str(tmp), str(v)], capture_output=True, text=True, timeout=300)
        out = tmp / f"{png.stem}.png"
        if not out.exists():
            raise SystemExit(f"échec du rendu LibreOffice pour {png.name} : {r.stdout} {r.stderr}")
        shutil.copy(out, png)


def main():
    import argparse
    ap = argparse.ArgumentParser(description="Diagrammes Visio LGTM (vue réseau, logos intégrés)")
    ap.add_argument("--env", default="prod", choices=["prod", "preprod"], help="valeurs utilisées pour les PNG")
    ap.add_argument("--sans-png", action="store_true", help="ne pas produire les PNG")
    ap.add_argument("--png-seulement", action="store_true", help="ne produire que les PNG (les .vsdx ne sont pas réécrits)")
    ap.add_argument("--valeurs", help="valeurs résolues en JSON (fournies par Actualiser-Variables.ps1) au lieu de bash")
    a = ap.parse_args()
    pages = all_pages()
    written = []
    if not a.png_seulement:
        written.append(write_vsdx(HERE / "00_lgtm_prod_tous_diagrammes.vsdx", pages,
                                  "Plateforme LGTM préprod/prod — tous les diagrammes"))
        for fn, pg in zip(FILENAMES, pages):
            written.append(write_vsdx(HERE / f"{fn}.vsdx", [pg], pg.name))
    if not a.sans_png:
        if a.valeurs:
            import json
            vals = json.loads(Path(a.valeurs).read_text(encoding="utf-8"))
        else:
            vals = lire_valeurs(a.env)
        tr, manquants = remplaceur(vals)
        for fn, pg in zip(FILENAMES, pages):
            png = HERE / f"{fn}.png"
            rendre_png(pg, png, tr)
            written.append(png)
        if manquants:
            print("variables non définies :", ", ".join(sorted(manquants)))
    print("écrit :")
    for w in written:
        print(f"  {w.name}  ({w.stat().st_size} octets)")


if __name__ == "__main__":
    main()
