# Architecture — Plateforme LGTM préproduction et production

Ce dossier décrit l'architecture cible de la plateforme d'observabilité LGTM
(Loki, Grafana, Tempo, Mimir) avec Kafka, OpenTelemetry Collector, intégration
Elasticsearch **8.19.0** protégé par ReadonlyREST **Enterprise 1.72.0**, authentification **LDAP** (mécanisme principal, Grafana OSS), vue unique,
et intégration logique de SCOM 2019 et d'AppDynamics on-premises.

Il est autonome : il ne suppose pas la lecture d'un autre runbook. Les deux
modes de déploiement (machines virtuelles RHEL 8 et Kubernetes) partagent
cette architecture logique.

## Contenu

| Document | Rôle |
|---|---|
| [01_Document_architecture.md](01_Document_architecture.md) | Vue d'ensemble, flux, matrice réseau, exigences non fonctionnelles |
| [02_Etude_impact.md](02_Etude_impact.md) | Impacts sur l'existant, risques, plan de transition |
| [adr/](adr/) | Décisions d'architecture (une par fichier, format ADR) |
| [diagrammes/](diagrammes/) | Fichiers Visio (`.vsdx`) éditables, aperçus PNG, générateur |
| [`../variables/`](../variables/) | DNS, VIP, plan d'adressage — **modifier ici seulement** |
| [annexes/Checklist_decision_stockage_objet.md](annexes/Checklist_decision_stockage_objet.md) | Décision prise : MinIO distribué ; contrôles avant installation ; questions archivage à froid |
| [annexes/Annexe_Stockage_objet_Hitachi_HCP_S3.md](annexes/Annexe_Stockage_objet_Hitachi_HCP_S3.md) | Archivage à froid (optionnel) — plateforme S3 interne d'objet et d'archivage |
| [annexes/Annexe_Stockage_objet_S3_MinIO.md](annexes/Annexe_Stockage_objet_S3_MinIO.md) | Stockage objet cible — MinIO distribué |
| Annexes B des runbooks | SSO Kerberos / OIDC (complément optionnel) |

## Décisions (ADR)

| ADR | Sujet |
|---|---|
| [ADR-001](adr/ADR-001_Kafka_tampon.md) | Kafka comme tampon |
| [ADR-002](adr/ADR-002_Stockage_objet.md) | Stockage objet : **MinIO distribué** (AGPLv3 à examiner avant installation) ; plateforme S3 interne rejetée pour le chemin chaud, archivage à froid optionnel ; NFS / HNAS rejetés |
| [ADR-003](adr/ADR-003_VM_vs_Kubernetes.md) | Deux réalisations : VM et Kubernetes |
| [ADR-004](adr/ADR-004_ROR_vs_XPack.md) | ReadonlyREST **Enterprise 1.72.0** (ES **8.19.0**) plutôt que X-Pack Security |
| [ADR-005](adr/ADR-005_Grafana_OSS_ACL_sync.md) | Grafana OSS + composant ACL |
| [ADR-006](adr/ADR-006_Authentification_LDAP.md) | LDAP / Active Directory — authentification **principale** |
| [ADR-007](adr/ADR-007_Strategie_PKI_certificats.md) | PKI, SAN, rotation |
| [ADR-008](adr/ADR-008_Integration_SCOM_AppDynamics.md) | SCOM 2019 et AppDynamics on-premises |
| [ADR-009](adr/ADR-009_Strategie_HA.md) | Haute disponibilité |
| [ADR-010](adr/ADR-010_Vue_one_screen.md) | Vue unique Grafana |
| [ADR-011](adr/ADR-011_SSO_Grafana_OSS.md) | SSO Grafana OSS — **complément optionnel** (annexe) |

## Diagrammes Visio

Fichier unique multi-pages : [`diagrammes/00_lgtm_prod_tous_diagrammes.vsdx`](diagrammes/00_lgtm_prod_tous_diagrammes.vsdx).

| Page | Visio | Aperçu |
|---|---|---|
| Architecture VM RHEL 8 | [01_architecture_vm.vsdx](diagrammes/01_architecture_vm.vsdx) | ![VM](diagrammes/01_architecture_vm.png) |
| Architecture Kubernetes | [02_architecture_k8s.vsdx](diagrammes/02_architecture_k8s.vsdx) | [PNG](diagrammes/02_architecture_k8s.png) |
| Flux de données | [03_flux_donnees.vsdx](diagrammes/03_flux_donnees.vsdx) | [PNG](diagrammes/03_flux_donnees.png) |
| Sécurité, LDAP, ROR, certificats | [04_flux_securite_auth.vsdx](diagrammes/04_flux_securite_auth.vsdx) | [PNG](diagrammes/04_flux_securite_auth.png) |
| Topologie HA et bascule | [05_topologie_ha.vsdx](diagrammes/05_topologie_ha.vsdx) | [PNG](diagrammes/05_topologie_ha.png) |
| Intégration SCOM et AppDynamics | [06_integration_scom_appd.vsdx](diagrammes/06_integration_scom_appd.vsdx) | [PNG](diagrammes/06_integration_scom_appd.png) |
| Stockage objet — MinIO distribué (cible) | [07_stockage_objet_minio.vsdx](diagrammes/07_stockage_objet_minio.vsdx) | [PNG](diagrammes/07_stockage_objet_minio.png) |
| Archivage à froid (optionnel) — plateforme S3 interne | [08_stockage_objet_hitachi.vsdx](diagrammes/08_stockage_objet_hitachi.vsdx) | [PNG](diagrammes/08_stockage_objet_hitachi.png) |

Les `.vsdx` sont des paquets OPC Visio 2013 (formes, groupes et connecteurs éditables). Chaque machine est une icône portant le logo officiel de son produit (images intégrées, provenance dans [`diagrammes/_logos/SOURCES.md`](diagrammes/_logos/SOURCES.md)) ; nom d'hôte, IP, zone et sous-réseau figurent aussi en données de forme. Les libellés sont des variables `{{NOM_VARIABLE}}`, remplacées dans la copie produite par [`../scripts/Actualiser-Variables.ps1`](../scripts/Actualiser-Variables.ps1). Les aperçus `.png` sont rendus depuis les mêmes `.vsdx` avec les valeurs de production d'exemple.

Contrôles : structure zip, XML bien formé, relations d'images présentes, ouverture par LibreOffice. Régénération (python3, bibliothèque standard ; LibreOffice pour les PNG) :

```bash
python3 diagrammes/_gen_visio.py                    # .vsdx + .png (valeurs prod)
python3 diagrammes/_gen_visio.py --env preprod --png-seulement
```

## Runbooks associés

- `../Runbook_LGTM_Prod_VM_RHEL8.md` — déploiement sur machines virtuelles
- `../Runbook_LGTM_Prod_Kubernetes.md` — déploiement Kubernetes
- `../scripts/` — composant `grafana_acl_sync`
- `../dashboards/one_screen_home.json` — tableau de bord d'accueil
