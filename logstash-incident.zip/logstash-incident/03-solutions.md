# 03 — Solutions et configurations

**Hôte :** SFPPRL17728  
**Version :** Logstash 8.19  
**Fuseau :** America/Toronto (UTC−5)

Les mots de passe ne figurent jamais en clair. Les placer dans le coffre-fort Logstash et les référencer par `${ES_PWD}`.

```bash
sudo -u logstash /usr/share/logstash/bin/logstash-keystore \
  --path.settings /etc/logstash add ES_PWD
```

Ensuite, dans la configuration : `password => "${ES_PWD}"`. La substitution du coffre-fort fonctionne dans `logstash.yml` et dans les fichiers de pipeline, pas dans `pipelines.yml`.

Le relais SMTP est indiqué comme `smtp.interne.local` port 25 : **remplacer** par l’adresse réelle du relais interne.

L’ordre d’implantation recommandé est dans [04-feuille-de-route.md](04-feuille-de-route.md).

---

## A. Court terme (Phase 0 et Phase 1)

### A.1 Procédure de récupération sûre

**Ne plus commencer par un `rm` du dossier de la file.** Un vidage jette les événements et efface les preuves.

1. **Pendant le blocage**, capturer les métriques et les journaux :

```bash
TS=$(date +%F-%H%M)
OUT=/var/tmp/logstash-incident-$TS
mkdir -p "$OUT"
curl -s 'http://localhost:9600/_node/stats/pipelines?pretty' > "$OUT/node-stats-pipelines.json"
curl -s 'http://localhost:9600/_node/stats?pretty' > "$OUT/node-stats.json"
sudo journalctl -u logstash --since "2 hours ago" > "$OUT/journal-logstash.txt"
sudo tail -n 5000 /var/log/logstash/logstash-plain.log > "$OUT/logstash-plain.tail.log"
# Côté ES, si accessible depuis cet hôte :
# curl -s -u revenu --cacert /etc/pki/ca-trust/source/anchors/ca-elasticsearch.pem \
#   'https://es-prod.gestion:9200/_cluster/health?pretty' > "$OUT/es-health.json"
```

2. **Copier la file avant toute réparation** (Logstash peut rester démarré pour la copie, puis on l’arrête) :

```bash
sudo cp -a /var/lib/logstash/data2/queue "$OUT/queue-copy"
```

3. **Arrêter Logstash proprement** et attendre l’arrêt complet.

```bash
sudo systemctl stop logstash
sudo systemctl is-active logstash   # doit répondre : inactive
```

4. **Diagnostiquer** avec `pqcheck` (outil officiel 8.19, depuis `LOGSTASH_HOME`) :

```bash
# Le sous-dossier porte le pipeline.id (en pratique « main » avec path.config actuel)
sudo -u logstash /usr/share/logstash/bin/pqcheck \
  /var/lib/logstash/data2/queue/main/
```

Si `pqcheck` signale une anomalie (par exemple `NOT FOUND` pour une page) ou si Logstash refuse de redémarrer à cause de la file :

```bash
sudo -u logstash /usr/share/logstash/bin/pqrepair \
  /var/lib/logstash/data2/queue/main/
```

`pqrepair` peut faire perdre les segments corrompus. Il n’y a pas de sortie si l’utilitaire s’exécute normalement. Il exige un droit d’écriture sur le dossier (d’où `sudo -u logstash`).

5. **Redémarrer** et vérifier que `events.out` reprend dans `_node/stats/pipelines`.

6. **Vidage manuel : dernier recours seulement**, après une copie `cp -a`, et seulement si `pqrepair` ne suffit pas ou si un lot bloquant doit être écarté en connaissance de cause (perte de données). Ne jamais supprimer la seule copie.

### A.2 Points à vérifier sur la VIP `es-prod.gestion`

Voir [ADR-004](adr/ADR-004-configuration-vip-load-balancer.md). En résumé :

| Réglage VIP | Cible |
| --- | --- |
| Délai d’inactivité / de réponse | **Strictement supérieur** à 120 s (ex. 180 s ou plus), puisque Logstash attend déjà 120 s |
| Persistance de session (sticky) | À désactiver, sauf justification : elle peut envoyer tous les `_bulk` sur un seul nœud |
| Health check | HTTP sur une API Elasticsearch (ex. `/_cluster/health` ou équivalent du fournisseur), pas seulement TCP/9200 |
| Limite de connexions par client | Suffisante pour le nombre actuel de sorties (~25 pools) ; sera moins critique après la sortie unique |

Garder un seul `hosts => ["https://es-prod.gestion:9200"]` est acceptable **une fois** la VIP validée. Lister les nœuds en dur n’est pas nécessaire si la VIP fait correctement son travail.

### A.3 Activation de la DLQ (Logstash 8.19)

Réglages officiels (`logstash.yml` ou, mieux, uniquement sur le pipeline principal dans `pipelines.yml`) :

```yaml
# /etc/logstash/logstash.yml  (extrait à ajouter)
dead_letter_queue.enable: true
dead_letter_queue.max_bytes: 1024mb
dead_letter_queue.storage_policy: drop_newer
dead_letter_queue.retain.age: 14d
# Optionnel : laisser le défaut, qui suit path.data
# path.dead_letter_queue: /var/lib/logstash/data2/dead_letter_queue
```

Notes officielles :

- `dead_letter_queue.enable` : désactivé par défaut.
- `dead_letter_queue.max_bytes` : taille maximale **par** file DLQ (défaut `1024mb`). Au-delà, des événements sont abandonnés selon `storage_policy`.
- `dead_letter_queue.storage_policy` : `drop_newer` (défaut) refuse les nouveaux événements ; `drop_older` supprime les plus anciens.
- `dead_letter_queue.retain.age` : pas d’unité par défaut, il **faut** la préciser (`d`, `h`, `m`, `s`). Exemple officiel : `2d`. Ici `14d` laisse le temps d’analyser.
- Chemin par défaut : `path.data/dead_letter_queue`, donc `/var/lib/logstash/data2/dead_letter_queue/<pipeline.id>`.
- La DLQ n’est pas supportée sur NFS.
- Codes pris en charge nativement par la sortie Elasticsearch : **400** et **404** (échecs par document dans une réponse `_bulk` HTTP 200). L’option `dlq_custom_codes` (liste de codes HTTP **additionnels**) existe, mais **ne doit pas** réutiliser 400, 404, les codes de succès ni 409. Elle **ne capture pas** les 429 / 5xx / délais d’attente : dans ces cas la requête HTTP entière est réessayée indéfiniment et la DLQ n’intervient pas. Ne pas ajouter `429` en pensant résoudre le présent incident.

Vérification après rechargement :

```bash
ls -l /var/lib/logstash/data2/dead_letter_queue/main/
curl -s 'http://localhost:9600/_node/stats/pipelines?pretty' \
  | python3 -c 'import json,sys; d=json.load(sys.stdin); print({k: v.get("dead_letter_queue") for k,v in d.get("pipelines",{}).items()})'
```

### A.4 Passage à `pipelines.yml` (pipeline principal + pipeline d’alerte DLQ)

Quand `pipelines.yml` est présent, c’est lui qui définit les pipelines (il remplace l’usage exclusif de `path.config` dans `logstash.yml`). Préparer le fichier, tester, puis recharger.

```yaml
# /etc/logstash/pipelines.yml
- pipeline.id: main
  path.config: "/etc/logstash/pipeline.global.conf"
  # Conserver la file persistante et la DLQ sur le pipeline d'ingestion seulement
  dead_letter_queue.enable: true
  dead_letter_queue.max_bytes: 1024mb
  dead_letter_queue.retain.age: 14d

- pipeline.id: dlq-alerte
  path.config: "/etc/logstash/conf.d/dlq-alerte.conf"
  pipeline.workers: 1
  pipeline.batch.size: 50
  dead_letter_queue.enable: false
```

Si `dead_letter_queue.enable` est aussi à `true` dans `logstash.yml`, le pipeline `dlq-alerte` pourrait hériter de l’activation globale. Préférer activer la DLQ **uniquement** sur `main` dans `pipelines.yml`, et laisser `dead_letter_queue.enable: false` (ou absent) au niveau global.

### A.5 Pipeline d’alerte courriel (relais SMTP interne)

Créer `/etc/logstash/conf.d/dlq-alerte.conf`. Le pipeline lit la DLQ de `main`, agrège pendant 15 minutes (`pipeline.workers` doit valoir 1 à cause du filtre `aggregate`) et envoie **un courriel résumé**, pas un courriel par événement.

```ruby
# /etc/logstash/conf.d/dlq-alerte.conf
# Logstash 8.19 — lecture de la DLQ du pipeline « main » et courriel résumé.
# Remplacer smtp.interne.local et les adresses courriel.

input {
  dead_letter_queue {
    path => "/var/lib/logstash/data2/dead_letter_queue"
    pipeline_id => "main"
    commit_offsets => true
    clean_consumed => false
  }
}

filter {
  ruby {
    code => '
      reason = ""
      begin
        reason = event.get("[@metadata][dead_letter_queue][reason]").to_s
      rescue
        reason = ""
      end
      event.set("[dlq][reason]", reason)
      idx = "inconnu"
      if reason =~ /_index["=>:\s]+([a-zA-Z0-9._-]+)/
        idx = $1
      elsif !event.get("[@metadata][_index]").nil?
        idx = event.get("[@metadata][_index]").to_s
      end
      event.set("[dlq][index]", idx)
    '
  }

  aggregate {
    task_id => "digest-dlq-main"
    code => "
      map['count'] ||= 0
      map['count'] += 1
      map['by_index'] ||= {}
      idx = event.get('[dlq][index]') || 'inconnu'
      map['by_index'][idx] ||= 0
      map['by_index'][idx] += 1
      map['exemples'] ||= []
      if map['exemples'].length < 8
        map['exemples'] << event.get('[dlq][reason]').to_s[0, 800]
      end
      event.cancel
    "
    timeout => 900
    timeout_tags => ["digest_dlq"]
    push_map_as_event_on_timeout => true
  }

  if "digest_dlq" in [tags] {
    ruby {
      code => '
        by = event.get("by_index") || {}
        lines = by.sort_by { |_, v| -v }.map { |k, v| "#{k}: #{v}" }
        event.set("resume_index", lines.join("\n"))
        ex = event.get("exemples") || []
        event.set("resume_exemples", ex.join("\n---\n"))
      '
    }
  }
}

output {
  if "digest_dlq" in [tags] {
    email {
      to => "observabilite@exemple.interne"
      from => "logstash-dlq@exemple.interne"
      subject => "DLQ Logstash SFPPRL17728 : %{count} événement(s) non indexé(s)"
      body => "Hôte : SFPPRL17728
Pipeline : main
Nombre d'événements dans la fenêtre : %{count}

Répartition par index :
%{resume_index}

Exemples de messages d'erreur :
%{resume_exemples}

La dead letter queue reste sur le disque
(/var/lib/logstash/data2/dead_letter_queue/main)
tant qu'elle n'est pas traitée ou nettoyée.
Les délais d'attente, 429 et 5xx ne passent PAS par la DLQ.
"
      address => "smtp.interne.local"
      port => 25
      via => "smtp"
      domain => "sfpprl17728"
      use_tls => false
    }
  }
}
```

Réglages officiels du plugin `email` utilisés ici : `to` (obligatoire), `from`, `subject`, `body`, `address` (serveur SMTP, défaut `localhost`), `port` (défaut 25), `via` (défaut `smtp`), `domain` (EHLO), `use_tls` (défaut `false`). Ajouter `username`, `password` et `authentication` seulement si le relais interne l’exige (mot de passe alors dans le coffre-fort, p. ex. `${SMTP_PWD}`).

`clean_consumed => false` au départ : les événements restent dans la DLQ pour analyse. Passer à `true` (officiel depuis 8.4, exige `commit_offsets => true`) une fois le processus de traitement rodée, pour libérer l’espace.

### A.6 Script de supervision de la file persistante

Ce script couvre ce que la DLQ ne couvre pas : file qui grossit, `SocketTimeout`, plus de connexions vivantes. À placer par exemple dans `/usr/local/sbin/alerte-queue-logstash.sh`, puis en tâche cron toutes les 5 minutes.

```bash
#!/bin/bash
# alerte-queue-logstash.sh — Logstash 8.19, API officielle _node/stats/pipelines
# Remplacer smtp.interne.local et les adresses.

set -euo pipefail

API="${API:-http://localhost:9600/_node/stats/pipelines}"
PIPELINE_ID="${PIPELINE_ID:-main}"
SEUIL_PCT="${SEUIL_PCT:-70}"
LOG="${LOG:-/var/log/logstash/logstash-plain.log}"
STATE_DIR="${STATE_DIR:-/var/tmp/logstash-alerte}"
SMTP_HOST="${SMTP_HOST:-smtp.interne.local}"
SMTP_PORT="${SMTP_PORT:-25}"
MAIL_TO="${MAIL_TO:-observabilite@exemple.interne}"
MAIL_FROM="${MAIL_FROM:-logstash-queue@exemple.interne}"
HOSTNAME_COURT="$(hostname -s)"

mkdir -p "$STATE_DIR"
JSON="$(curl -sf --max-time 10 "$API")" || {
  echo "Impossible de joindre $API" >&2
  exit 1
}

python3 - "$JSON" "$PIPELINE_ID" "$SEUIL_PCT" "$LOG" "$STATE_DIR" \
        "$SMTP_HOST" "$SMTP_PORT" "$MAIL_TO" "$MAIL_FROM" "$HOSTNAME_COURT" << 'PY'
import json, os, re, smtplib, sys, time
from email.message import EmailMessage
from pathlib import Path

raw, pipeline_id, seuil_pct, log_path, state_dir, smtp_host, smtp_port, mail_to, mail_from, host = sys.argv[1:]
seuil_pct = float(seuil_pct)
data = json.loads(raw)
p = data.get("pipelines", {}).get(pipeline_id)
if not p:
    sys.exit(f"Pipeline {pipeline_id} introuvable dans _node/stats")

q = p.get("queue") or {}
cap = q.get("capacity") or {}
size = cap.get("queue_size_in_bytes")
if size is None:
    size = q.get("queue_size_in_bytes") or 0
maxi = cap.get("max_queue_size_in_bytes") or 0
events = q.get("events_count", q.get("events"))
ev = p.get("events") or {}
flow = p.get("flow") or {}
backpressure = (flow.get("queue_backpressure") or {}).get("current")

pct = (100.0 * size / maxi) if maxi else 0.0
raison = []
if maxi and pct >= seuil_pct:
    raison.append(f"File persistante à {pct:.1f} % du maximum ({size} / {maxi} octets, seuil {seuil_pct:.0f} %).")
if backpressure not in (None, 0, 0.0):
    # signal d'accompagnement, pas un seuil officiel unique
    pass

# Signatures récentes dans le journal (2 minutes)
signatures = []
cutoff = time.time() - 120
try:
    # Le fichier peut être volumineux : on lit la fin seulement
    with open(log_path, "rb") as f:
        f.seek(0, os.SEEK_END)
        length = f.tell()
        f.seek(max(0, length - 512_000), os.SEEK_SET)
        tail = f.read().decode("utf-8", "replace")
    pat = re.compile(r"SocketTimeout|no living connections|Marking url as dead|HostUnreachableError", re.I)
    hits = [ln for ln in tail.splitlines() if pat.search(ln)]
    if hits:
        signatures = hits[-8:]
        raison.append(f"{len(hits)} occurrence(s) récente(s) de timeout / connexions mortes dans {log_path}.")
except FileNotFoundError:
    pass

if not raison:
    sys.exit(0)

# Anti-rafale : au plus un courriel par 30 minutes pour le même motif
key = Path(state_dir) / "last-alert"
now = time.time()
motif = " | ".join(raison)
if key.exists() and now - key.stat().st_mtime < 1800 and key.read_text(encoding="utf-8") == motif:
    sys.exit(0)

corps = f"""Alerte file persistante Logstash
Hôte : {host}
Pipeline : {pipeline_id}

{chr(10).join(raison)}

events.in={ev.get("in")}  events.out={ev.get("out")}  events_count={events}
queue_size_in_bytes={size}  max_queue_size_in_bytes={maxi}
queue_backpressure.current={backpressure}

Exemples de journaux :
{chr(10).join(signatures) if signatures else "(aucun extrait)"}

Ceci couvre les cas que la DLQ ne prend pas en charge (délai d'attente, 429, 5xx, VIP).
Ne pas vider la file : suivre la procédure de récupération sûre (copie, pqcheck, pqrepair).
"""
msg = EmailMessage()
msg["From"] = mail_from
msg["To"] = mail_to
msg["Subject"] = f"Alerte file Logstash {host} : {pct:.0f} % / timeout"
msg.set_content(corps)
with smtplib.SMTP(smtp_host, int(smtp_port), timeout=15) as s:
    s.send_message(msg)
key.write_text(motif, encoding="utf-8")
print("Courriel envoyé")
PY
```

```cron
# /etc/cron.d/alerte-queue-logstash
*/5 * * * * logstash /usr/local/sbin/alerte-queue-logstash.sh
```

Ajuster le propriétaire, le droit d’exécution (`chmod 0755`) et l’accès en lecture au journal. Tester en abaissant temporairement `SEUIL_PCT=1`.

---

## B. Moyen terme (Phase 2)

### B.1 Une seule sortie Elasticsearch (+ une pour les traces avec `document_id`)

Voir [ADR-001](adr/ADR-001-sortie-elasticsearch-unique.md). Principe :

- calculer `[@metadata][index]` **sans** le suffixe de date dans la section `filter` ;
- une sortie générique : `index => "%{[@metadata][index]}-%{+YYYY.MM.dd}"` ;
- une deuxième sortie, uniquement pour les traces GX, avec le même index et `document_id`.

Les préfixes ci-dessous reproduisent ce qui a été **observé**. Les branches dont le préfixe n’a pas été lu en entier sont marquées **À CONFIRMER** : les recopier depuis le `pipeline.global.conf` actuel avant toute mise en production. Ne pas inventer un nom d’index.

Les réglages SSL utilisent les noms officiels 8.19 (`ssl_enabled`, `ssl_certificate_authorities`). Le fichier actuel utilise `cacert` : valider le rechargement (`config.reload.automatic` est déjà à `true`, mais un changement de `pipelines.yml` demande typiquement un redémarrage).

```ruby
# /etc/logstash/pipeline.global.conf
# Logstash 8.19 — même routage et mêmes noms d'index, une sortie générique
# plus une sortie pour les traces GX (document_id).
# Mot de passe : coffre-fort Logstash, clé ES_PWD.
# À CONFIRMER : préfixes d'index des branches non entièrement transcrites.

input {
  beats {
    port => 5044
  }
}

filter {
  # Condition de drop observée : événements elastalert_status.
  # À CONFIRMER : le champ exact (type, tags, ou autre) utilisé aujourd'hui.
  if [type] == "elastalert_status" or "elastalert_status" in [tags] {
    drop { }
  }

  if "traces-gx-accept-api" in [tags] or "traces-gx-prod-api" in [tags] {
    fingerprint {
      method => "MURMUR3"
      # À CONFIRMER : recopier le bloc fingerprint actuel (source / key / target).
    }
  }

  # À CONFIRMER : recopier les mutate IIS (client / indexname) et la mise en minuscules
  # exactement tels qu'ils sont dans le fichier en production.
  mutate {
    lowercase => ["client", "indexname"]
  }

  # --- Calcul du nom d'index (sans le suffixe quotidien) ---
  # Motifs observés avec certitude :
  #   rq-sdf-cit-%{[indexname]}
  #   rq-ia-%{[client]}-%{[indexname]}
  #   rq-gx-accept-api
  #   un index 400 a visé rq-gv-graph-tech-intg-gv_graph-YYYY-MM-DD
  #
  # Clients / branches observés dans les if/else : iis (selon indexname / hôte),
  # nginx, gunicorn / ia-portail, daaas, ocean_bleu, ia-predictions, ia-dvc,
  # défaut, traces GX.

  if "traces-gx-accept-api" in [tags] {
    mutate { add_field => { "[@metadata][index]" => "rq-gx-accept-api" } }
    mutate { add_field => { "[@metadata][sortie]" => "traces" } }
  } else if "traces-gx-prod-api" in [tags] {
    # À CONFIRMER : le préfixe exact côté production (rq-gx-prod-api ou autre).
    mutate { add_field => { "[@metadata][index]" => "rq-gx-prod-api" } }
    mutate { add_field => { "[@metadata][sortie]" => "traces" } }
  } else if [client] == "iis" {
    # Observé comme exemple de préfixe IIS / CIT. À CONFIRMER s'il existe
    # plusieurs préfixes selon l'hôte ou l'indexname.
    mutate { add_field => { "[@metadata][index]" => "rq-sdf-cit-%{[indexname]}" } }
    mutate { add_field => { "[@metadata][sortie]" => "standard" } }
  } else if [client] == "nginx" {
    # À CONFIRMER : préfixe exact (ex. rq-…-%{[indexname]}).
    mutate { add_field => { "[@metadata][index]" => "À_CONFIRMER-nginx-%{[indexname]}" } }
    mutate { add_field => { "[@metadata][sortie]" => "standard" } }
  } else if [client] == "gunicorn" or [client] == "ia-portail" {
    mutate { add_field => { "[@metadata][index]" => "rq-ia-%{[client]}-%{[indexname]}" } }
    mutate { add_field => { "[@metadata][sortie]" => "standard" } }
  } else if [client] == "daaas" {
    # À CONFIRMER : préfixe exact.
    mutate { add_field => { "[@metadata][index]" => "À_CONFIRMER-daaas-%{[indexname]}" } }
    mutate { add_field => { "[@metadata][sortie]" => "standard" } }
  } else if [client] == "ocean_bleu" {
    # À CONFIRMER : préfixe exact.
    mutate { add_field => { "[@metadata][index]" => "À_CONFIRMER-ocean_bleu-%{[indexname]}" } }
    mutate { add_field => { "[@metadata][sortie]" => "standard" } }
  } else if [client] == "ia-predictions" or [client] == "ia-dvc" {
    mutate { add_field => { "[@metadata][index]" => "rq-ia-%{[client]}-%{[indexname]}" } }
    mutate { add_field => { "[@metadata][sortie]" => "standard" } }
  } else if [client] {
    # Branche par défaut observée : À CONFIRMER le motif exact.
    # Un 400 a ciblé rq-gv-graph-tech-intg-gv_graph-2026-11-16.
    mutate { add_field => { "[@metadata][index]" => "À_CONFIRMER-%{[client]}-%{[indexname]}" } }
    mutate { add_field => { "[@metadata][sortie]" => "standard" } }
  } else {
    mutate { add_field => { "[@metadata][index]" => "À_CONFIRMER-defaut" } }
    mutate { add_field => { "[@metadata][sortie]" => "standard" } }
  }
}

output {
  if [@metadata][sortie] == "traces" {
    elasticsearch {
      id => "es-traces-gx"
      hosts => ["https://es-prod.gestion:9200"]
      index => "%{[@metadata][index]}-%{+YYYY.MM.dd}"
      document_id => "%{fingerprint}"
      user => "revenu"
      password => "${ES_PWD}"
      ssl_enabled => true
      ssl_certificate_authorities => ["/etc/pki/ca-trust/source/anchors/ca-elasticsearch.pem"]
      ssl_verification_mode => "full"
      timeout => 120
      retry_initial_interval => 5
      retry_max_interval => 60
    }
  } else {
    elasticsearch {
      id => "es-sortie-unique"
      hosts => ["https://es-prod.gestion:9200"]
      index => "%{[@metadata][index]}-%{+YYYY.MM.dd}"
      user => "revenu"
      password => "${ES_PWD}"
      ssl_enabled => true
      ssl_certificate_authorities => ["/etc/pki/ca-trust/source/anchors/ca-elasticsearch.pem"]
      ssl_verification_mode => "full"
      timeout => 120
      retry_initial_interval => 5
      retry_max_interval => 60
    }
  }
}
```

Avant la bascule :

1. Recopier **toutes** les valeurs `index =>` et les conditions `if` du fichier actuel à la place des `À_CONFIRMER`.
2. Recopier le bloc `fingerprint` et les `mutate` IIS tels quels.
3. Tester : `/usr/share/logstash/bin/logstash --path.settings /etc/logstash --config.test_and_exit`.
4. Faire un essai sur un sous-ensemble (ou une fenêtre courte) et comparer les noms d’index produits avec ceux d’aujourd’hui.
5. Conserver le fichier actuel en copie.

`document_id => "%{fingerprint}"` suppose que le filtre écrit le champ `fingerprint` (comportement par défaut du plugin). Si le pipeline actuel utilise un autre champ cible, le recopier.

### B.2 Réduction des shards et ILM

Voir [ADR-003](adr/ADR-003-reduction-shards-ilm.md). **Ne pas appliquer de politique ILM avant d’avoir le compte réel de shards et la taille des index** (commandes en 02-probleme.md, section 4.2).

Lignes directrices, une fois les mesures en main :

- 1 shard primaire pour les flux dont l’index quotidien reste petit (beaucoup moins de 10 à 50 Go, ordre de grandeur usuel à ajuster selon le matériel).
- Pour ces petits flux, passer à un indice **mensuel** (`%{+YYYY.MM}`) ou à un data stream / un alias géré par ILM (rollover par taille primaire, p. ex. 30–50 Go, et par âge, p. ex. 30 jours), plutôt qu’un nouvel index tous les jours par client et par `indexname`.
- Éviter de multiplier les réplicas au-delà du besoin de résilience réel.
- Les noms d’index changent si l’on quitte le suffixe quotidien : planifier la mise à jour des alias, tableaux de bord et droits. Ce n’est pas un changement anodin ; le faire après la sortie unique, ou en parallèle seulement sur un sous-ensemble d’index.

Exemple de politique ILM (à adapter après mesure ; ne pas l’activer tel quel) :

```json
PUT _ilm/policy/rq-logs-standard
{
  "policy": {
    "phases": {
      "hot": {
        "actions": {
          "rollover": {
            "max_primary_shard_size": "40gb",
            "max_age": "30d"
          }
        }
      },
      "warm": {
        "min_age": "30d",
        "actions": { "readonly": {} }
      },
      "delete": {
        "min_age": "180d",
        "actions": { "delete": {} }
      }
    }
  }
}
```

Les durées de rétention ci-dessus sont des **placeholders**. Les remplacer par la politique de conservation réelle de l’organisation.

---

## C. Long terme (Phase 3)

- **Capacité Elasticsearch :** une fois la VIP validée, la sortie unique en place et le nombre de shards réduit, relire les journaux et les `_cat` aux heures typiques de blocage (vers 02:00). Traiter ce qui reste : heap / GC, taille du `thread_pool/write`, watermarks disque, fenêtres de snapshot, relocalisations.
- **Alertes Stack Monitoring ou Metricbeat :** taille de la file persistante, `queue_backpressure` / croissance de la file, échecs de sortie (`SocketTimeout`), taille de la DLQ (`pipelines.<id>.dead_letter_queue.queue_size_in_bytes`), rejets `thread_pool/write`. Le script de la section A.6 peut rester comme filet local.
- **Revue périodique** du nombre d’index `rq-*` et de shards, pour éviter que le schéma quotidien ne se réinstalle au fil des nouveaux clients.

---

## D. Ce qu’il ne faut pas faire

- Vider la file sans copie et sans `pqcheck`.
- Augmenter seulement `timeout` ou `queue.max_bytes` sans traiter la VIP, le nombre de sorties et les shards : on retarde l’incident, on ne le supprime pas.
- Compter sur la DLQ pour les `SocketTimeout`, 429 ou 5xx.
- Mettre en production le pipeline réécrit tant que les marqueurs **À CONFIRMER** n’ont pas été remplacés par les valeurs du fichier actuel.
