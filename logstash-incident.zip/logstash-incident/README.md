# Dossier d’incident — Logstash 8.19, file d’attente persistante

**Hôte :** SFPPRL17728  
**Version :** Logstash 8.19  
**Cluster cible :** `https://es-prod.gestion:9200` (VIP devant Elasticsearch)  
**Fuseau des horodatages :** America/Toronto (UTC−5)  
**Dernière mise à jour :** 16 novembre 2026

## Contexte en bref

Les données cessent d’arriver dans Elasticsearch. La file persistante (PQ) de Logstash **grossit sur le disque**. Un vidage du dossier de la file suivi d’un redémarrage rétablit temporairement l’ingestion. Le problème revient de plus en plus souvent. Au moment des blocages, les ressources de Logstash (processeur, mémoire, etc.) n’étaient **pas au pic**.

Les journaux du 16 novembre 2026 vers 02:00 (UTC−5) montrent des `Manticore::SocketTimeout` sur `https://es-prod.gestion:9200/_bulk`, l’URL marquée morte, puis `no living connections in the pool`. Des erreurs `status=>400` sur l’index `rq-gv-graph-tech-intg-gv_graph-2026-11-16` sont aussi présentes : elles font perdre des documents, mais ce n’est pas elles qui bloquent la file.

## Contenu du dossier

| Fichier | Rôle |
| --- | --- |
| [README.md](README.md) | Vue d’ensemble, index, état et prochaines étapes |
| [01-analyse.md](01-analyse.md) | Chronologie, preuves (journaux), configurations observées, raisonnement |
| [02-probleme.md](02-probleme.md) | Énoncé du problème, impact, hypothèses classées, validations encore en attente (commandes exactes) |
| [03-solutions.md](03-solutions.md) | Correctifs court / moyen / long terme, configuration concrète (pipeline réécrit, DLQ, courriel, script, ILM, VIP, récupération sûre) |
| [04-feuille-de-route.md](04-feuille-de-route.md) | Phases 0 à 3, priorités, dépendances, ADR liés, critères de validation, propriétaires et dates à remplir |
| [adr/ADR-001-sortie-elasticsearch-unique.md](adr/ADR-001-sortie-elasticsearch-unique.md) | Une seule sortie Elasticsearch (+ traces avec `document_id`) |
| [adr/ADR-002-activation-dlq.md](adr/ADR-002-activation-dlq.md) | Activation de la dead letter queue et courriel résumé |
| [adr/ADR-003-reduction-shards-ilm.md](adr/ADR-003-reduction-shards-ilm.md) | Réduction des shards et ILM |
| [adr/ADR-004-configuration-vip-load-balancer.md](adr/ADR-004-configuration-vip-load-balancer.md) | Réglages à vérifier sur la VIP `es-prod.gestion` |
| [adr/ADR-005-supervision-file-persistante.md](adr/ADR-005-supervision-file-persistante.md) | Supervision de la file persistante et alertes |

Les noms de réglages cités ont été vérifiés dans la documentation officielle Logstash 8.19 (file persistante, DLQ, plugin de sortie Elasticsearch, plugin `email`, API `_node/stats`, coffre-fort de secrets).

## État au 16 novembre 2026

**Établi**

- La file n’est pas corrompue : elle **grossissait**, ce qui indique que Logstash recevait des événements mais n’arrivait plus à les écrire vers Elasticsearch.
- Logstash lui-même n’était pas à court de ressources au moment du blocage.
- `timeout => 120` est déjà en place dans les sorties Elasticsearch : les délais d’attente viennent d’une réponse trop lente (Elasticsearch ou la VIP), pas d’un timeout Logstash resté à 60 s.
- Environ 25 blocs `elasticsearch { }` visent le même hôte VIP, chacun avec son propre pool de connexions.
- Les index sont quotidiens, par client et par `indexname`.
- La DLQ n’est pas activée. `queue.max_bytes` vaut 4096mb. `pipeline.batch.size` et `pipeline.workers` sont aux valeurs par défaut (125 événements, autant de travailleurs que de cœurs).
- La file a déjà été vidée pour cet incident : l’enquête se poursuit à partir des journaux.

**Encore en attente (ne pas traiter comme des faits)**

- Santé du cluster, occupation disque/heap, rejets du `thread_pool/write`, nombre de shards, blocs d’index en lecture seule.
- Journaux Elasticsearch autour de 02:00 le 16 novembre 2026 (GC, watermark, snapshot, relocalisation, etc.).
- Réglages réels de la VIP (délai d’inactivité, sticky, health check, limites de connexions).
- Comparaison de latence : appel via `es-prod.gestion` versus un nœud data en direct.
- Certains préfixes d’index du `pipeline.global.conf` n’ont été que partiellement transcrits ; ils sont marqués **À CONFIRMER** dans [03-solutions.md](03-solutions.md).

## Prochaines étapes

Suivre [04-feuille-de-route.md](04-feuille-de-route.md), Phase 0, dans cet ordre :

1. Adopter la procédure de récupération sûre (copie de la file, `pqcheck` / `pqrepair`, plus de vidage comme premier geste).
2. Récupérer les journaux Elasticsearch et le monitoring autour de 02:00 le 16 novembre 2026.
3. Lancer les commandes de validation du cluster et la comparaison VIP / nœud (listées dans [02-probleme.md](02-probleme.md)).
4. Ensuite seulement : VIP, DLQ, supervision (Phase 1), puis sortie unique et ILM (Phase 2).

Le mot de passe Elasticsearch n’apparaît nulle part en clair dans ce dossier. Utiliser le coffre-fort Logstash et la substitution `${ES_PWD}`.
