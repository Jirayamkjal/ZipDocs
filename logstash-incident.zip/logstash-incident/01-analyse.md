# 01 — Analyse de l’incident

**Hôte :** SFPPRL17728  
**Version :** Logstash 8.19  
**Fuseau :** America/Toronto (UTC−5)  
**Date de l’analyse :** 16 novembre 2026

## 1. Chronologie

Les heures ci-dessous sont en heure de Toronto (UTC−5). L’heure exacte du vidage de la file n’a pas été fournie ; le signal utile dans les journaux Logstash se situe **vers 02:00 le 16 novembre 2026**.

| Quand | Quoi | Source |
| --- | --- | --- |
| Avant le 16 novembre, de façon répétée | L’ingestion vers Elasticsearch s’arrête. La file persistante grossit sur le disque. Seul un vidage du dossier de la file + un redémarrage rétablit le flux. Le problème devient de plus en plus fréquent. | Constat d’exploitation |
| Pendant les blocages | Les ressources de Logstash (processeur, mémoire, etc.) ne sont pas au pic. | Constat d’exploitation |
| Vers 02:00, 16 novembre 2026 | Requêtes `_bulk` vers `https://es-prod.gestion:9200` : `Manticore::SocketTimeout`. Logstash marque l’URL comme morte, puis signale `no living connections in the pool`. Le même lot est réessayé. La file continue de grossir. | `logstash-plain.log` |
| Même période | Échecs d’indexation `status=>400` sur `rq-gv-graph-tech-intg-gv_graph-2026-11-16`, origine `172.31.66.108`. | `logstash-plain.log` |
| Après 02:00, heure de vidage non précisée | La file est vidée et Logstash est redémarré. L’ingestion reprend. | Constat d’exploitation |
| Après le vidage | Plus de file à inspecter. L’enquête se poursuit à partir des journaux et des validations encore à faire côté Elasticsearch et VIP. | Session de dépannage |

## 2. Preuves (extraits de journaux)

Les messages suivants ont été observés dans les journaux Logstash vers 02:00 le 16 novembre 2026. Le texte est reconstitué à partir des captures de la session ; ce n’est pas une copie ligne par ligne du fichier.

```
Marking url as dead ... HostUnreachableError
Elasticsearch Unreachable:
[https://es-prod.gestion:9200/_bulk?filter_path=errors,items.*.error,items.*.status]
[Manticore::SocketTimeout]

Attempted to send a bulk request but there are no living connections in the pool
(perhaps Elasticsearch is unreachable or down?)
No Available connections

Could not index event to Elasticsearch. status=>400 action index
_index rq-gv-graph-tech-intg-gv_graph-2026-11-16
```

Lecture de ces messages :

1. `Manticore::SocketTimeout` : la requête `_bulk` n’a pas reçu de réponse avant le délai de la sortie Elasticsearch, ici **120 secondes** (déjà configuré, ce n’est pas la valeur par défaut de 60 s).
2. Logstash marque alors `https://es-prod.gestion:9200` comme morte. Tant que le contrôle d’état ne la remet pas en service, les travailleurs voient `no living connections in the pool`.
3. Le même lot est renvoyé, expire à nouveau, et la boucle continue. Pendant ce temps, l’entrée Beats continue de remplir la file persistante.
4. Le vidage « règle » le symptôme parce qu’il jette le retard accumulé (et éventuellement le lot trop lent), pas parce qu’il corrige la cause.
5. Les `status=>400` sont des documents refusés (souvent un conflit de correspondance / *mapping*). Sans DLQ, ils sont perdus. Ils ne sont pas la cause du remplissage de la file : un 400 n’est pas réessayé indéfiniment de la même façon qu’un délai d’attente sur toute la requête `_bulk`.

**EN ATTENTE :** les journaux Elasticsearch des nœuds derrière la VIP, au même moment (chercher `watermark`, `read_only`, `rejected`, `circuit_breaking`, `GC overhead`, `master not discovered`, `node-left`, snapshots, relocalisation de shards). Aussi `journalctl -u logstash` (et le service Elasticsearch si accessible) autour de 02:00.

## 3. Configurations observées

### 3.1 `logstash.yml` (relevé sur SFPPRL17728)

| Réglage | Valeur observée | Commentaire |
| --- | --- | --- |
| `path.data` | `/var/lib/logstash/data2` | La file persistante se trouve donc par défaut sous `/var/lib/logstash/data2/queue` (sous-dossier du `pipeline.id`, en pratique `main`). |
| `path.config` | `/etc/logstash/pipeline.global.conf` | Un seul fichier de pipeline. |
| `path.logs` | `/var/log/logstash` | Journaux, dont `logstash-plain.log`. |
| `config.reload.automatic` | `true` | Rechargement automatique de la configuration. |
| `queue.type` | `persisted` | File persistante sur disque. |
| `queue.max_bytes` | `4096mb` | Jusqu’à 4 Go de retard peuvent s’accumuler avant que l’entrée ne bloque. Valeur par défaut officielle : `1024mb`. |
| `xpack.monitoring` | activé vers `https://es-prod.gestion:9200`, utilisateur `revenu` | Monitoring envoyé au même cluster / à la même VIP. |
| `pipeline.ecs_compatibility` | `disabled` | Valeur par défaut officielle de 8.19 également `disabled`. |
| `pipeline.batch.size` | non défini | Défaut officiel : **125** événements par lot. |
| `pipeline.workers` | non défini | Défaut officiel : un travailleur par cœur processeur. |
| `dead_letter_queue.enable` | absent / non activé | Défaut officiel : `false`. Les 400 sont donc perdus. |

`path.queue` n’a pas été vu comme étant redéfini : le chemin effectif à retenir est `/var/lib/logstash/data2/queue/<pipeline.id>`.

### 3.2 Pipeline `/etc/logstash/pipeline.global.conf` (relevé)

**Entrée**

- `beats { }` sur le port **5044**.

**Filtres (tels qu’observés)**

- Suppression des événements `elastalert_status` (`drop`).
- `fingerprint` avec la méthode **MURMUR3** pour les étiquettes `traces-gx-accept-api` et `traces-gx-prod-api`.
- `mutate` sur `client` / `indexname` pour IIS, et mise en minuscules.

**Sortie**

- Environ **25** blocs `elasticsearch { }` dans une arborescence `if` / `else` sur `[client]`, notamment : IIS (selon `indexname` / hôte), nginx, gunicorn / ia-portail, daaas, ocean_bleu, ia-predictions, ia-dvc, un cas par défaut, plus les traces GX avec `document_id` (empreinte).
- Tous les blocs pointent vers le **même** hôte : `https://es-prod.gestion:9200`.
- Paramètres communs observés : vérification SSL, `cacert => "/etc/pki/ca-trust/source/anchors/ca-elasticsearch.pem"`, utilisateur `revenu`, `timeout => 120`, `retry_initial_interval => 5`, `retry_max_interval => 60`.

**Noms d’index observés (quotidiens)**

- `rq-sdf-cit-%{[indexname]}-%{+YYYY.MM.dd}`
- `rq-ia-%{[client]}-%{[indexname]}-%{+YYYY.MM.dd}`
- `rq-gx-accept-api-%{+YYYY.MM.dd}`
- Un événement 400 a ciblé `rq-gv-graph-tech-intg-gv_graph-2026-11-16` (donc un motif du type préfixe + `indexname` + date quotidienne).

D’autres préfixes existent dans les ~25 branches et n’ont pas tous été transcrits mot à mot. Ils sont marqués **À CONFIRMER** dans la configuration proposée.

**Note 8.19 sur SSL :** la documentation officielle de la sortie Elasticsearch recommande `ssl_enabled => true` et `ssl_certificate_authorities`. Le fichier actuel utilise `cacert`. La réécriture proposée adopte les noms officiels 8.19, en conservant le même certificat.

### 3.3 Elasticsearch et la VIP

- `es-prod.gestion` est une **VIP de répartition de charge** devant le cluster Elasticsearch. Ce n’est pas un nœud unique.
- Un seul nom d’hôte dans `hosts` est donc cohérent avec cette architecture, mais la VIP elle-même peut couper ou concentrer le trafic (voir [02-probleme.md](02-probleme.md) et [ADR-004](adr/ADR-004-configuration-vip-load-balancer.md)).
- Compte, rôles et charge des nœuds : **EN ATTENTE** (`_cluster/health`, `_cat/nodes`, etc.).

## 4. Raisonnement

1. **Ce que le symptôme exclut.** Une file corrompue (page ou point de contrôle illisible) se manifeste plutôt par un Logstash qui démarre mais ne lit plus la file, ou par une taille de file stable avec peu de fichiers `page.*`. Ici la file **grossissait** : Logstash écrivait bien dans la PQ, et le goulot était en **sortie**.
2. **Ce que les ressources Logstash excluent.** L’absence de pic processeur / mémoire / GC côté Logstash écarte, pour cet incident, un pipeline saturé par des filtres trop lents ou un manque de ressources locales. Le lot par défaut (125) n’est pas non plus un lot géant.
3. **Ce que les journaux établissent.** La sortie n’obtient pas de réponse `_bulk` en 120 s via la VIP. Logstash déclare l’URL morte et réessaie le même lot. Pendant les retries, la file de 4 Go peut absorber des heures de retard sans signal d’alarme (aucune supervision de la taille de file n’est en place).
4. **Deux suspects restent ouverts pour expliquer la lenteur des `_bulk`.**
   - **Elasticsearch lent ou qui refuse les écritures** (heap / GC, rejets du pool `write`, disque au watermark, trop de shards, rollover ILM, snapshot ou autre tâche vers 02:00). Non vérifié : pas encore de journaux ni de `_cat` du cluster.
   - **La VIP** : délai d’inactivité souvent à 60 s par défaut (inférieur au `timeout` 120 s de Logstash), sessions persistantes qui envoient tout le trafic sur un seul nœud, health check TCP seulement, plafond de connexions (aggravé par ~25 pools). Non vérifié : réglages VIP inconnus ; pas encore de comparaison de latence VIP vs nœud direct.
5. **Ce qui aggrave la charge, même si ce n’est pas le déclencheur unique.**
   - ~25 sorties Elasticsearch = ~25 pools et autant de flux `_bulk` vers la même VIP, souvent avec de petits lots.
   - Un index par client, par `indexname` et par jour : croissance rapide du nombre d’index et de shards, cause classique de `_bulk` lents. Hypothèse forte, pas encore mesurée.
6. **Pourquoi le vidage « corrige ».** Il jette le retard et interrompt la boucle de retry. Il ne change ni la VIP, ni le nombre de sorties, ni le nombre de shards. Le problème revient.
7. **Les 400 sont un problème distinct.** Ils doivent aller dans une DLQ et déclencher un courriel. Ils ne doivent pas être confondus avec la cause du blocage.

## 5. Ce qui n’est pas établi

- La cause précise de la lenteur des `_bulk` à 02:00 (ES, VIP, ou les deux).
- Le nombre réel de shards et l’état de santé du cluster.
- Les réglages du répartiteur `es-prod.gestion`.
- L’heure exacte du vidage de la file.
- Le contenu complet, ligne par ligne, de toutes les branches `if` / `else` du pipeline.
