# 02 — Problème, impact, hypothèses et validations

**Hôte :** SFPPRL17728  
**Version :** Logstash 8.19  
**Fuseau :** America/Toronto (UTC−5)

## 1. Énoncé du problème

L’ingestion Logstash vers Elasticsearch s’interrompt de façon répétée. Les événements s’accumulent dans la file persistante sur disque (`queue.type: persisted`, `queue.max_bytes: 4096mb`, chemin par défaut `/var/lib/logstash/data2/queue`). L’entrée Beats (port 5044) continue d’alimenter la file. La sortie n’arrive plus à envoyer les lots `_bulk` à `https://es-prod.gestion:9200` dans le délai configuré de 120 secondes (`Manticore::SocketTimeout`), l’URL est marquée morte, puis Logstash signale l’absence de connexion disponible et réessaie le même lot.

Le seul remède utilisé jusqu’ici — vider le dossier de la file et redémarrer Logstash — rétablit le flux mais jette le retard accumulé. Le phénomène devient de plus en plus fréquent. Il se produit alors que Logstash n’est pas à court de ressources.

Un problème distinct et parallèle : des documents sont refusés avec `status=>400` (exemple : index `rq-gv-graph-tech-intg-gv_graph-2026-11-16`). Sans dead letter queue, ces documents sont perdus et aucun courriel n’est envoyé.

## 2. Impact

| Impact | Détail |
| --- | --- |
| Perte de données à chaque « correction » | Le vidage de la file jette les événements non encore écrits dans Elasticsearch. |
| Perte silencieuse des documents invalides | Les erreurs 400/404 ne sont ni mises de côté ni signalées (DLQ désactivée). |
| Retard d’observabilité | Tant que la file n’est pas pleine (jusqu’à 4 Go), l’ingestion peut être arrêtée en sortie pendant longtemps sans alerte. |
| Récurrence | Le correctif actuel ne touche pas la cause ; les incidents se rapprochent. |
| Charge opérationnelle | Interventions manuelles (vidage, redémarrage) sur SFPPRL17728, sans procédure de conservation des preuves. |

## 3. Hypothèses de cause, classées

Les niveaux de confiance reflètent uniquement les preuves de cette session. Une confiance élevée signifie « établi par les journaux ou la configuration » ; une confiance moyenne signifie « mécanisme plausible et aggravant, pas encore mesuré ».

### H1 — Les requêtes `_bulk` expirant après 120 s déclenchent une boucle de retry qui remplit la file

**Confiance : élevée.**

Les journaux du 16 novembre 2026 vers 02:00 (UTC−5) montrent la séquence complète : `Manticore::SocketTimeout` sur `/_bulk`, `Marking url as dead`, `no living connections in the pool`, puis nouvel essai. C’est le mécanisme direct du symptôme (file qui grossit, déblocage par vidage). Ce n’est pas encore l’explication de *pourquoi* le `_bulk` est lent.

### H2 — Elasticsearch est trop lent ou refuse les écritures à ce moment-là

**Confiance : moyenne** (cause typique, **non mesurée** ici).

Un `_bulk` qui dépasse 120 s pointe souvent vers le cluster : GC / heap, rejets du `thread_pool/write`, watermark disque ou index en lecture seule, trop de shards, relocalisation, rollover ILM, snapshot ou tâche planifiée (l’heure 02:00 est compatible avec une fenêtre de maintenance). Rien de tout cela n’a encore été confirmé. Les commandes de la section 4 sont faites pour trancher.

### H3 — La VIP `es-prod.gestion` coupe, retarde ou concentre le trafic

**Confiance : moyenne** (architecture confirmée, réglages **inconnus**).

`es-prod.gestion` est une VIP, pas un nœud. Un délai d’inactivité inférieur à 120 s (souvent 60 s par défaut) suffit à provoquer un `SocketTimeout` côté Logstash alors qu’Elasticsearch est encore en train de répondre. D’autres réglages aggravants : persistance de session (tout le trafic sur un seul nœud), health check TCP seulement, plafond de connexions par client (plus probable avec ~25 pools). À valider par les réglages du répartiteur et par une comparaison de latence VIP vs nœud direct.

### H4 — Les ~25 sorties Elasticsearch multiplient les requêtes `_bulk` et les connexions

**Confiance : moyenne à élevée** comme **facteur aggravant**, pas comme seul déclencheur.

Chaque bloc `elasticsearch { }` a son propre pool et son propre flux `_bulk` vers la même VIP. Cela multiplie les connexions et les petits lots, ce qui alourdit Elasticsearch et se heurte plus vite à d’éventuelles limites de la VIP. La taille de lot par défaut (125) n’est pas excessive ; c’est surtout le *nombre* de sorties qui pèse.

### H5 — L’explosion du nombre de shards (index quotidiens par client et par `indexname`) ralentit les écritures

**Confiance : moyenne** (schéma d’indexation confirmé, **compte de shards non fait**).

Les motifs du type `rq-…-%{[indexname]}-%{+YYYY.MM.dd}` et `rq-ia-%{[client]}-%{[indexname]}-%{+YYYY.MM.dd}` créent beaucoup d’index, souvent trop petits pour justifier un shard primaire (et des réplicas) par jour. Un cluster trop fragmenté devient lent à écrire. C’est une cause classique, à confirmer par `_cat/shards` et la taille réelle des index.

### H6 — La file de 4 Go et l’absence d’alerte masquent le problème jusqu’à ce qu’il soit grave

**Confiance : élevée** comme facteur d’impact, pas comme cause du timeout.

`queue.max_bytes: 4096mb` est volontairement large. Sans supervision de `queue_size_in_bytes` ni alerte sur `SocketTimeout`, le retard peut grossir longtemps. Ce n’est pas ce qui déclenche le timeout, mais c’est ce qui le rend coûteux.

### H7 — File persistante corrompue

**Confiance : faible**, écartée pour *cet* incident.

Une corruption (arrêt brutal, disque plein, point de contrôle illisible) n’explique pas une file qui **grossit**. Elle reste possible lors d’un futur arrêt brutal : d’où `pqcheck` / `pqrepair` dans la procédure de récupération, plutôt qu’un `rm` immédiat.

### H8 — Manque de ressources sur le processus Logstash

**Confiance : faible**, écartée pour *cet* incident par le constat d’exploitation (ressources pas au pic). À revoir seulement si un prochain incident montre un pic processeur, une heap saturée ou un GC excessif sur SFPPRL17728.

### Ce que la DLQ ne résoudra pas

D’après la documentation officielle Logstash 8.19, la DLQ intercepte les échecs **par document** renvoyés dans une réponse `_bulk` réussie au niveau HTTP, typiquement les codes **400** et **404**. Si la requête HTTP elle-même échoue (cluster injoignable, délai d’attente, 429, 5xx), la sortie Elasticsearch **réessaie la requête indéfiniment** et la DLQ n’a pas l’occasion d’intervenir. Les erreurs 400 observées iront dans la DLQ une fois activée ; la boucle de `SocketTimeout` exige la supervision de la file, la VIP et la performance d’écriture d’Elasticsearch.

## 4. Validations en attente

Exécuter de préférence **pendant un blocage**. Sinon, les lancer maintenant et conserver les sorties, puis les relancer au prochain incident **avant** tout vidage de file. Remplacer `ES_PWD` par le mot de passe (idéalement déjà dans le coffre-fort) ; ne pas le laisser dans l’historique si possible.

Authentification : utilisateur `revenu`, URL `https://es-prod.gestion:9200`. Ajuster le certificat si `curl` le demande (`--cacert /etc/pki/ca-trust/source/anchors/ca-elasticsearch.pem`).

### 4.1 Santé et charge du cluster — EN ATTENTE

```bash
curl -s -u revenu -k --cacert /etc/pki/ca-trust/source/anchors/ca-elasticsearch.pem \
  'https://es-prod.gestion:9200/_cluster/health?pretty'

curl -s -u revenu --cacert /etc/pki/ca-trust/source/anchors/ca-elasticsearch.pem \
  'https://es-prod.gestion:9200/_cat/nodes?v&h=name,heap.percent,cpu,disk.used_percent,node.role,uptime'

curl -s -u revenu --cacert /etc/pki/ca-trust/source/anchors/ca-elasticsearch.pem \
  'https://es-prod.gestion:9200/_cat/allocation?v'

curl -s -u revenu --cacert /etc/pki/ca-trust/source/anchors/ca-elasticsearch.pem \
  'https://es-prod.gestion:9200/_cat/thread_pool/write?v&h=node_name,active,queue,rejected'
```

À regarder : état `red`/`yellow`, heap et disque élevés, `rejected` croissant sur le pool `write`.

### 4.2 Blocs d’index et nombre de shards — EN ATTENTE

```bash
curl -s -u revenu --cacert /etc/pki/ca-trust/source/anchors/ca-elasticsearch.pem \
  'https://es-prod.gestion:9200/_all/_settings/index.blocks*?pretty'

curl -s -u revenu --cacert /etc/pki/ca-trust/source/anchors/ca-elasticsearch.pem \
  'https://es-prod.gestion:9200/_cat/shards?h=index,shard,prirep,state,docs,store,node' \
  | tee /tmp/shards-$(date +%F).txt

# Résumé : nombre de shards et d'index
awk 'NF{s++} END{print "shards:", s}' /tmp/shards-$(date +%F).txt
curl -s -u revenu --cacert /etc/pki/ca-trust/source/anchors/ca-elasticsearch.pem \
  'https://es-prod.gestion:9200/_cat/indices?h=index,pri,rep,docs.count,store.size,pri.store.size' \
  | grep -E '^rq-' | sort
```

À regarder : `index.blocks.read_only` / `read_only_allow_delete` (watermark), un très grand nombre de petits index `rq-*-YYYY.MM.dd`.

### 4.3 Comparaison de latence VIP vs nœud direct — EN ATTENTE

Remplacer `<IP_NOEUD_ES>` par l’adresse d’un nœud data (obtenue via `_cat/nodes` ou l’inventaire). Lancer les deux appels à quelques secondes d’intervalle, idéalement pendant un ralentissement.

```bash
curl -s -u revenu --cacert /etc/pki/ca-trust/source/anchors/ca-elasticsearch.pem \
  -w '\nVIP time_total=%{time_total}s http=%{http_code}\n' \
  -o /dev/null \
  'https://es-prod.gestion:9200/_cluster/health'

curl -s -u revenu --cacert /etc/pki/ca-trust/source/anchors/ca-elasticsearch.pem \
  -w '\nNOEUD time_total=%{time_total}s http=%{http_code}\n' \
  -o /dev/null \
  --resolve es-prod.gestion:9200:<IP_NOEUD_ES> \
  'https://es-prod.gestion:9200/_cluster/health'
```

Un écart important en faveur du nœud direct oriente vers la VIP (ou vers un nœud saturé encore présent dans le pool de la VIP).

### 4.4 Journaux Elasticsearch et système autour de 02:00 — EN ATTENTE

Adapter le chemin du journal de cluster (`/var/log/elasticsearch/<cluster>.log`) et l’heure si le vidage n’était pas en matinée.

```bash
# Sur les nœuds Elasticsearch, autour de 02:00 le 16 novembre 2026 (UTC-5)
grep -E '2026-11-16T0[123]' /var/log/elasticsearch/*.log \
  | grep -Ei 'watermark|read_only|rejected|circuit_breaking|GC overhead|master not discovered|node-left|snapshot|allocation|flood'

# Sur SFPPRL17728
sudo journalctl -u logstash --since "2026-11-16 00:00" --until "2026-11-16 06:00"
```

Les journaux Logstash utiles ont déjà été vus ; les conserver dans l’archive d’incident :

```bash
grep -E '^\[2026-11-16T(00|01|02|03|04|05):' /var/log/logstash/logstash-plain.log \
  | grep -Ei 'warn|error|retry|429|block|bulk|SocketTimeout|living connections|status=>400'
```

### 4.5 Réglages de la VIP — EN ATTENTE

À obtenir auprès de l’équipe réseau / équilibreur (voir [ADR-004](adr/ADR-004-configuration-vip-load-balancer.md)) :

- délai d’inactivité et délai de réponse (doivent être **supérieurs** à 120 s, avec marge) ;
- persistance de session (sticky) : activée ou non, et sur quel nœud les connexions de SFPPRL17728 aboutissent ;
- nature du health check (TCP au port 9200 seulement, ou HTTP sur une API Elasticsearch) ;
- limite de connexions par client / par membre.

### 4.6 Métriques Logstash à capturer **pendant** le prochain blocage, avant toute intervention

```bash
curl -s 'http://localhost:9600/_node/stats/pipelines?pretty'
```

Champs utiles (documentation officielle de l’API Node Stats 8.19) :

- `pipelines.<id>.events.in` / `.out` / `.filtered`
- `pipelines.<id>.flow.output_throughput` et `queue_backpressure`
- `pipelines.<id>.queue.events_count`
- `pipelines.<id>.queue.queue_size_in_bytes` (et, selon la vue, `queue.capacity.queue_size_in_bytes` / `max_queue_size_in_bytes`)

Puis copier la file **avant** tout vidage :

```bash
sudo cp -a /var/lib/logstash/data2/queue /var/tmp/queue-backup-$(date +%F-%H%M)
```

### 4.7 Préfixes d’index à confirmer

Recopier depuis `/etc/logstash/pipeline.global.conf` toutes les valeurs `index =>` des branches non entièrement transcrites (IIS par hôte / `indexname`, nginx, gunicorn / ia-portail, daaas, ocean_bleu, ia-predictions, ia-dvc, défaut, traces GX). Sans cette liste, la bascule vers une sortie unique (Phase 2) ne doit pas être mise en production.
