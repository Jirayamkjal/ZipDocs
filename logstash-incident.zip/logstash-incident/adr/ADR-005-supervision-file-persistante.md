# ADR-005 — Supervision de la file persistante

- **Statut :** Proposé
- **Date :** 16 novembre 2026
- **Hôte concerné :** SFPPRL17728 (Logstash 8.19)
- **Liens :** [03-solutions.md](../03-solutions.md), [04-feuille-de-route.md](../04-feuille-de-route.md) (items 1.4 et 3.2)

## Contexte

`queue.type: persisted` et `queue.max_bytes: 4096mb` permettent jusqu’à 4 Go de retard sur disque (chemin par défaut `/var/lib/logstash/data2/queue`). Il n’y a pas d’alerte sur la taille de cette file ni sur les `SocketTimeout`. Lors des incidents, la file grossit longtemps ; on ne s’en rend compte que lorsque l’ingestion vers Elasticsearch a déjà cessé, et le remède utilisé est le vidage.

La DLQ (ADR-002) **ne signale pas** ces cas : d’après la documentation 8.19, un échec de la requête HTTP (`SocketTimeout`, 429, 5xx, VIP qui coupe) est réessayé indéfiniment, sans passage par la DLQ. Il faut donc un canal d’alerte distinct.

L’API officielle `GET http://localhost:9600/_node/stats/pipelines` expose, pour chaque pipeline, les événements `in`/`out`, le flux (`queue_backpressure`, `output_throughput`, croissance de la file) et la taille de la file persistante (`queue_size_in_bytes` / capacité maximale). La taille de la DLQ est exposée dans `pipelines.<id>.dead_letter_queue.queue_size_in_bytes`.

Stack Monitoring est déjà alimenté (`xpack.monitoring` vers la même VIP, utilisateur `revenu`). La présence d’alertes prêtes à l’emploi n’a **pas été vérifiée**.

## Décision

1. **Court terme :** déployer sur SFPPRL17728 le script décrit dans [03-solutions.md](../03-solutions.md#a6-script-de-supervision-de-la-file-persistante), exécuté périodiquement (ex. toutes les 5 minutes), qui :
   - interroge `_node/stats/pipelines` ;
   - envoie un courriel via le relais interne (`smtp.interne.local:25` à remplacer) si la file dépasse un seuil (ex. 70 % de 4096mb) ou si le journal récent contient `SocketTimeout` / `Marking url as dead` / `no living connections` ;
   - applique un anti-rafale (ex. un courriel par 30 minutes pour le même motif).
2. Le courriel rappelle de **ne pas vider la file** et de suivre la procédure de récupération sûre (copie, `pqcheck`, `pqrepair`).
3. **Moyen / long terme :** créer des alertes équivalentes dans Stack Monitoring (ou Metricbeat, si c’est l’outil en place — **à confirmer**), incluant aussi la taille de la DLQ et les rejets `thread_pool/write` côté Elasticsearch. Le script local peut demeurer comme filet si le monitoring central passe par la même VIP et devient lui-même indisponible pendant un incident.
4. Ne pas baisser `queue.max_bytes` uniquement pour « avoir une alerte plus tôt » : l’alerte doit précéder la saturation, et les 4 Go restent une réserve utile pendant un ralentissement *court* une fois les causes traitées. Réévaluer la taille seulement après quelques semaines de métriques.

## Conséquences

**Positives**

- Signal avant que 4 Go de données ne soient en jeu, y compris pour les pannes que la DLQ ne voit pas.
- Pendant un incident, on peut encore capturer `_node/stats` et copier la file au lieu de la jeter.
- Peu de dépendance à un changement du pipeline d’ingestion.
- Filet local si le monitoring central est lui-même impacté par la VIP ou le cluster.

**Négatives / risques**

- Dépendance au relais SMTP et à cron / à un minuteur sur l’hôte (le script doit tourner même si Logstash est saturé en sortie ; l’API 9600 doit rester joignable localement).
- Faux positifs possibles au démarrage (file qui se remplit un instant) : d’où le seuil à 70 % et l’anti-rafale, à ajuster.
- Le script ne répare rien : une alerte ignorée reproduira le même cycle.
- `xpack.monitoring` emprunte la VIP : pendant un incident identique, les alertes centralisées peuvent arriver en retard. D’où le maintien du script local.

## Alternatives considérées

- **S’en remettre uniquement à la DLQ / au courriel d’erreur 400.** Ne couvre pas le présent incident. Rejetée comme seule mesure.
- **Alertes Stack Monitoring seulement, dès maintenant.** Souhaitable, mais la disponibilité et le paramétrage des alertes ne sont pas confirmés, et le monitoring transite par la même VIP. Conservé comme Phase 3, pas comme seul filet immédiat.
- **Réduire `queue.max_bytes` pour que l’entrée Beats s’arrête plus tôt.** Cela rend le problème visible d’une autre façon (les producteurs bloquent) et augmente le risque de perte en amont, sans donner un diagnostic. Rejetée comme substitut à une vraie alerte.
- **Superviser seulement la taille disque du dossier `queue`.** Simple, mais moins précis que l’API (pas d’`events.in`/`out`, pas de `queue_backpressure`). Peut servir de complément, pas de source unique.
