# ADR-003 — Réduction des shards et ILM

- **Statut :** Proposé
- **Date :** 16 novembre 2026
- **Hôte / cible :** cluster derrière la VIP `es-prod.gestion`, alimenté par Logstash 8.19 sur SFPPRL17728
- **Liens :** [03-solutions.md](../03-solutions.md), [04-feuille-de-route.md](../04-feuille-de-route.md) (items 0.3, 2.2, 3.3)

## Contexte

Les sorties actuelles créent des index **quotidiens**, **par client** et **par `indexname`**, par exemple :

- `rq-sdf-cit-%{[indexname]}-%{+YYYY.MM.dd}`
- `rq-ia-%{[client]}-%{[indexname]}-%{+YYYY.MM.dd}`
- `rq-gx-accept-api-%{+YYYY.MM.dd}`

Un échec 400 a aussi visé `rq-gv-graph-tech-intg-gv_graph-2026-11-16`. Avec une vingtaine de branches et un nouveau couple client / `indexname`, le nombre d’index (donc de shards primaires et de réplicas) grimpe vite. Un cluster trop fragmenté est une cause classique de requêtes `_bulk` lentes, compatibles avec les `Manticore::SocketTimeout` de 120 s observés le 16 novembre 2026 vers 02:00 (UTC−5).

**Cette cause n’est pas encore mesurée.** Le nombre de shards, la taille des index `rq-*` et l’état de santé du cluster sont **en attente** (commandes dans [02-probleme.md](../02-probleme.md)). Cette ADR propose une direction, pas un paramétrage chiffré définitif.

## Décision

1. **Mesurer d’abord** : `_cluster/health`, `_cat/shards`, `_cat/indices` (taille primaire, nombre de documents), nombre total de shards par nœud, présence de `index.blocks.read_only*`.
2. Pour les flux dont l’index quotidien est petit, viser **1 shard primaire** et une cadence de rollover plus lente :
   - soit un suffixe **mensuel** (`%{+YYYY.MM}`) là où le volume le permet ;
   - soit un alias / data stream géré par **ILM**, avec rollover par taille de shard primaire et par âge (valeurs à fixer après mesure ; un ordre de grandeur courant est 30–50 Go et 30 jours, à confirmer selon le matériel et la rétention réelle).
3. Ne pas appliquer une politique de suppression ou de rétention inventée : les durées d’exemple dans [03-solutions.md](../03-solutions.md) sont des **placeholders**.
4. Faire ce travail **après** ou en étroit parallèle avec la sortie unique (ADR-001), et seulement sur un sous-ensemble d’index pour commencer, car un changement de motif d’index impacte alias, tableaux de bord et droits.
5. Instituer une revue périodique du nombre d’index `rq-*` et de shards (Phase 3) pour éviter que de nouveaux clients ne reproduisent le schéma quotidien fragmenté.

## Conséquences

**Positives**

- Moins de shards à suivre pour le maître et moins de fichiers à ouvrir pour chaque `_bulk`, donc de meilleures écritures si l’hypothèse se confirme.
- Index mieux dimensionnés, rétention et passage au tiède / suppression plus prévisibles une fois ILM en place.
- Moins d’erreurs de *mapping* « un index par petite source par jour » mal initialisés (bénéfice collatéral possible, non garanti).

**Négatives / risques**

- Changement de nom d’index (mensuel ou rollover ILM) : rupture des motifs `*-YYYY.MM.dd` consommés par Kibana, droits, ILM déjà existant (**existence non vérifiée**).
- Un rollover mal dimensionné peut créer l’effet inverse (index trop gros ou trop nombreux). D’où l’obligation de mesurer avant.
- Travail côté cluster (modèles d’index, politiques, alias) qui dépasse Logstash et demande une fenêtre de changement.
- Ne résout pas à elle seule une VIP qui coupe les connexions avant 120 s (ADR-004).

## Alternatives considérées

- **Rester en index quotidiens et seulement fixer `number_of_shards: 1`.** Déjà utile, mais le nombre d’index continue de croître chaque jour et pour chaque `indexname`. Insuffisant à long terme si le catalogue de clients est large. Peut servir de première étape.
- **Tout regrouper dans un seul index quotidien.** Simplifie les shards au maximum, mais mélange des schémas potentiellement incompatibles (le 400 sur `rq-gv-graph-tech-intg-…` rappelle que les mappings divergent). Rejetée comme approche globale.
- **Augmenter les ressources du cluster sans toucher au schéma.** Peut être nécessaire (Phase 3) mais coûteux et fragile si les shards continuent d’exploser. Complément, pas substitut.
- **Appliquer tout de suite l’exemple ILM du guide sans mesure.** Rejeté : trop d’inconnues (volume, rétention, ILM déjà présent).
