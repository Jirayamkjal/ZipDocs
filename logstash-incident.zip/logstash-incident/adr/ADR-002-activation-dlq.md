# ADR-002 — Activation de la dead letter queue et courriel d’alerte

- **Statut :** Proposé
- **Date :** 16 novembre 2026
- **Hôte concerné :** SFPPRL17728 (Logstash 8.19)
- **Liens :** [03-solutions.md](../03-solutions.md), [04-feuille-de-route.md](../04-feuille-de-route.md) (items 1.2 et 1.3)

## Contexte

La dead letter queue n’est pas activée. Lors de l’incident du 16 novembre 2026, des événements ont été refusés avec `status=>400` sur l’index `rq-gv-graph-tech-intg-gv_graph-2026-11-16` (source 172.31.66.108). Sans DLQ, ces documents sont perdus et personne n’est avisé.

Ces 400 ne sont **pas** la cause du remplissage de la file persistante (celle-ci vient des `SocketTimeout` sur la requête `_bulk` entière). Il s’agit d’un second problème, fréquent dès qu’il existe des conflits de correspondance (*mapping*) sur des index nombreux et typés par client.

La documentation officielle Logstash 8.19 indique clairement les limites : la DLQ de la sortie Elasticsearch reçoit les échecs par document, typiquement **400** et **404**. Si la requête HTTP échoue (cluster injoignable, délai d’attente, 429, 5xx), la sortie **réessaie indéfiniment** et la DLQ n’intervient pas. Un courriel DLQ ne remplace donc pas la supervision de la file (ADR-005).

Un relais SMTP interne est disponible ; l’adresse exacte n’est pas encore fournie (marqueur `smtp.interne.local:25`).

## Décision

1. Activer la DLQ sur le pipeline d’ingestion `main` uniquement, avec les réglages officiels 8.19 :
   - `dead_letter_queue.enable: true`
   - `dead_letter_queue.max_bytes: 1024mb` (défaut officiel ; à hausser seulement si besoin)
   - `dead_letter_queue.storage_policy: drop_newer` (défaut)
   - `dead_letter_queue.retain.age: 14d` (unité obligatoire : `d`/`h`/`m`/`s`)
   - chemin par défaut sous `path.data` : `/var/lib/logstash/data2/dead_letter_queue/main`
2. Ne **pas** compter sur `dlq_custom_codes` pour les 429 ou les délais d’attente. Cette option ajoute des codes **en plus** de 400 et 404 ; elle ne doit pas réutiliser 400, 404, les codes de succès ni 409 ; elle ne change pas le comportement de retry de la requête HTTP entière.
3. Introduire un second pipeline `dlq-alerte` dans `pipelines.yml` qui lit la DLQ avec le plugin d’entrée officiel `dead_letter_queue` (`path` = répertoire de premier niveau, `pipeline_id => "main"`, `commit_offsets => true`).
4. Envoyer un **courriel résumé** (agrégation, ex. toutes les 15 minutes) via le plugin officiel `email` et le relais interne, contenant au minimum l’index visé, le nombre d’événements et des exemples de message d’erreur. Un courriel par événement est exclu.
5. Laisser `clean_consumed` à `false` au départ, pour conserver les événements le temps d’analyser les 400. Le passer à `true` plus tard si l’espace disque l’exige (`clean_consumed` exige `commit_offsets => true`, fonction officielle depuis 8.4).

La configuration complète est dans [03-solutions.md](../03-solutions.md#a3-activation-de-la-dlq-logstash-819).

## Conséquences

**Positives**

- Les documents invalides ne sont plus silencieusement perdus.
- Un courriel groupé donne l’index et l’erreur, ce qui permet de corriger un *mapping* ou un producteur (ex. `rq-gv-graph-tech-intg-…`) sans noyer la boîte de réception.
- Le pipeline principal n’est plus tenté de « vivre avec » des 400 non traités ; la file persistante n’est pas le bon endroit pour ces documents.

**Négatives / risques**

- Espace disque supplémentaire sous `path.data` (plafond `1024mb` par pipeline, plus la rétention 14 jours). À surveiller (`pipelines.main.dead_letter_queue.queue_size_in_bytes`).
- Introduction de `pipelines.yml` : ce fichier devient la source des pipelines et doit déclarer explicitement `main` (aujourd’hui défini via `path.config`). Un oubli arrêterait l’ingestion.
- Fausse impression de sécurité si l’on croit que la DLQ arrête les `SocketTimeout`. Elle ne le fera pas.
- Dépendance au relais SMTP et aux adresses à confirmer.
- Le filtre `aggregate` impose `pipeline.workers: 1` sur `dlq-alerte`.

## Alternatives considérées

- **Sortie `file` ou index Elasticsearch « erreurs » sans courriel.** Utile en complément, mais ne répond pas à la demande d’avis immédiat. Non retenue comme seul canal.
- **Un courriel par événement.** Simple à configurer, inacceptable en volume dès qu’un *mapping* casse un flux entier. Rejetée.
- **Réindexer automatiquement depuis la DLQ vers Elasticsearch.** Dangereux tant que la cause du 400 n’est pas corrigée (boucle). La réindexation reste une action manuelle, après correction.
- **Utiliser `dlq_custom_codes` pour y mettre les 429.** Inopérant selon le fonctionnement officiel du plugin (retry de la requête HTTP). Rejetée.
