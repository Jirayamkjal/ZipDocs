# ADR-001 — Sortie Elasticsearch unique

- **Statut :** Proposé
- **Date :** 16 novembre 2026
- **Hôte concerné :** SFPPRL17728 (Logstash 8.19)
- **Liens :** [03-solutions.md](../03-solutions.md), [04-feuille-de-route.md](../04-feuille-de-route.md) (item 2.1)

## Contexte

Le pipeline `/etc/logstash/pipeline.global.conf` contient environ 25 blocs `elasticsearch { }` dans une arborescence `if` / `else` sur `[client]` (IIS selon `indexname` / hôte, nginx, gunicorn / ia-portail, daaas, ocean_bleu, ia-predictions, ia-dvc, branche par défaut, plus les traces GX). Tous visent le même hôte, la VIP `https://es-prod.gestion:9200`, avec les mêmes paramètres de sécurité et de délai (`timeout => 120`, `retry_initial_interval => 5`, `retry_max_interval => 60`).

Chaque bloc possède son propre pool de connexions et envoie ses propres requêtes `_bulk`. Cela multiplie les connexions vers la VIP et le nombre de lots, souvent petits, que le cluster doit absorber. Lors de l’incident du 16 novembre 2026 vers 02:00 (UTC−5), les `_bulk` ont expiré après 120 s et la file persistante a grossi.

Les traces GX (`traces-gx-accept-api`, `traces-gx-prod-api`) utilisent un `fingerprint` MURMUR3 et un `document_id` : elles ne peuvent pas passer par la sortie générique sans ce paramètre.

Plusieurs préfixes d’index n’ont été que partiellement transcrits depuis les captures. Ils doivent être recopiés depuis le fichier en production avant la bascule.

## Décision

1. Calculer le nom d’index (sans le suffixe de date) dans la section `filter`, champ `[@metadata][index]`, en conservant les mêmes conditions de routage et les mêmes préfixes qu’aujourd’hui.
2. Remplacer les ~25 sorties par **deux** blocs seulement :
   - une sortie standard : `index => "%{[@metadata][index]}-%{+YYYY.MM.dd}"` ;
   - une sortie traces GX : le même motif d’index, avec `document_id` (champ produit par `fingerprint`).
3. Conserver un seul `hosts => ["https://es-prod.gestion:9200"]`, la cible étant une VIP (voir ADR-004).
4. Utiliser les noms de réglages SSL officiels de Logstash 8.19 (`ssl_enabled`, `ssl_certificate_authorities`, `ssl_verification_mode`) et le coffre-fort pour le mot de passe (`${ES_PWD}`).
5. Ne mettre en production qu’après remplacement de tous les marqueurs **À CONFIRMER** et un `--config.test_and_exit`.

La configuration proposée est dans [03-solutions.md](../03-solutions.md#b1-une-seule-sortie-elasticsearch--une-pour-les-traces-avec-document_id).

## Conséquences

**Positives**

- Un ou deux pools de connexions au lieu d’environ 25, donc moins de pression sur la VIP et sur le `thread_pool/write` d’Elasticsearch.
- Lots `_bulk` potentiellement mieux remplis (un seul flux au lieu de nombreux petits flux).
- Configuration plus courte, plus simple à superviser (`id` de plugin unique) et à faire évoluer (un nouvel index se décide dans `filter`, pas par un nouveau bloc de sortie).
- Compatible avec la DLQ (ADR-002) : les 400/404 d’une seule sortie aboutissent au même endroit.

**Négatives / risques**

- Erreur de transcription d’un préfixe d’index : les événements partiraient vers un mauvais index. Mitigé par la recopie systématique des `index =>` actuels et par un essai contrôlé.
- Deux sorties restent nécessaires pour `document_id`, donc deux pools — c’est acceptable et nettement inférieur à 25.
- Un changement de configuration sur un pipeline de production : s’appuyer sur `config.test_and_exit`, une copie du fichier actuel, et une fenêtre de bascule.
- Cette décision **ne corrige pas à elle seule** une VIP trop impatiente ni un cluster saturé de shards (ADR-003, ADR-004).

## Alternatives considérées

- **Garder 25 sorties et augmenter `timeout` / `queue.max_bytes`.** Écarte le symptôme, aggrave le retard caché, ne réduit pas la charge. Rejetée comme correctif permanent.
- **Une seule sortie même pour les traces, sans `document_id`.** Casserait la déduplication / l’identité des documents traces. Rejetée.
- **Plusieurs pipelines Logstash (un par client) chacun avec une sortie.** Isolerait les files, mais multiplierait encore les pools vers la même VIP et complexifierait l’exploitation. Non retenue pour l’instant.
- **Lister les nœuds data dans `hosts` au lieu de la VIP.** Possible en secours si la VIP est en cause (ADR-004), mais ce n’est pas le levier principal de cette décision et cela contourne la redondance voulue par la VIP.
