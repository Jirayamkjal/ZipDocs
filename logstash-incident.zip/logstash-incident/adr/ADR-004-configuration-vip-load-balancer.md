# ADR-004 — Configuration de la VIP (répartiteur) `es-prod.gestion`

- **Statut :** Proposé
- **Date :** 16 novembre 2026
- **Composant :** VIP `es-prod.gestion:9200` devant le cluster Elasticsearch, utilisée par Logstash 8.19 sur SFPPRL17728
- **Liens :** [03-solutions.md](../03-solutions.md), [04-feuille-de-route.md](../04-feuille-de-route.md) (items 0.3 et 1.1)

## Contexte

Toutes les sorties Elasticsearch (et le monitoring X-Pack) pointent vers `https://es-prod.gestion:9200`. Il a été confirmé que **`es-prod.gestion` est une VIP** : la redondance des nœuds est déjà assurée derrière le répartiteur. Lister tous les nœuds dans `hosts` n’est donc pas un prérequis.

En revanche, un `Manticore::SocketTimeout` sur `/_bulk` avec `timeout => 120` déjà en place peut venir **du répartiteur** autant que d’Elasticsearch. Les réglages de la VIP n’ont **pas encore été relevés**. Les points suivants sont des suspects typiques, pas des faits établis sur cet équilibreur :

- délai d’inactivité ou de réponse inférieur à 120 s (souvent 60 s par défaut), qui coupe le `_bulk` pendant qu’Elasticsearch travaille encore ;
- persistance de session (sticky) qui envoie toutes les connexions de SFPPRL17728 vers un seul nœud, lequel sature ;
- health check TCP uniquement, qui laisse dans le pool un nœud lent ou en pause GC ;
- plafond de connexions par client, plus facile à atteindre avec ~25 pools de sorties.

Une comparaison de latence VIP versus nœud data en direct, pendant un ralentissement, est **en attente**.

## Décision

1. **Conserver** `hosts => ["https://es-prod.gestion:9200"]` comme cible normale, une fois la VIP validée ou corrigée.
2. Faire vérifier et, au besoin, ajuster les quatre points suivants, avec preuve écrite des valeurs avant / après :
   - délai d’inactivité et délai de réponse **strictement supérieurs** au `timeout` Logstash de 120 s (recommandation pratique : 180 s ou plus) ;
   - persistance de session désactivée, sauf justification documentée, et vérification du nœud réellement atteint par l’hôte Logstash ;
   - health check **HTTP** sur une API Elasticsearch, pas seulement l’ouverture du port 9200 ;
   - limite de connexions par client (et par membre) suffisante pour le nombre de pools actuel, puis réévaluée après la sortie unique (ADR-001).
3. Documenter la comparaison de latence (commandes dans [02-probleme.md](../02-probleme.md) section 4.3). Si la VIP est nettement plus lente ou coupe la requête alors que le nœud direct répond, traiter la VIP **avant** d’imputer le reste uniquement à Elasticsearch.
4. N’augmenter le `timeout` Logstash au-delà de 120 s qu’**après** s’être assuré que la VIP n’est pas plus courte que ce délai. Sinon, Logstash attendra un délai que la VIP a déjà coupé.
5. Le listage des nœuds data dans `hosts` reste une **échappatoire temporaire** de diagnostic ou de contournement, pas la cible d’architecture, afin de ne pas perdre la bascule automatique de la VIP.

## Conséquences

**Positives**

- On élimine (ou on confirme) une cause fréquente de `SocketTimeout` qui n’apparaît ni dans les journaux ES ni dans ceux de Logstash comme « connexion répartiteur coupée ».
- On aligne le délai réseau sur le délai applicatif déjà choisi (120 s).
- On évite de saturer un seul nœud si la sticky était active.
- On garde la haute disponibilité voulue par la VIP.

**Négatives / risques**

- Changement réseau : nécessite l’équipe responsable de l’équilibreur, une fenêtre, et une validation qu’un délai plus long n’enchaîne pas des connexions mortes (d’où un health check HTTP de qualité).
- Tant que les valeurs actuelles sont inconnues, on ne peut pas affirmer que la VIP est en cause. Cette ADR ne doit pas retarder la collecte des preuves ES (Phase 0).
- Un health check HTTP mal choisi (ex. une page trop lourde, ou un contrôle qui échoue quand le cluster est jaune) peut retirer des nœuds sains du pool.

## Alternatives considérées

- **Abandonner la VIP et lister tous les nœuds dans Logstash.** Donne à Logstash le basculement natif du plugin, mais duplique la logique de disponibilité et demande une mise à jour à chaque ajout ou retrait de nœud. Conservée seulement comme plan B.
- **Monter `timeout => 300` sans regarder la VIP.** Inutile si la VIP coupe à 60 s ; la connexion meurt toujours. Rejetée comme geste isolé.
- **Désactiver la vérification SSL ou viser un nœud en HTTP pour « aller plus vite ».** Inacceptable en production.
