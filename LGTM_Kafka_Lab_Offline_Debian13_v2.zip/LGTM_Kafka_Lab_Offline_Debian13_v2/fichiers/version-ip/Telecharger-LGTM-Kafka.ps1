﻿<#
  Telecharger-LGTM-Kafka.ps1 - Étape 1 du runbook LGTM + Kafka hors ligne (Debian 13 amd64, une VM par service)
  Rôle : TÉLÉCHARGER SEULEMENT. Aucune installation, aucune configuration, aucune vérification de signature
         (elles se font sur Linux avec sqv et sha256sum).
  Sortie : C:\lgtm-telechargement (paquets des VM kafka01, otel-gw, mimir01, loki01, tempo01, grafana01 ; agents ELK et DC)
           C:\lgtm-iso            (ISO Debian 13 pour créer les nouvelles VM)
  Utilisation (PowerShell, utilisateur standard) :
    powershell -ExecutionPolicy Bypass -File .\Telecharger-LGTM-Kafka.ps1
#>
param(
  [string]$Racine   = 'C:\lgtm-telechargement',
  [string]$RacineIso = 'C:\lgtm-iso',
  [switch]$SansIso
)
$ErrorActionPreference = 'Stop'
$ProgressPreference    = 'SilentlyContinue'

# ---------- Versions épinglées (vérifiées le 28 oct. 2026) ----------
$GRAFANA_VERSION = '13.2.4'; $GRAFANA_BUILD = '38252365904'   # numéro de build inclus dans le nom du .deb
$MIMIR_VERSION   = '3.2.3'
$LOKI_VERSION    = '3.7.9'
$TEMPO_VERSION   = '3.1.1'
$PROM_VERSION    = '3.15.1'
$NODEEXP_VERSION = '1.12.1'
$OTELCOL_VERSION = '0.164.0'
$WINEXP_VERSION  = '0.32.0'
$DEBIAN_VERSION  = '13.7.0'
$ADDUSER_VERSION = '3.152'
$KAFKA_VERSION   = '4.4.0'; $KAFKA_SCALA = '2.13'               # binaire officiel Apache (Scala 2.13)
$JAVA_FEATURE    = '25';    $JAVA_VERSION = '25.0.5+8'          # Eclipse Temurin JRE 25 (LTS), archive .tar.gz

$GH   = 'https://github.com'
$OTEL = "$GH/open-telemetry/opentelemetry-collector-releases/releases/download/v$OTELCOL_VERSION"
# Kafka : downloads.apache.org ne garde que les versions courantes ; archive.apache.org les garde toutes (plus lent)
$KAFKA_TGZ = "kafka_${KAFKA_SCALA}-$KAFKA_VERSION.tgz"
$KAFKA_URLS = @("https://downloads.apache.org/kafka/$KAFKA_VERSION", "https://archive.apache.org/dist/kafka/$KAFKA_VERSION")
# Temurin : le « + » de la version s'écrit %2B dans l'URL, « _ » dans le nom du fichier
$JAVA_TAG  = 'jdk-' + $JAVA_VERSION.Replace('+','%2B')
$JAVA_TGZ  = "OpenJDK${JAVA_FEATURE}U-jre_x64_linux_hotspot_$($JAVA_VERSION.Replace('+','_')).tar.gz"
$JAVA_BASE = "$GH/adoptium/temurin${JAVA_FEATURE}-binaries/releases/download/$JAVA_TAG"

# D = sous-dossier, U = URL (ou liste d'URL essayées dans l'ordre), N = nom local (si l'URL ne se termine pas par le nom du fichier)
$Fichiers = @(
  # Grafana OSS (.deb + empreinte publiée + clé de signature du dépôt APT)
  @{ D='grafana'; U="https://dl.grafana.com/grafana/release/$GRAFANA_VERSION/grafana_${GRAFANA_VERSION}_${GRAFANA_BUILD}_linux_amd64.deb" }
  @{ D='grafana'; U="https://dl.grafana.com/grafana/release/$GRAFANA_VERSION/grafana_${GRAFANA_VERSION}_${GRAFANA_BUILD}_linux_amd64.deb.sha256" }
  @{ D='grafana'; U='https://apt.grafana.com/gpg-full.key' }
  # Index signé du dépôt APT Grafana : sert à la vérification GPG hors ligne (Grafana, Mimir, Loki, Tempo)
  @{ D='grafana-apt'; U='https://apt.grafana.com/dists/stable/InRelease' }
  @{ D='grafana-apt'; U='https://apt.grafana.com/dists/stable/main/binary-amd64/Packages.gz' }
  # Grafana Mimir (mode monolithique) + mimirtool
  @{ D='mimir'; U="$GH/grafana/mimir/releases/download/mimir-$MIMIR_VERSION/mimir-${MIMIR_VERSION}_amd64.deb" }
  @{ D='mimir'; U="$GH/grafana/mimir/releases/download/mimir-$MIMIR_VERSION/mimir-${MIMIR_VERSION}_amd64.deb-sha-256" }
  @{ D='mimir'; U="$GH/grafana/mimir/releases/download/mimir-$MIMIR_VERSION/mimirtool_${MIMIR_VERSION}_amd64.deb" }
  @{ D='mimir'; U="$GH/grafana/mimir/releases/download/mimir-$MIMIR_VERSION/mimirtool_${MIMIR_VERSION}_amd64.deb-sha-256" }
  # Loki
  @{ D='loki'; U="$GH/grafana/loki/releases/download/v$LOKI_VERSION/loki_${LOKI_VERSION}_amd64.deb" }
  @{ D='loki'; U="$GH/grafana/loki/releases/download/v$LOKI_VERSION/SHA256SUMS" }
  # Tempo
  @{ D='tempo'; U="$GH/grafana/tempo/releases/download/v$TEMPO_VERSION/tempo_${TEMPO_VERSION}_linux_amd64.deb" }
  @{ D='tempo'; U="$GH/grafana/tempo/releases/download/v$TEMPO_VERSION/SHA256SUMS" }
  # Prometheus (utilisé en mode agent : collecte + remote_write vers Mimir)
  @{ D='prometheus'; U="$GH/prometheus/prometheus/releases/download/v$PROM_VERSION/prometheus-$PROM_VERSION.linux-amd64.tar.gz" }
  @{ D='prometheus'; U="$GH/prometheus/prometheus/releases/download/v$PROM_VERSION/sha256sums.txt" }
  # node_exporter (toutes les VM Linux)
  @{ D='node_exporter'; U="$GH/prometheus/node_exporter/releases/download/v$NODEEXP_VERSION/node_exporter-$NODEEXP_VERSION.linux-amd64.tar.gz" }
  @{ D='node_exporter'; U="$GH/prometheus/node_exporter/releases/download/v$NODEEXP_VERSION/sha256sums.txt" }
  # OpenTelemetry Collector contrib (passerelle otel-gw, consommateurs mimir01/loki01/tempo01, agent ELK)
  @{ D='otelcol-contrib'; U="$OTEL/otelcol-contrib_${OTELCOL_VERSION}_linux_amd64.deb" }
  @{ D='otelcol-contrib'; U="$OTEL/otelcol-contrib_${OTELCOL_VERSION}_linux_amd64.deb.sha256" }
  # Agents Windows pour le DC
  @{ D='windows'; U="$OTEL/otelcol-contrib_${OTELCOL_VERSION}_windows_x64.msi" }
  @{ D='windows'; U="$OTEL/otelcol-contrib_${OTELCOL_VERSION}_windows_x64.msi.sha256" }
  @{ D='windows'; U="$GH/prometheus-community/windows_exporter/releases/download/v$WINEXP_VERSION/windows_exporter-$WINEXP_VERSION-amd64.msi" }
  @{ D='windows'; U="$GH/prometheus-community/windows_exporter/releases/download/v$WINEXP_VERSION/sha256sums.txt" }
  # Apache Kafka (kafka01) : archive binaire + empreinte SHA-512 + signature .asc + clés des responsables de version
  @{ D='kafka'; U=($KAFKA_URLS | ForEach-Object { "$_/$KAFKA_TGZ" }) }
  @{ D='kafka'; U=($KAFKA_URLS | ForEach-Object { "$_/$KAFKA_TGZ.sha512" }) }
  @{ D='kafka'; U=($KAFKA_URLS | ForEach-Object { "$_/$KAFKA_TGZ.asc" }) }
  @{ D='kafka'; U=@('https://downloads.apache.org/kafka/KEYS', 'https://archive.apache.org/dist/kafka/KEYS') }
  # Java pour Kafka (kafka01) : Eclipse Temurin JRE, archive autonome + SHA-256 + signature + clé publique Adoptium
  @{ D='java'; U="$JAVA_BASE/$JAVA_TGZ" }
  @{ D='java'; U="$JAVA_BASE/$JAVA_TGZ.sha256.txt" }
  @{ D='java'; U="$JAVA_BASE/$JAVA_TGZ.sig" }
  @{ D='java'; U='https://packages.adoptium.net/artifactory/api/gpg/key/public'; N='adoptium-public.key' }
  # Dépendance Debian de secours (normalement déjà installée : priorité « important »)
  @{ D='debian'; U="https://deb.debian.org/debian/pool/main/a/adduser/adduser_${ADDUSER_VERSION}_all.deb" }
)
$FichiersIso = @(
  @{ D=''; U="https://cdimage.debian.org/cdimage/release/$DEBIAN_VERSION/amd64/iso-cd/debian-$DEBIAN_VERSION-amd64-netinst.iso" }
  @{ D=''; U="https://cdimage.debian.org/cdimage/release/$DEBIAN_VERSION/amd64/iso-cd/SHA256SUMS" }
  @{ D=''; U="https://cdimage.debian.org/cdimage/release/$DEBIAN_VERSION/amd64/iso-cd/SHA256SUMS.sign" }
  @{ D=''; U='https://keyring.debian.org/pks/lookup?op=get&search=0xDA87E80D6294BE9B'; N='debian-cd-signing-key.asc' }
)

function Get-Lot([string]$Base, $Liste) {
  foreach ($f in $Liste) {
    $dir = if ($f.D) { Join-Path $Base $f.D } else { $Base }
    New-Item -ItemType Directory -Force -Path $dir | Out-Null
    $urls = @($f.U)
    $nom  = if ($f.N) { $f.N } else { [uri]::UnescapeDataString(($urls[0] -split '/')[-1]) }
    $dest = Join-Path $dir $nom
    if ((Test-Path $dest) -and ((Get-Item $dest).Length -gt 0)) { Write-Host "déjà présent : $nom"; continue }
    $reussi = $false
    foreach ($u in $urls) {
      Write-Host "téléchargement : $nom  <- $u"
      # curl.exe est fourni avec Windows 10 1809+ et Windows 11 ; plus rapide qu'Invoke-WebRequest pour les gros fichiers
      & curl.exe --fail --location --retry 3 --silent --show-error --output $dest $u
      if ($LASTEXITCODE -eq 0) { $reussi = $true; break }
      Remove-Item -Force -ErrorAction SilentlyContinue $dest
    }
    if (-not $reussi) { throw "Échec du téléchargement : $($urls -join ' | ')" }
  }
}

function Write-Manifeste([string]$Base) {
  # Manifeste au format sha256sum (minuscules, 2 espaces, chemin relatif avec /), fins de ligne LF
  $m = Join-Path $Base 'MANIFEST-SHA256.txt'
  $lignes = Get-ChildItem -Path $Base -Recurse -File |
    Where-Object { $_.Name -ne 'MANIFEST-SHA256.txt' } |
    Sort-Object FullName | ForEach-Object {
      $h   = (Get-FileHash -Algorithm SHA256 -Path $_.FullName).Hash.ToLower()
      $rel = $_.FullName.Substring((Resolve-Path $Base).Path.TrimEnd('\','/').Length + 1).Replace('\','/')
      "$h  $rel"
    }
  [IO.File]::WriteAllText($m, (($lignes -join "`n") + "`n"))
  Write-Host "manifeste : $m ($($lignes.Count) fichiers)"
}

Get-Lot $Racine $Fichiers
Write-Manifeste $Racine
if (-not $SansIso) { Get-Lot $RacineIso $FichiersIso; Write-Manifeste $RacineIso }

# Archive unique pour le transfert (tar.exe est fourni avec Windows 10 1803+) ; Linux l'ouvre avec tar, sans unzip
$Archive = Join-Path (Split-Path $Racine -Parent) ("lgtm-bundle-{0}.tar" -f (Get-Date -Format 'yyyyMMdd'))
& tar.exe -cf $Archive -C (Split-Path $Racine -Parent) (Split-Path $Racine -Leaf)
if ($LASTEXITCODE -ne 0) { throw "Échec de tar.exe" }
$hA = (Get-FileHash -Algorithm SHA256 -Path $Archive).Hash.ToLower()
[IO.File]::WriteAllText("$Archive.sha256", "$hA  $(Split-Path $Archive -Leaf)`n")
Write-Host "archive : $Archive"
Write-Host "SHA-256 : $hA   (à comparer sur Linux, transfert seulement)"
