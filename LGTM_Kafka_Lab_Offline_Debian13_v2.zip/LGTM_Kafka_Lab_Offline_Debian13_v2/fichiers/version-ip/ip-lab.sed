# ip-lab.sed - remplace les marqueurs <ip-…> des fichiers du runbook par les adresses réelles.
# Édite UNE fois les adresses (à droite), copie ce fichier sur chaque VM (/root/ip-lab.sed),
# puis : sed -i -f /root/ip-lab.sed <fichier>   ; contrôle : grep -n '<ip-' <fichier> (doit être vide)
s/<ip-dc>/A.B.C.10/g
s/<ip-elk>/A.B.C.11/g
s/<ip-kafka01>/A.B.C.21/g
s/<ip-otel-gw>/A.B.C.22/g
s/<ip-mimir01>/A.B.C.23/g
s/<ip-loki01>/A.B.C.24/g
s/<ip-tempo01>/A.B.C.25/g
s/<ip-grafana01>/A.B.C.26/g
