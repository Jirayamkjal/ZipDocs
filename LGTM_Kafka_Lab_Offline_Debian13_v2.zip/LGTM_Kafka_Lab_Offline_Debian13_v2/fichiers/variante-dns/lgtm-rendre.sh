#!/bin/bash
# lgtm-rendre (installé en /usr/local/sbin/lgtm-rendre) - rend un GABARIT du runbook (variante DNS du DC) :
# remplace ${VARIABLE} par la valeur de /etc/lgtm/lab.env. Seules les variables de lab.env (+ SELF_*) sont
# remplacées : ${env:ES_OTEL_API_KEY}, $__file{...}, $MAINPID, etc. restent intacts.
# Utilisation : lgtm-rendre -i <fichier>...        (sur place)
#               lgtm-rendre <gabarit> [<sortie>]   (vers <sortie> ou la sortie standard)
# SELF_HOST / SELF_IP / SELF_FQDN : la VM courante, trouvée en comparant « hostname -s » aux <ROLE>_HOST.
# Outil : envsubst (paquet gettext-base) s'il est présent, sinon sed (même résultat).
set -euo pipefail
ENV_FILE=${LAB_ENV:-/etc/lgtm/lab.env}
[ -r "$ENV_FILE" ] || { echo "lgtm-rendre : $ENV_FILE introuvable" >&2; exit 2; }
set -a; . "$ENV_FILE"; set +a
VARS=$(grep -oE '^[A-Z][A-Z0-9_]*=' "$ENV_FILE" | tr -d '=' | sort -u)
SELF_HOST=$(hostname -s); SELF_IP=""
for v in $VARS; do
  case $v in *_HOST) [ "${!v}" = "$SELF_HOST" ] && { r=${v%_HOST}_IP; SELF_IP=${!r}; } ;; esac
done
SELF_FQDN="$SELF_HOST.$LAB_DOMAIN"
export SELF_HOST SELF_IP SELF_FQDN
VARS="$VARS SELF_HOST SELF_IP SELF_FQDN"

rendre() {  # gabarit sur l'entrée standard -> sortie standard
  if [ -z "${LGTM_SANS_ENVSUBST:-}" ] && command -v envsubst >/dev/null 2>&1; then
    envsubst "$(printf '${%s} ' $VARS)"
  else
    local script="" v val
    for v in $VARS; do
      val=$(printf '%s' "${!v}" | sed 's/[\\|&]/\\&/g')
      script+="s|\\\${$v}|$val|g;"
    done
    sed -e "$script"
  fi
}
controle() {  # signale une variable du lab non remplacée (faute de frappe, variable absente de lab.env)
  if grep -nE '\$\{(LAB_[A-Z_]+|[A-Z0-9]+_(HOST|IP|FQDN)|ES_HOST|SELF_[A-Z]+)\}' "$1" >&2; then
    echo "lgtm-rendre : variable(s) non remplacée(s) dans $2" >&2; return 1
  fi
  if [ -z "$SELF_IP" ] && grep -q 'SELF_IP' "$2"; then
    echo "lgtm-rendre : SELF_IP vide (hostname -s='$SELF_HOST' absent de lab.env)" >&2; return 1
  fi
}
if [ "${1:-}" = "-i" ]; then
  shift; [ $# -ge 1 ] || { echo "usage : lgtm-rendre -i <fichier>..." >&2; exit 2; }
  for f in "$@"; do
    t=$(mktemp "$f.XXXXXX"); rendre < "$f" > "$t"
    controle "$t" "$f" || { rm -f "$t"; exit 1; }
    chmod --reference="$f" "$t"; chown --reference="$f" "$t" 2>/dev/null || true
    mv -f "$t" "$f"; echo "rendu : $f"
  done
else
  [ $# -ge 1 ] || { echo "usage : lgtm-rendre <gabarit> [<sortie>] | -i <fichier>..." >&2; exit 2; }
  if [ -n "${2:-}" ]; then
    rendre < "$1" > "$2"; controle "$2" "$1"; echo "rendu : $2" >&2
  else
    t=$(mktemp); rendre < "$1" > "$t"; controle "$t" "$1" || { rm -f "$t"; exit 1; }; cat "$t"; rm -f "$t"
  fi
fi
