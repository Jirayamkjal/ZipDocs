#!/bin/bash
# distribuer-lot.sh (VM otel-gw, root) - variante DNS du DC : envoie à chaque VM seulement les fichiers qui la
# concernent, depuis le lot déjà VÉRIFIÉ (/opt/lgtm-bundle), puis recontrôle les empreintes SUR la VM de destination.
# Les VM sont jointes par leur FQDN (DNS du DC) ; CIBLE=ip pour utiliser les adresses de lab.env (DNS en panne).
# Prérequis : /etc/lgtm/lab.env sur otel-gw ; compte « admin » (sudo) sur chaque VM, SSH joignable.
set -euo pipefail
LOT=${LOT:-/opt/lgtm-bundle}
SSH=${SSH:-ssh}
UTIL=${UTIL:-admin}
CIBLE=${CIBLE:-fqdn}
set -a; . "${LAB_ENV:-/etc/lgtm/lab.env}"; set +a
adr() { local r=$1; if [ "$CIBLE" = ip ]; then v=${r}_IP; else v=${r}_FQDN; fi; echo "${!v}"; }
NE=node_exporter/node_exporter-1.12.1.linux-amd64.tar.gz
OC=otelcol-contrib/otelcol-contrib_0.164.0_linux_amd64.deb
LAB="lab/lab.env lab/lgtm-rendre.sh lab/verifier-dns.sh lab/gabarits"
DNS=$(cd "$LOT" && ls debian-dns/*.deb 2>/dev/null | tr '\n' ' ' || true)   # outils DNS facultatifs (dig, host)
declare -A LISTE=(
  [KAFKA01]="$NE kafka/kafka_2.13-4.4.0.tgz java/OpenJDK25U-jre_x64_linux_hotspot_25.0.5_8.tar.gz"
  [MIMIR01]="$NE $OC mimir/mimir-3.2.3_amd64.deb mimir/mimirtool_3.2.3_amd64.deb"
  [LOKI01]="$NE $OC loki/loki_3.7.9_amd64.deb"
  [TEMPO01]="$NE $OC tempo/tempo_3.1.1_linux_amd64.deb"
  [GRAFANA01]="$NE grafana/grafana_13.2.4_38252365904_linux_amd64.deb debian/adduser_3.152_all.deb"
  [ELK]="$NE $OC"
)
cd "$LOT"
for r in "${!LISTE[@]}"; do
  h=${r}_HOST
  [ -n "${1:-}" ] && [ "$1" != "${!h}" ] && continue          # option : ./distribuer-lot.sh loki01
  a=$(adr "$r"); echo "== ${!h} ($a)"
  # shellcheck disable=SC2086
  tar -cf - ${LISTE[$r]} $LAB $DNS lgtm-sha256-attendus MANIFEST-SHA256.txt | \
    $SSH "$UTIL@$a" 'rm -rf /var/tmp/lgtm-lot && mkdir -p /var/tmp/lgtm-lot && tar -xf - -C /var/tmp/lgtm-lot && cd /var/tmp/lgtm-lot && sha256sum -c --ignore-missing --strict lgtm-sha256-attendus && sha256sum -c --ignore-missing --strict --quiet MANIFEST-SHA256.txt && echo "MANIFEST : OK"'
done
echo "Distribution terminée : chaque VM a recontrôlé ses fichiers (lignes « OK » ci-dessus)."
