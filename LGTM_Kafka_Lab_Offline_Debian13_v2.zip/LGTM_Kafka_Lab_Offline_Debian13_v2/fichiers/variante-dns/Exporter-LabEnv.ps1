﻿# Exporter-LabEnv.ps1 - écrit lab.env (Bash, fins de ligne LF, ASCII) à partir de lab-params.psd1.
# Utilisation : .\Exporter-LabEnv.ps1 [-Sortie C:\lgtm-telechargement\lab\lab.env]
# Sur chaque VM Linux : /etc/lgtm/lab.env, lu par lgtm-rendre et par les scripts du runbook.
param(
  [string]$Fichier = (Join-Path $PSScriptRoot 'lab-params.psd1'),
  [string]$Sortie  = 'C:\lgtm-telechargement\lab\lab.env'
)
$ErrorActionPreference = 'Stop'
$LAB = & (Join-Path $PSScriptRoot 'Lire-LabParams.ps1') -Fichier $Fichier
$l = @('# /etc/lgtm/lab.env - GENERE par Exporter-LabEnv.ps1 depuis lab-params.psd1 : ne pas modifier ici.',
       '# Parametres du lab LGTM + Kafka (variante DNS du DC). Lecture : set -a; . /etc/lgtm/lab.env; set +a')
foreach ($k in $LAB.Keys) {
  if ($k.StartsWith('_')) { continue }
  $v = [string]$LAB[$k]
  if ($v -notmatch '^[A-Za-z0-9._-]+$') { throw "Valeur refusée pour $k : '$v' (lettres, chiffres, . _ - seulement)" }
  $l += "$k=$v"
}
New-Item -ItemType Directory -Force -Path (Split-Path $Sortie -Parent) | Out-Null
[IO.File]::WriteAllText($Sortie, (($l -join "`n") + "`n"), [Text.Encoding]::ASCII)
Write-Host "lab.env ecrit : $Sortie ($($l.Count - 2) variables)"
