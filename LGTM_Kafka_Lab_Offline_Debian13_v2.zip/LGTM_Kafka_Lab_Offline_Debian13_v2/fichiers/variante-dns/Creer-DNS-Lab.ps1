﻿# Creer-DNS-Lab.ps1 - À lancer SUR LE DC (PowerShell en administrateur, module DnsServer présent avec le rôle DNS).
# Crée, dans la zone DNS intégrée à AD du domaine (LAB_DOMAIN, déjà existante) :
#   - la zone inverse intégrée à AD du réseau du lab (si absente) ;
#   - un enregistrement A + PTR pour ELK et les 6 nouvelles VM (celui du DC existe déjà : seul son PTR est ajouté si absent) ;
#   - les CNAME facultatifs de lab-params.psd1.
# Idempotent : ne modifie JAMAIS un enregistrement existant ; un écart avec lab-params.psd1 est signalé, pas corrigé.
# Aucun redirecteur (forwarder) n'est créé : le lab est hors ligne, le DC ne résout que ses propres zones.
# Utilisation :  .\Creer-DNS-Lab.ps1 -Simulation   (affiche seulement)   puis   .\Creer-DNS-Lab.ps1
param(
  [string]$Fichier = (Join-Path $PSScriptRoot 'lab-params.psd1'),
  [switch]$Simulation
)
$ErrorActionPreference = 'Stop'
$LAB  = & (Join-Path $PSScriptRoot 'Lire-LabParams.ps1') -Fichier $Fichier
$Zone = $LAB.LAB_DOMAIN
$Inv  = $LAB.LAB_REVERSE_ZONE
$NbOct = 4 - [int]$LAB.LAB_PREFIX / 8          # octets de l'adresse dans le nom PTR (1 pour un /24)
function Faire([string]$Texte, [scriptblock]$Action) {
  if ($Simulation) { Write-Host "[SIMULATION] $Texte" } else { Write-Host $Texte; & $Action }
}
function NomPtr([string]$Ip) { $o = $Ip.Split('.'); $p = $o[(4 - $NbOct)..3]; [array]::Reverse($p); $p -join '.' }

# 0. La zone directe doit exister (c'est la zone du domaine AD)
if (-not (Get-DnsServerZone -Name $Zone -ErrorAction SilentlyContinue)) { throw "Zone $Zone introuvable sur ce DC (LAB_DOMAIN ?)" }

# 1. Zone inverse intégrée à AD (réplication : domaine ; mises à jour dynamiques sécurisées)
if (Get-DnsServerZone -Name $Inv -ErrorAction SilentlyContinue) { Write-Host "zone inverse $Inv : existe" }
else {
  Faire "creation zone inverse $Inv ($($LAB.LAB_NETWORK)/$($LAB.LAB_PREFIX))" {
    Add-DnsServerPrimaryZone -NetworkId "$($LAB.LAB_NETWORK)/$($LAB.LAB_PREFIX)" -ReplicationScope Domain -DynamicUpdate Secure
  }
}

# 2. A + PTR par VM
foreach ($r in $LAB._ROLES) {
  $h = $LAB["${r}_HOST"]; $ip = $LAB["${r}_IP"]; $fq = $LAB["${r}_FQDN"]
  $a = Get-DnsServerResourceRecord -ZoneName $Zone -Name $h -RRType A -ErrorAction SilentlyContinue
  if (-not $a) {
    Faire "A   $fq -> $ip (+ PTR)" { Add-DnsServerResourceRecordA -ZoneName $Zone -Name $h -IPv4Address $ip -CreatePtr }
    continue
  }
  $ipsA = @($a | ForEach-Object { $_.RecordData.IPv4Address.IPAddressToString })
  if ($ipsA -notcontains $ip) { Write-Warning "A $fq existe avec $($ipsA -join ', ') (lab-params : $ip) : NON modifie, a corriger a la main"; continue }
  Write-Host "A   $fq -> $ip : existe"
  $n = NomPtr $ip
  $ptr = Get-DnsServerResourceRecord -ZoneName $Inv -Name $n -RRType Ptr -ErrorAction SilentlyContinue
  if ($ptr) { Write-Host "PTR $ip -> $(@($ptr)[0].RecordData.PtrDomainName) : existe" }
  else { Faire "PTR $ip -> $fq." { Add-DnsServerResourceRecordPtr -ZoneName $Inv -Name $n -PtrDomainName "$fq." } }
}

# 3. CNAME facultatifs (alias -> nom d'hôte du lab)
foreach ($al in $LAB._CNAMES.Keys) {
  $cible = "$($LAB._CNAMES[$al]).$Zone."
  if (Get-DnsServerResourceRecord -ZoneName $Zone -Name $al -ErrorAction SilentlyContinue) { Write-Host "CNAME $al.$Zone : nom deja utilise, ignore" }
  else { Faire "CNAME $al.$Zone -> $cible" { Add-DnsServerResourceRecordCName -ZoneName $Zone -Name $al -HostNameAlias $cible } }
}

# 4. Contrôle : interrogation du DNS du DC (directe et inverse)
if (-not $Simulation) {
  foreach ($r in $LAB._ROLES) {
    $fq = $LAB["${r}_FQDN"]; $ip = $LAB["${r}_IP"]
    $d = (Resolve-DnsName -Name $fq -Type A -Server $LAB.DC_IP -DnsOnly -ErrorAction SilentlyContinue | Where-Object Type -eq 'A').IPAddress
    $i = (Resolve-DnsName -Name $ip -Type PTR -Server $LAB.DC_IP -DnsOnly -ErrorAction SilentlyContinue).NameHost
    '{0,-34} A={1,-15} PTR={2}' -f $fq, ($d -join ','), ($i -join ',')
  }
}
