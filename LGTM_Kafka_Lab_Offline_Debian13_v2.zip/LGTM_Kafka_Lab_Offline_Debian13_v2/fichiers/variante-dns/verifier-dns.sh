#!/bin/bash
# verifier-dns.sh - contrôle DNS d'une VM Linux du lab (variante DNS du DC). Lecture seule, sans secret.
# Compare ce que le DNS répond avec /etc/lgtm/lab.env (source unique) : noms directs, inverses (PTR), domaine de recherche.
# Usage : bash verifier-dns.sh        (DNS_PORT=53 par défaut, utilisé seulement par dig)
set -u
set -a; . "${LAB_ENV:-/etc/lgtm/lab.env}"; set +a
ECHEC=0
ok(){ printf '  [OK]    %s\n' "$1"; }
ko(){ printf '  [ECHEC] %s\n' "$1"; ECHEC=1; }
av(){ printf '  [ATTN]  %s\n' "$1"; }
ROLES="DC ELK KAFKA01 OTELGW MIMIR01 LOKI01 TEMPO01 GRAFANA01"

echo "1) Résolveur (/etc/resolv.conf)"
RC=${RESOLV_CONF:-/etc/resolv.conf}
ns=$(awk '$1=="nameserver"{print $2}' "$RC" | tr '\n' ' ')
[ "${ns%% *}" = "$DC_IP" ] && ok "premier nameserver = DC ($DC_IP)" || ko "premier nameserver = '${ns%% *}' (attendu : $DC_IP)"
grep -qE "^(search|domain)[[:space:]].*\b${LAB_DOMAIN//./\\.}\b" "$RC" && ok "search $LAB_DOMAIN" || ko "domaine de recherche $LAB_DOMAIN absent"

echo "2) Nom de cette VM"
self=$(hostname -s); fq=$(hostname -f 2>/dev/null || true)
[ "$fq" = "$self.$LAB_DOMAIN" ] && ok "hostname -f = $fq" || ko "hostname -f = '$fq' (attendu : $self.$LAB_DOMAIN ; voir /etc/hosts)"

echo "3) Noms directs (A) et inverses (PTR) de chaque VM, comparés à lab.env"
for r in $ROLES; do
  h=${r}_HOST; i=${r}_IP; f=${r}_FQDN
  got=$(getent ahostsv4 "${!f}" | awk 'NR==1{print $1}')
  [ "$got" = "${!i}" ] && ok "${!f} -> $got" || ko "${!f} -> '${got:-aucune réponse}' (attendu : ${!i})"
  rev=$(getent hosts "${!i}" | awk 'NR==1{print $2}')
  [ "$rev" = "${!f}" ] && ok "${!i} -> $rev (PTR)" || av "${!i} -> '${rev:-aucun PTR}' (attendu : ${!f})"
done
short=$(getent ahostsv4 "$KAFKA01_HOST" | awk 'NR==1{print $1}')
[ "$short" = "$KAFKA01_IP" ] && ok "nom court $KAFKA01_HOST (domaine de recherche)" || av "nom court $KAFKA01_HOST non résolu (utiliser les FQDN)"
[ "$ES_HOST" = "$ELK_FQDN" ] || { got=$(getent ahostsv4 "$ES_HOST" | awk 'NR==1{print $1}'); [ -n "$got" ] && ok "ES_HOST $ES_HOST -> $got" || ko "ES_HOST $ES_HOST non résolu"; }

echo "4) Secours /etc/hosts"
n=$(grep -cE "^[0-9].*\.${LAB_DOMAIN//./\\.}" /etc/hosts || true)
[ "$n" -le 1 ] && ok "pas de secours actif (seulement la VM elle-même)" || av "$n lignes du lab actives dans /etc/hosts : le DNS du DC est court-circuité"

echo "5) Interrogation directe du DC (si dig est installé)"
if command -v dig >/dev/null 2>&1; then
  a=$(dig +short +time=2 +tries=1 -p "${DNS_PORT:-53}" @"$DC_IP" "$KAFKA01_FQDN" A)
  [ "$a" = "$KAFKA01_IP" ] && ok "dig @$DC_IP $KAFKA01_FQDN = $a" || ko "dig @$DC_IP $KAFKA01_FQDN = '${a:-aucune réponse}'"
else
  av "dig absent (facultatif : paquet bind9-dnsutils, runbook §4.6)"
fi
echo
[ "$ECHEC" -eq 0 ] && echo "RÉSULTAT DNS : conforme." || { echo "RÉSULTAT DNS : au moins un contrôle a échoué."; exit 1; }
