﻿# Lire-LabParams.ps1 - lit lab-params.psd1 et renvoie un dictionnaire ordonné :
#   valeurs du fichier + valeurs dérivées (<ROLE>_FQDN, ES_HOST, LAB_REVERSE_ZONE) + liste des rôles.
# Utilisation :  $LAB = & .\Lire-LabParams.ps1 [-Fichier .\lab-params.psd1]
param([string]$Fichier = (Join-Path $PSScriptRoot 'lab-params.psd1'))
$ErrorActionPreference = 'Stop'
$p = Import-PowerShellDataFile -Path $Fichier
$Roles = 'DC','ELK','KAFKA01','OTELGW','MIMIR01','LOKI01','TEMPO01','GRAFANA01'
$LAB = [ordered]@{}
foreach ($k in 'LAB_DOMAIN','LAB_NETWORK','LAB_PREFIX','LAB_GW') { $LAB[$k] = [string]$p[$k] }
foreach ($r in $Roles) {
  foreach ($s in '_HOST','_IP') {
    $v = [string]$p["$r$s"]
    if (-not $v) { throw "Paramètre manquant : $r$s" }
    $LAB["$r$s"] = $v
  }
}
foreach ($r in $Roles) { $LAB["${r}_FQDN"] = "$($LAB["${r}_HOST"]).$($LAB.LAB_DOMAIN)" }
$LAB['ES_HOST'] = if ($p.ES_HOST) { [string]$p.ES_HOST } else { $LAB.ELK_FQDN }
# Zone inverse (préfixe multiple de 8 seulement : 8, 16 ou 24)
$pre = [int]$LAB.LAB_PREFIX
if ($pre % 8 -ne 0) { throw "LAB_PREFIX=$pre : utiliser 8, 16 ou 24 (zone inverse classique)" }
$oct = $LAB.LAB_NETWORK.Split('.')[0..($pre / 8 - 1)]
[array]::Reverse($oct)
$LAB['LAB_REVERSE_ZONE'] = ($oct -join '.') + '.in-addr.arpa'
# Contrôles simples : IPv4 valides, adresses et noms uniques
$ips = foreach ($r in $Roles) { $LAB["${r}_IP"] }
foreach ($ip in $ips + $LAB.LAB_GW) { if (-not ($ip -as [ipaddress])) { throw "Adresse IPv4 invalide : $ip" } }
if (($ips | Sort-Object -Unique).Count -ne $ips.Count) { throw 'Deux rôles ont la même adresse IP' }
$hs = foreach ($r in $Roles) { $LAB["${r}_HOST"] }
if (($hs | Sort-Object -Unique).Count -ne $hs.Count) { throw "Deux rôles ont le même nom d'hôte" }
# Éléments non exportés vers lab.env (préfixe _)
$LAB['_ROLES']   = $Roles
$LAB['_CNAMES']  = if ($p.CNAMES) { $p.CNAMES } else { @{} }
$LAB['_DC_VM']   = [string]$p.DC_VM
$LAB['_ELK_VM']  = [string]$p.ELK_VM
$LAB['_VSWITCH'] = [string]$p.VSWITCH
$LAB['_VM_DOSSIER'] = [string]$p.VM_DOSSIER
$LAB['_ISO_DEBIAN'] = [string]$p.ISO_DEBIAN
$LAB
