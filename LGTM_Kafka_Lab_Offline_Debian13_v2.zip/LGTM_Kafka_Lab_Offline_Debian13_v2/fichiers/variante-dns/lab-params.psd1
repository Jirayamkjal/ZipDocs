﻿# lab-params.psd1 - PARAMÈTRES UNIQUES du lab LGTM + Kafka (variante « DNS du DC »).
# Seul fichier à modifier. Toutes les valeurs ci-dessous sont des EXEMPLES :
#   - lab.example.test : domaine réservé à la documentation (RFC 2606/6761), à remplacer par TON domaine AD ;
#   - 192.0.2.0/24     : plage réservée à la documentation (RFC 5737), à remplacer par TON réseau de lab.
# Lu par Lire-LabParams.ps1 (Creer-DNS-Lab.ps1, Creer-VM-LGTM-Kafka.ps1, Exporter-LabEnv.ps1, Rendre-Gabarit.ps1).
# Exporter-LabEnv.ps1 en tire lab.env (mêmes noms de variables) pour les VM Linux : /etc/lgtm/lab.env.
@{
  # --- Domaine Active Directory et zone DNS intégrée à AD (sur le DC) ---
  LAB_DOMAIN   = 'lab.example.test'        # EXEMPLE : nom DNS du domaine AD (zone directe existante)
  # --- Réseau du lab (vSwitch Hyper-V) ---
  LAB_NETWORK  = '192.0.2.0'               # EXEMPLE : adresse du réseau
  LAB_PREFIX   = 24                        # longueur du préfixe (24 conseillé : une zone inverse simple)
  LAB_GW       = '192.0.2.1'               # EXEMPLE : passerelle (ou une adresse du lab si aucune)
  # --- VM existantes (ressources INCHANGÉES ; seuls leurs noms et adresses servent ici) ---
  DC_HOST      = 'dc01';      DC_IP      = '192.0.2.10';  DC_VM  = 'DC'     # EXEMPLE ; DC_VM = nom de la VM dans Hyper-V
  ELK_HOST     = 'elk';       ELK_IP     = '192.0.2.11';  ELK_VM = 'ELK'    # EXEMPLE
  # --- Nouvelles VM (nom d'hôte = nom de la VM Hyper-V) ---
  KAFKA01_HOST   = 'kafka01';   KAFKA01_IP   = '192.0.2.21'   # EXEMPLE
  OTELGW_HOST    = 'otel-gw';   OTELGW_IP    = '192.0.2.22'   # EXEMPLE
  MIMIR01_HOST   = 'mimir01';   MIMIR01_IP   = '192.0.2.23'   # EXEMPLE
  LOKI01_HOST    = 'loki01';    LOKI01_IP    = '192.0.2.24'   # EXEMPLE
  TEMPO01_HOST   = 'tempo01';   TEMPO01_IP   = '192.0.2.25'   # EXEMPLE
  GRAFANA01_HOST = 'grafana01'; GRAFANA01_IP = '192.0.2.26'   # EXEMPLE
  # --- Nom d'Elasticsearch utilisé en HTTPS : doit figurer dans le certificat HTTP d'ES (SAN) ---
  ES_HOST      = ''                        # vide = ELK_HOST.LAB_DOMAIN
  # --- Alias DNS facultatifs (CNAME -> nom d'hôte du lab) ; @{} pour n'en créer aucun ---
  CNAMES       = @{ grafana = 'grafana01'; kafka = 'kafka01' }
  # --- Hyper-V (hôte) ---
  VSWITCH      = 'vSwitch-Lab'             # EXEMPLE : Get-VMSwitch
  VM_DOSSIER   = 'C:\Hyper-V'              # dossier des VHDX
  ISO_DEBIAN   = 'C:\lgtm-iso\debian-13.7.0-amd64-netinst.iso'
}
