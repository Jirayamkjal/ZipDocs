﻿# Rendre-Gabarit.ps1 - équivalent Windows de lgtm-rendre : remplace ${VARIABLE} par la valeur de lab-params.psd1.
# Seules les variables connues (celles de lab.env) sont remplacées ; ${env:...} et les autres restent intacts.
# Utilisation (sur le DC) : .\Rendre-Gabarit.ps1 -Gabarit .\otelcol-agent-dc.yaml -Sortie 'C:\Program Files\OpenTelemetry Collector\config.yaml'
param(
  [Parameter(Mandatory)] [string]$Gabarit,
  [Parameter(Mandatory)] [string]$Sortie,
  [string]$Fichier = (Join-Path $PSScriptRoot 'lab-params.psd1')
)
$ErrorActionPreference = 'Stop'
$LAB = & (Join-Path $PSScriptRoot 'Lire-LabParams.ps1') -Fichier $Fichier
$t = [IO.File]::ReadAllText((Resolve-Path $Gabarit))
foreach ($k in $LAB.Keys) {
  if ($k.StartsWith('_')) { continue }
  $t = $t.Replace('${' + $k + '}', [string]$LAB[$k])
}
$reste = [regex]::Matches($t, '\$\{(LAB_[A-Z_]+|[A-Z0-9]+_(HOST|IP|FQDN)|ES_HOST)\}') | ForEach-Object Value
if ($reste) { throw "Variables non remplacées : $($reste -join ', ')" }
[IO.File]::WriteAllText($Sortie, $t, (New-Object Text.UTF8Encoding $false))
Write-Host "rendu : $Sortie"
