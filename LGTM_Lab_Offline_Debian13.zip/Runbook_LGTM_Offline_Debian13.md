# Runbook – Pile LGTM (Loki, Grafana, Tempo, Mimir) hors ligne sur Debian 13, à côté d'ELK (lab Hyper-V)

**Cible :** nouvelle VM **obs-lgtm**, Debian **13 « trixie »** amd64, **aucun accès Internet**, dans le lab Hyper-V de démonstration (VM DC, ELK, AppDynamics). Tous les outils tournent en **services systemd natifs** (paquets `.deb` ou binaires officiels), **sans Docker**.
**Poste Windows connecté :** il **télécharge seulement** les fichiers officiels, produit un manifeste et une archive, puis les copie par SFTP/SCP. La vérification des empreintes et des signatures, l'installation et la configuration se font **sur Linux**.
**Objectif :** installer une vraie pile LGTM (Grafana **Mimir** pour les métriques, Loki pour les journaux, Tempo pour les traces, Grafana pour la consultation), alimentée par OpenTelemetry Collector et Prometheus en mode agent, à côté de la pile ELK existante, selon le plan Strangler Fig de `Plan_integration_observabilite_lab.md`.

Le runbook suit cet ordre :
- **Étape 1 – Téléchargement depuis Windows** (section 2) : script PowerShell, manifeste SHA-256, archive, transfert, puis vérification sur Linux.
- **Étape 2 – Restructuration de l'infrastructure du lab** (section 3) : vCPU, RAM, disque de chaque VM et commandes Hyper-V.
- **Étape 3 – Installation sur obs-lgtm** (section 4) : `dpkg -i`, unités systemd, configurations minimales, sources de données Grafana, vérifications.
- **Étape 4 – Agents sur la VM ELK et le DC** (section 5).

Documents compagnons dans `architecture-lgtm/` : `README.md` (carte des documents, versions), **`GUARDRAILS.md` (garde-fous à lire avant toute intervention)** et les documents d'architecture `01` à `08` (flux, ports, ADR, dimensionnement, sécurité, migration, exploitation).

> **Hypothèses à valider :**
> - VM existantes : **DC** (Windows Server, AD DS + DNS), **ELK** (Debian 13, Elasticsearch 9 + Kibana, ElastAlert 2 en service systemd), **AppDynamics** (contrôleur, éteinte par défaut comme dans le plan).
> - Réseau : un vSwitch Hyper-V du lab ; les adresses `<ip-dc>`, `<ip-elk>`, `<ip-obs-lgtm>` sont des **valeurs à remplacer**.
> - Elasticsearch 9 a la sécurité activée (TLS sur 9200, authentification), avec le CA HTTP dans `/etc/elasticsearch/certs/http_ca.crt` sur la VM ELK.
> - Les valeurs de ressources sont des minimums de **démonstration**, pas de production.
> - Le plan d'intégration existant n'est **pas modifié** ; ce runbook le complète et indique explicitement chaque écart (section 3.2).

### Versions épinglées (vérifiées le 28 oct. 2026)

| Composant | Version | Artefact | Vérification amont disponible |
|---|---|---|---|
| Grafana OSS | **13.2.4** (build 38252365904) | `.deb` sur `dl.grafana.com` | `.sha256` publié + index APT Grafana **signé GPG** |
| Grafana Mimir | **3.2.3** | `.deb` (GitHub) + `mimirtool` | fichier `-sha-256` publié + index APT Grafana signé |
| Grafana Loki | **3.7.9** | `.deb` (GitHub) | index APT Grafana signé (le `SHA256SUMS` de la release ne liste pas le `.deb`) |
| Grafana Tempo | **3.1.1** | `.deb` (GitHub) | `SHA256SUMS` + index APT Grafana signé |
| Prometheus (mode agent) | **3.15.1** | `tar.gz` (GitHub) | `sha256sums.txt` |
| node_exporter | **1.12.1** | `tar.gz` (GitHub) | `sha256sums.txt` |
| OpenTelemetry Collector contrib | **0.164.0** | `.deb` Linux + `.msi` Windows | `.sha256` par fichier (+ signatures Sigstore, non utilisées hors ligne) |
| windows_exporter | **0.32.0** | `.msi` | `sha256sums.txt` |
| Debian (ISO d'installation) | **13.7.0** netinst amd64 | `.iso` | `SHA256SUMS` **signé GPG** (clé « Debian CD signing key ») |

> **Pourquoi Grafana 13.2.4 et pas 13.3.0 ?** La 13.3.0 est sortie le 27 oct. 2026 et n'était pas encore dans l'index signé du dépôt APT Grafana le 28 oct. La 13.2.4 y figure : on peut donc vérifier sa signature GPG hors ligne, en plus de son empreinte. Pour passer en 13.3.x plus tard, change `GRAFANA_VERSION` et `GRAFANA_BUILD` dans le script (section 2.4) et l'empreinte en section 2.8.

---

## 0. Démarrage rapide (résumé)

> Séquence condensée, détaillée plus bas. Prends un **checkpoint Hyper-V** de chaque VM avant de commencer (section 3.4).

**Poste Windows (téléchargement seulement)**

```powershell
powershell -ExecutionPolicy Bypass -File .\Telecharger-LGTM.ps1      # §2.4 : C:\lgtm-telechargement + C:\lgtm-iso + C:\lgtm-bundle-AAAAMMJJ.tar
scp.exe -r C:\lgtm-iso admin@<ip-elk>:/var/tmp/                       # §2.7 : l'ISO est vérifiée sur la VM ELK (Debian)
# §3.4 : commandes Hyper-V (ressources, création d'obs-lgtm, installation de Debian depuis l'ISO vérifiée)
scp.exe C:\lgtm-bundle-AAAAMMJJ.tar C:\lgtm-bundle-AAAAMMJJ.tar.sha256 admin@<ip-obs-lgtm>:/var/tmp/
```

**VM obs-lgtm (root) : tout le reste**

```bash
cd /var/tmp && sha256sum -c lgtm-bundle-*.tar.sha256 && tar xf lgtm-bundle-*.tar
cd /var/tmp/lgtm-telechargement && bash /var/tmp/verifier-lgtm.sh   # §2.8 : manifeste, empreintes amont, chaîne GPG
dpkg -i mimir/mimir-*.deb loki/loki_*.deb tempo/tempo_*.deb otelcol-contrib/*.deb grafana/grafana_*.deb mimir/mimirtool_*.deb
# §4 : configurations, unités systemd, limites mémoire, provisioning Grafana, démarrage ordonné, test de bout en bout
```

---

## 1. Architecture et choix techniques

### 1.1 Chaîne hors ligne : Windows télécharge, Linux fait tout le reste

```mermaid
flowchart LR
  subgraph NET[Zone connectée]
    SRC[(Sources officielles<br/>github.com, dl.grafana.com<br/>apt.grafana.com, deb.debian.org<br/>cdimage.debian.org)]
    WIN[Poste Windows<br/>téléchargement, manifeste, archive]
    SRC -->|HTTPS, curl.exe| WIN
  end
  subgraph XFER[Transfert]
    COPY[scp.exe / sftp.exe / WinSCP<br/>copie binaire, rien d'autre]
  end
  subgraph LAB[Lab Hyper-V - aucun accès Internet]
    ELK[VM ELK<br/>vérifie l'ISO Debian]
    OBS[VM obs-lgtm<br/>Debian 13]
    CHK[sha256sum -c<br/>sqv : signatures GPG]
    INS[dpkg -i, tar<br/>unités systemd]
    CFG[configurations<br/>provisioning Grafana]
    OBS --> CHK --> INS --> CFG
  end
  WIN --> COPY
  COPY -->|lgtm-iso| ELK
  COPY -->|lgtm-bundle.tar| OBS
```

### 1.2 Architecture cible sur obs-lgtm

```mermaid
flowchart LR
  subgraph SRC[Sources]
    DC[DC Windows<br/>windows_exporter :9182<br/>otelcol-contrib agent]
    ELKVM[VM ELK<br/>node_exporter :9100<br/>otelcol-contrib agent]
    APP[App de démo<br/>SDK / agent OTel]
  end
  subgraph OBS[VM obs-lgtm - services systemd]
    COL[otelcol-contrib<br/>:4317 / :4318<br/>façade d'ingestion]
    PROM[Prometheus 3 --agent<br/>scrape + remote_write]
    MIMIR[(Mimir 3 monolithique<br/>:9009 - métriques<br/>ruler + Alertmanager)]
    LOKI[(Loki :3100<br/>journaux)]
    TEMPO[(Tempo :3200<br/>traces)]
    GRAF[Grafana :3000<br/>façade de consultation]
    NE[node_exporter :9100]
  end
  ES[(Elasticsearch 9 / Kibana<br/>système existant)]

  DC -->|OTLP journaux| COL
  ELKVM -->|OTLP journaux| COL
  APP -->|OTLP| COL
  PROM -->|scrape| DC
  PROM -->|scrape| ELKVM
  PROM -->|scrape| NE
  PROM -->|remote_write| MIMIR
  COL -->|OTLP métriques /otlp| MIMIR
  COL -->|OTLP journaux /otlp| LOKI
  COL -->|OTLP traces| TEMPO
  COL -.->|double écriture phases 1-3| ES
  TEMPO -->|span-metrics, service graph| MIMIR
  LOKI -->|alertes ruler| MIMIR
  GRAF --> MIMIR
  GRAF --> LOKI
  GRAF --> TEMPO
  GRAF -.->|datasource transitoire| ES
```

### 1.3 Choix retenus (résumé ; détail dans `architecture-lgtm/04_Decisions_architecture_ADR.md`)

- **Mimir en mode monolithique, architecture « classique » (sans Kafka).** Un seul processus `mimir` (`target: all,alertmanager`) avec stockage sur disque local. Depuis Mimir 3.0, l'architecture *ingest storage* (Kafka) est l'architecture recommandée, mais l'architecture classique reste prise en charge ([notes de version 3.0](https://grafana.com/docs/mimir/v3.0.x/release-notes/v3.0/), [architecture classique](https://grafana.com/docs/mimir/latest/get-started/about-grafana-mimir-architecture/about-classic-architecture/)). Pour un lab sans Docker et à faible mémoire, ajouter un courtier Kafka n'apporte rien. Le stockage `filesystem` est signalé par Mimir lui-même comme réservé au développement et aux tests : c'est acceptable ici, pas en production.
- **Prometheus en mode agent plutôt que Grafana Alloy.** Prometheus `--agent` fait seulement la collecte (*scrape*) et l'envoi `remote_write` vers Mimir, sans base locale interrogeable ni évaluation de règles ([mode agent](https://prometheus.io/docs/prometheus/latest/prometheus_agent/)). On garde ainsi l'outil et les fichiers déjà décrits dans le plan (`prometheus.yml`, `promtool`). **Alloy n'est pas retenu** : il ferait doublon avec `otelcol-contrib`, qui reste la façade d'ingestion du Strangler Fig sur obs-lgtm et l'agent du DC. L'archive `.deb` d'Alloy 1.21.2 fait environ 168 Mo, pour un rôle déjà couvert. Alloy reste une option si l'on veut un seul agent Grafana (voir l'ADR).
- **Pas d'Alertmanager autonome.** Mimir intègre un Alertmanager compatible ; le *ruler* de Mimir (règles de métriques) et celui de Loki (règles de journaux) lui envoient leurs alertes. On retire ainsi un service par rapport au plan (`alertmanager`).
- **Métriques OTLP :** `otelcol-contrib` envoie les métriques OTLP directement à Mimir (`/otlp`), et les journaux à Loki (`/otlp`), sans conversion intermédiaire.

### 1.4 Ports sur obs-lgtm

| Service | Port | Écoute | Exposé au réseau du lab |
|---|---|---|---|
| otelcol-contrib | 4317 (OTLP gRPC), 4318 (OTLP HTTP) | 0.0.0.0 | **oui** (agents DC, ELK, applications) |
| otelcol-contrib | 8888 (métriques internes) | 127.0.0.1 | non |
| Prometheus (agent) | 9090 | 127.0.0.1 | non |
| Mimir | 9009 (HTTP, API Prometheus `/prometheus`, Alertmanager `/alertmanager`), 9097 (gRPC), 7946 (memberlist) | 127.0.0.1 | non |
| Loki | 3100 (HTTP), 9096 (gRPC) | 127.0.0.1 | non |
| Tempo | 3200 (HTTP), 9095 (gRPC), 4417/4418 (OTLP, déplacés pour ne pas entrer en conflit avec le collecteur) | 127.0.0.1 | non |
| Grafana | 3000 | 0.0.0.0 | **oui** (consultation) |
| node_exporter | 9100 | 0.0.0.0 | oui (scrape local ; utile si un autre collecteur est ajouté) |

> Mimir, Loki et Tempo écoutent tous en gRPC par défaut sur 9095 : on les sépare (9097, 9096, 9095). Seuls Grafana et le collecteur sont joignables depuis le réseau du lab.

---
## 2. Étape 1 – Téléchargement depuis le poste Windows

```mermaid
flowchart LR
  A1[2.1 Poste Windows<br/>curl.exe, tar.exe, OpenSSH client] --> A2[2.2 Inventaire<br/>24 fichiers + 4 pour l'ISO]
  A2 --> A3[2.3 Motifs d'URL vérifiés]
  A3 --> A4[2.4 Telecharger-LGTM.ps1<br/>versions épinglées en tête]
  A4 --> A5[2.5 Dépendances Debian<br/>adduser, systemd]
  A5 --> A6[2.6 Manifeste SHA-256<br/>+ archive .tar]
  A6 --> A7[2.7 Transfert scp / sftp / WinSCP]
  A7 --> A8[2.8 Sur Linux : sha256sum -c,<br/>empreintes amont, sqv GPG]
```

Le poste Windows **ne fait que télécharger, empaqueter et copier**. Il ne vérifie rien : le manifeste qu'il produit sert seulement à prouver, côté Linux, que le transfert n'a rien altéré. Les vérifications d'authenticité (empreintes publiées par chaque projet, signatures GPG) se font **sur Linux** en section 2.8.

### 2.1 Prérequis du poste Windows

- Windows 10 1809 ou plus récent, ou Windows 11 : `curl.exe` et `tar.exe` sont fournis avec le système ([curl et tar dans Windows](https://curl.se/windows/microsoft.html)), ainsi que le client OpenSSH (`scp.exe`, `sftp.exe`) ([OpenSSH pour Windows](https://learn.microsoft.com/en-us/windows-server/administration/openssh/openssh_install_firstuse)). WinSCP convient aussi pour le transfert.
- Accès HTTPS (proxy accepté) à : `github.com` et `objects.githubusercontent.com` / `release-assets.githubusercontent.com` (redirections des releases), `dl.grafana.com`, `apt.grafana.com`, `deb.debian.org`, `cdimage.debian.org` (et ses miroirs de redirection), `keyring.debian.org`.
- Espace disque : ≈ **0,9 Go** pour `C:\lgtm-telechargement`, ≈ **0,8 Go** pour `C:\lgtm-iso`, et autant pour l'archive `.tar` (≈ 0,9 Go). Prévoir **3 Go** libres.
- Analyse antivirus des dossiers selon ta politique habituelle.

### 2.2 Inventaire des fichiers

**Lot obs-lgtm et agents** (`C:\lgtm-telechargement`, 24 fichiers, ≈ 925 Mo) :

| # | Dossier | Fichier | Taille | Rôle | Vérification sur Linux (§2.8) |
|---|---|---|---|---|---|
| 1 | `grafana` | `grafana_13.2.4_38252365904_linux_amd64.deb` | 381 Mo | Grafana OSS | empreinte runbook + `.sha256` + index APT signé |
| 2 | `grafana` | `grafana_13.2.4_38252365904_linux_amd64.deb.sha256` | 65 o | empreinte publiée | – |
| 3 | `grafana` | `gpg-full.key` | 8 Ko | clés publiques du dépôt APT Grafana | empreinte de clé `B53AE77BADB630A683046005963FA27710458545` |
| 4 | `grafana-apt` | `InRelease` | 8 Ko | index du dépôt, **signé** | `sqv` avec `gpg-full.key` |
| 5 | `grafana-apt` | `Packages.gz` | 428 Ko | liste des paquets et SHA-256 | empreinte lue dans `InRelease` |
| 6 | `mimir` | `mimir-3.2.3_amd64.deb` | 38 Mo | Mimir | empreinte runbook + `-sha-256` + index APT signé |
| 7 | `mimir` | `mimir-3.2.3_amd64.deb-sha-256` | 65 o | empreinte publiée | – |
| 8 | `mimir` | `mimirtool_3.2.3_amd64.deb` | 29 Mo | outil CLI (règles, contrôles) | empreinte runbook + `-sha-256` + index APT signé |
| 9 | `mimir` | `mimirtool_3.2.3_amd64.deb-sha-256` | 65 o | empreinte publiée | – |
| 10 | `loki` | `loki_3.7.9_amd64.deb` | 47 Mo | Loki | empreinte runbook + index APT signé |
| 11 | `loki` | `SHA256SUMS` | 3 Ko | empreintes de la release (zip seulement) | conservé pour traçabilité |
| 12 | `tempo` | `tempo_3.1.1_linux_amd64.deb` | 73 Mo | Tempo | empreinte runbook + `SHA256SUMS` + index APT signé |
| 13 | `tempo` | `SHA256SUMS` | 1 Ko | empreintes de la release | – |
| 14 | `prometheus` | `prometheus-3.15.1.linux-amd64.tar.gz` | 112 Mo | Prometheus (mode agent), `promtool` | empreinte runbook + `sha256sums.txt` |
| 15 | `prometheus` | `sha256sums.txt` | 4 Ko | empreintes de la release | – |
| 16 | `node_exporter` | `node_exporter-1.12.1.linux-amd64.tar.gz` | 12 Mo | métriques système Linux | empreinte runbook + `sha256sums.txt` |
| 17 | `node_exporter` | `sha256sums.txt` | 2 Ko | empreintes de la release | – |
| 18 | `otelcol-contrib` | `otelcol-contrib_0.164.0_linux_amd64.deb` | 116 Mo | collecteur (obs-lgtm et agent ELK) | empreinte runbook + `.sha256` |
| 19 | `otelcol-contrib` | `otelcol-contrib_0.164.0_linux_amd64.deb.sha256` | 64 o | empreinte publiée | – |
| 20 | `windows` | `otelcol-contrib_0.164.0_windows_x64.msi` | 103 Mo | agent du DC (service Windows) | empreinte runbook + `.sha256` |
| 21 | `windows` | `otelcol-contrib_0.164.0_windows_x64.msi.sha256` | 64 o | empreinte publiée | – |
| 22 | `windows` | `windows_exporter-0.32.0-amd64.msi` | 15 Mo | métriques du DC (service Windows) | empreinte runbook + `sha256sums.txt` |
| 23 | `windows` | `sha256sums.txt` | 404 o | empreintes de la release | – |
| 24 | `debian` | `adduser_3.152_all.deb` | 191 Ko | dépendance de secours (§2.5) | empreinte runbook (index Debian signé) |

Le script ajoute `MANIFEST-SHA256.txt` à la racine du dossier (25ᵉ fichier).

**Lot ISO** (`C:\lgtm-iso`, 4 fichiers, ≈ 793 Mo) : `debian-13.7.0-amd64-netinst.iso` (793 Mo), `SHA256SUMS`, `SHA256SUMS.sign`, `debian-cd-signing-key.asc` (clé publique « Debian CD signing key », empreinte `DF9B 9C49 EAA9 2984 3258 9D76 DA87 E80D 6294 BE9B`, publiée sur [debian.org/CD/verify](https://www.debian.org/CD/verify)). Il est vérifié sur la VM ELK, qui existe déjà (§2.7).

### 2.3 Motifs d'URL (vérifiés le 28 oct. 2026)

Chaque URL ci-dessous a répondu `200` et le fichier téléchargé correspond à l'empreinte publiée.

| Projet | Motif | Remarque |
|---|---|---|
| Grafana | `https://dl.grafana.com/grafana/release/<V>/grafana_<V>_<BUILD>_linux_amd64.deb` (+ `.sha256`) | Depuis Grafana 12.2.0 (constat sur l’API publique), le nom contient un **numéro de build**. Il se lit dans l'API publique `https://grafana.com/api/downloads/grafana/versions/<V>` (champ `url` du paquet `deb`/`amd64`), ou sur la page de téléchargement. L'ancien motif `dl.grafana.com/oss/release/grafana_<V>_amd64.deb` répond encore, mais n'est pas utilisé ici. |
| Dépôt APT Grafana | `https://apt.grafana.com/dists/stable/InRelease`, `.../main/binary-amd64/Packages.gz`, clé `https://apt.grafana.com/gpg-full.key` | `InRelease` est régénéré chaque jour : télécharge `InRelease` et `Packages.gz` **ensemble** (le script le fait). |
| Mimir | `https://github.com/grafana/mimir/releases/download/mimir-<V>/mimir-<V>_amd64.deb` (+ `-sha-256`), `.../mimirtool_<V>_amd64.deb` (+ `-sha-256`) | Le tag est `mimir-<V>` (pas `v<V>`) ; le paquet `mimir` utilise un tiret, `mimirtool` un souligné. |
| Loki | `https://github.com/grafana/loki/releases/download/v<V>/loki_<V>_amd64.deb`, `.../SHA256SUMS` | `SHA256SUMS` ne liste que les `.zip` : le `.deb` est vérifié par l'index APT signé et par l'empreinte du runbook. |
| Tempo | `https://github.com/grafana/tempo/releases/download/v<V>/tempo_<V>_linux_amd64.deb`, `.../SHA256SUMS` | |
| Prometheus | `https://github.com/prometheus/prometheus/releases/download/v<V>/prometheus-<V>.linux-amd64.tar.gz`, `.../sha256sums.txt` | |
| node_exporter | `https://github.com/prometheus/node_exporter/releases/download/v<V>/node_exporter-<V>.linux-amd64.tar.gz`, `.../sha256sums.txt` | |
| OTel Collector | `https://github.com/open-telemetry/opentelemetry-collector-releases/releases/download/v<V>/otelcol-contrib_<V>_linux_amd64.deb` et `..._windows_x64.msi` (+ `.sha256` chacun) | Les fichiers `.sigstore.json` (Sigstore/cosign) existent aussi ; ils exigent `cosign`, non disponible hors ligne ici. |
| windows_exporter | `https://github.com/prometheus-community/windows_exporter/releases/download/v<V>/windows_exporter-<V>-amd64.msi`, `.../sha256sums.txt` | |
| Debian (paquet) | `https://deb.debian.org/debian/pool/main/<initiale>/<source>/<paquet>_<version>_<arch>.deb` | Chemin exact et SHA-256 lisibles sur `https://packages.debian.org/trixie/amd64/<paquet>/download`. |
| Debian (ISO) | `https://cdimage.debian.org/cdimage/release/<V>/amd64/iso-cd/debian-<V>-amd64-netinst.iso`, `SHA256SUMS`, `SHA256SUMS.sign` | Le chemin `release/<V>` reste stable, contrairement à `current/`. |

### 2.4 Script PowerShell `Telecharger-LGTM.ps1`

Enregistre ce script dans un dossier de travail (par exemple `C:\lgtm-scripts\Telecharger-LGTM.ps1`), puis lance-le **sans élévation** :

```powershell
cd C:\lgtm-scripts
powershell -ExecutionPolicy Bypass -File .\Telecharger-LGTM.ps1
# Option : ne pas retélécharger l'ISO
powershell -ExecutionPolicy Bypass -File .\Telecharger-LGTM.ps1 -SansIso
```

```powershell
<#
  Telecharger-LGTM.ps1 - Étape 1 du runbook LGTM hors ligne (Debian 13 amd64)
  Rôle : TÉLÉCHARGER SEULEMENT. Aucune installation, aucune configuration.
  Sortie : C:\lgtm-telechargement (paquets obs-lgtm, agents ELK et DC)
           C:\lgtm-iso            (ISO Debian 13 pour créer la VM obs-lgtm)
  Utilisation (PowerShell, utilisateur standard) :
    powershell -ExecutionPolicy Bypass -File .\Telecharger-LGTM.ps1
#>
param(
  [string]$Racine   = 'C:\lgtm-telechargement',
  [string]$RacineIso = 'C:\lgtm-iso',
  [switch]$SansIso
)
$ErrorActionPreference = 'Stop'
$ProgressPreference    = 'SilentlyContinue'

# ---------- Versions épinglées (vérifiées le 28 oct. 2026) ----------
$GRAFANA_VERSION = '13.2.4'; $GRAFANA_BUILD = '38252365904'   # numéro de build inclus dans le nom du .deb
$MIMIR_VERSION   = '3.2.3'
$LOKI_VERSION    = '3.7.9'
$TEMPO_VERSION   = '3.1.1'
$PROM_VERSION    = '3.15.1'
$NODEEXP_VERSION = '1.12.1'
$OTELCOL_VERSION = '0.164.0'
$WINEXP_VERSION  = '0.32.0'
$DEBIAN_VERSION  = '13.7.0'
$ADDUSER_VERSION = '3.152'

$GH   = 'https://github.com'
$OTEL = "$GH/open-telemetry/opentelemetry-collector-releases/releases/download/v$OTELCOL_VERSION"

# D = sous-dossier, U = URL, N = nom local (seulement si l'URL ne se termine pas par le nom du fichier)
$Fichiers = @(
  # Grafana OSS (.deb + empreinte publiée + clé de signature du dépôt APT)
  @{ D='grafana'; U="https://dl.grafana.com/grafana/release/$GRAFANA_VERSION/grafana_${GRAFANA_VERSION}_${GRAFANA_BUILD}_linux_amd64.deb" }
  @{ D='grafana'; U="https://dl.grafana.com/grafana/release/$GRAFANA_VERSION/grafana_${GRAFANA_VERSION}_${GRAFANA_BUILD}_linux_amd64.deb.sha256" }
  @{ D='grafana'; U='https://apt.grafana.com/gpg-full.key' }
  # Index signé du dépôt APT Grafana : sert à la vérification GPG hors ligne (Grafana, Mimir, Loki, Tempo)
  @{ D='grafana-apt'; U='https://apt.grafana.com/dists/stable/InRelease' }
  @{ D='grafana-apt'; U='https://apt.grafana.com/dists/stable/main/binary-amd64/Packages.gz' }
  # Grafana Mimir (mode monolithique) + mimirtool
  @{ D='mimir'; U="$GH/grafana/mimir/releases/download/mimir-$MIMIR_VERSION/mimir-${MIMIR_VERSION}_amd64.deb" }
  @{ D='mimir'; U="$GH/grafana/mimir/releases/download/mimir-$MIMIR_VERSION/mimir-${MIMIR_VERSION}_amd64.deb-sha-256" }
  @{ D='mimir'; U="$GH/grafana/mimir/releases/download/mimir-$MIMIR_VERSION/mimirtool_${MIMIR_VERSION}_amd64.deb" }
  @{ D='mimir'; U="$GH/grafana/mimir/releases/download/mimir-$MIMIR_VERSION/mimirtool_${MIMIR_VERSION}_amd64.deb-sha-256" }
  # Loki
  @{ D='loki'; U="$GH/grafana/loki/releases/download/v$LOKI_VERSION/loki_${LOKI_VERSION}_amd64.deb" }
  @{ D='loki'; U="$GH/grafana/loki/releases/download/v$LOKI_VERSION/SHA256SUMS" }
  # Tempo
  @{ D='tempo'; U="$GH/grafana/tempo/releases/download/v$TEMPO_VERSION/tempo_${TEMPO_VERSION}_linux_amd64.deb" }
  @{ D='tempo'; U="$GH/grafana/tempo/releases/download/v$TEMPO_VERSION/SHA256SUMS" }
  # Prometheus (utilisé en mode agent : collecte + remote_write vers Mimir)
  @{ D='prometheus'; U="$GH/prometheus/prometheus/releases/download/v$PROM_VERSION/prometheus-$PROM_VERSION.linux-amd64.tar.gz" }
  @{ D='prometheus'; U="$GH/prometheus/prometheus/releases/download/v$PROM_VERSION/sha256sums.txt" }
  # node_exporter (obs-lgtm et VM ELK)
  @{ D='node_exporter'; U="$GH/prometheus/node_exporter/releases/download/v$NODEEXP_VERSION/node_exporter-$NODEEXP_VERSION.linux-amd64.tar.gz" }
  @{ D='node_exporter'; U="$GH/prometheus/node_exporter/releases/download/v$NODEEXP_VERSION/sha256sums.txt" }
  # OpenTelemetry Collector contrib (façade sur obs-lgtm, agent sur la VM ELK)
  @{ D='otelcol-contrib'; U="$OTEL/otelcol-contrib_${OTELCOL_VERSION}_linux_amd64.deb" }
  @{ D='otelcol-contrib'; U="$OTEL/otelcol-contrib_${OTELCOL_VERSION}_linux_amd64.deb.sha256" }
  # Agents Windows pour le DC
  @{ D='windows'; U="$OTEL/otelcol-contrib_${OTELCOL_VERSION}_windows_x64.msi" }
  @{ D='windows'; U="$OTEL/otelcol-contrib_${OTELCOL_VERSION}_windows_x64.msi.sha256" }
  @{ D='windows'; U="$GH/prometheus-community/windows_exporter/releases/download/v$WINEXP_VERSION/windows_exporter-$WINEXP_VERSION-amd64.msi" }
  @{ D='windows'; U="$GH/prometheus-community/windows_exporter/releases/download/v$WINEXP_VERSION/sha256sums.txt" }
  # Dépendance Debian de secours (normalement déjà installée : priorité « important »)
  @{ D='debian'; U="https://deb.debian.org/debian/pool/main/a/adduser/adduser_${ADDUSER_VERSION}_all.deb" }
)
$FichiersIso = @(
  @{ D=''; U="https://cdimage.debian.org/cdimage/release/$DEBIAN_VERSION/amd64/iso-cd/debian-$DEBIAN_VERSION-amd64-netinst.iso" }
  @{ D=''; U="https://cdimage.debian.org/cdimage/release/$DEBIAN_VERSION/amd64/iso-cd/SHA256SUMS" }
  @{ D=''; U="https://cdimage.debian.org/cdimage/release/$DEBIAN_VERSION/amd64/iso-cd/SHA256SUMS.sign" }
  @{ D=''; U='https://keyring.debian.org/pks/lookup?op=get&search=0xDA87E80D6294BE9B'; N='debian-cd-signing-key.asc' }
)

function Get-Lot([string]$Base, $Liste) {
  foreach ($f in $Liste) {
    $dir = if ($f.D) { Join-Path $Base $f.D } else { $Base }
    New-Item -ItemType Directory -Force -Path $dir | Out-Null
    $nom  = if ($f.N) { $f.N } else { [uri]::UnescapeDataString(($f.U -split '/')[-1]) }
    $dest = Join-Path $dir $nom
    if ((Test-Path $dest) -and ((Get-Item $dest).Length -gt 0)) { Write-Host "déjà présent : $nom"; continue }
    Write-Host "téléchargement : $nom"
    # curl.exe est fourni avec Windows 10 1803+ et Windows 11 ; plus rapide qu'Invoke-WebRequest pour les gros fichiers
    & curl.exe --fail --location --retry 3 --silent --show-error --output $dest $f.U
    if ($LASTEXITCODE -ne 0) {
      Remove-Item -Force -ErrorAction SilentlyContinue $dest
      throw "Échec du téléchargement : $($f.U)"
    }
  }
}

function Write-Manifeste([string]$Base) {
  # Manifeste au format sha256sum (minuscules, 2 espaces, chemin relatif avec /), fins de ligne LF
  $m = Join-Path $Base 'MANIFEST-SHA256.txt'
  $lignes = Get-ChildItem -Path $Base -Recurse -File |
    Where-Object { $_.Name -ne 'MANIFEST-SHA256.txt' } |
    Sort-Object FullName | ForEach-Object {
      $h   = (Get-FileHash -Algorithm SHA256 -Path $_.FullName).Hash.ToLower()
      $rel = $_.FullName.Substring((Resolve-Path $Base).Path.TrimEnd('\','/').Length + 1).Replace('\','/')
      "$h  $rel"
    }
  [IO.File]::WriteAllText($m, (($lignes -join "`n") + "`n"))
  Write-Host "manifeste : $m ($($lignes.Count) fichiers)"
}

Get-Lot $Racine $Fichiers
Write-Manifeste $Racine
if (-not $SansIso) { Get-Lot $RacineIso $FichiersIso; Write-Manifeste $RacineIso }

# Archive unique pour le transfert (tar.exe est fourni avec Windows 10 1803+) ; Linux l'ouvre avec tar, sans unzip
$Archive = Join-Path (Split-Path $Racine -Parent) ("lgtm-bundle-{0}.tar" -f (Get-Date -Format 'yyyyMMdd'))
& tar.exe -cf $Archive -C (Split-Path $Racine -Parent) (Split-Path $Racine -Leaf)
if ($LASTEXITCODE -ne 0) { throw "Échec de tar.exe" }
$hA = (Get-FileHash -Algorithm SHA256 -Path $Archive).Hash.ToLower()
[IO.File]::WriteAllText("$Archive.sha256", "$hA  $(Split-Path $Archive -Leaf)`n")
Write-Host "archive : $Archive"
Write-Host "SHA-256 : $hA   (à comparer sur Linux, transfert seulement)"

```

Comportement :
- les versions sont des **variables en tête** du script ; changer une version suffit à changer les URL ;
- un fichier déjà présent et non vide n'est pas retéléchargé (relance possible après une coupure) ;
- `curl.exe --fail` arrête le script dès qu'une URL ne répond pas `200` ; le fichier partiel est supprimé ;
- `UnescapeDataString` redonne le vrai nom des fichiers dont l'URL contient `%2b` (`+`) ;
- le manifeste est écrit en UTF-8 sans BOM, avec des fins de ligne LF : `sha256sum -c` le lit directement sous Linux.

> **Test réalisé le 28 oct. 2026 :** le script a été exécuté avec PowerShell 7 sous Linux (avec `curl` et `tar` à la place de `curl.exe` et `tar.exe`). Il a produit 24 + 4 fichiers, le manifeste et l'archive, et toutes les vérifications de la section 2.8 ont réussi. Il n'a **pas** été exécuté sous Windows PowerShell 5.1 sur un vrai poste Windows (voir l'annexe A).

### 2.5 Dépendances Debian des paquets

Contrôle fait le 28 oct. 2026 en lisant le champ `Depends` de chaque `.deb` (`dpkg-deb -I`) :

| Paquet | `Depends` | Présent sur Debian 13 standard ? |
|---|---|---|
| `grafana` 13.2.4 | `adduser, systemd` | Oui : `adduser` (priorité *important*) et `systemd` sont installés par défaut et figurent sur l'ISO netinst 13.7.0. |
| `mimir`, `mimirtool`, `loki`, `tempo`, `otelcol-contrib` | aucun | – (binaires Go statiques). Les scripts `postinst` de Loki et Tempo appellent `adduser`. |

Les anciennes versions de Grafana dépendaient de `libfontconfig1` et `musl` ; ce n'est **plus le cas** pour la 13.2.4. Le lot contient tout de même `adduser_3.152_all.deb` (version de trixie, SHA-256 lu dans l'index Debian signé) en secours.

À faire **sur obs-lgtm** avant l'installation (section 4.1) :

```bash
dpkg-query -W -f='${Package} ${Version} ${Status}\n' adduser systemd sqv wget 2>/dev/null
# Contrôle préalable : dpkg simule l'installation et liste ce qui manquerait (aucune modification)
dpkg --dry-run -i /var/tmp/lgtm-telechargement/grafana/grafana_*.deb
```

Si un paquet manque (installation Debian minimale non standard), méthode hors ligne :
1. Sur Windows, ouvre `https://packages.debian.org/trixie/amd64/<paquet>/download` (ou `.../all/...` pour un paquet `Architecture: all`). La page donne le chemin `pool/main/...` et le **SHA-256** du fichier.
2. Ajoute l'URL `https://deb.debian.org/debian/pool/main/...` au tableau `$Fichiers` du script (dossier `debian`) et ajoute l'empreinte à `lgtm-sha256-attendus` (§2.8).
3. Répète pour chaque dépendance listée dans la section « dépendances » de la page du paquet, tant que `dpkg --dry-run -i` signale un manque.
4. Sur Linux : `dpkg -i /var/tmp/lgtm-telechargement/debian/*.deb` **avant** les paquets LGTM.

> `apt-get download` n'est pas utilisable ici : il faudrait une machine Debian connectée, et seul le poste Windows a Internet.

### 2.6 Manifeste et archive

Le script produit :
- `C:\lgtm-telechargement\MANIFEST-SHA256.txt` et `C:\lgtm-iso\MANIFEST-SHA256.txt` : une ligne `<sha256>  <chemin relatif>` par fichier, calculée avec `Get-FileHash -Algorithm SHA256` ([Get-FileHash](https://learn.microsoft.com/en-us/powershell/module/microsoft.powershell.utility/get-filehash)) ;
- `C:\lgtm-bundle-AAAAMMJJ.tar` : archive `tar` du dossier `lgtm-telechargement` (avec son manifeste), et `C:\lgtm-bundle-AAAAMMJJ.tar.sha256`.

Pourquoi `.tar` plutôt que `.zip` : `tar` est présent sur toute installation Debian, alors que `unzip` n'est pas installé par défaut. `Compress-Archive` n'est donc pas utilisé.

> Le manifeste **ne prouve pas l'authenticité** (il est calculé sur le poste Windows). Il prouve seulement que les fichiers reçus sous Linux sont identiques à ceux du poste Windows. L'authenticité vient des empreintes amont et des signatures (§2.8).

### 2.7 Transfert (OpenSSH, WinSCP)

**1) ISO Debian vers la VM ELK** (pour la vérifier sur Linux avant de créer obs-lgtm) :

```powershell
scp.exe -r C:\lgtm-iso admin@<ip-elk>:/var/tmp/
```

**2) Archive vers obs-lgtm**, une fois la VM installée (section 3.5) :

```powershell
scp.exe C:\lgtm-bundle-20261028.tar C:\lgtm-bundle-20261028.tar.sha256 admin@<ip-obs-lgtm>:/var/tmp/
```

Équivalent `sftp.exe` :

```text
sftp.exe admin@<ip-obs-lgtm>
sftp> put C:/lgtm-bundle-20261028.tar /var/tmp/
sftp> put C:/lgtm-bundle-20261028.tar.sha256 /var/tmp/
sftp> bye
```

**WinSCP :** glisse les fichiers vers `/var/tmp/`, en mode de transfert **binaire**. En script : `open sftp://admin@<ip-obs-lgtm>/ -hostkey="<empreinte de la clé d'hôte>"`, `put -transfer=binary C:\lgtm-bundle-20261028.tar /var/tmp/`, `exit`.

- Vérifie l'empreinte de la clé d'hôte SSH à la première connexion (`ssh-keygen -lf /etc/ssh/ssh_host_ed25519_key.pub` sur la VM, lu dans la console Hyper-V).
- `admin` est un compte non root créé à l'installation de Debian ; les commandes de la section 4 se font ensuite avec `sudo -i`.
- **3) Agents Windows vers le DC :** les deux `.msi` sont copiés du poste Windows vers le DC (partage administratif ou session RDP) **après** leur vérification sur obs-lgtm (§2.8), puis contrôlés sur le DC (§5.2).

### 2.8 Vérification sur Linux

#### 2.8.1 ISO Debian (sur la VM ELK)

```bash
cd /var/tmp/lgtm-iso
sha256sum -c --strict MANIFEST-SHA256.txt                     # copie identique au fichier du poste Windows
sqv --keyring=debian-cd-signing-key.asc --signature-file=SHA256SUMS.sign SHA256SUMS
# attendu : DF9B9C49EAA9298432589D76DA87E80D6294BE9B   (clé « Debian CD signing key »)
sha256sum --ignore-missing -c SHA256SUMS                      # attendu : debian-13.7.0-amd64-netinst.iso: OK
```

`sqv` (Sequoia) est installé sur toute Debian 13, car `apt` en dépend ; il lit directement la clé téléchargée depuis `keyring.debian.org`, même si elle est enveloppée dans une page HTML. Comme le manifeste est conforme, l'ISO **restée sur le poste Windows** est identique à celle qui vient d'être vérifiée : c'est elle qu'on monte dans Hyper-V (section 3.5). Ensuite : `rm -rf /var/tmp/lgtm-iso`.

#### 2.8.2 Lot obs-lgtm (sur obs-lgtm)

```bash
sudo -i
cd /var/tmp
sha256sum -c lgtm-bundle-*.tar.sha256          # transfert de l'archive
tar xf lgtm-bundle-*.tar                        # crée /var/tmp/lgtm-telechargement
```

Écris les **empreintes amont** à partir de ce runbook (elles ne voyagent pas avec les fichiers). Elles viennent des fichiers d'empreintes publiés, du champ `digest` des releases GitHub, de l'index APT Grafana signé et de l'index Debian signé, et ont été recalculées sur les fichiers téléchargés le 28 oct. 2026 :

```bash
cat > /var/tmp/lgtm-sha256-attendus <<'EOF2'
f32ba4e166e35a376f39cbeb8dd47c57f7bf608b09339cb41adf6d39082af3c5  grafana/grafana_13.2.4_38252365904_linux_amd64.deb
db81814dad58ca1e2aafba05fcaecfe678717546d886b8f5c31a4d73923ee521  mimir/mimir-3.2.3_amd64.deb
7f80c96bc2f1943c724348f9d8ad6e2d995a12a88ee40617a8284fe6aff90793  mimir/mimirtool_3.2.3_amd64.deb
9647b50011ea4eb6d44b82bf708b3eb4fa5d837b33a52741cdda5f912f6cd45d  loki/loki_3.7.9_amd64.deb
79f3f8385ec4cf83ca79979e5da3258994791781281ae3be9abff0968b64fb26  tempo/tempo_3.1.1_linux_amd64.deb
6a726885328ad9efebbf36e876ce2fb6225468a71fd1e7ce3ba666d5f4d97a84  prometheus/prometheus-3.15.1.linux-amd64.tar.gz
b51d8a76aa2a9156a55d501aca6276fae09e262259a5e4e831d2c2222f084e63  node_exporter/node_exporter-1.12.1.linux-amd64.tar.gz
1995260c54cf5d74964a85e5e7d27834bb9a252c87a2582a4fb6a6c34565a90d  otelcol-contrib/otelcol-contrib_0.164.0_linux_amd64.deb
dcdae63474a3bb0b9bb09d869e4f6ddb5a0e22d1ed5cf299454336d69a69292b  windows/otelcol-contrib_0.164.0_windows_x64.msi
d48ebad7999aac5603fe01007016a0ddbcecbc1aa0ecbc51867a2416b6c60a7d  windows/windows_exporter-0.32.0-amd64.msi
e50984d2e1ef6300e3fd51303839842189a077b10cb5cadff1923df10c61c493  debian/adduser_3.152_all.deb
EOF2
```

Puis le script de vérification (écrit lui aussi sur le serveur) :

```bash
cat > /var/tmp/verifier-lgtm.sh <<'EOF2'
#!/bin/bash
# verifier-lgtm.sh - vérification hors ligne du lot LGTM (à lancer sur obs-lgtm, dans le dossier lgtm-telechargement)
# Usage : cd /var/tmp/lgtm-telechargement && bash /var/tmp/verifier-lgtm.sh
set -u
ECHEC=0
ok(){ printf '  [OK]    %s\n' "$1"; }
ko(){ printf '  [ECHEC] %s\n' "$1"; ECHEC=1; }

echo "1) Intégrité du transfert (manifeste produit sous Windows)"
sha256sum -c --strict --quiet MANIFEST-SHA256.txt && ok "MANIFEST-SHA256.txt" || ko "MANIFEST-SHA256.txt"

echo "2) Empreintes amont épinglées dans le runbook (écrites sur le serveur, pas transférées)"
sha256sum -c --strict --quiet /var/tmp/lgtm-sha256-attendus && ok "lgtm-sha256-attendus" || ko "lgtm-sha256-attendus"

echo "3) Recoupement avec les fichiers d'empreintes publiés par chaque projet"
for d in prometheus node_exporter tempo windows; do
  f=$(ls "$d"/SHA256SUMS "$d"/sha256sums.txt 2>/dev/null | head -1)
  (cd "$d" && sha256sum --ignore-missing --strict --quiet -c "$(basename "$f")") && ok "$d/$(basename "$f")" || ko "$d/$(basename "$f")"
done
# Fichiers d'empreinte « valeur seule » (sans nom de fichier) : Grafana .sha256, Mimir -sha-256, OTel .sha256
for s in grafana/*.deb.sha256 mimir/*-sha-256 otelcol-contrib/*.sha256 windows/*.msi.sha256; do
  cible="${s%.sha256}"; cible="${cible%-sha-256}"
  echo "$(tr -d ' \r\n' < "$s")  $cible" | sha256sum -c --strict --quiet && ok "$s" || ko "$s"
done

echo "4) Chaîne GPG du dépôt APT Grafana (InRelease signé -> Packages.gz -> .deb)"
EMPREINTE_GRAFANA=B53AE77BADB630A683046005963FA27710458545
rm -f /tmp/InRelease.verifie   # sqv refuse d'écraser un fichier de sortie existant
signataire=$(sqv --keyring=grafana/gpg-full.key --cleartext --output=/tmp/InRelease.verifie grafana-apt/InRelease 2>/dev/null)
[ "$signataire" = "$EMPREINTE_GRAFANA" ] && ok "InRelease signé par $signataire" || ko "signature InRelease (obtenu : '${signataire}')"
attendu=$(awk '/^SHA256:/{f=1;next} /^[A-Za-z]/{f=0} f && $3=="main/binary-amd64/Packages.gz"{print $1}' /tmp/InRelease.verifie)
echo "$attendu  grafana-apt/Packages.gz" | sha256sum -c --strict --quiet && ok "Packages.gz conforme à InRelease" || ko "Packages.gz"
zcat grafana-apt/Packages.gz | awk 'BEGIN{RS="";FS="\n"} {fn="";sh=""; for(i=1;i<=NF;i++){if($i~/^Filename: /)fn=substr($i,11); if($i~/^SHA256: /)sh=substr($i,9)} n=split(fn,a,"/"); if(sh!="") print sh"  "a[n]}' > /tmp/grafana-apt-sha256
for deb in grafana/grafana_*.deb mimir/mimir-*.deb mimir/mimirtool_*.deb loki/loki_*.deb tempo/tempo_*.deb; do
  b=$(basename "$deb"); h=$(awk -v n="$b" '$2==n{print $1; exit}' /tmp/grafana-apt-sha256)
  [ -n "$h" ] && echo "$h  $deb" | sha256sum -c --strict --quiet && ok "$b (index APT signé)" || ko "$b absent ou différent dans l'index APT signé"
done

echo
[ "$ECHEC" -eq 0 ] && echo "RÉSULTAT : tout est conforme, l'installation peut commencer." || { echo "RÉSULTAT : au moins une vérification a échoué. NE RIEN INSTALLER."; exit 1; }
EOF2
cd /var/tmp/lgtm-telechargement && bash /var/tmp/verifier-lgtm.sh
```

Résultat attendu (extrait) :

```text
4) Chaîne GPG du dépôt APT Grafana (InRelease signé -> Packages.gz -> .deb)
  [OK]    InRelease signé par B53AE77BADB630A683046005963FA27710458545
  [OK]    Packages.gz conforme à InRelease
  [OK]    grafana_13.2.4_38252365904_linux_amd64.deb (index APT signé)
  ...
RÉSULTAT : tout est conforme, l'installation peut commencer.
```

- La **chaîne GPG** : `InRelease` est signé par la clé du dépôt Grafana ; il contient l'empreinte de `Packages.gz`, qui contient à son tour l'empreinte de chaque `.deb` (`grafana`, `mimir`, `mimirtool`, `loki`, `tempo`). Un `.deb` modifié casse la chaîne.
- **Contrôle de la clé :** l'empreinte `B53AE77BADB630A683046005963FA27710458545` (clé « Grafana Labs », créée le 2023-08-24, expire le 2027-08-22) est celle qui signait `InRelease` le 28 oct. 2026. Si `sqv` affiche une autre empreinte, arrête-toi et compare avec la [page d'installation Debian de Grafana](https://grafana.com/docs/grafana/latest/setup-grafana/installation/debian/).
- Un `[ECHEC]` : retélécharge le fichier concerné sous Windows ; ne corrige jamais une empreinte à la main. Le script a été testé aussi avec un `.deb` volontairement altéré : il signale l'échec à trois niveaux (manifeste, empreinte amont, index signé).
- Prometheus, node_exporter, otelcol-contrib et windows_exporter ne publient pas de signature GPG : leur vérification repose sur l'empreinte du runbook et sur le fichier d'empreintes de la release, tous deux obtenus en HTTPS.

Rangement (conservé pour les réinstallations et le retour arrière) :

```bash
test ! -e /opt/lgtm-bundle
install -d -o root -g root -m 0755 /opt/lgtm-bundle
cp -a /var/tmp/lgtm-telechargement/. /opt/lgtm-bundle/
cp /var/tmp/lgtm-sha256-attendus /var/tmp/verifier-lgtm.sh /opt/lgtm-bundle/
chmod -R go-w /opt/lgtm-bundle
```

---
## 3. Étape 2 – Restructuration de l'infrastructure du lab

### 3.1 Dimensionnement cible par VM

| VM | OS | Rôle | vCPU | RAM démarrage | RAM min / max (mémoire dynamique) | Disque | IP | État |
|---|---|---|---|---|---|---|---|---|
| **DC** | Windows Server (existant) | AD DS, DNS ; agents `windows_exporter` et `otelcol-contrib` (services Windows) | 1 | 2 Go | 1 Go / 2 Go | existant | `<ip-dc>` | Allumée |
| **ELK** | Debian 13 | Elasticsearch 9, Kibana, ElastAlert 2 ; Logstash jusqu'à la phase 3 ; agents `node_exporter` et `otelcol-contrib` | 2 | **4 Go** | **3 Go / 5 Go** | existant | `<ip-elk>` | Allumée jusqu'à la phase 6 |
| **AppDynamics** | existant | Contrôleur (conservé pour retour arrière) | inchangé | – | – | existant | – | **Éteinte** (`AutomaticStartAction Nothing`) |
| **obs-lgtm** (nouvelle) | Debian 13.7 | otelcol-contrib, Prometheus agent, **Mimir**, Loki, Tempo, Grafana, node_exporter | 2 | **4 Go** | **3 Go / 6 Go** | **60 Go** VHDX dynamique | `<ip-obs-lgtm>` | Nouvelle |
| **Total actif** | | | **5** | **10 Go** | **7 Go / 13 Go** | | | |

**Budget de l'hôte :** relève d'abord ses ressources (PowerShell admin) :

```powershell
Get-VMHost | Select-Object LogicalProcessorCount, @{n='RAM_Go';e={[math]::Round($_.MemoryCapacity/1GB,1)}}
Get-VM | Select-Object Name, State, ProcessorCount, @{n='Demarrage_Go';e={$_.MemoryStartup/1GB}}, DynamicMemoryEnabled
```

- Avec un hôte de **16 Go**, les 10 Go de démarrage laissent environ 6 Go à Windows et aux applications de l'hôte. Les maximums (13 Go) ne sont atteints que sous charge ; la mémoire dynamique redistribue la RAM selon la demande ([Dynamic Memory](https://learn.microsoft.com/en-us/windows-server/virtualization/hyper-v/dynamic-memory)).
- Avec un hôte de **8 à 12 Go**, garde ELK à 3 Go (valeurs du plan) et obs-lgtm à 4 Go, et n'allume pas ELK et obs-lgtm en même temps hors des phases de comparaison.
- 5 vCPU actifs conviennent à partir de 4 processeurs logiques sur l'hôte (les vCPU se partagent). Si l'hôte en a 8 ou plus, passer obs-lgtm à **4 vCPU** accélère le démarrage de Grafana et de Mimir.

### 3.2 Écarts avec le plan d'intégration (section 2 du plan) et justification

| Élément | Plan | Ce runbook | Raison |
|---|---|---|---|
| obs-lgtm, RAM | 3 Go (2–4 Go) | **4 Go (3–6 Go)** | Ajout de **Mimir** (le plan stockait les métriques dans Prometheus). Mesures au repos faites le 28 oct. 2026 sur l'environnement de test (pas sur Hyper-V) : Grafana 13.2 ≈ 360–380 Mo, otelcol-contrib ≈ 205 Mo, Mimir ≈ 150–215 Mo, Loki ≈ 160 Mo, Tempo ≈ 120–135 Mo, Prometheus agent ≈ 115–130 Mo. La limite de 256 Mo du plan pour Grafana et pour otelcol-contrib est trop basse. |
| obs-lgtm, disque | 40 Go | **60 Go** | Rétention Mimir 7 jours + Loki 72 h + Tempo 24 h + lot hors ligne conservé (`/opt/lgtm-bundle`, ≈ 0,9 Go). |
| ELK, RAM | 3 Go (2–4 Go) | **4 Go (3–5 Go)** | ElastAlert 2 et les deux agents (`node_exporter`, `otelcol-contrib`) s'ajoutent à Elasticsearch 9 (heap 1 Go), Kibana et Logstash. Revenir aux valeurs du plan est possible après l'arrêt de Logstash (phase 3). |
| Alertmanager | service autonome (64 Mo) | **supprimé** | Alertmanager intégré à Mimir. |
| Prometheus | serveur complet, rétention 3 jours | **mode agent** | Le stockage et les requêtes passent à Mimir. |
| Total démarrage | 8 Go | **10 Go** | +1 Go obs-lgtm, +1 Go ELK. |

Aucune autre VM n'est nécessaire : l'application de démonstration de la phase 4 s'installe sur une VM existante, comme dans le plan.

### 3.3 Topologie Hyper-V du lab

```mermaid
flowchart TB
  subgraph HOST[Hôte Hyper-V - vSwitch du lab - aucun accès Internet pour les VM Linux]
    DC["DC<br/>1 vCPU · 2 Go (1-2 Go)<br/>AD DS, DNS<br/>windows_exporter :9182, otelcol-contrib"]
    ELK["ELK - Debian 13<br/>2 vCPU · 4 Go (3-5 Go)<br/>ES 9 :9200, Kibana :5601, ElastAlert 2<br/>node_exporter :9100, otelcol-contrib"]
    OBS["obs-lgtm - Debian 13<br/>2 vCPU · 4 Go (3-6 Go) · 60 Go<br/>otelcol :4317/4318, Grafana :3000<br/>Mimir, Loki, Tempo, Prometheus agent (locaux)"]
    APPD["AppDynamics<br/>éteinte"]
  end
  WIN["Poste Windows connecté<br/>téléchargement seulement"]
  WIN -. "scp / sftp" .-> OBS
  WIN -. "scp (ISO)" .-> ELK
  DC -- "OTLP 4317 (journaux)" --> OBS
  ELK -- "OTLP 4317 (journaux)" --> OBS
  OBS -- "scrape 9182" --> DC
  OBS -- "scrape 9100" --> ELK
  OBS -. "double écriture 9200 (phases 1 à 3)" .-> ELK
  style APPD fill:#ddd,stroke:#999,stroke-dasharray: 5 5
  style OBS fill:#e6f4ea,stroke:#34a853
```

```mermaid
pie showData
  title RAM de démarrage par VM (Go) - total 10 Go
  "DC" : 2
  "ELK" : 4
  "obs-lgtm" : 4
```

### 3.4 Commandes Hyper-V (PowerShell en administrateur, sur l'hôte)

> Adapte les noms de VM (`Get-VM`) et le nom du vSwitch (`Get-VMSwitch`). Les changements de vCPU exigent une VM **arrêtée** ([Set-VMProcessor](https://learn.microsoft.com/en-us/powershell/module/hyper-v/set-vmprocessor)).

```powershell
# 0. Checkpoint de chaque VM avant toute modification
Get-VM | ForEach-Object { Checkpoint-VM -Name $_.Name -SnapshotName "avant-lgtm-$(Get-Date -Format yyyyMMdd)" }

# 1. AppDynamics : arrêt, pas de démarrage automatique
Stop-VM -Name "AppDynamics"
Set-VM  -Name "AppDynamics" -AutomaticStartAction Nothing

# 2. DC (inchangé par rapport au plan)
Stop-VM -Name "DC"
Set-VMProcessor -VMName "DC" -Count 1
Set-VMMemory    -VMName "DC" -DynamicMemoryEnabled $true -StartupBytes 2GB -MinimumBytes 1GB -MaximumBytes 2GB
Start-VM -Name "DC"

# 3. ELK (4 Go au démarrage, 3 à 5 Go)
Stop-VM -Name "ELK"
Set-VMProcessor -VMName "ELK" -Count 2
Set-VMMemory    -VMName "ELK" -DynamicMemoryEnabled $true -StartupBytes 4GB -MinimumBytes 3GB -MaximumBytes 5GB
Start-VM -Name "ELK"

# 4. Nouvelle VM obs-lgtm (génération 2, disque dynamique de 60 Go)
$Switch = "<vSwitch du lab>"
New-VM -Name "obs-lgtm" -Generation 2 -MemoryStartupBytes 4GB `
       -NewVHDPath "C:\Hyper-V\obs-lgtm\obs-lgtm.vhdx" -NewVHDSizeBytes 60GB -SwitchName $Switch
Set-VMProcessor -VMName "obs-lgtm" -Count 2
Set-VMMemory    -VMName "obs-lgtm" -DynamicMemoryEnabled $true -StartupBytes 4GB -MinimumBytes 3GB -MaximumBytes 6GB
Set-VMFirmware  -VMName "obs-lgtm" -SecureBootTemplate MicrosoftUEFICertificateAuthority
Add-VMDvdDrive  -VMName "obs-lgtm" -Path "C:\lgtm-iso\debian-13.7.0-amd64-netinst.iso"
Set-VMFirmware  -VMName "obs-lgtm" -FirstBootDevice (Get-VMDvdDrive -VMName "obs-lgtm")
Set-VM          -Name "obs-lgtm" -AutomaticCheckpointsEnabled $false -AutomaticStartAction Start
Start-VM -Name "obs-lgtm"
vmconnect.exe localhost "obs-lgtm"

# 5. Contrôle
Get-VM | Select-Object Name, State, ProcessorCount, @{n='Demarrage_Go';e={$_.MemoryStartup/1GB}}, @{n='Min_Go';e={$_.MemoryMinimum/1GB}}, @{n='Max_Go';e={$_.MemoryMaximum/1GB}}
```

- **Démarrage sécurisé :** une VM Linux de génération 2 doit utiliser le modèle « Microsoft UEFI Certificate Authority » ([Set-VMFirmware](https://learn.microsoft.com/en-us/powershell/module/hyper-v/set-vmfirmware)). Si l'installateur Debian ne démarre pas, la page Microsoft sur Debian indique de désactiver le démarrage sécurisé : `Set-VMFirmware -VMName "obs-lgtm" -EnableSecureBoot Off` ([Debian sur Hyper-V](https://learn.microsoft.com/en-us/windows-server/virtualization/hyper-v/supported-debian-virtual-machines-on-hyper-v)).
- La même page indique que la mémoire dynamique (ajout à chaud et *ballooning*) est prise en charge pour Debian.
- Références : [New-VM](https://learn.microsoft.com/en-us/powershell/module/hyper-v/new-vm), [Set-VMMemory](https://learn.microsoft.com/en-us/powershell/module/hyper-v/set-vmmemory), [Add-VMDvdDrive](https://learn.microsoft.com/en-us/powershell/module/hyper-v/add-vmdvddrive), [Checkpoint-VM](https://learn.microsoft.com/en-us/powershell/module/hyper-v/checkpoint-vm), [Set-VM](https://learn.microsoft.com/en-us/powershell/module/hyper-v/set-vm).

### 3.5 Installation de Debian 13 sur obs-lgtm (sans Internet)

Dans la console de la VM (`vmconnect`) :
1. **Install** (mode texte), langue et clavier (par exemple Français / Canada).
2. Réseau : configuration **manuelle** avec `<ip-obs-lgtm>`, masque, passerelle et DNS = `<ip-dc>`. Nom d'hôte `obs-lgtm`, domaine du lab.
3. Mot de passe root **vide** (le compte créé ensuite reçoit `sudo`), puis le compte `admin`.
4. Partitionnement guidé, disque entier (un seul système de fichiers suffit pour le lab).
5. **Miroir réseau : Non** (aucun accès Internet). L'installateur termine avec les paquets de l'ISO.
6. Sélection des logiciels : **décoche** l'environnement de bureau ; coche **serveur SSH** et **utilitaires usuels du système**. L'ISO netinst 13.7.0 contient notamment `openssh-server`, `sqv`, `wget`, `adduser` et `systemd` (liste officielle `debian-13.7.0-amd64-netinst.list.gz`).
7. Après le redémarrage : `Set-VMDvdDrive -VMName "obs-lgtm" -Path $null` sur l'hôte pour éjecter l'ISO.

Contrôles sur obs-lgtm, puis checkpoint :

```bash
cat /etc/debian_version        # attendu : 13.7
systemctl is-active ssh
timedatectl                    # l'heure doit être juste : les métriques et les traces sont horodatées
ls -d /var/log/journal 2>/dev/null || echo "journal non persistant (/run/log/journal)"
```

```powershell
Checkpoint-VM -Name "obs-lgtm" -SnapshotName "debian-13.7-installee"
```

> `curl` n'est **pas** sur l'ISO netinst : les commandes de contrôle de la section 4 utilisent `wget`, présent avec les utilitaires usuels. Si aucun serveur NTP n'est joignable, configure `systemd-timesyncd` vers le DC (`NTP=<ip-dc>` dans `/etc/systemd/timesyncd.conf`).

---
## 4. Étape 3 – Installation sur obs-lgtm (hors ligne, services systemd)

```mermaid
flowchart TB
  S1[4.1 Contrôles, comptes système] --> S2[4.2 dpkg -i des .deb<br/>puis arrêt des services auto-démarrés]
  S2 --> S3[4.3 Mimir] --> S4[4.4 Loki] --> S5[4.5 Tempo]
  S5 --> S6[4.6 Prometheus agent + node_exporter]
  S6 --> S7[4.7 otelcol-contrib<br/>secret ES saisi sans écho]
  S7 --> S8[4.8 Grafana + provisioning]
  S8 --> S9[4.9 Limites mémoire, journald]
  S9 --> S10[4.10 Démarrage ordonné, vérifications]
  S10 --> S11[4.11 Test de bout en bout, règles Mimir]
```

Toutes les commandes se font en `root` (`sudo -i`) sur obs-lgtm. Règle commune : **valider chaque configuration avant de (re)démarrer** le service.

| Outil | Commande de validation |
|---|---|
| Mimir | `mimir --config.file=/etc/mimir/config.yml -print.config >/dev/null && echo OK` |
| Alertmanager de Mimir | `mimirtool alertmanager verify /etc/mimir/alertmanager-fallback.yml` |
| Loki | `loki -config.file=/etc/loki/config.yml -verify-config` |
| Tempo | `tempo -config.file=/etc/tempo/config.yml -config.verify=true` |
| Prometheus | `promtool check config --agent /etc/prometheus/prometheus.yml` |
| otelcol-contrib | `otelcol-contrib validate --config=/etc/otelcol-contrib/config.yaml` |
| Règles Mimir | `mimirtool rules lint <fichier>` |
| Grafana | pas de validateur hors ligne : lire `journalctl -u grafana-server` après le démarrage (lignes `provisioning`) |

Ces commandes ont été testées le 28 oct. 2026 avec les versions épinglées : elles renvoient un code de sortie non nul sur une clé inconnue.

### 4.1 Contrôles et comptes système

```bash
dpkg-query -W -f='${Package} ${Version}\n' adduser systemd sqv wget   # §2.5
dpkg --dry-run -i /opt/lgtm-bundle/grafana/grafana_*.deb               # aucune dépendance manquante attendue

# Comptes pour les outils installés depuis une archive (les .deb créent les leurs)
for u in prometheus node_exporter; do
  id "$u" >/dev/null 2>&1 || useradd --system --no-create-home --shell /usr/sbin/nologin "$u"
done
install -d -o prometheus -g prometheus -m 0750 /var/lib/prometheus
install -d -o root -g prometheus -m 0750 /etc/prometheus
```

### 4.2 Installation des paquets `.deb`

```bash
cd /opt/lgtm-bundle
dpkg -i mimir/mimir-3.2.3_amd64.deb mimir/mimirtool_3.2.3_amd64.deb \
        loki/loki_3.7.9_amd64.deb tempo/tempo_3.1.1_linux_amd64.deb \
        otelcol-contrib/otelcol-contrib_0.164.0_linux_amd64.deb \
        grafana/grafana_13.2.4_38252365904_linux_amd64.deb
# Les scripts postinst de Mimir, Loki, Tempo et otelcol-contrib ACTIVENT et DÉMARRENT le service
# avec la configuration d'exemple du paquet : on les arrête avant de configurer.
systemctl stop mimir loki tempo otelcol-contrib
rm -rf /tmp/loki                                   # données créées par la config d'exemple de Loki
dpkg -l mimir mimirtool loki tempo otelcol-contrib grafana | tail -n 6
```

Ce que chaque paquet installe (lu dans les paquets le 28 oct. 2026) :

| Paquet | Binaire | Unité systemd | Configuration | Utilisateur créé |
|---|---|---|---|---|
| `mimir` | `/usr/local/bin/mimir` | `/lib/systemd/system/mimir.service` (`Type=notify`, `EnvironmentFile=/etc/default/mimir`) | `/etc/mimir/config.yml`, `runtime_config.yml` | `mimir` (home `/var/lib/mimir`) |
| `mimirtool` | `/usr/local/bin/mimirtool` | – | – | – |
| `loki` | `/usr/bin/loki` | `/etc/systemd/system/loki.service` | `/etc/loki/config.yml` | `loki` |
| `tempo` | `/usr/bin/tempo`, `tempo-cli`, `tempo-query` | `/etc/systemd/system/tempo.service` | `/etc/tempo/config.yml` | `tempo` (crée `/var/tempo`, 0700) |
| `otelcol-contrib` | `/usr/bin/otelcol-contrib` | `/lib/systemd/system/otelcol-contrib.service` (`EnvironmentFile=/etc/otelcol-contrib/otelcol-contrib.conf`) | `/etc/otelcol-contrib/config.yaml` | `otelcol-contrib` |
| `grafana` | `/usr/share/grafana/bin/grafana` | `/usr/lib/systemd/system/grafana-server.service` | `/etc/grafana/grafana.ini`, `/etc/grafana/provisioning/` | `grafana` ; **ne démarre pas** à l'installation |

### 4.3 Grafana Mimir (métriques, monolithique)

Sources : [démarrage Mimir](https://grafana.com/docs/mimir/latest/get-started/), [modes de déploiement](https://grafana.com/docs/mimir/latest/references/architecture/deployment-modes/), [paramètres de configuration](https://grafana.com/docs/mimir/latest/configure/configuration-parameters/), [Alertmanager de Mimir](https://grafana.com/docs/mimir/latest/references/architecture/components/alertmanager/).

```bash
cat > /etc/mimir/config.yml <<'EOF2'
# /etc/mimir/config.yml - Mimir 3.2.3, mode monolithique (target: all,alertmanager), architecture classique (sans Kafka)
# Lab de démonstration uniquement : un seul processus, stockage sur disque local.
target: all,alertmanager     # « all » n'inclut pas l'Alertmanager intégré (mimir -modules)
multitenancy_enabled: false

server:
  http_listen_address: 127.0.0.1   # consulté seulement par Grafana et Prometheus (même VM)
  http_listen_port: 9009
  grpc_listen_address: 127.0.0.1
  grpc_listen_port: 9097          # 9095 = Tempo, 9096 = Loki
  log_level: warn

# gRPC écoute seulement sur la boucle locale : le query-frontend doit donc
# annoncer 127.0.0.1 (sinon les queriers internes ne le joignent pas).
frontend:
  address: 127.0.0.1

# Le module memberlist-kv démarre toujours (port 7946) : on le limite à la boucle locale.
memberlist:
  bind_addr: [127.0.0.1]

common:
  storage:
    backend: filesystem
    filesystem:
      dir: /var/lib/mimir/data

blocks_storage:
  backend: filesystem
  filesystem:
    dir: /var/lib/mimir/blocks
  bucket_store:
    sync_dir: /var/lib/mimir/tsdb-sync
  tsdb:
    dir: /var/lib/mimir/tsdb
    retention_period: 13h

compactor:
  data_dir: /var/lib/mimir/compactor
  sharding_ring:
    kvstore:
      store: inmemory

distributor:
  ring:
    instance_addr: 127.0.0.1
    kvstore:
      store: inmemory

ingester:
  ring:
    instance_addr: 127.0.0.1
    kvstore:
      store: inmemory
    replication_factor: 1

store_gateway:
  sharding_ring:
    instance_addr: 127.0.0.1
    kvstore:
      store: inmemory
    replication_factor: 1

ruler:
  alertmanager_url: http://127.0.0.1:9009/alertmanager
  ring:
    instance_addr: 127.0.0.1
    kvstore:
      store: inmemory

ruler_storage:
  backend: filesystem
  filesystem:
    dir: /var/lib/mimir/rules

alertmanager:
  data_dir: /var/lib/mimir/alertmanager
  fallback_config_file: /etc/mimir/alertmanager-fallback.yml
  external_url: http://127.0.0.1:9009/alertmanager
  sharding_ring:
    instance_addr: 127.0.0.1
    kvstore:
      store: inmemory
    replication_factor: 1

alertmanager_storage:
  backend: filesystem
  filesystem:
    dir: /var/lib/mimir/alertmanager-storage

limits:
  compactor_blocks_retention_period: 7d
  max_global_series_per_user: 150000
  ingestion_rate: 20000

usage_stats:
  enabled: false
EOF2

cat > /etc/mimir/alertmanager-fallback.yml <<'EOF2'
# /etc/mimir/alertmanager-fallback.yml - récepteur factice (à remplacer par le webhook ITSM)
route:
  receiver: lab-null
  group_by: [alertname]
receivers:
  - name: lab-null
EOF2

chown root:mimir /etc/mimir/config.yml /etc/mimir/alertmanager-fallback.yml
chmod 0640 /etc/mimir/config.yml /etc/mimir/alertmanager-fallback.yml
sed -i 's/^LOG_LEVEL=.*/LOG_LEVEL="warn"/' /etc/default/mimir      # l'unité passe --log.level $LOG_LEVEL
mimir --config.file=/etc/mimir/config.yml -print.config >/dev/null && echo "config Mimir OK"
mimirtool alertmanager verify /etc/mimir/alertmanager-fallback.yml && echo "fallback Alertmanager OK"
```

Points clés (tous vérifiés en exécutant Mimir 3.2.3 avec ce fichier) :
- `target: all,alertmanager` : la cible `all` **n'inclut pas** l'Alertmanager (`mimir -modules`) ; sans `alertmanager`, `/alertmanager` répond `404`.
- `kvstore: inmemory` partout : un seul processus, pas de cluster memberlist ; `memberlist.bind_addr` limite le port 7946, qui s'ouvre quand même, à la boucle locale.
- `frontend.address: 127.0.0.1` : obligatoire quand le gRPC écoute seulement sur `127.0.0.1` ; sinon le query-frontend annonce l'adresse de la carte réseau et **toutes les requêtes restent bloquées**.
- Rétention : `compactor_blocks_retention_period: 7d` ; limites d'ingestion basses (`max_global_series_per_user: 150000`, `ingestion_rate: 20000`) pour protéger la RAM du lab.
- `blocks_storage.tsdb.retention_period: 13h` : durée pendant laquelle l'ingester garde les blocs locaux après leur envoi dans le stockage `filesystem`.

### 4.4 Grafana Loki (journaux)

Sources : [configuration](https://grafana.com/docs/loki/latest/configure/), [rétention](https://grafana.com/docs/loki/latest/operations/storage/retention/), [réception OTLP](https://grafana.com/docs/loki/latest/send-data/otel/).

```bash
install -d -o loki -g nogroup -m 0750 /var/lib/loki
cat > /etc/loki/config.yml <<'EOF2'
# /etc/loki/config.yml - Loki 3.7.9, mode monolithique, stockage disque local
auth_enabled: false

server:
  http_listen_address: 127.0.0.1   # consulté seulement par Grafana et Prometheus (même VM)
  http_listen_port: 3100
  grpc_listen_address: 127.0.0.1
  grpc_listen_port: 9096
  log_level: warn

common:
  instance_addr: 127.0.0.1
  path_prefix: /var/lib/loki
  storage:
    filesystem:
      chunks_directory: /var/lib/loki/chunks
      rules_directory: /var/lib/loki/rules
  replication_factor: 1
  ring:
    kvstore:
      store: inmemory

query_range:
  results_cache:
    cache:
      embedded_cache:
        enabled: true
        max_size_mb: 32

schema_config:
  configs:
    - from: 2026-01-01
      store: tsdb
      object_store: filesystem
      schema: v13
      index:
        prefix: index_
        period: 24h

limits_config:
  retention_period: 72h
  allow_structured_metadata: true

compactor:
  working_directory: /var/lib/loki/compactor
  retention_enabled: true
  delete_request_store: filesystem

ruler:
  alertmanager_url: http://127.0.0.1:9009/alertmanager
  storage:
    type: local
    local:
      directory: /var/lib/loki/rules

analytics:
  reporting_enabled: false
EOF2
chown root:root /etc/loki/config.yml && chmod 0644 /etc/loki/config.yml
loki -config.file=/etc/loki/config.yml -verify-config && echo "config Loki OK"
```

> Le paquet crée l'utilisateur `loki` avec `adduser --system` (groupe principal `nogroup` sur Debian) : vérifie avec `id loki` et adapte le groupe de `/var/lib/loki` si besoin.

### 4.5 Grafana Tempo (traces)

Sources : [configuration Tempo](https://grafana.com/docs/tempo/latest/configuration/), [déploiement Linux](https://grafana.com/docs/tempo/latest/set-up-for-tracing/setup-tempo/deploy/locally/linux/).

```bash
cat > /etc/tempo/config.yml <<'EOF2'
# /etc/tempo/config.yml - Tempo 3.1.1, mode monolithique, stockage disque local
stream_over_http_enabled: true

server:
  http_listen_address: 127.0.0.1   # consulté seulement par Grafana et Prometheus (même VM)
  http_listen_port: 3200
  grpc_listen_address: 127.0.0.1
  grpc_listen_port: 9095
  log_level: warn

distributor:
  receivers:
    otlp:
      protocols:
        grpc:
          endpoint: "127.0.0.1:4417"   # 4317/4318 = otelcol-contrib
        http:
          endpoint: "127.0.0.1:4418"

metrics_generator:
  registry:
    external_labels:
      source: tempo
      cluster: lab
  storage:
    path: /var/tempo/generator/wal
    remote_write:
      - url: http://127.0.0.1:9009/api/v1/push
        send_exemplars: true

storage:
  trace:
    backend: local
    wal:
      path: /var/tempo/wal
    local:
      path: /var/tempo/blocks

overrides:
  defaults:
    metrics_generator:
      processors: [service-graphs, span-metrics]
    compaction:
      block_retention: 24h          # rétention des traces (surcharge par défaut, tous locataires)

usage_report:
  reporting_enabled: false
EOF2
chown root:root /etc/tempo/config.yml && chmod 0644 /etc/tempo/config.yml
ls -ld /var/tempo                                    # créé par le paquet : tempo, 0700
tempo -config.file=/etc/tempo/config.yml -config.verify=true && echo "config Tempo OK"
```

- **Tempo 3.x** utilise `/var/tempo` par défaut pour plusieurs composants internes (live-store, backend-scheduler) ; on garde donc toutes les données sous `/var/tempo`, le dossier créé par le paquet. Pointer seulement le WAL ailleurs fait échouer le démarrage (`mkdir /var/tempo: permission denied` si le dossier manque).
- La rétention de 24 h passe par `overrides.defaults.compaction.block_retention` (surcharge appliquée à tous les locataires) ; vérifie après le démarrage : `wget -qO- http://127.0.0.1:3200/status/config | grep block_retention`.
- Le *metrics-generator* (`service-graphs`, `span-metrics`) envoie ses métriques à Mimir ; Grafana s'en sert pour la carte des services.

### 4.6 Prometheus en mode agent et node_exporter

Sources : [mode agent](https://prometheus.io/docs/prometheus/latest/prometheus_agent/), [configuration](https://prometheus.io/docs/prometheus/latest/configuration/configuration/), [node_exporter](https://prometheus.io/docs/guides/node-exporter/).

```bash
cd /var/tmp
tar xzf /opt/lgtm-bundle/prometheus/prometheus-3.15.1.linux-amd64.tar.gz
install -m 0755 prometheus-3.15.1.linux-amd64/prometheus prometheus-3.15.1.linux-amd64/promtool /usr/local/bin/
tar xzf /opt/lgtm-bundle/node_exporter/node_exporter-1.12.1.linux-amd64.tar.gz
install -m 0755 node_exporter-1.12.1.linux-amd64/node_exporter /usr/local/bin/
rm -rf prometheus-3.15.1.linux-amd64 node_exporter-1.12.1.linux-amd64

cat > /etc/prometheus/prometheus.yml <<'EOF2'
# /etc/prometheus/prometheus.yml - Prometheus 3.15.1 en mode agent (--agent) :
# il collecte (scrape) et pousse tout vers Mimir ; il ne stocke ni n'évalue rien.
global:
  scrape_interval: 30s
  # Noms de métriques et d'étiquettes « classiques » (sans points) : Mimir refuse par défaut
  # les étiquettes UTF-8 comme service.instance.id exposées par otelcol-contrib.
  metric_name_validation_scheme: legacy
  external_labels:
    lab: obs-lgtm

remote_write:
  - url: http://127.0.0.1:9009/api/v1/push

scrape_configs:
  - job_name: prometheus-agent
    static_configs:
      - targets: ['127.0.0.1:9090']
  - job_name: node
    static_configs:
      - targets: ['127.0.0.1:9100']
        labels: { vm: obs-lgtm }
      - targets: ['<ip-elk>:9100']
        labels: { vm: elk }
  - job_name: windows
    static_configs:
      - targets: ['<ip-dc>:9182']
        labels: { vm: dc }
  - job_name: lgtm-self
    static_configs:
      - targets: ['127.0.0.1:9009']
        labels: { service: mimir }
      - targets: ['127.0.0.1:3100']
        labels: { service: loki }
      - targets: ['127.0.0.1:3200']
        labels: { service: tempo }
      - targets: ['127.0.0.1:8888']
        labels: { service: otelcol-contrib }
      - targets: ['127.0.0.1:3000']
        labels: { service: grafana }
EOF2
sed -i 's/<ip-elk>/192.0.2.11/; s/<ip-dc>/192.0.2.10/' /etc/prometheus/prometheus.yml   # remplace par TES adresses
chown root:prometheus /etc/prometheus/prometheus.yml && chmod 0640 /etc/prometheus/prometheus.yml
promtool check config --agent /etc/prometheus/prometheus.yml

cat > /etc/systemd/system/prometheus.service <<'EOF2'
# /etc/systemd/system/prometheus.service - Prometheus 3.15.1 en mode agent
[Unit]
Description=Prometheus (mode agent) - collecte et remote_write vers Mimir
Wants=network-online.target
After=network-online.target mimir.service

[Service]
User=prometheus
Group=prometheus
ExecStart=/usr/local/bin/prometheus \
  --agent \
  --config.file=/etc/prometheus/prometheus.yml \
  --storage.agent.path=/var/lib/prometheus \
  --web.listen-address=127.0.0.1:9090
ExecReload=/bin/kill -HUP $MAINPID
Restart=on-failure
NoNewPrivileges=true
ProtectSystem=full
ProtectHome=true

[Install]
WantedBy=multi-user.target
EOF2

cat > /etc/systemd/system/node_exporter.service <<'EOF2'
# /etc/systemd/system/node_exporter.service - node_exporter 1.12.1
[Unit]
Description=Prometheus node_exporter
Wants=network-online.target
After=network-online.target

[Service]
User=node_exporter
Group=node_exporter
ExecStart=/usr/local/bin/node_exporter --web.listen-address=:9100
Restart=on-failure
MemoryMax=64M
NoNewPrivileges=true
ProtectSystem=full
ProtectHome=true

[Install]
WantedBy=multi-user.target
EOF2
```

> `metric_name_validation_scheme: legacy` est nécessaire : Prometheus 3 accepte des noms d'étiquettes UTF-8 (par exemple `service.instance.id` exposé par otelcol-contrib), et **Mimir 3.2.3 rejette** alors tout le lot (`err-mimir-label-invalid`, HTTP 400). Constaté pendant les tests ; avec `legacy`, les points sont convertis en soulignés. Les adresses `192.0.2.x` de la commande `sed` sont des adresses de documentation : remplace-les.

### 4.7 OpenTelemetry Collector contrib (façade d'ingestion)

Sources : [installation Linux](https://opentelemetry.io/docs/collector/install/binary/linux/), [configuration](https://opentelemetry.io/docs/collector/configuration/), [exportateur elasticsearch](https://github.com/open-telemetry/opentelemetry-collector-contrib/blob/main/exporter/elasticsearchexporter/README.md), [OTLP vers Mimir](https://grafana.com/docs/mimir/latest/configure/configure-otel-collector/), [OTLP vers Loki](https://grafana.com/docs/loki/latest/send-data/otel/).

1. **Certificat CA d'Elasticsearch** (public, pas un secret), depuis la VM ELK :

```bash
# Sur la VM ELK :
scp /etc/elasticsearch/certs/http_ca.crt admin@<ip-obs-lgtm>:/var/tmp/es-http-ca.crt
# Sur obs-lgtm :
install -o root -g otelcol-contrib -m 0644 /var/tmp/es-http-ca.crt /etc/otelcol-contrib/es-http-ca.crt
install -o root -g grafana          -m 0644 /var/tmp/es-http-ca.crt /etc/grafana/es-http-ca.crt
```

2. **Clé API Elasticsearch d'écriture** (double écriture des phases 1 à 3). Dans Kibana > Dev Tools, avec un compte administrateur ; **ne fais pas de capture d'écran de la réponse** :

```json
POST /_security/api_key
{
  "name": "otelcol-obs-lgtm",
  "expiration": "90d",
  "role_descriptors": {
    "otel_writer": {
      "cluster": ["monitor"],
      "indices": [
        { "names": ["logs-*"], "privileges": ["auto_configure", "create_doc"] }
      ]
    }
  }
}
```

La réponse contient le champ `encoded` : c'est la valeur attendue par l'exportateur (`api_key`, format « encoded »). Saisis-la **sans écho** sur obs-lgtm :

```bash
read -rsp "Valeur 'encoded' de la clé API ES (otelcol) : " K; echo
printf 'ES_OTEL_API_KEY=%s\n' "$K" >> /etc/otelcol-contrib/otelcol-contrib.conf; unset K
chown root:root /etc/otelcol-contrib/otelcol-contrib.conf && chmod 0600 /etc/otelcol-contrib/otelcol-contrib.conf
grep -c '^ES_OTEL_API_KEY=' /etc/otelcol-contrib/otelcol-contrib.conf      # attendu : 1 (n'affiche jamais la valeur)
```

3. **Configuration :**

```bash
cat > /etc/otelcol-contrib/config.yaml <<'EOF2'
# /etc/otelcol-contrib/config.yaml - otelcol-contrib 0.164.0, façade d'ingestion (Strangler Fig)
receivers:
  otlp:
    protocols:
      grpc:
        endpoint: "0.0.0.0:4317"
      http:
        endpoint: "0.0.0.0:4318"

processors:
  memory_limiter:
    check_interval: 1s
    limit_mib: 300          # ≈ 80 % de MemoryMax=384M
    spike_limit_mib: 60
  batch: {}

exporters:
  otlphttp/mimir:
    endpoint: "http://127.0.0.1:9009/otlp"
  otlphttp/loki:
    endpoint: "http://127.0.0.1:3100/otlp"
  otlp/tempo:
    endpoint: "127.0.0.1:4417"
    tls:
      insecure: true
  # Double écriture vers ELK (phases 1 à 3) - à retirer en phase 6
  elasticsearch:
    endpoints: ["https://<ip-elk>:9200"]
    api_key: ${env:ES_OTEL_API_KEY}     # défini dans /etc/otelcol-contrib/otelcol-contrib.conf (0600, root), jamais dans ce fichier
    tls:
      ca_file: /etc/otelcol-contrib/es-http-ca.crt

service:
  telemetry:
    metrics:
      readers:
        - pull:
            exporter:
              prometheus:
                host: 127.0.0.1
                port: 8888
  pipelines:
    metrics:
      receivers: [otlp]
      processors: [memory_limiter, batch]
      exporters: [otlphttp/mimir]
    logs:
      receivers: [otlp]
      processors: [memory_limiter, batch]
      exporters: [otlphttp/loki, elasticsearch]
    traces:
      receivers: [otlp]
      processors: [memory_limiter, batch]
      exporters: [otlp/tempo]
EOF2
sed -i 's/<ip-elk>/elk.lab.local/' /etc/otelcol-contrib/config.yaml   # nom présent dans le certificat HTTP d'ES
chown root:otelcol-contrib /etc/otelcol-contrib/config.yaml && chmod 0640 /etc/otelcol-contrib/config.yaml
set -a; . /etc/otelcol-contrib/otelcol-contrib.conf; set +a
otelcol-contrib validate --config=/etc/otelcol-contrib/config.yaml && echo "config otelcol OK"
unset ES_OTEL_API_KEY
```

- Utilise dans `endpoints` un nom d'hôte ou une IP **présent dans le certificat** HTTP d'Elasticsearch (contrôle sur la VM ELK : `openssl s_client -connect localhost:9200 </dev/null 2>/dev/null | openssl x509 -noout -ext subjectAltName`). `elk.lab.local` est un exemple : remplace-le, et ajoute-le dans `/etc/hosts` d'obs-lgtm ou dans le DNS du DC.
- **Tant que la clé n'existe pas** (ou en phase 6), retire `elasticsearch` de la liste `exporters` du pipeline `logs` : c'est la bascule Strangler Fig décrite dans le plan.
- Le *mapping* par défaut de l'exportateur est le mode `otel` (README de la 0.164.0) ; vérifie dans Kibana les *data streams* créés avant de bâtir des tableaux de bord.

### 4.8 Grafana (consultation) et sources de données

Sources : [provisioning](https://grafana.com/docs/grafana/latest/administration/provisioning/), [datasource Prometheus/Mimir](https://grafana.com/docs/grafana/latest/datasources/prometheus/configure/), [Loki](https://grafana.com/docs/grafana/latest/datasources/loki/), [Tempo](https://grafana.com/docs/grafana/latest/datasources/tempo/configure-tempo-data-source/), [Alertmanager](https://grafana.com/docs/grafana/latest/datasources/alertmanager/), [Elasticsearch](https://grafana.com/docs/grafana/latest/datasources/elasticsearch/).

1. **Aucun appel sortant** (télémétrie, mises à jour, préinstallation de plugins) :

```bash
install -d -m 0755 /etc/systemd/system/grafana-server.service.d
cat > /etc/systemd/system/grafana-server.service.d/offline.conf <<'EOF2'
# /etc/systemd/system/grafana-server.service.d/offline.conf
# Aucun appel sortant : pas de télémétrie, pas de vérification de mises à jour, pas de préinstallation de plugins.
[Service]
Environment=GF_ANALYTICS_REPORTING_ENABLED=false
Environment=GF_ANALYTICS_CHECK_FOR_UPDATES=false
Environment=GF_ANALYTICS_CHECK_FOR_PLUGIN_UPDATES=false
Environment=GF_NEWS_NEWS_FEED_ENABLED=false
Environment=GF_PLUGINS_PREINSTALL_DISABLED=true
EOF2
```

2. **Clé API Elasticsearch de lecture** pour la datasource transitoire (Kibana > Dev Tools, sans capture d'écran) :

```json
POST /_security/api_key
{
  "name": "grafana-obs-lgtm",
  "expiration": "90d",
  "role_descriptors": {
    "grafana_reader": {
      "cluster": ["monitor"],
      "indices": [
        { "names": ["logs-*"], "privileges": ["read", "view_index_metadata"] }
      ]
    }
  }
}
```

```bash
read -rsp "Valeur 'encoded' de la clé API ES (Grafana) : " K; echo
printf '%s' "$K" > /etc/grafana/es-grafana-apikey; unset K
chown root:grafana /etc/grafana/es-grafana-apikey && chmod 0640 /etc/grafana/es-grafana-apikey
```

3. **Provisioning des sources de données** (Mimir par défaut, Alertmanager de Mimir, Loki, Tempo, Elasticsearch) :

```bash
cat > /etc/grafana/provisioning/datasources/lgtm.yaml <<'EOF2'
# /etc/grafana/provisioning/datasources/lgtm.yaml
apiVersion: 1
datasources:
  - name: Mimir
    uid: mimir
    type: prometheus
    access: proxy
    url: http://127.0.0.1:9009/prometheus
    isDefault: true
    jsonData:
      prometheusType: Mimir
      timeInterval: 30s
      exemplarTraceIdDestinations:
        - name: trace_id
          datasourceUid: tempo
  - name: Mimir Alertmanager
    uid: mimir-am
    type: alertmanager
    access: proxy
    url: http://127.0.0.1:9009
    jsonData:
      implementation: mimir
      handleGrafanaManagedAlerts: false
  - name: Loki
    uid: loki
    type: loki
    access: proxy
    url: http://127.0.0.1:3100
    jsonData:
      derivedFields:
        - name: TraceID
          matcherType: label
          matcherRegex: trace_id
          datasourceUid: tempo
          url: '$${__value.raw}'
  - name: Tempo
    uid: tempo
    type: tempo
    access: proxy
    url: http://127.0.0.1:3200
    jsonData:
      tracesToLogsV2:
        datasourceUid: loki
        filterByTraceID: true
      tracesToMetrics:
        datasourceUid: mimir
      serviceMap:
        datasourceUid: mimir
      nodeGraph:
        enabled: true
  - name: Elasticsearch (ELK, transitoire)
    uid: elk
    type: elasticsearch
    access: proxy
    url: https://<ip-elk>:9200
    jsonData:
      index: 'logs-*'
      timeField: '@timestamp'
      tlsAuthWithCACert: true
      httpHeaderName1: Authorization
    secureJsonData:
      tlsCACert: $__file{/etc/grafana/es-http-ca.crt}
      httpHeaderValue1: ApiKey $__file{/etc/grafana/es-grafana-apikey}
EOF2
sed -i 's#https://<ip-elk>:9200#https://elk.lab.local:9200#' /etc/grafana/provisioning/datasources/lgtm.yaml
chown root:grafana /etc/grafana/provisioning/datasources/lgtm.yaml && chmod 0640 /etc/grafana/provisioning/datasources/lgtm.yaml
```

- `$__file{...}` lit le secret dans un fichier au démarrage : la clé n'apparaît ni dans le YAML ni dans l'interface. `$$` échappe le `$` de `${__value.raw}` (lien journaux → traces).
- Le mot de passe initial `admin` / `admin` doit être changé à la **première connexion** (Grafana le demande).
- Tests faits le 28 oct. 2026 avec Grafana 13.2.4 et ce fichier : contrôles de santé `OK` pour Mimir, Loki et Tempo ; l'Alertmanager de Mimir répond via `/api/alertmanager/mimir-am/api/v2/status` (sa datasource n'a pas de bouton « Test » utilisable).

### 4.9 Limites mémoire (drop-ins systemd) et journal

Source : [systemd.resource-control](https://www.freedesktop.org/software/systemd/man/latest/systemd.resource-control.html), [GOMEMLIMIT](https://pkg.go.dev/runtime#hdr-Environment_Variables).

| Service | `MemoryMax` | `MemoryHigh` | `GOMEMLIMIT` | Mesuré au repos (test) |
|---|---|---|---|---|
| `mimir` | 768M | 690M | 600MiB | 150–215 Mo |
| `loki` | 512M | 460M | 400MiB | ≈ 160 Mo |
| `tempo` | 512M | 460M | 400MiB | 120–135 Mo |
| `otelcol-contrib` | 384M | 345M | 300MiB (`memory_limiter` 300/60) | ≈ 205 Mo |
| `prometheus` (agent) | 256M | 230M | 200MiB | 115–130 Mo |
| `grafana-server` | 512M | 460M | 400MiB | 360–380 Mo |
| `node_exporter` | 64M (dans l'unité) | – | – | ≈ 20 Mo |
| **Total** | **≈ 3,0 Go** | | | **≈ 1,2 Go** |

```bash
set_limits() {  # $1=service  $2=MemoryHigh  $3=MemoryMax  $4=GOMEMLIMIT
  mkdir -p "/etc/systemd/system/$1.service.d"
  printf '[Service]\nMemoryHigh=%s\nMemoryMax=%s\nEnvironment=GOMEMLIMIT=%s\n' "$2" "$3" "$4" \
    > "/etc/systemd/system/$1.service.d/limits.conf"
}
set_limits mimir           690M 768M 600MiB
set_limits loki            460M 512M 400MiB
set_limits tempo           460M 512M 400MiB
set_limits otelcol-contrib 345M 384M 300MiB
set_limits prometheus      230M 256M 200MiB
set_limits grafana-server  460M 512M 400MiB

# Journal systemd plafonné (les journaux des services restent consultables avec journalctl)
mkdir -p /etc/systemd/journald.conf.d
printf '[Journal]\nSystemMaxUse=500M\n' > /etc/systemd/journald.conf.d/lab.conf
systemctl restart systemd-journald
systemctl daemon-reload
```

### 4.10 Démarrage ordonné et vérifications

```bash
for s in mimir loki tempo otelcol-contrib prometheus node_exporter grafana-server; do
  systemctl enable --now "$s"; sleep 3; printf '%-16s %s\n' "$s" "$(systemctl is-active "$s")"
done
```

Mimir et Loki renvoient `503 Ingester not ready: waiting for 15s after being ready` pendant **une à deux minutes** après le démarrage (observé en test) ; c'est normal.

```bash
for u in 9009 3100 3200; do printf '%s : ' "$u"; wget -qO- "http://127.0.0.1:$u/ready" || echo "pas encore prêt"; echo; done
wget -qO- http://127.0.0.1:3000/api/health; echo
wget -qO- 'http://127.0.0.1:9009/prometheus/api/v1/query?query=up' | tr ',' '\n' | grep -E '"job"|"instance"|"value"' | head -n 40
wget -qO- http://127.0.0.1:9009/alertmanager/api/v2/status | head -c 120; echo
systemctl show mimir loki tempo otelcol-contrib prometheus grafana-server -p Id -p MemoryMax -p MemoryCurrent
ss -ltnp | grep -E ':(3000|3100|3200|4317|4318|9009|9090|9100)\b'
```

Attendu : `ready` pour 9009, 3100 et 3200 ; `"database": "ok"` pour Grafana ; `up` à `1` pour `prometheus-agent`, `node` (obs-lgtm) et `lgtm-self` (mimir, loki, tempo, otelcol-contrib, grafana). Les cibles `<ip-elk>:9100` et `<ip-dc>:9182` restent à `0` tant que les agents de la section 5 ne sont pas installés.

### 4.11 Test de bout en bout (OTLP → Mimir, Loki, Tempo) et règles d'alerte

Sur obs-lgtm, envoie un journal, une trace et une métrique de test au collecteur (`wget --post-data`, sans `curl`) :

```bash
NOW=$(date +%s%N); TID=5b8efff798038103d269b633813fc60c; SID=eee19b7ec3c1b174; H='Content-Type: application/json'
wget -qO- --header="$H" --post-data='{"resourceLogs":[{"resource":{"attributes":[{"key":"service.name","value":{"stringValue":"lab-test"}}]},"scopeLogs":[{"logRecords":[{"timeUnixNano":"'$NOW'","severityText":"ERROR","body":{"stringValue":"test LGTM ORA-02049 m5"},"traceId":"'$TID'","spanId":"'$SID'"}]}]}]}' http://127.0.0.1:4318/v1/logs; echo
wget -qO- --header="$H" --post-data='{"resourceSpans":[{"resource":{"attributes":[{"key":"service.name","value":{"stringValue":"lab-test"}}]},"scopeSpans":[{"spans":[{"traceId":"'$TID'","spanId":"'$SID'","name":"GET /test","kind":2,"startTimeUnixNano":"'$((NOW-50000000))'","endTimeUnixNano":"'$NOW'"}]}]}]}' http://127.0.0.1:4318/v1/traces; echo
wget -qO- --header="$H" --post-data='{"resourceMetrics":[{"resource":{"attributes":[{"key":"service.name","value":{"stringValue":"lab-test"}}]},"scopeMetrics":[{"metrics":[{"name":"lab_test_gauge","gauge":{"dataPoints":[{"asDouble":42,"timeUnixNano":"'$NOW'"}]}}]}]}]}' http://127.0.0.1:4318/v1/metrics; echo
sleep 20
wget -qO- 'http://127.0.0.1:9009/prometheus/api/v1/query?query=lab_test_gauge'; echo                      # Mimir : valeur 42
wget -qO- 'http://127.0.0.1:3100/loki/api/v1/query_range?query=%7Bservice_name%3D%22lab-test%22%7D&limit=5' | head -c 300; echo   # Loki
wget -qO- "http://127.0.0.1:3200/api/v2/traces/$TID" | head -c 200; echo                                     # Tempo
```

Résultats obtenus en test : Mimir renvoie `lab_test_gauge{job="lab-test"} 42`, Loki renvoie la ligne avec `trace_id` et `span_id` en métadonnées, Tempo renvoie la trace `GET /test`.

**Règles d'alerte Mimir** (ruler → Alertmanager intégré) :

```bash
cat > /etc/mimir/regles-lab.yaml <<'EOF2'
# Règles Mimir (ruler) - chargées avec : mimirtool rules load regles-lab.yaml
namespace: lab
groups:
  - name: lab-sante
    interval: 1m
    rules:
      - alert: CibleInjoignable
        expr: up == 0
        for: 5m
        labels: { severity: warning }
        annotations:
          summary: "{{ $labels.job }} / {{ $labels.instance }} ne répond plus"
      - alert: LabWatchdog
        expr: vector(1)
        labels: { severity: none }
        annotations:
          summary: "Alerte permanente : prouve que la chaîne ruler -> Alertmanager fonctionne"
EOF2
mimirtool rules lint /etc/mimir/regles-lab.yaml
mimirtool rules load --address=http://127.0.0.1:9009 --id=anonymous /etc/mimir/regles-lab.yaml
mimirtool rules list --address=http://127.0.0.1:9009 --id=anonymous
sleep 90; wget -qO- http://127.0.0.1:9009/alertmanager/api/v2/alerts | grep -o '"alertname":"[^"]*"'   # attendu : LabWatchdog
```

- `--id=anonymous` : avec `multitenancy_enabled: false`, Mimir utilise le locataire `anonymous` (`no_auth_tenant`).
- Le récepteur `lab-null` ne transmet rien. Pour la phase 5 du plan, remplace-le par un récepteur `webhook_configs` vers l'ITSM, puis `mimirtool alertmanager verify` et `mimirtool alertmanager load` ([mimirtool](https://grafana.com/docs/mimir/latest/manage/tools/mimirtool/)).

Checkpoint après validation :

```powershell
Checkpoint-VM -Name "obs-lgtm" -SnapshotName "lgtm-installee-$(Get-Date -Format yyyyMMdd)"
```

---
## 5. Étape 4 – Agents sur la VM ELK et le DC

### 5.1 VM ELK : node_exporter et otelcol-contrib (agent)

Copie les fichiers **déjà vérifiés** depuis obs-lgtm, puis contrôle-les de nouveau sur la VM ELK :

```bash
# Sur obs-lgtm :
scp /opt/lgtm-bundle/node_exporter/node_exporter-1.12.1.linux-amd64.tar.gz \
    /opt/lgtm-bundle/otelcol-contrib/otelcol-contrib_0.164.0_linux_amd64.deb \
    /opt/lgtm-bundle/lgtm-sha256-attendus admin@<ip-elk>:/var/tmp/
# Sur la VM ELK (root) :
cd /var/tmp && grep -E 'node_exporter-1.12.1|otelcol-contrib_0.164.0_linux' lgtm-sha256-attendus | sed 's#  [a-z_-]*/#  #' | sha256sum -c --strict
```

**node_exporter** (même unité qu'en 4.6) :

```bash
useradd --system --no-create-home --shell /usr/sbin/nologin node_exporter
tar xzf node_exporter-1.12.1.linux-amd64.tar.gz
install -m 0755 node_exporter-1.12.1.linux-amd64/node_exporter /usr/local/bin/
cat > /etc/systemd/system/node_exporter.service <<'EOF2'
# /etc/systemd/system/node_exporter.service - node_exporter 1.12.1
[Unit]
Description=Prometheus node_exporter
Wants=network-online.target
After=network-online.target

[Service]
User=node_exporter
Group=node_exporter
ExecStart=/usr/local/bin/node_exporter --web.listen-address=:9100
Restart=on-failure
MemoryMax=64M
NoNewPrivileges=true
ProtectSystem=full
ProtectHome=true

[Install]
WantedBy=multi-user.target
EOF2
systemctl daemon-reload && systemctl enable --now node_exporter
wget -qO- http://127.0.0.1:9100/metrics | grep -m1 node_uname_info
```

**otelcol-contrib en agent** (receveur [journald](https://github.com/open-telemetry/opentelemetry-collector-contrib/blob/main/receiver/journaldreceiver/README.md) : journaux d'Elasticsearch, Kibana, ElastAlert 2 et SSH) :

```bash
dpkg -i otelcol-contrib_0.164.0_linux_amd64.deb && systemctl stop otelcol-contrib
usermod -aG systemd-journal otelcol-contrib          # lecture du journal via journalctl
cat > /etc/otelcol-contrib/config.yaml <<'EOF2'
# /etc/otelcol-contrib/config.yaml sur la VM ELK - agent : journal systemd -> obs-lgtm (OTLP)
receivers:
  journald:
    directory: /var/log/journal        # vérifier : ls /var/log/journal (sinon /run/log/journal)
    units: [elasticsearch, kibana, elastalert2, ssh]
    priority: info

processors:
  memory_limiter:
    check_interval: 1s
    limit_mib: 200
    spike_limit_mib: 40
  resource:
    attributes:
      - key: service.namespace
        value: elk
        action: upsert
  batch: {}

exporters:
  otlp/obs:
    endpoint: "<ip-obs-lgtm>:4317"
    tls:
      insecure: true                   # lab : réseau Hyper-V interne ; TLS en annexe sécurité

service:
  telemetry:
    metrics:
      readers:
        - pull:
            exporter:
              prometheus:
                host: 127.0.0.1
                port: 8888
  pipelines:
    logs:
      receivers: [journald]
      processors: [memory_limiter, resource, batch]
      exporters: [otlp/obs]
EOF2
sed -i 's/<ip-obs-lgtm>/192.0.2.20/' /etc/otelcol-contrib/config.yaml       # remplace par l'IP d'obs-lgtm
chown root:otelcol-contrib /etc/otelcol-contrib/config.yaml && chmod 0640 /etc/otelcol-contrib/config.yaml
otelcol-contrib validate --config=/etc/otelcol-contrib/config.yaml
mkdir -p /etc/systemd/system/otelcol-contrib.service.d
printf '[Service]\nMemoryHigh=288M\nMemoryMax=320M\nEnvironment=GOMEMLIMIT=256MiB\n' > /etc/systemd/system/otelcol-contrib.service.d/limits.conf
systemctl daemon-reload && systemctl enable --now otelcol-contrib
journalctl -u otelcol-contrib -n 20 --no-pager
```

> Les noms d'unités (`elasticsearch`, `kibana`, `elastalert2`, `ssh`) sont ceux du lab ; vérifie-les avec `systemctl list-units --type=service`. Ce fichier a été validé (`otelcol-contrib validate`) le 28 oct. 2026, mais **pas** exécuté sur la VM ELK.

Contrôle sur obs-lgtm : `wget -qO- 'http://127.0.0.1:3100/loki/api/v1/label/service_namespace/values'` doit contenir `elk` quelques minutes après.

### 5.2 DC : windows_exporter et otelcol-contrib (services Windows)

1. Copie `windows_exporter-0.32.0-amd64.msi` et `otelcol-contrib_0.164.0_windows_x64.msi` du poste Windows (`C:\lgtm-telechargement\windows`) vers `C:\lgtm` sur le DC, puis compare leurs empreintes aux valeurs **vérifiées sous Linux** (fichier `lgtm-sha256-attendus`, §2.8) :

```powershell
Get-FileHash C:\lgtm\*.msi -Algorithm SHA256 | Format-Table Hash, Path -AutoSize
# attendu :
#  D48EBAD7999AAC5603FE01007016A0DDBCECBC1AA0ECBC51867A2416B6C60A7D  windows_exporter-0.32.0-amd64.msi
#  DCDAE63474A3BB0B9BB09D869E4F6DDB5A0E22D1ED5CF299454336D69A69292B  otelcol-contrib_0.164.0_windows_x64.msi
```

2. **windows_exporter** (propriétés MSI documentées dans le [README de la 0.32.0](https://github.com/prometheus-community/windows_exporter/blob/v0.32.0/README.md)) :

```powershell
msiexec /i C:\lgtm\windows_exporter-0.32.0-amd64.msi --% ENABLED_COLLECTORS="cpu,logical_disk,memory,net,os,service,ad,dns" LISTEN_PORT=9182 ADDLOCAL=FirewallException /qn
Get-Service windows_exporter
(Invoke-WebRequest -UseBasicParsing http://localhost:9182/metrics).Content.Length
```

3. **otelcol-contrib** ([installation Windows](https://opentelemetry.io/docs/collector/install/binary/windows/) : service nommé d'après la distribution, `otelcol-contrib`) :

```powershell
msiexec /i C:\lgtm\otelcol-contrib_0.164.0_windows_x64.msi /qn
Get-CimInstance Win32_Service -Filter "Name='otelcol-contrib'" | Select-Object Name, State, PathName
# Le chemin du config.yaml utilisé par le service figure dans PathName : remplace son contenu par le fichier ci-dessous
Set-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Services\otelcol-contrib" -Name Environment -Type MultiString -Value "GOMEMLIMIT=200MiB"
& "C:\Program Files\OpenTelemetry Collector\otelcol-contrib.exe" validate --config="<chemin du config.yaml>"
Restart-Service otelcol-contrib
```

```yaml
# config.yaml de l'agent otelcol-contrib sur le DC (service Windows) - journaux d'événements -> obs-lgtm
receivers:
  windowseventlog/system:   { channel: System }
  windowseventlog/security: { channel: Security }
  windowseventlog/dirsvc:   { channel: "Directory Service" }

processors:
  memory_limiter: { check_interval: 1s, limit_mib: 200, spike_limit_mib: 40 }
  resource:
    attributes:
      - { key: service.namespace, value: dc, action: upsert }
  batch: {}

exporters:
  otlp/obs:
    endpoint: "<ip-obs-lgtm>:4317"
    tls: { insecure: true }

service:
  pipelines:
    logs:
      receivers: [windowseventlog/system, windowseventlog/security, windowseventlog/dirsvc]
      processors: [memory_limiter, resource, batch]
      exporters: [otlp/obs]
```

> Le chemin `C:\Program Files\OpenTelemetry Collector\` est une hypothèse : prends celui de `PathName`. Le receveur `windowseventlog` n'existe que sous Windows : la configuration n'a donc **pas pu être validée** sur l'environnement de test (annexe A). Il n'existe pas sous Windows de limite dure équivalente à `MemoryMax` ; `GOMEMLIMIT` et `memory_limiter` limitent l'usage.

Contrôle sur obs-lgtm : `up{job="windows"}` à `1` dans Mimir, et `service_namespace="dc"` dans Loki.

---

## 6. Dépannage (problèmes rencontrés pendant les tests)

| Symptôme | Cause | Correction |
|---|---|---|
| Prometheus : `non-recoverable error ... received a series with an invalid label: 'service.instance.id' (err-mimir-label-invalid)` | Prometheus 3 transmet des étiquettes UTF-8 ; Mimir les refuse. | `metric_name_validation_scheme: legacy` dans `global` (§4.6). |
| `/alertmanager/...` répond `404` | La cible `all` n'inclut pas l'Alertmanager. | `target: all,alertmanager` (§4.3). |
| Requêtes Mimir bloquées ; journal `attempt to send initial message to query-frontend failed ... connection refused` | gRPC sur `127.0.0.1`, mais le query-frontend annonce l'IP de la carte réseau. | `frontend.address: 127.0.0.1` (§4.3). |
| `503 Ingester not ready: waiting for 15s after being ready` | Démarrage de l'anneau de l'ingester (Mimir, Loki). | Attendre 1 à 2 minutes. |
| Tempo : `failed to create shutdown marker directory: mkdir /var/tempo: permission denied` | Tempo 3.x écrit sous `/var/tempo` par défaut. | Garder les données sous `/var/tempo` (créé par le paquet, propriétaire `tempo`). |
| `bind: address already in use` au redémarrage d'un service | L'ancien processus s'arrête encore, ou le service démarré par le `postinst` tourne toujours. | `systemctl stop <service>`, `ss -ltnp`, puis `systemctl start`. |
| Le script de vérification affiche `signature InRelease (obtenu : '')` | `sqv --output` refuse d'écraser un fichier existant. | Le script supprime `/tmp/InRelease.verifie` avant l'appel (déjà corrigé). |
| `otelcol-contrib` tué (OOM) ou refusant des données (`memory_limiter`) | Limite trop basse pour contrib (≈ 205 Mo au repos en test). | Ne pas descendre sous `MemoryMax=384M` / `limit_mib: 300` sur obs-lgtm. |
| Grafana tué (OOM) | 256 Mo (valeur du plan) < RSS au repos (≈ 370 Mo en test). | `MemoryMax=512M` (§4.9). |
| Rien dans Loki pour la VM ELK | `otelcol-contrib` n'a pas accès au journal, ou mauvais `directory`. | `id otelcol-contrib` (groupe `systemd-journal`), `ls /var/log/journal`. |

Commandes utiles : `journalctl -u <service> -n 50 --no-pager`, `systemd-cgtop -m`, `journalctl -k | grep -i oom`, `wget -qO- http://127.0.0.1:9009/config | head`, `wget -qO- http://127.0.0.1:3200/status/config | head`.

---

## 7. Retour arrière et désinstallation

```bash
# 1. Arrêt immédiat, réversible (obs-lgtm)
systemctl disable --now grafana-server prometheus otelcol-contrib tempo loki mimir node_exporter
# 2. Strangler Fig : revenir à ELK seul = retirer les exportateurs LGTM du collecteur, ou arrêter le collecteur ;
#    sur ELK et le DC, arrêter les agents : systemctl disable --now otelcol-contrib node_exporter / Stop-Service otelcol-contrib, windows_exporter
# 3. Désinstallation (obs-lgtm)
dpkg -P grafana mimir mimirtool loki tempo otelcol-contrib
rm -f /usr/local/bin/prometheus /usr/local/bin/promtool /usr/local/bin/node_exporter \
      /etc/systemd/system/prometheus.service /etc/systemd/system/node_exporter.service
rm -rf /etc/systemd/system/{mimir,loki,tempo,otelcol-contrib,prometheus,grafana-server}.service.d
rm -rf /var/lib/mimir /var/lib/loki /var/tempo /var/lib/prometheus /var/lib/grafana /etc/prometheus
systemctl daemon-reload
# /opt/lgtm-bundle : à conserver tant qu'une réinstallation de cette version est possible
```

- **Clés API Elasticsearch :** les révoquer dans Kibana > Dev Tools : `DELETE /_security/api_key` avec `{ "name": "otelcol-obs-lgtm" }`, puis `{ "name": "grafana-obs-lgtm" }`.
- **Retour arrière complet :** restaurer les checkpoints Hyper-V (`Restore-VMCheckpoint`), et rallumer AppDynamics si nécessaire (`Start-VM -Name "AppDynamics"`).
- **DC :** `msiexec /x C:\lgtm\otelcol-contrib_0.164.0_windows_x64.msi /qn` et `msiexec /x C:\lgtm\windows_exporter-0.32.0-amd64.msi /qn`.

---
## 8. Sources

Toutes les adresses ont été consultées le 28 oct. 2026.

**Releases et artefacts**
- [Grafana – API de téléchargement 13.2.4](https://grafana.com/api/downloads/grafana/versions/13.2.4), [releases GitHub Grafana](https://github.com/grafana/grafana/releases)
- [Dépôt APT Grafana : InRelease](https://apt.grafana.com/dists/stable/InRelease), [clé gpg-full.key](https://apt.grafana.com/gpg-full.key)
- [Mimir – release 3.2.3](https://github.com/grafana/mimir/releases/tag/mimir-3.2.3), [Loki – release 3.7.9](https://github.com/grafana/loki/releases/tag/v3.7.9), [Tempo – release 3.1.1](https://github.com/grafana/tempo/releases/tag/v3.1.1)
- [Prometheus – release 3.15.1](https://github.com/prometheus/prometheus/releases/tag/v3.15.1), [node_exporter – release 1.12.1](https://github.com/prometheus/node_exporter/releases/tag/v1.12.1)
- [OpenTelemetry Collector – release 0.164.0](https://github.com/open-telemetry/opentelemetry-collector-releases/releases/tag/v0.164.0), [windows_exporter – release 0.32.0](https://github.com/prometheus-community/windows_exporter/releases/tag/v0.32.0)
- [Grafana Alloy – release 1.21.2](https://github.com/grafana/alloy/releases/tag/v1.21.2) (évalué, non retenu)
- [Debian – ISO 13.7.0](https://cdimage.debian.org/cdimage/release/13.7.0/amd64/iso-cd/), [liste des paquets de l'ISO netinst](https://cdimage.debian.org/cdimage/release/13.7.0/amd64/list-cd/), [vérifier une image Debian](https://www.debian.org/CD/verify)
- [Debian – adduser (trixie)](https://packages.debian.org/trixie/all/adduser/download), [index trixie](https://deb.debian.org/debian/dists/trixie/InRelease)

**Grafana Mimir**
- [Démarrage (mode monolithique, remote_write)](https://grafana.com/docs/mimir/latest/get-started/)
- [Modes de déploiement](https://grafana.com/docs/mimir/latest/references/architecture/deployment-modes/)
- [Architecture classique](https://grafana.com/docs/mimir/latest/get-started/about-grafana-mimir-architecture/about-classic-architecture/) et [ingest storage](https://grafana.com/docs/mimir/latest/get-started/about-grafana-mimir-architecture/about-ingest-storage-architecture/)
- [Notes de version 3.0](https://grafana.com/docs/mimir/v3.0.x/release-notes/v3.0/)
- [Paramètres de configuration](https://grafana.com/docs/mimir/latest/configure/configuration-parameters/), [API HTTP](https://grafana.com/docs/mimir/latest/references/http-api/)
- [Alertmanager](https://grafana.com/docs/mimir/latest/references/architecture/components/alertmanager/), [mimirtool](https://grafana.com/docs/mimir/latest/manage/tools/mimirtool/)
- [Envoyer des données OTLP à Mimir avec le Collector](https://grafana.com/docs/mimir/latest/configure/configure-otel-collector/)

**Loki, Tempo, Grafana**
- [Loki – configuration](https://grafana.com/docs/loki/latest/configure/), [rétention](https://grafana.com/docs/loki/latest/operations/storage/retention/), [ingestion OTLP](https://grafana.com/docs/loki/latest/send-data/otel/)
- [Tempo – configuration (3.x)](https://grafana.com/docs/tempo/latest/configuration/), [déploiement Linux](https://grafana.com/docs/tempo/latest/set-up-for-tracing/setup-tempo/deploy/locally/linux/)
- [Grafana – installation Debian](https://grafana.com/docs/grafana/latest/setup-grafana/installation/debian/), [provisioning](https://grafana.com/docs/grafana/latest/administration/provisioning/)
- [Datasources : Prometheus/Mimir](https://grafana.com/docs/grafana/latest/datasources/prometheus/configure/), [Loki](https://grafana.com/docs/grafana/latest/datasources/loki/), [Tempo](https://grafana.com/docs/grafana/latest/datasources/tempo/configure-tempo-data-source/), [Alertmanager](https://grafana.com/docs/grafana/latest/datasources/alertmanager/), [Elasticsearch](https://grafana.com/docs/grafana/latest/datasources/elasticsearch/)
- [Grafana Alloy – documentation](https://grafana.com/docs/alloy/latest/)

**Prometheus et OpenTelemetry**
- [Prometheus – mode agent](https://prometheus.io/docs/prometheus/latest/prometheus_agent/), [configuration](https://prometheus.io/docs/prometheus/latest/configuration/configuration/), [feature flags](https://prometheus.io/docs/prometheus/latest/feature_flags/)
- [node_exporter – guide](https://prometheus.io/docs/guides/node-exporter/), [windows_exporter – README 0.32.0](https://github.com/prometheus-community/windows_exporter/blob/v0.32.0/README.md)
- [Collector – installation Linux](https://opentelemetry.io/docs/collector/install/binary/linux/), [Windows](https://opentelemetry.io/docs/collector/install/binary/windows/), [configuration](https://opentelemetry.io/docs/collector/configuration/)
- [Exportateur elasticsearch](https://github.com/open-telemetry/opentelemetry-collector-contrib/blob/main/exporter/elasticsearchexporter/README.md), [receveur journald](https://github.com/open-telemetry/opentelemetry-collector-contrib/blob/main/receiver/journaldreceiver/README.md), [receveur windowseventlog](https://github.com/open-telemetry/opentelemetry-collector-contrib/blob/main/receiver/windowseventlogreceiver/README.md), [memory_limiter](https://github.com/open-telemetry/opentelemetry-collector/blob/main/processor/memorylimiterprocessor/README.md)

**Windows, Hyper-V, systemd**
- [curl et tar fournis avec Windows](https://curl.se/windows/microsoft.html), [OpenSSH pour Windows](https://learn.microsoft.com/en-us/windows-server/administration/openssh/openssh_install_firstuse), [Get-FileHash](https://learn.microsoft.com/en-us/powershell/module/microsoft.powershell.utility/get-filehash)
- [Debian sur Hyper-V](https://learn.microsoft.com/en-us/windows-server/virtualization/hyper-v/supported-debian-virtual-machines-on-hyper-v), [Dynamic Memory](https://learn.microsoft.com/en-us/windows-server/virtualization/hyper-v/dynamic-memory)
- [New-VM](https://learn.microsoft.com/en-us/powershell/module/hyper-v/new-vm), [Set-VMProcessor](https://learn.microsoft.com/en-us/powershell/module/hyper-v/set-vmprocessor), [Set-VMMemory](https://learn.microsoft.com/en-us/powershell/module/hyper-v/set-vmmemory), [Set-VMFirmware](https://learn.microsoft.com/en-us/powershell/module/hyper-v/set-vmfirmware), [Add-VMDvdDrive](https://learn.microsoft.com/en-us/powershell/module/hyper-v/add-vmdvddrive), [Checkpoint-VM](https://learn.microsoft.com/en-us/powershell/module/hyper-v/checkpoint-vm), [Set-VM](https://learn.microsoft.com/en-us/powershell/module/hyper-v/set-vm)
- [systemd.resource-control](https://www.freedesktop.org/software/systemd/man/latest/systemd.resource-control.html), [GOMEMLIMIT](https://pkg.go.dev/runtime#hdr-Environment_Variables)

**Documents du lab**
- `Plan_integration_observabilite_lab.md` (plan Strangler Fig, non modifié)
- `Runbook_ElastAlert2_Jinja2_Debian.md` (modèle de la chaîne hors ligne Windows → Linux)
- `architecture-lgtm/` (dossier d'architecture qui accompagne ce runbook)

---

## Annexe A – Points non vérifiés et limites des tests

| # | Point | État | Action |
|---|---|---|---|
| 1 | Script `Telecharger-LGTM.ps1` sous **Windows PowerShell 5.1** et avec les vrais `curl.exe` / `tar.exe` | Testé seulement avec PowerShell 7 sous Linux | Premier lancement sur le poste : vérifier `(Get-ChildItem C:\lgtm-telechargement -Recurse -File).Count` = 25. |
| 2 | Services lancés **par systemd** sur Debian 13 (unités, drop-ins, `Type=notify` de Mimir, `ProtectSystem`) | Configurations testées en lançant les binaires directement (sans systemd), sur un Linux qui n'est pas Debian 13 | Suivre §4.10 et lire `journalctl -u <service>`. |
| 3 | Valeurs mémoire (`MemoryMax`, RAM des VM) | Mesures au repos, sur un environnement de test, avec très peu de données | Observer `systemd-cgtop -m` une semaine, puis ajuster. |
| 4 | Privilèges des clés API Elasticsearch (`auto_configure`, `create_doc`, `read`, `view_index_metadata`, `monitor`) | Non testés contre Elasticsearch 9 | Tester la double écriture et la datasource ; ajuster le rôle si ES renvoie `403`. |
| 5 | Datasource Elasticsearch de Grafana 13.2 avec ES 9 et en-tête `ApiKey` | Provisioning testé ; connexion à un vrai ES 9 non testée | Bouton « Save & test » dans Grafana. |
| 6 | Configuration de l'agent du DC (`windowseventlog`) | Ne peut pas être validée hors Windows | `otelcol-contrib.exe validate` sur le DC. |
| 7 | Chemin d'installation du MSI otelcol-contrib sur Windows | Non vérifié | Lire `PathName` (§5.2). |
| 8 | Agent `journald` sur la VM ELK (noms d'unités, dossier du journal) | Configuration validée, non exécutée sur ELK | §5.1. |
| 9 | Installation de Debian 13.7 sans miroir réseau avec les tâches « serveur SSH » et « utilitaires usuels » | Contenu de l'ISO vérifié (liste officielle), installation non jouée | Contrôles de §3.5. |
| 10 | Règles d'alerte du *ruler* de **Loki** vers l'Alertmanager de Mimir | `alertmanager_url` configuré, aucune règle Loki testée | Tester en phase 5 du plan. |
| 11 | Grafana 13.3.x | Non retenu (absent de l'index APT signé le 28 oct. 2026) | Revoir à la prochaine mise à jour. |
| 12 | Hôte Hyper-V (RAM, processeurs) | Inconnu | §3.1 : relever avec `Get-VMHost`. |

## Annexe B – Tests réalisés le 28 oct. 2026 (environnement de test Linux, hors Hyper-V)

- Téléchargement de tous les artefacts, comparaison avec les fichiers d'empreintes publiés, le champ `digest` des releases GitHub, l'index APT Grafana signé (signature vérifiée avec `sqv` et `gpg`) et l'index Debian signé.
- Exécution du script PowerShell (PowerShell 7), extraction de l'archive, exécution de `verifier-lgtm.sh` : tout conforme ; avec un fichier altéré : échec détecté.
- Vérification de l'ISO Debian 13.7.0 : signature `SHA256SUMS.sign` (clé `DF9B…BE9B`) et empreinte.
- Lancement de Mimir 3.2.3, Loki 3.7.9, Tempo 3.1.1, otelcol-contrib 0.164.0, Prometheus 3.15.1 (agent), node_exporter 1.12.1 et Grafana 13.2.4 avec **exactement** les fichiers de configuration de ce runbook (chemins de données adaptés) :
  - `up` = 1 pour toutes les cibles locales dans Mimir ;
  - journal, trace et métrique OTLP envoyés au collecteur, retrouvés dans Loki, Tempo et Mimir ;
  - règles chargées avec `mimirtool`, alerte `LabWatchdog` présente dans l'Alertmanager de Mimir ;
  - sources de données Grafana Mimir, Loki et Tempo : état `OK` ; variables `GF_*` hors ligne prises en compte.
- Validation des configurations : `promtool check config --agent`, `otelcol-contrib validate` (façade et agent ELK), `loki -verify-config`, `tempo -config.verify=true`, `mimir -print.config`, `mimirtool alertmanager verify`, `mimirtool rules lint`.
