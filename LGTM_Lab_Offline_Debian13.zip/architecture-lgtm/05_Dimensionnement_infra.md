# 05 – Dimensionnement de l'infrastructure

> Valeurs identiques au §3 et au §4.9 du runbook. Les mesures de mémoire ont été faites **au repos**, avec très peu de données, sur un environnement de test Linux (pas sur Hyper-V, pas sous systemd) le 28 oct. 2026 : ce sont des ordres de grandeur, à confirmer sur le lab (`systemd-cgtop -m`).

## 1. VM du lab

| VM | OS | Rôle | vCPU | RAM démarrage | RAM min / max (mémoire dynamique) | Disque | IP | État |
|---|---|---|---|---|---|---|---|---|
| **DC** | Windows Server (existant) | AD DS, DNS ; `windows_exporter`, `otelcol-contrib` (services Windows) | 1 | 2 Go | 1 / 2 Go | existant | `<ip-dc>` | allumée |
| **ELK** | Debian 13 | Elasticsearch 9, Kibana, ElastAlert 2, Logstash (jusqu'à la phase 3) ; `node_exporter`, `otelcol-contrib` | 2 | **4 Go** | **3 / 5 Go** | existant | `<ip-elk>` | allumée jusqu'à la phase 6 |
| **AppDynamics** | existant | contrôleur APM (retour arrière) | inchangé | – | – | existant | – | **éteinte** (`AutomaticStartAction Nothing`) |
| **obs-lgtm** | Debian 13.7 | otelcol-contrib, Prometheus agent, **Mimir**, Loki, Tempo, Grafana, node_exporter | 2 (4 si l'hôte a ≥ 8 processeurs logiques) | **4 Go** | **3 / 6 Go** | **60 Go** VHDX dynamique | `<ip-obs-lgtm>` | nouvelle |
| **Total actif** | | | **5** | **10 Go** | **7 / 13 Go** | | | |

## 2. Budget de l'hôte Hyper-V

À relever avant toute modification :

```powershell
Get-VMHost | Select-Object LogicalProcessorCount, @{n='RAM_Go';e={[math]::Round($_.MemoryCapacity/1GB,1)}}
```

| RAM de l'hôte | Recommandation |
|---|---|
| **16 Go ou plus** (recommandé) | Valeurs du tableau. Environ 6 Go restent à Windows et aux applications de l'hôte ; les maximums (13 Go) ne sont atteints que sous charge. |
| 8 à 12 Go | ELK à 3 Go (2–4 Go, valeurs du plan), obs-lgtm à 4 Go ; ne pas garder ELK et obs-lgtm allumées en même temps hors des phases de comparaison. |
| moins de 8 Go | Non recommandé : Elasticsearch 9 et la pile LGTM ne tiennent pas ensemble. |

| Processeurs logiques de l'hôte | obs-lgtm |
|---|---|
| 4 à 7 | 2 vCPU (5 vCPU actifs au total, partagés) |
| 8 ou plus | 4 vCPU (démarrage plus rapide de Grafana et de Mimir) |

```mermaid
pie showData
  title RAM de démarrage des VM actives (Go)
  "DC" : 2
  "ELK" : 4
  "obs-lgtm" : 4
```

## 3. Budget mémoire de obs-lgtm

| Service | `MemoryHigh` | `MemoryMax` | `GOMEMLIMIT` | Autre limite | Mesuré au repos (test) |
|---|---|---|---|---|---|
| `mimir` | 690M | 768M | 600MiB | – | 150–215 Mo |
| `loki` | 460M | 512M | 400MiB | – | ≈ 160 Mo |
| `tempo` | 460M | 512M | 400MiB | – | 120–135 Mo |
| `otelcol-contrib` | 345M | 384M | 300MiB | `memory_limiter` 300 / 60 MiB | ≈ 205 Mo |
| `prometheus` (agent) | 230M | 256M | 200MiB | – | 115–130 Mo |
| `grafana-server` | 460M | 512M | 400MiB | – | 360–380 Mo |
| `node_exporter` | – | 64M (dans l'unité) | – | – | ≈ 20 Mo |
| **Total services** | | **≈ 3,0 Go** | | | **≈ 1,2 Go** |
| Debian 13 (noyau, sshd, journald, cache) | | | | journal ≤ 500 Mo sur disque | – |

Règles appliquées :

- `GOMEMLIMIT` ≈ 80 % de `MemoryMax` : le ramasse-miettes Go devient plus actif avant la limite dure.
- `MemoryHigh` ≈ 90 % de `MemoryMax` : le noyau ralentit le service et récupère de la mémoire avant de le tuer.
- `memory_limiter` d'otelcol ≈ 80 % de `MemoryMax` : refus des données plutôt qu'OOM.
- La somme des `MemoryMax` (≈ 3,0 Go) laisse environ 1 Go à Debian dans les 4 Go de démarrage, et davantage quand la mémoire dynamique monte vers 6 Go. Un pic simultané de tous les services reste donc contenu par systemd avant de saturer la VM.

**Écarts par rapport au plan** (justification au §3.2 du runbook) : Grafana et otelcol-contrib étaient limités à 256 Mo dans le plan, moins que leur consommation au repos mesurée ; Mimir s'ajoute (768 Mo) ; l'Alertmanager autonome (64 Mo) disparaît.

## 4. Agents sur les autres VM

| VM | Service | Limites | `memory_limiter` |
|---|---|---|---|
| ELK | `otelcol-contrib` (agent journald) | `MemoryHigh=288M`, `MemoryMax=320M`, `GOMEMLIMIT=256MiB` | 200 / 40 MiB |
| ELK | `node_exporter` | `MemoryMax=64M` | – |
| DC | `otelcol-contrib` (service Windows) | `GOMEMLIMIT=200MiB` (Windows n'a pas d'équivalent de `MemoryMax`) | 200 / 40 MiB |
| DC | `windows_exporter` | aucune | – |

## 5. Disque de obs-lgtm (60 Go)

| Poste | Taille | Origine de la valeur |
|---|---|---|
| Debian 13 de base + paquets LGTM installés | quelques Go | estimation, à mesurer (`df -h /`) |
| Lot hors ligne conservé `/opt/lgtm-bundle` | ≈ 0,9 Go | mesuré (924 901 137 octets pour le dossier téléchargé) |
| Mimir (7 jours, ≤ 150 000 séries) | à mesurer | dépend du nombre de séries réellement actives |
| Loki (72 h) | à mesurer | dépend du volume de journaux du DC et d'ELK |
| Tempo (24 h) | à mesurer | dépend de l'application de démo |
| Journal systemd | ≤ 500 Mo | `SystemMaxUse=500M` |

Le volume de données du lab n'est **pas connu** à ce stade : la taille de 60 Go laisse une marge confortable par rapport à 40 Go (plan) pour les rétentions retenues. Suivre l'occupation avec `du -sh /var/lib/mimir /var/lib/loki /var/tempo` (voir [08_Exploitation_supervision.md](08_Exploitation_supervision.md)) et la métrique `node_filesystem_avail_bytes` dans Mimir.

## 6. Fin de la migration (phase 6)

Après l'arrêt d'ELK et la suppression d'AppDynamics : **DC + obs-lgtm = 3 vCPU et 6 Go de RAM au démarrage** (le plan indiquait environ 5 Go, avec obs-lgtm à 3 Go sans Mimir).

## 7. Commandes Hyper-V

Les commandes complètes (checkpoints, `Set-VMProcessor`, `Set-VMMemory`, création d'obs-lgtm en génération 2 avec `Set-VMFirmware -SecureBootTemplate MicrosoftUEFICertificateAuthority`) sont au §3.4 du runbook. Contrôle :

```powershell
Get-VM | Select-Object Name, State, ProcessorCount, @{n='Demarrage_Go';e={$_.MemoryStartup/1GB}}, @{n='Min_Go';e={$_.MemoryMinimum/1GB}}, @{n='Max_Go';e={$_.MemoryMaximum/1GB}}
```
