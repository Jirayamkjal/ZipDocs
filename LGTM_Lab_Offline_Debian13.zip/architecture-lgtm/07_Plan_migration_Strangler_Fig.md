# 07 – Plan de migration Strangler Fig

> Reprend les phases 0 à 6 de `../Plan_integration_observabilite_lab.md` (section 3), avec les changements du runbook : **Mimir** stocke les métriques (Prometheus en mode agent), l'**Alertmanager de Mimir** remplace l'Alertmanager autonome. Les dates du plan sont indicatives.

## 1. Principe

Le motif Strangler Fig remplace un système par morceaux : on place une **façade** devant l'ancien système, on construit la nouvelle capacité à côté, on bascule les consommateurs, puis on retire l'ancienne capacité. Ici :

- façade d'**entrée** : `otelcol-contrib` sur obs-lgtm (OTLP 4317/4318) ;
- façade de **consultation** : Grafana (3000), avec Elasticsearch comme première datasource.

```mermaid
flowchart LR
  P0["0. Préparation<br/>checkpoints, AppD éteinte"] --> P1["1. Façades<br/>obs-lgtm, collecteur, Grafana"]
  P1 --> P2["2. Métriques<br/>exporteurs → Prometheus agent → Mimir"]
  P2 --> P3["3. Journaux<br/>double écriture Loki + ES"]
  P3 --> P4["4. Traces<br/>Tempo remplace AppD"]
  P4 --> P5["5. Alertes<br/>ruler + Alertmanager Mimir"]
  P5 --> P6["6. Retrait<br/>ELK et AppD"]
```

## 2. Boucle de décision à chaque phase

```mermaid
flowchart TD
  A[Checkpoint Hyper-V<br/>et entrée au journal des changements] --> B[Activer la nouvelle capacité<br/>en parallèle de l'ancienne]
  B --> C{Critère de passage atteint ?}
  C -- Oui --> D[Basculer les consommateurs]
  D --> E[Désactiver l'ancienne capacité]
  E --> F[Phase suivante]
  C -- Non --> G{Corrigible rapidement ?}
  G -- Oui --> B
  G -- Non --> H[Retour arrière :<br/>configuration du collecteur, systemctl, ou checkpoint]
  H --> A
```

## 3. Détail des phases

| Phase | Capacité remplacée | Actions (renvoi au runbook) | Critère de passage (vérifiable) | Retour arrière |
|---|---|---|---|---|
| **0. Préparation** | – | Checkpoint de chaque VM ; AppDynamics éteinte (`AutomaticStartAction Nothing`) ; ressources de la section 3 ; téléchargement et vérification du lot (§2). | `verifier-lgtm.sh` se termine sans erreur ; lab fonctionnel avec ELK seul ; `Get-VM` conforme au §3.1. | `Restore-VMCheckpoint`, `Start-VM AppDynamics`. |
| **1. Façades** | Point d'entrée, point de consultation | Création d'obs-lgtm (§3.4–3.5) ; installation §4 ; datasource ES dans Grafana ; recréer 1 ou 2 tableaux Kibana dans Grafana. | Les 7 services sont `active` ; `/ready` = `ready` pour Mimir, Loki, Tempo ; datasources Mimir, Loki, Tempo « OK » ; Grafana affiche les mêmes données que Kibana. | `systemctl disable --now` des services d'obs-lgtm ; rien n'a changé sur ELK. |
| **2. Métriques** | Métriques système | `node_exporter` sur ELK (§5.1), `windows_exporter` sur le DC (§5.2) ; tableaux de métriques dans Grafana (datasource Mimir). | `up{job="node"}` et `up{job="windows"}` = 1 dans Mimir pendant 24 h ; mêmes indicateurs (CPU, RAM, disque, services AD) que dans Kibana. | Arrêter les exporteurs (`systemctl disable --now node_exporter`, `Stop-Service windows_exporter`) ; tableaux Kibana inchangés. |
| **3. Journaux** | Collecte et recherche de journaux | Agents `otelcol-contrib` sur ELK (journald) et le DC (journaux d'événements) ; **double écriture** Loki + ES ; comparaison KQL / LogQL ; puis `systemctl disable --now logstash`. | Pendant 2 à 3 jours, mêmes volumes d'événements dans Loki et ES (écart expliqué), requêtes de démo équivalentes ; aucun refus `memory_limiter` dans les métriques d'otelcol. | `systemctl enable --now logstash` ; retirer `otlphttp/loki` du pipeline `logs` (après `otelcol-contrib validate`). |
| **4. Traces** | APM (AppDynamics) | Application de démo instrumentée (OTel .NET ou Java), OTLP vers la façade, traces dans Tempo ; corrélations traces ↔ journaux ↔ métriques. | Une transaction se suit de bout en bout dans Grafana (Tempo → Loki → Mimir) ; service map affichée. | `Start-VM AppDynamics`. |
| **5. Alertes** | Alertes Kibana / ElastAlert 2 | Règles de métriques chargées dans le *ruler* de Mimir (`mimirtool rules lint` puis `load`), règles de journaux dans le *ruler* de Loki, configuration Alertmanager (`mimirtool alertmanager verify` puis `load`) vers le webhook ITSM ou un récepteur de test. | Une alerte de test (`LabWatchdog`) arrive au récepteur ; une règle `CibleInjoignable` se déclenche quand on arrête un exporteur. | Garder ElastAlert 2 actif en parallèle ; recharger la configuration de repli `lab-null`. |
| **6. Retrait** | Ancien système | Retirer l'exportateur `elasticsearch` du pipeline `logs` ; ES en lecture seule pendant l'observation ; révoquer les clés API ES ; éteindre ELK ; exporter puis supprimer la VM AppDynamics. | Plus aucune consultation de Kibana pendant la période d'observation ; aucune alerte manquée par rapport à ElastAlert 2. | Rallumer la VM ELK (données en lecture seule) ; rétablir l'exportateur `elasticsearch` (nouvelle clé API). |

## 4. Routage par phase

```mermaid
flowchart LR
  subgraph F1[Phases 0-1]
    S1[Sources] --> L1[Logstash] --> E1[(ES)] --> K1[Kibana]
    E1 --> G1[Grafana]
  end
  subgraph F3[Phases 2-5 : coexistence]
    S3[Sources] --> C3[otelcol-contrib]
    X3[Exporteurs] --> P3[Prometheus agent] --> M3[(Mimir)]
    C3 --> E3[(ES)]
    C3 --> L3[(Loki)]
    C3 --> T3[(Tempo)]
    C3 --> M3
    E3 --> G3[Grafana]
    M3 --> G3
    L3 --> G3
    T3 --> G3
  end
  subgraph F6[Phase 6 : cible]
    S6[Sources] --> C6[otelcol-contrib]
    X6[Exporteurs] --> P6[Prometheus agent] --> M6[(Mimir)]
    C6 --> L6[(Loki)]
    C6 --> T6[(Tempo)]
    C6 --> M6
    M6 --> G6[Grafana]
    L6 --> G6
    T6 --> G6
    M6 --> A6[Alertmanager Mimir] --> I6[ITSM]
  end
  F1 ==> F3 ==> F6
```

## 5. Commandes de contrôle des critères

```bash
# Phase 1 : services et santé
for s in mimir loki tempo otelcol-contrib prometheus node_exporter grafana-server; do printf '%-16s %s\n' "$s" "$(systemctl is-active "$s")"; done
for u in 9009 3100 3200; do printf '%s : ' "$u"; wget -qO- "http://127.0.0.1:$u/ready"; echo; done

# Phase 2 : cibles scrapées
wget -qO- 'http://127.0.0.1:9009/prometheus/api/v1/query?query=up' | tr ',' '\n' | grep -E '"job"|"instance"|"value"'

# Phase 3 : présence des journaux de chaque source dans Loki
wget -qO- 'http://127.0.0.1:3100/loki/api/v1/label/service_namespace/values'   # attendu : elk, dc
# Refus éventuels du memory_limiter (métrique interne du collecteur ; doit rester à 0)
wget -qO- http://127.0.0.1:8888/metrics | grep -E '^otelcol_processor_memory_limiter_(accepted|refused)' 

# Phase 5 : alertes actives dans l'Alertmanager de Mimir
wget -qO- http://127.0.0.1:9009/alertmanager/api/v2/alerts | tr ',' '\n' | grep alertname
```

> Noms relevés sur otelcol-contrib 0.164.0 en test (métriques marquées *Alpha*, susceptibles de changer). Seuls les compteurs `accepted` ont été observés en test (aucun refus provoqué) ; le nom exact des compteurs `refused` n'est pas vérifié.

## 6. Ressources par phase

| Phase | VM allumées | vCPU | RAM de démarrage |
|---|---|---|---|
| 0 | DC, ELK | 3 | 6 Go |
| 1 à 5 | DC, ELK, obs-lgtm | 5 | 10 Go |
| 6 (après retrait) | DC, obs-lgtm | 3 | 6 Go |

## 7. Retour arrière global

1. **Niveau service** : `systemctl disable --now <service>` (obs-lgtm, ELK) ou `Stop-Service` (DC).
2. **Niveau routage** : retirer un exportateur du pipeline du collecteur, valider (`otelcol-contrib validate --config=/etc/otelcol-contrib/config.yaml`), redémarrer.
3. **Niveau VM** : `Restore-VMCheckpoint` du checkpoint pris avant la phase (voir [GUARDRAILS.md](GUARDRAILS.md), §8).
4. **Désinstallation complète** : runbook §7.
