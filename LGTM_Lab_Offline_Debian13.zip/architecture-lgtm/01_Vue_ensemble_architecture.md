# 01 – Vue d'ensemble de l'architecture LGTM du lab

> Dossier d'architecture du lab d'observabilité Hyper-V. Document compagnon de `../Runbook_LGTM_Offline_Debian13.md` (le runbook fait foi pour les commandes et les fichiers de configuration). Versions vérifiées le 28 oct. 2026.

## 1. Contexte

Le lab Hyper-V héberge aujourd'hui :

- un **contrôleur de domaine** Windows (AD DS, DNS) ;
- une VM **ELK** (Elasticsearch 9, Kibana, Logstash, ElastAlert 2) qui centralise les journaux et les alertes ;
- une VM **AppDynamics** (APM) qui est **éteinte** pour libérer de la RAM, et conservée pour le retour arrière.

Le plan `../Plan_integration_observabilite_lab.md` prévoit de remplacer progressivement ELK et AppDynamics par une pile **LGTM** (Loki, Grafana, Tempo, **Mimir**) selon le motif **Strangler Fig** : les nouvelles capacités fonctionnent en parallèle des anciennes, puis les remplacent phase par phase.

Contraintes du lab :

| Contrainte | Conséquence sur l'architecture |
|---|---|
| Les VM Debian 13 **n'ont pas accès à Internet** | Un poste Windows connecté télécharge un lot de fichiers épinglés. Toute la vérification (empreintes, GPG), l'installation et la configuration se font sur Linux. Voir [ADR-002](04_Decisions_architecture_ADR.md#adr-002). |
| **Pas de Docker** | Paquets `.deb` et binaires officiels, lancés en services **systemd** natifs. Voir [ADR-001](04_Decisions_architecture_ADR.md#adr-001). |
| Hôte de lab avec peu de RAM | Une seule VM `obs-lgtm`, avec des composants en mode monolithique et des limites mémoire systemd. Voir [05_Dimensionnement_infra.md](05_Dimensionnement_infra.md). |
| Lab de démonstration | Un seul nœud par composant, stockage sur disque local, rétention courte. Pas de haute disponibilité. |

## 2. Composants

| Composant | Version | VM | Rôle | Remplace / complète |
|---|---|---|---|---|
| OpenTelemetry Collector **contrib** (`otelcol-contrib`) | 0.164.0 | obs-lgtm (façade), ELK et DC (agents) | **Façade d'ingestion** OTLP. Routage vers Mimir, Loki, Tempo et, pendant la transition, Elasticsearch. Les agents lisent journald (ELK) et les journaux d'événements Windows (DC). | Logstash (phase 3), agents AppDynamics (phase 4) |
| Prometheus (mode **agent**) | 3.15.1 | obs-lgtm | Collecte (*scrape*) des exporteurs, puis `remote_write` vers Mimir. Aucun stockage interrogeable. | Métriques Kibana / Metricbeat |
| **Grafana Mimir** (monolithique) | 3.2.3 | obs-lgtm | **Stockage long des métriques**, API Prometheus (`/prometheus`), réception OTLP (`/otlp`), *ruler* et **Alertmanager intégré**. | Prometheus serveur et Alertmanager autonome du plan |
| Grafana Loki | 3.7.9 | obs-lgtm | Stockage et requêtes des journaux (LogQL), réception OTLP. | Elasticsearch (journaux), phases 3 à 6 |
| Grafana Tempo | 3.1.1 | obs-lgtm | Stockage des traces ; `metrics_generator` (span-metrics, service graph) vers Mimir. | AppDynamics (APM), phase 4 |
| Grafana OSS | 13.2.4 | obs-lgtm | **Façade de consultation** : tableaux de bord, Explore, corrélations traces ↔ journaux ↔ métriques. ES reste une datasource transitoire. | Kibana |
| node_exporter | 1.12.1 | obs-lgtm, ELK | Métriques système Linux (`:9100`). | – |
| windows_exporter | 0.32.0 | DC | Métriques Windows, AD et DNS (`:9182`). | – |
| mimirtool | 3.2.3 | obs-lgtm | Chargement et vérification des règles et de la configuration Alertmanager. | – |

**Grafana Alloy (1.21.2) a été évalué mais n'est pas retenu** : il ferait doublon avec `otelcol-contrib` (voir [ADR-004](04_Decisions_architecture_ADR.md#adr-004)).

## 3. Vue logique

```mermaid
flowchart LR
  subgraph SRC[Sources]
    DC[DC Windows<br/>windows_exporter, otelcol agent]
    ELK[VM ELK<br/>node_exporter, otelcol agent]
    APP[Application de démo<br/>SDK ou agent OTel]
  end
  subgraph ING[Ingestion]
    COL[otelcol-contrib<br/>façade OTLP]
    PROM[Prometheus agent<br/>scrape + remote_write]
  end
  subgraph STO[Stockage]
    MIM[(Mimir<br/>métriques)]
    LOK[(Loki<br/>journaux)]
    TEM[(Tempo<br/>traces)]
    ES[(Elasticsearch 9<br/>transitoire)]
  end
  subgraph ALR[Alertes]
    AM[Alertmanager<br/>intégré à Mimir]
  end
  GRAF[Grafana<br/>consultation]
  DC -- OTLP journaux --> COL
  ELK -- OTLP journaux --> COL
  APP -- OTLP traces, métriques, journaux --> COL
  PROM -- scrape --> DC
  PROM -- scrape --> ELK
  PROM -- remote_write --> MIM
  COL -- métriques --> MIM
  COL -- journaux --> LOK
  COL -- traces --> TEM
  COL -. double écriture .-> ES
  TEM -- span-metrics --> MIM
  MIM -- ruler --> AM
  LOK -- ruler --> AM
  GRAF --> MIM
  GRAF --> LOK
  GRAF --> TEM
  GRAF -.-> ES
```

Principes :

1. **Deux façades** : toute donnée entre par `otelcol-contrib` (ou est collectée par Prometheus) ; toute consultation passe par Grafana. C'est ce qui permet le Strangler Fig : on change la destination derrière les façades sans toucher aux sources ni aux utilisateurs.
2. **Un composant par signal** : métriques dans Mimir, journaux dans Loki, traces dans Tempo.
3. **Alertes centralisées** dans l'Alertmanager de Mimir (règles de métriques par le *ruler* de Mimir, règles de journaux par le *ruler* de Loki).
4. Seuls **Grafana (3000)** et **le collecteur (4317/4318)** sont joignables depuis le réseau du lab ; les autres services écoutent sur `127.0.0.1` (voir [03_Matrice_reseau_ports.md](03_Matrice_reseau_ports.md)).

## 4. Vue physique (Hyper-V)

```mermaid
flowchart TB
  WIN[Poste Windows connecté<br/>téléchargement seulement]
  subgraph HV[Hôte Hyper-V - vSwitch du lab - aucun accès Internet pour les VM Linux]
    DC[DC - Windows Server<br/>1 vCPU · 2 Go 1-2 Go]
    ELK[ELK - Debian 13<br/>2 vCPU · 4 Go 3-5 Go]
    OBS[obs-lgtm - Debian 13.7<br/>2 vCPU · 4 Go 3-6 Go · 60 Go]
    APPD[AppDynamics<br/>éteinte]
  end
  WIN -. scp / sftp du lot vérifié .-> OBS
  WIN -. scp ISO Debian .-> ELK
  DC -- OTLP 4317 --> OBS
  ELK -- OTLP 4317 --> OBS
  OBS -- scrape 9182 --> DC
  OBS -- scrape 9100 --> ELK
  OBS -. HTTPS 9200 double écriture .-> ELK
  classDef off fill:#ddd,stroke:#999,stroke-dasharray: 5 5
  class APPD off
```

| VM | OS | vCPU | RAM démarrage (min / max) | Disque |
|---|---|---|---|---|
| DC | Windows Server (existant) | 1 | 2 Go (1 / 2) | existant |
| ELK | Debian 13 | 2 | 4 Go (3 / 5) | existant |
| AppDynamics | existant | inchangé | éteinte | existant |
| obs-lgtm | Debian 13.7 | 2 (4 si l'hôte a ≥ 8 processeurs logiques) | 4 Go (3 / 6) | 60 Go VHDX dynamique |

Détail et justification : [05_Dimensionnement_infra.md](05_Dimensionnement_infra.md) et le §3 du runbook.

## 5. Organisation sur obs-lgtm

| Service systemd | Utilisateur | Configuration | Données | Écoute |
|---|---|---|---|---|
| `otelcol-contrib` | `otelcol-contrib` | `/etc/otelcol-contrib/config.yaml` (+ `otelcol-contrib.conf`) | – (en mémoire) | 0.0.0.0:4317/4318, 127.0.0.1:8888 |
| `prometheus` (agent) | `prometheus` | `/etc/prometheus/prometheus.yml` | `/var/lib/prometheus` (WAL) | 127.0.0.1:9090 |
| `mimir` | `mimir` | `/etc/mimir/config.yml`, `/etc/default/mimir` | `/var/lib/mimir` | 127.0.0.1:9009, 9097, 7946 |
| `loki` | `loki` | `/etc/loki/config.yml` | `/var/lib/loki` | 127.0.0.1:3100, 9096 |
| `tempo` | `tempo` | `/etc/tempo/config.yml` | `/var/tempo` | 127.0.0.1:3200, 9095, 4417/4418 |
| `grafana-server` | `grafana` | `/etc/grafana/`, provisioning, drop-in `offline.conf` | `/var/lib/grafana` | 0.0.0.0:3000 |
| `node_exporter` | `node_exporter` | unité `/etc/systemd/system/node_exporter.service` | – | 0.0.0.0:9100 |

Le lot hors ligne vérifié reste dans `/opt/lgtm-bundle` (≈ 0,9 Go) pour une réinstallation à l'identique.

## 6. Hors périmètre

- Haute disponibilité, réplication, stockage objet (S3/MinIO) : non nécessaires pour un lab.
- Architecture *ingest storage* de Mimir (Kafka) : voir [ADR-003](04_Decisions_architecture_ADR.md#adr-003).
- Instrumentation détaillée de l'application de démo (phase 4 du plan).
- Connecteur ITSM réel : un récepteur nul (`lab-null`) est configuré par défaut dans l'Alertmanager.

## 7. Documents liés

- [02_Flux_de_donnees.md](02_Flux_de_donnees.md) : pipelines et séquences.
- [03_Matrice_reseau_ports.md](03_Matrice_reseau_ports.md) : flux réseau.
- [04_Decisions_architecture_ADR.md](04_Decisions_architecture_ADR.md) : décisions.
- [GUARDRAILS.md](GUARDRAILS.md) : garde-fous d'exploitation.
