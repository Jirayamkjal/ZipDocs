# 02 – Flux de données

> Décrit **ce qui circule, par où et dans quel format**. Les fichiers de configuration complets sont dans le runbook (`../Runbook_LGTM_Offline_Debian13.md`, §4 et §5). Les ports sont dans [03_Matrice_reseau_ports.md](03_Matrice_reseau_ports.md).

## 1. Vue d'ensemble des pipelines

| Signal | Source | Collecte | Transport | Destination | Consultation |
|---|---|---|---|---|---|
| Métriques système Linux | obs-lgtm, ELK | `node_exporter` :9100 | *scrape* HTTP par Prometheus agent, puis `remote_write` | Mimir `/api/v1/push` | Grafana → Mimir `/prometheus` |
| Métriques Windows, AD, DNS | DC | `windows_exporter` :9182 | *scrape* HTTP par Prometheus agent, puis `remote_write` | Mimir | Grafana → Mimir |
| Métriques internes LGTM | Mimir, Loki, Tempo, otelcol, Grafana | `/metrics` de chaque service | *scrape* (job `lgtm-self`), puis `remote_write` | Mimir | Grafana → Mimir |
| Métriques applicatives | Application de démo (phase 4) | SDK / agent OTel | OTLP vers otelcol, puis OTLP/HTTP | Mimir `/otlp` | Grafana → Mimir |
| Span-metrics, service graph | Tempo `metrics_generator` | dérivées des traces | `remote_write` | Mimir `/api/v1/push` | Grafana (service map) |
| Journaux ELK | ELK (journald : elasticsearch, kibana, elastalert2, ssh) | otelcol agent (`journald`) | OTLP gRPC vers la façade | Loki `/otlp` **et** Elasticsearch (phases 1 à 3) | Grafana → Loki (et ES, transitoire) |
| Journaux Windows | DC (journaux d'événements) | otelcol agent (`windowseventlog`) | OTLP gRPC vers la façade | Loki **et** Elasticsearch (phases 1 à 3) | Grafana → Loki |
| Journaux applicatifs | Application de démo | SDK / agent OTel | OTLP | Loki (et ES pendant la transition) | Grafana → Loki |
| Traces | Application de démo | SDK / agent OTel | OTLP vers otelcol, puis OTLP gRPC | Tempo :4417 | Grafana → Tempo |
| Alertes | *ruler* de Mimir (métriques), *ruler* de Loki (journaux) | règles chargées avec `mimirtool` / fichiers de règles | HTTP | Alertmanager de Mimir `/alertmanager` | Grafana (datasource `mimir-am`), récepteur ITSM (phase 5) |

## 2. Pipelines du collecteur central (obs-lgtm)

Extrait de `/etc/otelcol-contrib/config.yaml` (runbook §4.7) :

| Pipeline | Récepteur | Processeurs | Exportateurs |
|---|---|---|---|
| `metrics` | `otlp` (0.0.0.0:4317 gRPC, 0.0.0.0:4318 HTTP) | `memory_limiter` (300 / 60 MiB), `batch` | `otlphttp/mimir` → `http://127.0.0.1:9009/otlp` |
| `logs` | `otlp` | `memory_limiter`, `batch` | `otlphttp/loki` → `http://127.0.0.1:3100/otlp` **+** `elasticsearch` → `https://<ip-elk>:9200` (clé API, CA du cluster) |
| `traces` | `otlp` | `memory_limiter`, `batch` | `otlp/tempo` → `127.0.0.1:4417` (gRPC, sans TLS sur la boucle locale) |

```mermaid
flowchart LR
  R[otlp<br/>:4317 / :4318] --> ML[memory_limiter<br/>300 / 60 MiB] --> B[batch]
  B -->|metrics| EM[otlphttp/mimir<br/>127.0.0.1:9009/otlp]
  B -->|logs| EL[otlphttp/loki<br/>127.0.0.1:3100/otlp]
  B -->|logs| EE[elasticsearch<br/>https://ip-elk:9200]
  B -->|traces| ET[otlp/tempo<br/>127.0.0.1:4417]
  classDef trans stroke-dasharray: 5 5
  class EE trans
```

**Pourquoi `memory_limiter` en premier :** il refuse les données (erreur renvoyée à l'émetteur, qui réessaie) avant que le processus n'atteigne `MemoryMax=384M`. Sans lui, le noyau tuerait le collecteur (OOM) et toutes les données en mémoire seraient perdues.

## 3. Routage OTel et étiquettes

- **Attribut `service.namespace`** : chaque agent l'ajoute (`elk` pour la VM ELK, `dc` pour le DC) avec le processeur `resource`. Loki le transforme en étiquette d'index `service_namespace` ; les requêtes de démo filtrent avec `{service_namespace="elk"}`.
- **Attribut `service.name`** : fourni par l'application (SDK OTel). Il devient l'étiquette `service_name` dans Loki et l'attribut de ressource `service.name` dans Tempo.
- **Métriques OTLP dans Mimir :** les attributs de ressource sont placés dans la métrique `target_info` ; les noms sont convertis au format Prometheus par l'endpoint `/otlp` de Mimir ([documentation Mimir](https://grafana.com/docs/mimir/latest/configure/configure-otel-collector/)).
- **Métriques Prometheus :** `metric_name_validation_scheme: legacy` est imposé dans `prometheus.yml`, car Mimir refuse les étiquettes UTF-8 envoyées par défaut par Prometheus 3 (problème constaté en test, voir le §6 du runbook).
- **Corrélation :** la datasource Loki définit un champ dérivé `TraceID` (étiquette `trace_id`) vers Tempo ; la datasource Tempo renvoie vers Loki (`tracesToLogsV2`) et vers Mimir (`tracesToMetrics`, service map) ; la datasource Mimir relie les *exemplars* `trace_id` à Tempo.

## 4. Double écriture ELK / Loki (phases 1 à 3 du Strangler Fig)

Pendant la transition, le pipeline `logs` a **deux exportateurs**. Chaque exportateur a sa propre file d'attente et ses propres réessais : une panne d'Elasticsearch ne bloque pas l'écriture dans Loki, et inversement.

```mermaid
sequenceDiagram
  autonumber
  participant AG as Agent otelcol (ELK ou DC)
  participant COL as otelcol-contrib (obs-lgtm)
  participant LOK as Loki
  participant ES as Elasticsearch 9
  participant GRAF as Grafana
  AG->>COL: OTLP gRPC :4317 (lot de journaux)
  COL->>COL: memory_limiter puis batch
  COL-->>AG: OK (acquitté dès la mise en lot)
  par Exportateur Loki
    COL->>LOK: POST /otlp/v1/logs (127.0.0.1:3100)
    LOK-->>COL: 2xx
  and Exportateur Elasticsearch
    COL->>ES: POST _bulk (HTTPS :9200, ApiKey)
    ES-->>COL: 2xx
  end
  GRAF->>LOK: requête LogQL
  GRAF->>ES: requête Lucene (datasource transitoire)
  Note over COL,ES: Phase 6 : retirer « elasticsearch » des exportateurs du pipeline logs
```

**Critère de comparaison (plan, phase 3) :** mêmes événements dans Loki et ES pendant 2 à 3 jours, et requêtes de démo équivalentes (KQL / LogQL). Voir [07_Plan_migration_Strangler_Fig.md](07_Plan_migration_Strangler_Fig.md).

## 5. Métriques : Prometheus agent → Mimir

```mermaid
sequenceDiagram
  autonumber
  participant P as Prometheus agent (127.0.0.1:9090)
  participant NE as node_exporter / windows_exporter
  participant M as Mimir (127.0.0.1:9009)
  participant G as Grafana
  loop toutes les 30 s
    P->>NE: GET /metrics
    NE-->>P: exposition texte
    P->>P: WAL local (/var/lib/prometheus)
  end
  P->>M: POST /api/v1/push (remote_write, snappy + protobuf)
  M-->>P: 200 (ou 4xx : échantillon refusé, 5xx : nouvel essai)
  G->>M: GET /prometheus/api/v1/query_range
  M-->>G: série temporelle
```

Si Mimir est arrêté, Prometheus agent garde les échantillons dans son WAL et les renvoie au redémarrage de Mimir (dans la limite de la rétention du WAL).

## 6. Traces : application → Tempo → Mimir

```mermaid
sequenceDiagram
  autonumber
  participant APP as Application (SDK OTel)
  participant COL as otelcol-contrib
  participant T as Tempo (4417 / 3200)
  participant M as Mimir
  participant G as Grafana
  APP->>COL: OTLP (spans)
  COL->>T: OTLP gRPC 127.0.0.1:4417
  T->>T: ingester puis bloc sur /var/tempo
  T->>M: remote_write span-metrics, service graph
  G->>T: TraceQL / recherche par trace ID
  G->>M: service map (traces_service_graph_*)
```

## 7. Alertes

```mermaid
sequenceDiagram
  autonumber
  participant RM as ruler Mimir
  participant RL as ruler Loki
  participant AM as Alertmanager (Mimir)
  participant RCV as Récepteur (lab-null, puis ITSM)
  RM->>RM: évalue les règles (namespace lab)
  RM->>AM: POST alertes (127.0.0.1:9009/alertmanager)
  RL->>AM: POST alertes (même URL)
  AM->>AM: groupement, inhibition, silences
  AM->>RCV: notification (aucune en phase 1 : récepteur nul)
```

Règles fournies dans le runbook (§4.11) : `CibleInjoignable` (`up == 0` pendant 5 min) et `LabWatchdog` (toujours active, pour vérifier la chaîne). Les règles de journaux du *ruler* de Loki ne sont pas testées (annexe A du runbook).

## 8. Évolution du routage par phase

| Phase | Journaux | Métriques | Traces | Consultation |
|---|---|---|---|---|
| 0 | Logstash → ES | Kibana | AppDynamics (éteinte) | Kibana |
| 1 | Logstash → ES ; collecteur prêt (double écriture) | Prometheus agent → Mimir (obs-lgtm seul) | – | Grafana avec ES comme datasource |
| 2 | idem | + DC et ELK scrapés | – | dashboards de métriques dans Grafana |
| 3 | agents otelcol → façade → **Loki + ES** ; Logstash arrêté | idem | – | dashboards de journaux vers Loki |
| 4 | idem | idem | app → façade → **Tempo** | corrélations dans Grafana |
| 5 | idem | idem | idem | alertes dans l'Alertmanager de Mimir |
| 6 | façade → **Loki seul** | idem | idem | Grafana seul ; ES en lecture seule puis VM éteinte |
