# 04 – Décisions d'architecture (ADR)

> Format : contexte, décision, conséquences, alternatives écartées. Statut au 28 oct. 2026. Toute nouvelle décision s'ajoute à la fin avec un nouveau numéro ; une décision remplacée passe au statut « Remplacée par ADR-xxx ».

| ADR | Titre | Statut |
|---|---|---|
| [ADR-001](#adr-001) | Services systemd natifs, sans Docker | Acceptée |
| [ADR-002](#adr-002) | Installation hors ligne : Windows télécharge, Linux vérifie et installe | Acceptée |
| [ADR-003](#adr-003) | Mimir monolithique, architecture classique (sans Kafka) | Acceptée |
| [ADR-004](#adr-004) | Prometheus en mode agent plutôt que Grafana Alloy | Acceptée |
| [ADR-005](#adr-005) | Alertmanager intégré à Mimir | Acceptée |
| [ADR-006](#adr-006) | Migration Strangler Fig avec double écriture ELK / Loki | Acceptée |
| [ADR-007](#adr-007) | Rétention courte et plafonds de disque | Acceptée |
| [ADR-008](#adr-008) | Versions épinglées et Grafana 13.2.4 plutôt que 13.3.0 | Acceptée |

---

<a id="adr-001"></a>
## ADR-001 – Services systemd natifs, sans Docker

**Contexte.** Le lab tourne sur un hôte Hyper-V à RAM limitée. Les VM Linux n'ont pas Internet : un registre d'images ne serait pas joignable, et il faudrait importer des images à la main (`docker load`). Le plan d'intégration impose déjà une installation native.

**Décision.** Chaque composant est installé à partir du paquet `.deb` officiel (Grafana, Mimir, mimirtool, Loki, Tempo, otelcol-contrib) ou de l'archive binaire officielle (Prometheus, node_exporter), et tourne en **service systemd** avec son propre utilisateur système. Les limites de ressources sont posées par des drop-ins (`MemoryHigh`, `MemoryMax`, `GOMEMLIMIT`).

**Conséquences.**
- (+) Pas de démon de conteneurs, pas d'images à transporter ; empreinte mémoire plus faible.
- (+) Outils standard : `systemctl`, `journalctl`, `systemd-cgtop`, `dpkg`.
- (+) Les paquets fournissent l'unité systemd, l'utilisateur et la configuration d'exemple.
- (−) Les scripts `postinst` de Mimir, Loki, Tempo et otelcol-contrib **activent et démarrent** le service avec la configuration d'exemple : il faut les arrêter juste après `dpkg -i` (runbook §4.2).
- (−) Mise à jour = nouveau lot hors ligne, puis `dpkg -i` (voir [08_Exploitation_supervision.md](08_Exploitation_supervision.md)).

**Alternatives écartées.** Docker / Podman avec images importées (plus de RAM, plus de fichiers à transporter, contraire au plan) ; Kubernetes / Helm (hors de proportion pour un lab).

---

<a id="adr-002"></a>
## ADR-002 – Installation hors ligne : Windows télécharge, Linux vérifie et installe

**Contexte.** Seul un poste Windows a accès à Internet. Les outils de vérification fiables (`sha256sum`, `sqv`) sont présents sur Debian 13 ; sur Windows, seuls `Get-FileHash`, `curl.exe` et `tar.exe` sont garantis.

**Décision.**
1. Le poste Windows **ne fait que télécharger** : script `Telecharger-LGTM.ps1` (versions épinglées, `curl.exe --fail`), manifeste `Get-FileHash`, archive `tar`, transfert `scp`.
2. Toute la confiance est établie **sur Linux** (`verifier-lgtm.sh`) à trois niveaux : (a) empreintes publiées par chaque projet, (b) **index APT Grafana signé** (`InRelease`, clé `B53A E77B ADB6 30A6 8304 6005 963F A277 1045 8545`, vérifiée avec `sqv`), qui contient les SHA-256 des `.deb` Grafana, Mimir, mimirtool, Loki et Tempo, (c) empreintes attendues inscrites dans le runbook (`lgtm-sha256-attendus`).
3. L'ISO Debian est vérifiée avec `SHA256SUMS.sign` (clé `DF9B 9C49 EAA9 2984 3258 9D76 DA87 E80D 6294 BE9B`).
4. Rien n'est installé si une seule vérification échoue.

**Conséquences.**
- (+) Une archive altérée pendant le transfert, ou une empreinte publiée modifiée, est détectée (testé avec des fichiers altérés).
- (+) `sqv` est toujours présent sur Debian 13 (dépendance d'`apt` 3.0) ; `curl` n'est pas sur l'ISO netinst, d'où l'usage de `wget`.
- (−) `InRelease` est régénéré chaque jour : il faut le télécharger **en même temps** que `Packages.gz`.
- (−) Les signatures Sigstore (`.sigstore.json`) d'OpenTelemetry ne sont pas vérifiées (`cosign` absent hors ligne).

**Alternatives écartées.** Miroir APT local (`apt-mirror`, `aptly`) : trop lourd pour un lab ; vérification sous Windows : outils GPG non disponibles par défaut, et cela contredirait la séparation des rôles.

---

<a id="adr-003"></a>
## ADR-003 – Mimir monolithique, architecture classique (sans Kafka)

**Contexte.** Le plan stockait les métriques dans Prometheus. L'utilisateur a demandé une vraie pile LGTM avec **Mimir**. Depuis Mimir 3.0, l'architecture recommandée est l'*ingest storage* (Kafka) ; l'architecture classique reste prise en charge ([notes de version 3.0](https://grafana.com/docs/mimir/v3.0.x/release-notes/v3.0/)).

**Décision.** Un seul processus `mimir` avec `target: all,alertmanager`, architecture **classique**, stockage `filesystem` sous `/var/lib/mimir`, anneau `inmemory`, gRPC et memberlist sur `127.0.0.1`, `MemoryMax=768M`.

**Conséquences.**
- (+) Un seul service à exploiter ; pas de Kafka (qui demanderait une JVM ou un autre service et plus de RAM).
- (+) API Prometheus complète (`/prometheus`), réception OTLP native (`/otlp`), *ruler* et Alertmanager inclus.
- (−) Pas de haute disponibilité ; le stockage `filesystem` est signalé par Mimir comme réservé au développement et aux tests. Acceptable pour un lab, pas en production.
- (−) Mimir classique pourrait devenir obsolète dans une version majeure future : à revoir à chaque mise à jour.

**Alternatives écartées.** Prometheus serveur seul (pas de Mimir, contraire à la demande) ; Mimir en microservices ou avec ingest storage (hors de proportion) ; Thanos / VictoriaMetrics (hors pile LGTM).

---

<a id="adr-004"></a>
## ADR-004 – Prometheus en mode agent plutôt que Grafana Alloy

**Contexte.** Il faut un composant qui *scrape* les exporteurs (node_exporter, windows_exporter, métriques internes) et pousse vers Mimir. Deux candidats : Prometheus 3.15.1 `--agent` et Grafana Alloy 1.21.2.

**Décision.** **Prometheus en mode agent.** `otelcol-contrib` reste le seul collecteur OTLP (façade d'ingestion et agents).

| Critère | Prometheus agent | Alloy |
|---|---|---|
| Rôle restant à couvrir | scrape + `remote_write` uniquement | scrape, journaux, traces, OTLP… (déjà couverts par otelcol-contrib) |
| Doublon avec otelcol-contrib | non | **oui** (deux collecteurs à configurer et à limiter) |
| Continuité avec le plan | même outil, même `prometheus.yml`, `promtool check config --agent` | nouveau langage de configuration (Alloy syntax) |
| Taille de l'artefact | archive ≈ 112 Mo | `.deb` ≈ 168 Mo |
| Mémoire au repos mesurée en test | 115–130 Mo | non mesurée |

**Conséquences.** (+) Configuration connue et vérifiable avec `promtool`. (−) Deux outils de collecte (Prometheus pour le *pull*, otelcol pour le *push*) au lieu d'un seul. Alloy reste une option si l'on veut remplacer **à la fois** Prometheus agent et otelcol-contrib par un seul agent Grafana ; ce serait un nouvel ADR.

**Alternatives écartées.** Récepteur `prometheus` d'otelcol-contrib (possible, mais il augmenterait la charge du collecteur central et s'éloignerait du plan) ; Alloy.

---

<a id="adr-005"></a>
## ADR-005 – Alertmanager intégré à Mimir

**Décision.** Pas de service `alertmanager` autonome : Mimir fournit un Alertmanager compatible (`target: all,alertmanager`, `/alertmanager`). Le *ruler* de Mimir et celui de Loki y envoient leurs alertes. Configuration de repli `/etc/mimir/alertmanager-fallback.yml` avec un récepteur nul `lab-null` ; la configuration réelle se charge avec `mimirtool alertmanager load` après `mimirtool alertmanager verify`.

**Conséquences.** (+) Un service et 64 Mo de RAM de moins que le plan. (+) Datasource Grafana `mimir-am` (implémentation `mimir`). (−) La cible `all` seule ne démarre **pas** l'Alertmanager (constaté en test : `404`).

---

<a id="adr-006"></a>
## ADR-006 – Migration Strangler Fig avec double écriture ELK / Loki

**Contexte.** ELK est en service et sert aux démonstrations ; on ne peut pas le couper d'un coup.

**Décision.** Suivre les phases 0 à 6 du plan. Les deux **façades** (otelcol-contrib pour l'entrée, Grafana pour la consultation) sont installées d'abord ; les capacités sont ensuite remplacées une par une. Pour les journaux, le collecteur fait une **double écriture** vers Loki et Elasticsearch (phases 1 à 3), puis l'exportateur `elasticsearch` est retiré (phase 6). Détail : [07_Plan_migration_Strangler_Fig.md](07_Plan_migration_Strangler_Fig.md).

**Conséquences.** (+) Retour arrière possible à chaque phase sans perte. (+) Comparaison directe KQL / LogQL. (−) Charge temporaire : écriture en double, VM ELK plus grosse (4 Go au lieu de 3 Go) jusqu'à l'arrêt de Logstash.

---

<a id="adr-007"></a>
## ADR-007 – Rétention courte et plafonds de disque

**Décision.**

| Données | Rétention | Paramètre |
|---|---|---|
| Métriques (Mimir) | 7 jours | `limits.compactor_blocks_retention_period: 7d` |
| Journaux (Loki) | 72 h | `limits_config.retention_period: 72h`, `compactor.retention_enabled: true` |
| Traces (Tempo) | 24 h | `overrides.defaults.compaction.block_retention: 24h` (vérifié : `1d` dans `/status/config`) |
| WAL Prometheus agent | jusqu'à l'envoi vers Mimir | – |
| Journal systemd | 500 Mo | `SystemMaxUse=500M` |

Disque obs-lgtm : **60 Go** (VHDX dynamique). Mimir limite aussi la cardinalité (`max_global_series_per_user: 150000`, `ingestion_rate: 20000`).

**Conséquences.** (+) Le disque ne se remplit pas pendant une démonstration de plusieurs jours. (−) Pas d'historique long ; pour une comparaison sur plus de 72 h de journaux, augmenter la rétention Loki et surveiller le disque.

**Note de test.** Dans Tempo 3.1, le paramètre `block_retention` placé dans le bloc du *backend worker* n'était pas pris en compte ; seul le paramètre d'`overrides` l'a été.

---

<a id="adr-008"></a>
## ADR-008 – Versions épinglées et Grafana 13.2.4 plutôt que 13.3.0

**Décision.** Versions fixées dans le script de téléchargement et dans `lgtm-sha256-attendus` :

| Composant | Version |
|---|---|
| Grafana OSS | 13.2.4 (build 38252365904) |
| Grafana Mimir / mimirtool | 3.2.3 |
| Grafana Loki | 3.7.9 |
| Grafana Tempo | 3.1.1 |
| Prometheus | 3.15.1 |
| node_exporter | 1.12.1 |
| OpenTelemetry Collector contrib | 0.164.0 |
| windows_exporter | 0.32.0 |
| Debian | 13.7.0 (netinst), `adduser` 3.152 |

Grafana 13.3.0 est sorti le 27 oct. 2026 mais **n'était pas encore dans l'index APT signé** le 28 oct. 2026 : sa vérification par la chaîne GPG aurait été impossible. 13.2.4 est retenu.

**Conséquences.** Toute montée de version passe par une nouvelle vérification complète (voir [08_Exploitation_supervision.md](08_Exploitation_supervision.md) et [GUARDRAILS.md](GUARDRAILS.md)).
