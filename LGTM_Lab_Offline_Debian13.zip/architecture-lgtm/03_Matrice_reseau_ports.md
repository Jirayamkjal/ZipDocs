# 03 – Matrice réseau et ports

> Tous les flux du lab LGTM. Les adresses sont des espaces réservés (`<ip-dc>`, `<ip-elk>`, `<ip-obs-lgtm>`, `<ip-poste-windows>`) : remplace-les par les adresses du vSwitch du lab. Ports vérifiés dans les fichiers de configuration du runbook et, pour les valeurs par défaut, avec `-help` des binaires (28 oct. 2026).

## 1. Flux entre machines

| # | Source | Destination | Port | Protocole | Objet | Phase | Chiffrement |
|---|---|---|---|---|---|---|---|
| F1 | Poste Windows | obs-lgtm | 22 | TCP / SSH (scp, sftp) | Transfert du lot hors ligne vérifié | Préparation | SSH |
| F2 | Poste Windows | ELK | 22 | TCP / SSH (scp) | Transfert de l'ISO Debian 13.7 pour la vérifier avec `sqv` | Préparation | SSH |
| F3 | Poste Windows / navigateur de l'admin | obs-lgtm | 3000 | TCP / HTTP | Interface Grafana | 1 → 6 | non (lab) ; voir [06_Securite.md](06_Securite.md) |
| F4 | DC (otelcol agent) | obs-lgtm | 4317 | TCP / gRPC OTLP | Journaux d'événements Windows | 3 → 6 | non (lab) ; TLS possible |
| F5 | ELK (otelcol agent) | obs-lgtm | 4317 | TCP / gRPC OTLP | Journaux journald (elasticsearch, kibana, elastalert2, ssh) | 3 → 6 | non (lab) ; TLS possible |
| F6 | Application de démo | obs-lgtm | 4317 ou 4318 | TCP / gRPC ou HTTP OTLP | Traces, métriques, journaux applicatifs | 4 → 6 | non (lab) |
| F7 | obs-lgtm (Prometheus agent) | DC | 9182 | TCP / HTTP | Scrape `windows_exporter` | 2 → 6 | non |
| F8 | obs-lgtm (Prometheus agent) | ELK | 9100 | TCP / HTTP | Scrape `node_exporter` | 2 → 5 | non |
| F9 | obs-lgtm (otelcol-contrib) | ELK | 9200 | TCP / HTTPS | Double écriture des journaux (`_bulk`, clé API d'écriture) | 1 → 3 (retrait en 6) | TLS (CA HTTP d'ES) |
| F10 | obs-lgtm (Grafana) | ELK | 9200 | TCP / HTTPS | Datasource Elasticsearch transitoire (clé API de lecture) | 1 → 5 | TLS (CA HTTP d'ES) |
| F11 | Poste de l'admin | ELK | 5601 | TCP / HTTPS ou HTTP | Kibana (création des clés API, comparaison) | 0 → 5 | selon la configuration d'ELK existante |
| F12 | Poste de l'admin | VM Linux | 22 | TCP / SSH | Administration | toutes | SSH |
| F13 | obs-lgtm (Alertmanager de Mimir) | ITSM / webhook | à définir | HTTPS | Notifications d'alertes | 5 → 6 | à définir |

**Aucun flux sortant vers Internet** n'est nécessaire depuis les VM Linux. Grafana est configuré pour ne faire aucun appel sortant (drop-in `offline.conf`, runbook §4.8), Mimir et Loki ont `usage_stats` / `analytics` désactivés.

## 2. Ports d'écoute sur obs-lgtm

| Service | Port | Protocole | Adresse d'écoute | Joignable depuis le lab | Utilisé par |
|---|---|---|---|---|---|
| otelcol-contrib | 4317 | gRPC OTLP | 0.0.0.0 | **oui** | agents DC, ELK, application |
| otelcol-contrib | 4318 | HTTP OTLP | 0.0.0.0 | **oui** | application (HTTP) |
| otelcol-contrib | 8888 | HTTP (métriques internes) | 127.0.0.1 | non | Prometheus agent (`lgtm-self`) |
| Prometheus (agent) | 9090 | HTTP | 127.0.0.1 | non | administrateur local, `lgtm-self` |
| Mimir | 9009 | HTTP (push, `/prometheus`, `/otlp`, `/alertmanager`, `/ready`) | 127.0.0.1 | non | Prometheus, otelcol, Tempo, Loki ruler, Grafana |
| Mimir | 9097 | gRPC (interne) | 127.0.0.1 | non | composants internes de Mimir |
| Mimir | 7946 | memberlist (TCP/UDP) | 127.0.0.1 (`bind_addr`) | non | anneau interne (un seul membre) |
| Loki | 3100 | HTTP (`/otlp`, `/loki/api/v1/*`, `/ready`) | 127.0.0.1 | non | otelcol, Grafana |
| Loki | 9096 | gRPC (interne) | 127.0.0.1 | non | composants internes |
| Tempo | 3200 | HTTP (API, `/ready`, `/status`) | 127.0.0.1 | non | Grafana |
| Tempo | 9095 | gRPC (interne) | 127.0.0.1 | non | composants internes |
| Tempo | 4417 | gRPC OTLP | 127.0.0.1 | non | otelcol (exportateur `otlp/tempo`) |
| Tempo | 4418 | HTTP OTLP | 127.0.0.1 | non | non utilisé (réservé) |
| Grafana | 3000 | HTTP | 0.0.0.0 | **oui** | administrateurs, utilisateurs |
| node_exporter | 9100 | HTTP | 0.0.0.0 | oui | Prometheus agent (local) |
| sshd | 22 | SSH | 0.0.0.0 | oui | administrateurs, transfert |

> **Conflits évités :** Mimir, Loki et Tempo écoutent tous par défaut en gRPC sur **9095** ; ils sont séparés en 9097 (Mimir), 9096 (Loki) et 9095 (Tempo). Tempo reçoit l'OTLP par défaut sur 4317/4318 ; il est déplacé sur 4417/4418 pour laisser 4317/4318 à la façade.
>
> **Piège constaté en test :** sans `memberlist.bind_addr: [127.0.0.1]`, Mimir écoute sur `*:7946` ; sans `frontend.address: 127.0.0.1`, le *query-frontend* annonce l'IP de la carte réseau et les requêtes restent bloquées.

## 3. Ports d'écoute sur les autres VM

| VM | Service | Port | Adresse | Ajouté par ce projet |
|---|---|---|---|---|
| ELK | Elasticsearch | 9200 | existante | non |
| ELK | Kibana | 5601 | existante | non |
| ELK | node_exporter | 9100 | 0.0.0.0 | **oui** (phase 2) |
| ELK | otelcol-contrib (agent) | 8888 | 127.0.0.1 | **oui** (phase 3), aucun port public |
| DC | windows_exporter | 9182 | toutes (règle de pare-feu ajoutée par le MSI, `ADDLOCAL=FirewallException`) | **oui** (phase 2) |
| DC | otelcol-contrib (agent) | aucun port public | – | **oui** (phase 3) |

## 4. Schéma

```mermaid
flowchart LR
  WIN[Poste Windows]
  ADM[Admin / navigateur]
  subgraph LAB[vSwitch du lab]
    DC[DC<br/>:9182]
    ELK[ELK<br/>:9200 :5601 :9100]
    OBS[obs-lgtm<br/>:4317 :4318 :3000 :9100 :22]
  end
  WIN -- 22 SSH --> OBS
  WIN -- 22 SSH --> ELK
  ADM -- 3000 HTTP --> OBS
  ADM -- 5601 --> ELK
  DC -- 4317 OTLP --> OBS
  ELK -- 4317 OTLP --> OBS
  OBS -- 9182 --> DC
  OBS -- 9100 --> ELK
  OBS -- 9200 HTTPS --> ELK
```

## 5. Filtrage recommandé (non inclus dans le runbook, non testé)

Debian 13 netinst installe `nftables`. Pour limiter obs-lgtm aux seuls flux ci-dessus, un jeu de règles minimal serait le suivant (à adapter, et à tester après un checkpoint Hyper-V, voir [GUARDRAILS.md](GUARDRAILS.md)) :

```bash
# /etc/nftables.conf (exemple, non testé) - obs-lgtm
cat > /etc/nftables.conf <<'EOF2'
#!/usr/sbin/nft -f
flush ruleset
table inet filter {
  chain input {
    type filter hook input priority 0; policy drop;
    iif lo accept
    ct state established,related accept
    ip protocol icmp accept
    tcp dport 22 accept
    tcp dport { 3000, 4317, 4318 } accept
    tcp dport 9100 ip saddr 127.0.0.1 accept
  }
}
EOF2
nft -c -f /etc/nftables.conf && systemctl enable --now nftables
```

`nft -c` vérifie la syntaxe sans appliquer. Garde une console Hyper-V ouverte : une erreur sur le port 22 coupe la session SSH.
