# Garde-fous – Lab LGTM hors ligne (Debian 13, Hyper-V)

> Règles **obligatoires** pour toute intervention sur obs-lgtm, la VM ELK, le DC ou l'hôte Hyper-V dans le cadre du projet LGTM. Elles complètent `../Runbook_LGTM_Offline_Debian13.md` (procédures) et [06_Securite.md](06_Securite.md) (mesures de sécurité). En cas de conflit, le garde-fou l'emporte : on s'arrête et on corrige la procédure.

## 1. Hors ligne uniquement

- Les VM Debian 13 **n'accèdent jamais à Internet** : pas de `apt update` vers un miroir externe, pas de `wget`/`curl` vers l'extérieur, pas de `grafana cli plugins install`, pas de `curl … | sh`.
- **Seul le poste Windows télécharge**, avec `Telecharger-LGTM.ps1` et les versions épinglées. Il ne vérifie ni n'installe rien.
- Tout fichier qui entre dans une VM passe par le lot hors ligne (manifeste + archive + `scp`) et par `verifier-lgtm.sh`.
- Grafana garde son drop-in `offline.conf` (aucun appel sortant) ; Mimir et Loki gardent `usage_stats` / `analytics` désactivés.

## 2. Pas de Docker

- Aucun moteur de conteneurs (Docker, Podman, containerd) sur les VM du lab.
- Uniquement des paquets `.deb` officiels ou des archives binaires officielles, lancés en **services systemd** (ADR-001).

## 3. Vérification avant toute installation

Aucun `dpkg -i`, aucune copie de binaire dans `/usr/local/bin`, aucune installation de MSI tant que **toutes** les vérifications ne sont pas au vert :

| Contrôle | Commande | Attendu |
|---|---|---|
| Manifeste du transfert | `sha256sum -c --strict MANIFEST-SHA256.txt` (fait par `verifier-lgtm.sh`) | toutes les lignes `OK` |
| Empreintes publiées | `sha256sum -c` sur `SHA256SUMS`, `sha256sums.txt`, `*.sha256`, `*-sha-256` | `OK` |
| Index APT Grafana signé | `sqv --keyring gpg-full.key --output /tmp/InRelease.verifie InRelease` puis comparaison des SHA-256 de `Packages.gz` | signature valide (empreinte `B53AE77BADB630A683046005963FA27710458545`) et empreintes identiques |
| Empreintes attendues du runbook | `sha256sum -c --strict lgtm-sha256-attendus` | `OK` |
| ISO Debian | `sqv` sur `SHA256SUMS.sign` (clé `DF9B9C49EAA9298432589D76DA87E80D6294BE9B`) puis `sha256sum -c` | signature valide et `OK` |
| MSI sur le DC | `Get-FileHash -Algorithm SHA256` | égal à la valeur de `lgtm-sha256-attendus` |

Une seule erreur = **arrêt**. On ne contourne pas (`--force`, `--ignore`, édition du fichier d'empreintes) : on retélécharge le fichier depuis le poste Windows.

## 4. Checkpoint Hyper-V avant chaque changement

Avant **toute** modification (paquet, configuration, unité systemd, ressources de VM, règle de pare-feu) :

```powershell
# PowerShell en administrateur, sur l'hôte Hyper-V
$vm = "obs-lgtm"     # ou "ELK", "DC"
Checkpoint-VM -Name $vm -SnapshotName "avant-<objet>-$(Get-Date -Format yyyyMMdd-HHmm)"
Get-VMSnapshot -VMName $vm | Sort-Object CreationTime | Select-Object -Last 3 Name, CreationTime
```

- Les checkpoints automatiques sont désactivés sur obs-lgtm (`AutomaticCheckpointsEnabled $false`) : le checkpoint est **manuel et explicite**.
- Un checkpoint n'est pas une sauvegarde : il dépend du disque de la VM. Garder au plus 3 à 5 checkpoints par VM et faire un `Export-VM` hebdomadaire (voir [08_Exploitation_supervision.md](08_Exploitation_supervision.md)).

## 5. Secrets

- **Aucun secret** dans un fichier versionné, un dépôt git, une capture d'écran, un ticket, un courriel, un document de ce dossier ou le journal des changements.
- Les clés API Elasticsearch sont saisies **sans écho** (`read -rsp`) et stockées uniquement dans :
  - `/etc/otelcol-contrib/otelcol-contrib.conf` (`root:root`, `0600`) sous la forme `ES_OTEL_API_KEY=` suivi de la valeur (jamais recopiée ailleurs) ;
  - `/etc/grafana/es-grafana-apikey` (`root:grafana`, `0640`).
- **Masquage** : dans toute trace écrite, la variable apparaît sans valeur, `ES_OTEL_API_KEY=`. Ne jamais lancer `cat`, `systemctl show -p Environment`, `env` ou `ps e` sur un service qui porte une clé quand l'écran est partagé ou enregistré.
- Pour vérifier qu'une clé est présente : `grep -c '^ES_OTEL_API_KEY=' /etc/otelcol-contrib/otelcol-contrib.conf` (renvoie un nombre, jamais la valeur).
- Clés API ES : **`"expiration": "90d"`** obligatoire, rôle limité (**moindre privilège**) :
  - écriture (otelcol) : `monitor` + `auto_configure`, `create_doc` sur `logs-*` ;
  - lecture (Grafana) : `read`, `view_index_metadata` sur `logs-*` ;
  - jamais de clé `superuser`, jamais la clé ou le mot de passe du compte `elastic`.
- Les sauvegardes de configuration **excluent** les fichiers de secrets (commande au §3 de [08_Exploitation_supervision.md](08_Exploitation_supervision.md)).
- Mot de passe Grafana `admin` changé à la première connexion ; il n'est écrit nulle part.

## 6. Limites mémoire et disque

Chaque service porte une limite ; on ne la supprime pas pour « régler » un problème :

| Service | `MemoryHigh` | `MemoryMax` | `GOMEMLIMIT` | Autre |
|---|---|---|---|---|
| `mimir` | 690M | 768M | 600MiB | `max_global_series_per_user: 150000`, `ingestion_rate: 20000` |
| `loki` | 460M | 512M | 400MiB | – |
| `tempo` | 460M | 512M | 400MiB | – |
| `otelcol-contrib` (obs-lgtm) | 345M | 384M | 300MiB | `memory_limiter` 300 / 60 MiB, **en premier processeur** |
| `prometheus` (agent) | 230M | 256M | 200MiB | – |
| `grafana-server` | 460M | 512M | 400MiB | – |
| `node_exporter` | – | 64M | – | – |
| `otelcol-contrib` (ELK) | 288M | 320M | 256MiB | `memory_limiter` 200 / 40 MiB |
| `otelcol-contrib` (DC) | – | – | 200MiB | `memory_limiter` 200 / 40 MiB |

Disque et rétention (plafonds) :

| Données | Plafond |
|---|---|
| Mimir | 7 jours (`compactor_blocks_retention_period: 7d`) |
| Loki | 72 h (`retention_period: 72h`, `retention_enabled: true`) |
| Tempo | 24 h (`overrides.defaults.compaction.block_retention: 24h`) |
| Journal systemd | `SystemMaxUse=500M` |
| Disque obs-lgtm | 60 Go ; alerte manuelle si `/` dépasse 80 % (`df -h /`) |

Toute hausse d'une limite ou d'une rétention se justifie dans le journal des changements (mesure `systemd-cgtop -m` ou `du -sh` à l'appui), et reste compatible avec le budget de la VM ([05_Dimensionnement_infra.md](05_Dimensionnement_infra.md)).

## 7. Valider avant de redémarrer

Aucun `systemctl restart` ou `reload` sans validation réussie de la configuration **avec le binaire installé**. Les commandes Mimir, mimirtool, Loki, Tempo, promtool et otelcol-contrib ont été testées le 28 oct. 2026 : elles renvoient un code non nul sur une clé inconnue ou une erreur de syntaxe.

| Outil | Commande de validation |
|---|---|
| Mimir | `mimir --config.file=/etc/mimir/config.yml -print.config >/dev/null` |
| Alertmanager de Mimir | `mimirtool alertmanager verify /etc/mimir/alertmanager-fallback.yml` (ou le fichier à charger) |
| Règles Mimir | `mimirtool rules lint <fichier>` |
| Loki | `loki -config.file=/etc/loki/config.yml -verify-config` |
| Tempo | `tempo -config.file=/etc/tempo/config.yml -config.verify=true` |
| Prometheus (agent) | `promtool check config --agent /etc/prometheus/prometheus.yml` |
| otelcol-contrib | `otelcol-contrib validate --config=/etc/otelcol-contrib/config.yaml` |
| otelcol-contrib (DC) | `& "<chemin>\otelcol-contrib.exe" validate --config="<chemin>\config.yaml"` (non testé hors Windows) |
| Grafana | pas de validateur : `systemctl restart grafana-server` puis `journalctl -u grafana-server -n 50 --no-pager` et `wget -qO- http://127.0.0.1:3000/api/health` |
| Unités systemd | `systemd-analyze verify /etc/systemd/system/<unité>.service` puis `systemctl daemon-reload` (non testé : l'environnement de test n'avait pas systemd) |
| nftables (si utilisé) | `nft -c -f /etc/nftables.conf` (non testé) |

Après le redémarrage : `systemctl is-active <service>`, `journalctl -u <service> -n 50 --no-pager`, et le contrôle de santé du service ([08_Exploitation_supervision.md](08_Exploitation_supervision.md), §1).

## 8. Procédure de retour arrière

Du plus léger au plus lourd ; s'arrêter au premier niveau qui rétablit le service :

| Niveau | Quand | Action |
|---|---|---|
| 1. Configuration | une modification de fichier casse un service | restaurer la copie `fichier.AAAAMMJJ-HHMM` faite avant la modification (voir §10), valider (§7), redémarrer |
| 2. Service | un composant pose problème | `systemctl disable --now <service>` ; la façade continue pour les autres signaux |
| 3. Routage Strangler Fig | la nouvelle destination est en défaut | retirer l'exportateur du pipeline d'otelcol, `otelcol-contrib validate`, redémarrer ; ELK reste la référence jusqu'à la phase 6 |
| 4. Paquet | une mise à jour échoue | `dpkg -i` de l'ancien `.deb` conservé dans `/opt/lgtm-bundle` (vérifié), valider, redémarrer |
| 5. VM | état incertain ou plusieurs composants touchés | `Restore-VMCheckpoint -VMName <vm> -Name <checkpoint> -Confirm:$false`, puis `Start-VM` |
| 6. Projet | abandon | runbook §7 (désinstallation), révocation des clés API ES, `Start-VM AppDynamics` si nécessaire |

Après tout retour arrière : noter la cause et le niveau utilisé dans le journal des changements.

## 9. À ne jamais faire

| Interdit | Pourquoi |
|---|---|
| `elastalert-create-index --recreate` (ou supprimer les index `elastalert_status*`) | supprime les index de suivi d'ElastAlert 2 : historique, silences et état des règles perdus |
| Exposer Elasticsearch (mono-nœud) hors du vSwitch du lab (NAT, redirection de port, `network.host` public) | un seul nœud, aucune redondance ; données et API d'administration exposées |
| Installer Docker, Podman ou une image de conteneur | contraire à ADR-001 |
| `apt update` / `apt install` vers Internet, `curl … \| sh`, `grafana cli plugins install` | contraire au mode hors ligne ; contenu non vérifié |
| Installer un fichier dont une vérification a échoué, ou modifier `lgtm-sha256-attendus` pour « faire passer » un fichier | casse la chaîne de confiance |
| `dpkg --force-all`, `--force-depends` | dépendances incohérentes, retour arrière difficile |
| Afficher, copier ou capturer la valeur d'une clé API ; la mettre dans un YAML, un ticket ou git | fuite de secret |
| Créer une clé API ES sans expiration ou avec le rôle `superuser` | moindre privilège, durée de vie limitée |
| Retirer `memory_limiter` d'otelcol, ou le placer après `batch` | risque d'OOM et de perte de toutes les données en mémoire |
| Supprimer `MemoryMax` / `GOMEMLIMIT` d'un service | un service peut affamer toute la VM |
| Redémarrer un service sans validation de sa configuration | panne évitable |
| Supprimer `/var/lib/mimir`, `/var/lib/loki` ou `/var/tempo` service démarré | corruption des blocs et du WAL |
| Passer `memberlist`, gRPC ou HTTP de Mimir, Loki, Tempo sur `0.0.0.0` | ces API n'ont pas d'authentification (`multitenancy_enabled: false`) |
| Activer `multitenancy_enabled` sans mettre à jour Prometheus, otelcol, Tempo, Loki et Grafana | toutes les écritures et lectures échouent (en-tête `X-Scope-OrgID` manquant) |
| Retirer l'exportateur `elasticsearch` avant la fin des critères de la phase 3 | perte de la comparaison et du retour arrière |
| Changer plusieurs composants dans le même changement | impossible d'identifier la cause d'une panne |

## 10. Journal des changements

Chaque changement ajoute une ligne **avant** l'intervention (statut « prévu ») et la complète **après** (statut « fait » ou « annulé »). Emplacement conseillé : `/var/log/lgtm-changements.md` sur obs-lgtm (copie dans le dossier du lab). **Aucun secret** : écrire `ES_OTEL_API_KEY=` sans valeur.

| Date (heure de Toronto) | Auteur | VM | Composant | Changement | Checkpoint | Validation | Résultat | Retour arrière |
|---|---|---|---|---|---|---|---|---|
| 2026-10-28 15:00 (exemple) | Karim | obs-lgtm | loki | `retention_period` 72h → 96h | `avant-loki-retention-20261028-1500` | `loki -verify-config` OK | fait | niveau 1 si disque > 80 % |
| AAAA-MM-JJ HH:MM | | | | | | | prévu / fait / annulé | |

Copie de sécurité d'un fichier avant modification :

```bash
f=/etc/loki/config.yml; cp -a "$f" "$f.$(date +%Y%m%d-%H%M)"
```

## 11. Liste de contrôle avant changement

- [ ] Le changement est décrit dans le journal (§10), avec un seul composant.
- [ ] Les notes de version (pour une mise à jour) ont été lues.
- [ ] Les nouveaux fichiers viennent du lot hors ligne et `verifier-lgtm.sh` (ou l'équivalent) est au vert (§3).
- [ ] Checkpoint Hyper-V pris pour chaque VM touchée (§4).
- [ ] Copie de sécurité du fichier modifié (§10).
- [ ] Aucun secret dans les fichiers, commandes, captures ou notes (§5).
- [ ] Les limites mémoire et les rétentions restent dans le budget (§6).
- [ ] La validation de la configuration a réussi (§7).
- [ ] Le niveau de retour arrière est identifié (§8).
- [ ] Le changement ne figure pas dans la liste des interdits (§9).
- [ ] Après le changement : `systemctl is-active`, journal du service, contrôles de santé, `up` dans Mimir.
