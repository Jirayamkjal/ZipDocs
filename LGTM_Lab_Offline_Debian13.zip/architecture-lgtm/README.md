# Lab LGTM hors ligne – Debian 13 sur Hyper-V

## Objet

Ce dossier décrit l'architecture et l'exploitation de la pile d'observabilité **LGTM** du lab :

- **L**oki pour les journaux, **G**rafana pour la consultation, **T**empo pour les traces, **M**imir pour les métriques ;
- avec **OpenTelemetry Collector contrib** comme façade d'ingestion et **Prometheus en mode agent** pour la collecte des exporteurs ;
- installée sur une VM **Debian 13 sans accès Internet**, en **services systemd natifs** (pas de Docker) ;
- pour remplacer progressivement ELK et AppDynamics selon le plan **Strangler Fig** du lab.

La procédure pas à pas est dans le runbook ; ce dossier explique **pourquoi** et **comment exploiter**.

## Carte des documents

| Document | Pour qui / quand |
|---|---|
| [`../Runbook_LGTM_Offline_Debian13.md`](../Runbook_LGTM_Offline_Debian13.md) (+ `.docx`, schémas dans `../lgtm-diagrams/`) | **Procédure de référence** : téléchargement (Windows), vérification et installation (Linux), restructuration Hyper-V, agents, dépannage, sources, points non vérifiés |
| [GUARDRAILS.md](GUARDRAILS.md) | **À lire avant toute intervention** : règles obligatoires et liste de contrôle |
| [00_README.md](00_README.md) | Index numéroté du dossier |
| `diagrammes/` | Rendus PNG des schémas Mermaid de ce dossier (générés avec mermaid-cli) |
| [01_Vue_ensemble_architecture.md](01_Vue_ensemble_architecture.md) | Contexte, composants, vues logique et physique |
| [02_Flux_de_donnees.md](02_Flux_de_donnees.md) | Pipelines, routage OTel, double écriture ELK / Loki, séquences |
| [03_Matrice_reseau_ports.md](03_Matrice_reseau_ports.md) | Flux réseau et ports |
| [04_Decisions_architecture_ADR.md](04_Decisions_architecture_ADR.md) | Décisions d'architecture (ADR) |
| [05_Dimensionnement_infra.md](05_Dimensionnement_infra.md) | Dimensionnement des VM et des services |
| [06_Securite.md](06_Securite.md) | Sécurité : comptes, permissions, TLS, clés API |
| [07_Plan_migration_Strangler_Fig.md](07_Plan_migration_Strangler_Fig.md) | Phases, critères, retour arrière |
| [08_Exploitation_supervision.md](08_Exploitation_supervision.md) | Santé, sauvegardes, mises à jour hors ligne |
| [`../Plan_integration_observabilite_lab.md`](../Plan_integration_observabilite_lab.md) | Plan d'origine (non modifié ; les écarts sont justifiés au §3.2 du runbook) |

## Prérequis

| Élément | Exigence |
|---|---|
| Hôte Hyper-V | Windows avec le rôle Hyper-V ; **16 Go de RAM recommandés** (8 à 12 Go possibles avec les réserves de [05](05_Dimensionnement_infra.md)) ; au moins 4 processeurs logiques ; ≈ 60 Go libres pour obs-lgtm |
| Poste Windows connecté | PowerShell 5.1 ou 7, `curl.exe` et `tar.exe` (fournis avec Windows 10 1809+ / 11), client OpenSSH ; ≈ 3 Go libres (lot, ISO, archive) |
| VM existantes | DC (Windows Server, AD DS, DNS) ; ELK sous Debian 13 avec Elasticsearch 9 sécurisé (TLS sur 9200, CA HTTP disponible) et Kibana |
| Réseau | vSwitch du lab joignable entre les VM ; SSH (22) du poste Windows vers les VM Linux |
| Droits | administrateur Hyper-V, `sudo` sur les VM Linux, administrateur local sur le DC, compte Kibana pouvant créer des clés API |
| Outils Linux | présents sur Debian 13 netinst : `sqv`, `sha256sum`, `wget`, `tar`, `systemd` (`curl` est absent) |

## Démarrage rapide (ordre d'exécution)

1. Lire [GUARDRAILS.md](GUARDRAILS.md).
2. **Phase 0** : checkpoints de toutes les VM, AppDynamics éteinte (runbook §3.4).
3. **Téléchargement** sur le poste Windows : `Telecharger-LGTM.ps1` → manifeste → archive `lgtm-bundle-<date>.tar` (runbook §2.4–2.6).
4. **Restructuration Hyper-V** : ressources DC et ELK, création d'obs-lgtm (génération 2, 2 vCPU, 4 Go, 60 Go) ; vérification de l'ISO Debian 13.7 sur la VM ELK, puis installation de Debian sans miroir (runbook §3).
5. **Transfert et vérification** du lot sur obs-lgtm avec `verifier-lgtm.sh` (runbook §2.7–2.8). Arrêt à la première erreur.
6. **Installation** sur obs-lgtm : `dpkg -i`, arrêt des services démarrés par les `postinst`, configurations validées, limites mémoire, démarrage ordonné, contrôles (runbook §4.1–4.10).
7. **Test de bout en bout** OTLP → Mimir, Loki, Tempo, et règles d'alerte (runbook §4.11), puis checkpoint.
8. **Agents** : node_exporter et otelcol-contrib sur ELK, windows_exporter et otelcol-contrib sur le DC (runbook §5).
9. **Migration** phase par phase ([07](07_Plan_migration_Strangler_Fig.md)).

## Conventions

- **Langue** : français ; noms de commandes, fichiers et paramètres en anglais tels que les outils les attendent.
- **Espaces réservés** : `<ip-dc>`, `<ip-elk>`, `<ip-obs-lgtm>`, `<vSwitch du lab>`, `<V>` (version). `elk.lab.local` est un **exemple** de nom présent dans le certificat d'Elasticsearch.
- **Invites** : blocs `powershell` sur l'hôte ou le poste Windows (administrateur), blocs `bash` en `root` sur la VM indiquée.
- **Fichiers créés dans les VM** : heredoc avec le délimiteur `EOF2`, première ligne de commentaire = chemin du fichier.
- **Secrets** : jamais écrits ; la variable apparaît masquée, `ES_OTEL_API_KEY=`.
- **Statut des informations** : « vérifié » = constaté le 28 oct. 2026 (API, page officielle ou test) ; « non testé » / « à vérifier » = signalé comme tel, et listé dans l'annexe A du runbook.
- **Heures** : heure de Toronto (America/Toronto) dans le journal des changements.
- **Unités** : `M` / `MiB` comme dans systemd et Go ; Go / Mo dans le texte.

## Versions épinglées (vérifiées le 28 oct. 2026)

| Composant | Version | Artefact |
|---|---|---|
| Grafana OSS | **13.2.4** (build 38252365904) | `grafana_13.2.4_38252365904_linux_amd64.deb` |
| Grafana Mimir + mimirtool | **3.2.3** | `mimir-3.2.3_amd64.deb`, `mimirtool_3.2.3_amd64.deb` |
| Grafana Loki | **3.7.9** | `loki_3.7.9_amd64.deb` |
| Grafana Tempo | **3.1.1** | `tempo_3.1.1_linux_amd64.deb` |
| Prometheus (mode agent) | **3.15.1** | `prometheus-3.15.1.linux-amd64.tar.gz` |
| node_exporter | **1.12.1** | `node_exporter-1.12.1.linux-amd64.tar.gz` |
| OpenTelemetry Collector contrib | **0.164.0** | `otelcol-contrib_0.164.0_linux_amd64.deb`, `otelcol-contrib_0.164.0_windows_x64.msi` |
| windows_exporter | **0.32.0** | `windows_exporter-0.32.0-amd64.msi` |
| Debian | **13.7.0** netinst | `debian-13.7.0-amd64-netinst.iso` |
| adduser (Debian) | **3.152** | `adduser_3.152_all.deb` (secours) |

Non retenus : Grafana 13.3.0 (absent de l'index APT signé le 28 oct. 2026), Grafana Alloy 1.21.2 (doublon avec otelcol-contrib, [ADR-004](04_Decisions_architecture_ADR.md#adr-004)), Alertmanager autonome ([ADR-005](04_Decisions_architecture_ADR.md#adr-005)).
