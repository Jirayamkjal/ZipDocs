# 00 – Index du dossier d'architecture LGTM

Dossier d'architecture de la pile **LGTM** (Loki, Grafana, Tempo, Mimir) du lab Hyper-V, installée **hors ligne** sur Debian 13 en services **systemd** (sans Docker). Présentation générale, prérequis et ordre de lecture : [README.md](README.md).

| # | Document | Contenu |
|---|---|---|
| – | [README.md](README.md) | Objet, carte des documents, prérequis, démarrage rapide, conventions, versions épinglées |
| – | [GUARDRAILS.md](GUARDRAILS.md) | Garde-fous obligatoires : hors ligne, sans Docker, vérifications, checkpoints, secrets, limites, validation, retour arrière, interdits, liste de contrôle |
| 01 | [01_Vue_ensemble_architecture.md](01_Vue_ensemble_architecture.md) | Contexte, composants, vues logique et physique (Mermaid), organisation sur obs-lgtm |
| 02 | [02_Flux_de_donnees.md](02_Flux_de_donnees.md) | Pipelines par signal, routage OTel, double écriture ELK / Loki, diagrammes de séquence |
| 03 | [03_Matrice_reseau_ports.md](03_Matrice_reseau_ports.md) | Tous les flux (source, destination, port, protocole, objet), ports d'écoute, filtrage |
| 04 | [04_Decisions_architecture_ADR.md](04_Decisions_architecture_ADR.md) | ADR-001 à ADR-008 : systemd natif, hors ligne, Mimir monolithique, Prometheus agent vs Alloy, Alertmanager intégré, Strangler Fig, rétention, versions |
| 05 | [05_Dimensionnement_infra.md](05_Dimensionnement_infra.md) | vCPU, RAM et disque par VM, budget de l'hôte, limites mémoire par service |
| 06 | [06_Securite.md](06_Securite.md) | Utilisateurs, permissions, TLS, clés API (90 jours, moindre privilège), chaîne d'approvisionnement |
| 07 | [07_Plan_migration_Strangler_Fig.md](07_Plan_migration_Strangler_Fig.md) | Phases 0 à 6, critères de passage, retour arrière |
| 08 | [08_Exploitation_supervision.md](08_Exploitation_supervision.md) | Contrôles de santé, auto-supervision, sauvegardes, mises à jour hors ligne |

Documents du dossier parent :

- [`../Runbook_LGTM_Offline_Debian13.md`](../Runbook_LGTM_Offline_Debian13.md) (et `.docx`) : **procédure de référence** (téléchargement Windows, restructuration Hyper-V, installation, agents, dépannage, sources, points non vérifiés).
- [`../Plan_integration_observabilite_lab.md`](../Plan_integration_observabilite_lab.md) : plan d'intégration Strangler Fig d'origine (non modifié).

État : rédigé le 28 oct. 2026. Les composants ont été testés en lançant les binaires directement sur un environnement de test Linux ; l'installation complète sur Hyper-V / Debian 13 sous systemd reste à jouer (annexe A du runbook).
